import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  siteLogo: string = 'assets/imgs/logo125.png';
  currentyear:any;
  constructor() { }

  ngOnInit() {
    let d = new Date();
    this.currentyear=d.getFullYear();
  }

}
