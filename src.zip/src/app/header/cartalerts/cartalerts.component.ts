import { Component, OnInit, Input, HostListener, TemplateRef, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { AuthService } from '../../services/auth.service';
import { JwtService } from '../../services/jwt.service';
import { ApiService } from '../../services/api.service';
import { Http, RequestOptions, Response, Headers } from '@angular/http';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Observable } from 'rxjs/Rx';
import { error } from 'selenium-webdriver';

@Component({
  selector: 'app-cartalerts',
  templateUrl: './cartalerts.component.html',
  styleUrls: ['./cartalerts.component.css']
})
export class CartalertsComponent implements OnInit {
  modalRef: BsModalRef;inplaycartcolor:any="blue_circle.png";
  sub: any;clbid: any;alertsdetailsdata: any = [];hzalertsdetailsdata:any=[];prvcart: any;prvrdcount:any=0;popmodshow: boolean = false;
  @ViewChild('template') template: TemplateRef<any>;
  constructor(private router: Router,
    private title: Title,
    private authService: AuthService,
    private jwt: JwtService,
    private api: ApiService,
    private modalService: BsModalService,
    private spinnerService: Ng4LoadingSpinnerService) { }

  ngOnInit() {
    this.sub = Observable.interval(1000 * 60).subscribe(x => {
      this.clbid = localStorage.getItem('clubId');
      let uid=localStorage.getItem('userId');
      if (uid != '' && uid != undefined && uid != null) {
        if (this.clbid != '' && this.clbid != undefined && this.clbid != null) {
          var alertmodelinfo = {
            "clubid": parseInt(this.clbid)
          }
          this.api.postOH('GetAlerts', alertmodelinfo).subscribe(
            (response) => {
              //console.log(response);
              this.alertsdetailsdata = [];
              this.hzalertsdetailsdata=[];
              this.prvcart = '';
              if (response.GetAlertsResult.length > 0) {
                if (this.prvrdcount != response.GetAlertsResult.length) {
                  this.prvrdcount = response.GetAlertsResult.length;
                  this.popmodshow = false;
                  if (this.modalRef != undefined) {
                    this.modalRef.hide();
                  }
                }
                let incval = 1;
                let hzincval= 1;
                for (let i = 0; i < response.GetAlertsResult.length; i++) {
                  if (response.GetAlertsResult[i].AlertType != 'MSG') {
                    if (response.GetAlertsResult[i].clubid == this.clbid) {
                      // if (this.prvcart != response.GetAlertsResult[i].cartid) {
                      //   this.alertsdetailsdata.push({
                      //     "cartname": incval + ". " + response.GetAlertsResult[i].carname
                      //   });
                      //   incval++;
                      // }
                      // this.prvcart = response.GetAlertsResult[i].cartid;
                      if (response.GetAlertsResult[i].AlertType == 'GC') {
                        this.alertsdetailsdata.push({
                          // "cartname": incval + ". " + response.GetAlertsResult[i].carname
                          "cartname": response.GetAlertsResult[i].carname
                        });
                        incval++;
                      } else if (response.GetAlertsResult[i].AlertType == 'HZ') {
                        this.hzalertsdetailsdata.push({
                          "cartname": hzincval + ". " + response.GetAlertsResult[i].carname
                        });
                        hzincval++;
                      }
                    }
                  }
                }
                if (this.popmodshow == false) {
                  this.popmodshow = true;
                  this.modalRef = this.modalService.show(this.template, { class: 'modal-sm' });
                }

              } else {
                if (this.modalRef != undefined) {
                  this.modalRef.hide();
                }
                this.popmodshow = false;
              }
            }, error => {
            }
          );
        }
      }
    });
  }

  confirm(): void {
    var alertinfo = {
      "clubid": this.clbid,
      "alertid": 0
    }
    this.api.postOH('SaveAlertStatus', alertinfo).subscribe(
      (response) => {
        if (response.SaveAlertStatusResult == "Success") {

        }
      }, error => {
        console.log(error);
      });
    this.modalRef.hide();
    this.popmodshow = false;
  }

  decline(): void {
    this.modalRef.hide();
    this.popmodshow = false;
  }

}
