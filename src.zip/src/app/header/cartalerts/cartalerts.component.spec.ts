import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CartalertsComponent } from './cartalerts.component';

describe('CartalertsComponent', () => {
  let component: CartalertsComponent;
  let fixture: ComponentFixture<CartalertsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CartalertsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CartalertsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
