import { Component, OnInit, ViewContainerRef, TemplateRef, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';
import { JwtService } from '../../services/jwt.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-sidemenubind',
  templateUrl: './sidemenubind.component.html',
  styleUrls: ['./sidemenubind.component.css']
})
export class SidemenubindComponent implements OnInit {

  userloginid: any; 
  sidemenuMainModInfo: any; sidemenuSubModInfo: any;

  showsubMenu : boolean = true;
  view:boolean;
  viewshow:boolean=false;
  viewhide:boolean=true;
  GridMessage: any;assigendmodules:any=[];
  count: any = 0; uniquemainitem: any = 0; submodstartingid: any = 0;
  nineholecourse: boolean = false; reachpermission: boolean = false;

  constructor(private router: Router, private jwt: JwtService, private authService: AuthService, 
    public toastr: ToastsManager, private modalService: BsModalService, vcr: ViewContainerRef, 
    public api: ApiService,private spinnerService: Ng4LoadingSpinnerService) 
    { 
      this.sidemenuMainModInfo = []; this.sidemenuSubModInfo = [];
      this.userloginid = localStorage.getItem('userId');
    }

  ngOnInit() {
    this.authService.getUserName.subscribe(
      (name: string) => {
        if (name === undefined || name === '' || name === null) {
          
        } else {
          this.usersubmenumodules(name);
        }
      })
      this.usersubmenumodules(this.userloginid);
  }

  usersubmenumodules(userid) {
    this.nineholecourse = localStorage.getItem('nineholecourse') == 'Y' ? true : false;
    let parameters = { 'userID': userid };
    this.api.postOH('getsidemenunavigation', parameters).subscribe(
      (response) => {
        if (response.length > 0) {
          if (response[0].ResponseCode == "Success") {
            this.reachpermission = localStorage.getItem('Reachpermission') == 'Y' ? true : false;
            this.sidemenuMainModInfo = response[0].mainPrevilige;
            this.sidemenuSubModInfo = response[0].subprevilige;
          //  if(this.nineholecourse){
          //   this.sidemenuSubModInfo.push({
          //     'sub_createduser_id': 1,
          //     "sub_moduleicon": "calender.PNG",
          //     "sub_modulename": "Schedule Course",
          //     "sub_pagename": "clubmanagement/schedulecourse",
          //     "sub_sm_id": 0,
          //     "sub_sm_mainmoduleid": 1,
          //     "sub_sm_mod_status": "Y",
          //     "sub_sm_mod_ts": null,
          //     "sub_sm_submoduleid": 21,
          //   })
          //  }
          
            this.assigendmodules=[];
            for (var i = 0; i < this.sidemenuSubModInfo.length; i++) {
              this.assigendmodules.push({
                "pagename":this.sidemenuSubModInfo[i].sub_pagename,
                "ModuleName":this.sidemenuSubModInfo[i].sub_modulename
              })
             }
             localStorage["assigendsubmodules"]=JSON.stringify(this.assigendmodules);
          }
        }
      },error => {
        
      }
    );
  }
  schedulecourse() {
    this.router.navigate(['/clubmanagement/schedulecourse']);
  }
  logout(){
    localStorage.removeItem('clubId');
    localStorage.removeItem('clubname');
    localStorage.removeItem('clubcode');    
    localStorage.removeItem('courseId');
    localStorage.removeItem('holeId');
    localStorage.removeItem('cartId');
    localStorage.removeItem('userName');
    localStorage.removeItem('userId');
    localStorage.removeItem('userImage');
    localStorage.removeItem('mainmoduleid');
    localStorage.removeItem('roleCode');
    localStorage.removeItem('currentroot');
    localStorage.removeItem("nineholecourse");
    localStorage.removeItem("Reachpermission");
    localStorage.removeItem('ReachuserId');
    localStorage.clear();
    this.authService.getClubIdforheader();
    this.router.navigate(['/login']);    
  }

  godashboard(){
    this.router.navigate(['/cartmanagement/dashboard']);
  }

  goToMessage()
  {
    this.router.navigate(['/messages/messages']);
  }

  gotoAlerts()
  {
    this.router.navigate(['/messages/alerts']);
  }

}
