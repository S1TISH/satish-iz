import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SidemenubindComponent } from './sidemenubind.component';

describe('SidemenubindComponent', () => {
  let component: SidemenubindComponent;
  let fixture: ComponentFixture<SidemenubindComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SidemenubindComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SidemenubindComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
