import { Component, OnInit, Input, HostListener, TemplateRef, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { AuthService } from '../../services/auth.service';
import { JwtService } from '../../services/jwt.service';
import { ApiService } from '../../services/api.service';
import { Http, RequestOptions, Response, Headers } from '@angular/http';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Observable } from 'rxjs/Rx';
import { error } from 'selenium-webdriver';
import * as moment from "moment";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  modalRef: BsModalRef;

  menuDropDownShow = false;
  showheader: boolean = true;
  userLength = true;
  userimg: any;
  siteLogo: string = 'assets/imgs/logo125.png';
  username: string;
  menuInfo: any = '';
  subMenuInfo: any = '';
  subnavinfo: any;
  faChevrn = 'fa fa-chevron-down';
  selectedMenuId = 0;
  ClubCourseIDs: any;
  clubid: any;
  modid: any;
  showmainmenu: boolean = true;
  showsubmenu: boolean = true; soursefrom: boolean = false;
  clubname: any; coursename: any;
  golfclubsdata: any = []; ddlheadgolfclub: any; golfcoursesdata: any = []; ddlheadgolfcourse: any; assigendmodules: any = [];
  // @Output() logged: EventEmitter<any> = new EventEmitter();

  sub: any; modelmessage: any; clbid: any; alertid: any; alertsdetailsdata: any = []; prvcart: any; popmodshow: boolean = false; prvrdcount: any = 0;
  hzalertsdetailsdata: any = []; currentGolfClubDateTime: any; courselat: any; courselong: any;
  timeoffset: any = '';
  @ViewChild('template') template: TemplateRef<any>;

  //alert count
  alertcount: any = '';

  //message count
  messagecount: any = 0; syncdata: boolean = false;

  //role name
  //rolename: any = '';


  constructor(
    private router: Router,
    private title: Title,
    private authService: AuthService,
    private jwt: JwtService,
    private api: ApiService,
    private modalService: BsModalService,
    private spinnerService: Ng4LoadingSpinnerService
  ) {
    this.getgolfclubs();
  }

  ngOnInit() {
    this.authService.getUserName.subscribe(
      (name: string) => {
        if (name === undefined || name === '' || name === null) {
          this.showheader = false;
        } else {
          this.enableUserProfile();
          this.loadMenu();
          this.getgolfclubs();
        }
      }
    );

    this.jwt.getUserName.subscribe(
      (name: string) => {
        if (name === undefined || name === '' || name === null) {
          this.showheader = false;
        } else {
          this.enableUserProfile();
          this.loadMenu();
        }
      }
    );

    this.authService.getClubIdForHeader.subscribe(
      (name: string) => {
        if (name === undefined || name === '' || name === null) {
          this.getgolfclubs();
        } else {
          this.ddlheadgolfclub = localStorage.getItem('clubId');
          //localStorage.removeItem('courseId');
          this.getCourse(localStorage.getItem('clubId'));
        }
      }
    );

    this.authService.getCourseIdForHeader.subscribe(
      (name: string) => {
        if (name === undefined || name === '' || name === null) {

        } else {
          this.ddlheadgolfcourse = localStorage.getItem('courseId');
        }
      }
    );

    if (this.jwt.getToken()) {
      this.enableUserProfile();
      this.loadMenu();
    } else {
      this.showheader = false;
    }
    this.authService.getAlertCount.subscribe(
      (notifications: string) => {
        if (notifications === undefined || notifications === '' || notifications === null) {

        } else {
          this.alertcount = localStorage.getItem('AlertCount');
        }
      }
    );

    this.authService.getMessageCount.subscribe(
      (messages: string) => {
        if (messages === undefined || messages === '' || messages === null) {

        } else {
          this.messagecount = localStorage.getItem('MessageCount');
        }
      }
    );

    this.sub = Observable.interval(1000 * 60).subscribe(x => {
      this.getalertCount(this.ddlheadgolfclub);
      this.getmessageCount(this.ddlheadgolfclub);
    });
    if (localStorage.getItem('clubId') === "1026") {
      //  this.syncdata=true;
      this.syncdata = false;
    }
    else {
      this.syncdata = false;
    }
  }

  enableUserProfile() {
    this.showheader = true;
    this.username = localStorage.getItem('userName');
    //this.rolename = localStorage.getItem('roleName');
    if (localStorage.getItem('userImage') != "") {
      this.userimg = "http://adminapi.izongolf.com/uploads/profile/" + localStorage.getItem('userImage');
    }
    else {
      this.userimg = "assets/imgs/noprofile.png";
    }
  }

  loadMenu() {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    if (localStorage.getItem('clubId') === undefined || localStorage.getItem('clubId') === '' || localStorage.getItem('clubId') === null) {
      this.clubid = 0;
      this.showmainmenu = true;
      this.showsubmenu = false;
      this.clubname = "";
    }
    else {
      this.clubname = localStorage.getItem('clubname') + "(" + localStorage.getItem('clubcode') + ")";
      this.clubid = localStorage.getItem('clubId');
      this.showmainmenu = false;
      this.showsubmenu = true;
    }

    let Model = {
      'userID': localStorage.getItem('userId'), 'clubid': 0, 'modid': 0
    };
    this.api.postWithDataHeaders('getnavigation', options, Model).subscribe(
      res => {
        this.menuInfo = []; this.subMenuInfo = [];
        this.menuInfo = res[0].mainPrevilige;
        this.subMenuInfo = res[0].subprevilige;
        for (var i = 0; i < this.subMenuInfo.length; i++) {
          this.assigendmodules.push({
            "pagename": this.subMenuInfo[i].PageName,
            "ModuleName": this.subMenuInfo[i].ModuleName
          })
        }
        localStorage["assigendmodules"] = JSON.stringify(this.assigendmodules);


        let modulepagename = localStorage.getItem('currentroot');
        if (modulepagename === "golfclub") {
          for (var i = 0; i < this.menuInfo.length; i++) {
            if (this.menuInfo[i].Main_PageName === modulepagename) {
              localStorage.setItem('mainmoduleid', this.menuInfo[i].Main_Mod_Id);
            }
          }
          if (localStorage.getItem('mainmoduleid') === undefined || localStorage.getItem('mainmoduleid') === '' || localStorage.getItem('mainmoduleid') === null) {
            this.modid = 0;
          }
          else {
            this.modid = localStorage.getItem('mainmoduleid');
          }
          this.authService.getClubIdforheader();
          this.clubid = localStorage.getItem('clubId');
          if (this.clubid != 0) {
            let Model = {
              'userID': localStorage.getItem('userId'), 'clubid': this.clubid, 'modid': this.modid
            };
            this.api.postWithDataHeaders('getnavigation', options, Model).subscribe(
              res => {
                this.subnavinfo = [];
                //this.menuInfo = res[0].mainPrevilige;
                // this.subMenuInfo = res[0].subprevilige;
                this.subnavinfo = res[0].subnavprevilige;
                // console.log(this.subnavinfo);
              },
              error => {
                //alert(error);
              })
          }
        }

      },
      error => {
        //alert(error);
      })
  }

  logOut(): void {
    localStorage.removeItem('clubId');
    localStorage.removeItem('clubname');
    localStorage.removeItem('clubcode');
    localStorage.removeItem('courseId');
    localStorage.removeItem('holeId');
    localStorage.removeItem('cartId');
    localStorage.removeItem('userName');
    localStorage.removeItem('userId');
    localStorage.removeItem('userImage');
    localStorage.removeItem('mainmoduleid');
    localStorage.removeItem('roleCode');
    localStorage.removeItem('currentroot');
    localStorage.removeItem("Reachpermission");
    localStorage.removeItem('ReachuserId');
    localStorage.removeItem("nineholecourse");

    localStorage.clear();
    this.authService.getClubIdforheader();
    this.router.navigate(['/login']);
    //this.logged.emit();
    this.showheader = false;
  }

  @HostListener('document:click', ['$event'])

  onDoucmentClick(event: Event) {
    this.menuDropDownShow = false;
  }

  menuDropDownS(event: any): void {
    this.menuDropDownShow = !this.menuDropDownShow;
    this.selectedMenuId = 6;
    event.stopPropagation();
  }

  openSubModule(event, menuId) {
    if (this.selectedMenuId != menuId) {
      this.selectedMenuId = menuId;
    } else {
      this.selectedMenuId = 0;
    }
    event.stopPropagation();
  }

  setTitle(title: string, modid: string) {
    //localStorage.setItem('mainmoduleid', modid);
    if (title === "Golf Club") {
      //localStorage.removeItem('clubId');
      //localStorage.removeItem('clubname');
    }
    this.menuDropDownShow = false;
    this.authService.getCall();
    this.title.setTitle("IZON - " + title);
  }

  setsubTitle(title: string) {
    this.menuDropDownShow = false;
    this.authService.getCall();
    this.title.setTitle("IZON - " + title);
  }

  GotoPageUrl(pageurl) {
    //this.spinnerService.show();
    this.menuDropDownShow = false;
    //this.authService.getCall();
    this.router.navigate(['/' + pageurl]);
  }

  gotoclub() {
    //localStorage.removeItem('clubId');
    //localStorage.removeItem('clubname');
    this.authService.getCall();
    this.router.navigate(['/cartmanagement/dashboard']);
  }

  // confirm(): void {
  //   var alertinfo = {
  //     "clubid": this.clbid,
  //     "alertid": 0
  //   }
  //   this.api.postOH('SaveAlertStatus', alertinfo).subscribe(
  //     (response) => {
  //       if (response.SaveAlertStatusResult == "Success") {

  //       }
  //     }, error => {
  //       console.log(error);
  //     });
  //   this.modalRef.hide();
  //   this.popmodshow = false;
  // }

  // decline(): void {
  //   this.modalRef.hide();
  //   this.popmodshow = false;
  // }

  // openModal(template: TemplateRef<any>) {
  //   this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  // }

  getgolfclubs() {
    this.soursefrom = false;
    if (localStorage.getItem('roleCode') == "SA") {
      let parameters = {
        searchvalue: " where GCB_STATUS='Y'"
      };
      this.api.postOH('getgolfclubaddressddl', parameters).subscribe(
        (response) => {
          this.golfclubsdata = [];
          if (response.length > 0) {
            for (let i = 0; i < response.length; i++) {
              this.golfclubsdata.push({
                "id": response[i].id,
                "name": response[i].name,
                "clubcode": response[i].clubcode
              });
            }
            if (localStorage.getItem('clubId') != '' && localStorage.getItem('clubId') != undefined && localStorage.getItem('clubId') != null) {
              this.ddlheadgolfclub = localStorage.getItem('clubId');
              this.clubname = localStorage.getItem('clubname') + "(" + localStorage.getItem('clubcode') + ")";
              this.getCourse(localStorage.getItem('clubId'));
              this.getalertCount(this.ddlheadgolfclub);
              this.getmessageCount(this.ddlheadgolfclub);
            } else {
              this.ddlheadgolfclub = response[0].id;
              this.clubname = response[0].name + "(" + response[0].clubcode + ")";
              localStorage.setItem("clubId", response[0].id);
              localStorage.setItem("clubname", response[0].name);
              this.getCourse(response[0].id);
              this.getalertCount(this.ddlheadgolfclub);
              this.getmessageCount(this.ddlheadgolfclub);
            }
          }
        }
      )
    } else {
      let parameters1 = {
        uid: localStorage.getItem('userId'), rcode: localStorage.getItem('roleCode'), expression: " where GCCA_GCCL_ID='" + localStorage.getItem('userId') + "' AND GCB_STATUS='Y' AND GCCA_STATUS='Y'"
      };
      this.api.postOH('getclubassigneddetails', parameters1).subscribe(
        (response) => {
          this.golfclubsdata = [];
          if (response.length > 0) {
            for (let i = 0; i < response.length; i++) {
              this.golfclubsdata.push({
                "id": response[i].clubid,
                "name": response[i].clubname,
                "clubcode": response[i].clubcode
              });
            }
            if (localStorage.getItem('clubId') != '' && localStorage.getItem('clubId') != undefined && localStorage.getItem('clubId') != null) {
              this.ddlheadgolfclub = localStorage.getItem('clubId');
              this.clubname = localStorage.getItem('clubname') + "(" + localStorage.getItem('clubcode') + ")";
              this.getCourse(localStorage.getItem('clubId'));
              this.getalertCount(this.ddlheadgolfclub);
              this.getmessageCount(this.ddlheadgolfclub);
            } else {
              this.ddlheadgolfclub = response[0].clubid;
              this.clubname = response[0].clubname + "(" + response[0].clubcode + ")";
              localStorage.setItem("clubId", response[0].clubid);
              localStorage.setItem("clubname", response[0].clubname);
              this.getCourse(response[0].clubid);
              this.getalertCount(this.ddlheadgolfclub);
              this.getmessageCount(this.ddlheadgolfclub);
            }
          }
        }
      )
    }
  }

  getCourse(clbid) {
    let parameters = {
      searchvalue: " WHERE GC_GCB_ID='" + clbid + "' and GC_STATUS='Y' "
    };
    this.api.postOH('getgolfcourse', parameters).subscribe(
      (response) => {
        this.golfcoursesdata = [];
        if (response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            this.golfcoursesdata.push({
              "id": response[i].id,
              "name": response[i].labelname,
              "nineholecourse":response[i].oddcourse
            });
          }
          this.coursename = response[0].labelname;
          if (localStorage.getItem('courseId') != '' && localStorage.getItem('courseId') != undefined && localStorage.getItem('courseId') != null) {
            this.ddlheadgolfcourse = localStorage.getItem('courseId');
            localStorage.setItem("nineholecourse", this.golfcoursesdata.find(x=>x.id == this.ddlheadgolfcourse).nineholecourse);

          } else {
            this.ddlheadgolfcourse = response[0].id;
            localStorage.setItem("courseId", response[0].id);
            localStorage.setItem("coursename", response[0].labelname);
            localStorage.setItem("nineholecourse", response[0].oddcourse);
          }
          if (this.soursefrom == true) {
            location.reload();
          }
        }
      }, error => {

      }
    )
  }

  dropdownClub(val) {
    if (val.target.value === "1026") {
      // this.syncdata=true;
      this.syncdata = false;
    }
    else {
      this.syncdata = false;
    }
    localStorage.setItem("clubId", val.target.value);
    localStorage.setItem("clubname", val.target.options[val.target.selectedIndex].text);
    localStorage.removeItem('courseId');
    localStorage.removeItem('playcartId');
    localStorage.removeItem("nineholecourse");
    this.soursefrom = true;
    this.getCourse(val.target.value);
  }

  dropdownCourse(val) {
    this.getmessageCount(this.ddlheadgolfclub);
    localStorage.setItem("nineholecourse", this.golfcoursesdata.find(x=>x.id == val.target.value).nineholecourse);
    localStorage.setItem("courseId", val.target.value);
    localStorage.setItem("coursename", val.target.options[val.target.selectedIndex].text);
    localStorage.removeItem('playcartId');
    location.reload();
  }

  getalertCount(clubId) {
    this.currentGolfClubDateTime = "";
    var searchexp = " WHERE GC_GCB_ID='" + this.clubid + "' and GC_STATUS='Y' "
    let parameters1 = { searchvalue: searchexp };
    this.api.postOH('getgolfcourse', parameters1).subscribe(
      response => {
        if (response.length > 0) {
          this.courselat = response[0].latitude;
          this.courselong = response[0].longitude;
          this.timeoffset = response[0].timeoffset;
          let currentDate: any = '';
          let d = new Date();
          let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
          currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
          this.currentGolfClubDateTime = moment(currentDate).format('YYYY-MM-DD');
          let parameters = {
            searchvalue: " WHERE AR_GCB_ID=" + clubId + " AND AR_VIEW_STATUS = 'N'  AND convert(date, AR_DATE)= '" + this.currentGolfClubDateTime + "'"
          };
          this.api.postOH('getalertcount', parameters).subscribe(
            (response) => {
              this.alertcount = (response.getalertcountResult > 99) ? '99+' : response.getalertcountResult;
            });
        }
      });
  }

  gotoAlerts() {
    this.router.navigate(['/messages/alerts']);
  }

  getmessageCount(clubId) {
    var date = new Date(); var dateString;
    dateString = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
    let parameters = {
      searchvalue: " WHERE M_GC_ID=" + localStorage.getItem('courseId') + " AND M_GCB_ID=" + clubId + " AND M_READ_STATUS = 'N'"
      // searchvalue: " WHERE M_GC_ID="+localStorage.getItem('courseId')+" AND M_GCB_ID=" + clubId + " AND M_READ_STATUS = 'N' AND convert(date,M_TS)='"+dateString+"'"
    };
    this.api.postOH('getmessagecount', parameters).subscribe(
      (response) => {
        //console.log(response);
        this.messagecount = (response.getmessagecountResult > 99) ? '99+' : response.getmessagecountResult;
      });
  }

  gotoMessages() {
    this.router.navigate(['/messages/messages']);
  }
  SyncData() {
    this.spinnerService.show();
    location.reload();
    this.spinnerService.hide();
  }

}
