import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// import { HeaderComponent } from './header/header.component';
// import { FooterComponent } from './footer/footer.component';
// import { SubmenuComponent } from './submenu/submenu.component';
// import { CartalertsComponent } from './cartalerts/cartalerts.component';
// import { SidemenubindComponent } from './sidemenubind/sidemenubind.component';

const routes: Routes = [  
  // {
  //   path:'',
  //   component:HeaderComponent
  // }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule, ReactiveFormsModule
  ],
  exports: [RouterModule],
  //declarations: [HeaderComponent, FooterComponent, SubmenuComponent, CartalertsComponent, SidemenubindComponent]
})
export class HeaderModule { }
