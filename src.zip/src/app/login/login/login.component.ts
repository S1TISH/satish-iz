import { Component, OnInit, Output, EventEmitter, ViewChild, TemplateRef } from '@angular/core';
import { JwtService } from '../../services/jwt.service';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { Http, RequestOptions, Response, Headers } from '@angular/http';
import { Cookie } from 'ng2-cookies/ng2-cookies';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';

import { Title } from '@angular/platform-browser';
import { PlatformLocation } from '@angular/common';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  modalRef: BsModalRef;
  @ViewChild('template') template: TemplateRef<any>;
  emailid: any; forgotpwdmsg: any; forgotpwdinmsg: boolean = false;
  model: any = {}; parameters: any; config: any; remember: any; loginshow: boolean = false; email: any = 0;
  landingUrl: string = '/login';
  constructor(private location: PlatformLocation, private title: Title,private modalService: BsModalService, private jwt: JwtService, private spinnerService: Ng4LoadingSpinnerService, private api: ApiService, private authService: AuthService, private router: Router, ) {
    //  this.parameters = {}, this.config = {};
    // this.authService.getCall();
    this.title.setTitle("IZON - Login");
    this.model.src = "";
    this.model.rememberme=false;
    location.onPopState(() => 
    {
      history.go(1);
      window.location.replace(this.landingUrl);
    });
  }

  ngOnInit() {
    let uid=localStorage.getItem('userId');
    if (uid != '' && uid != undefined && uid != null) {
      this.loginshow=false;
      this.spinnerService.show();
      this.router.navigate(['/cartmanagement/cartsview']);
    }else{
      this.loginshow=true;
      this.getLogOut();
      this.model.username = Cookie.get('userEmail');
      this.model.password = Cookie.get('userPassword');
      this.model.rememberme = Cookie.get('rememberMe');
      if(this.model.rememberme==null){
        this.model.rememberme=false;
      }
    }    
  }
  
  login() {
    this.spinnerService.show();
    //this.model.rememberme = this.remember;
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    let Model = {
      'Email': this.model.username, 'Password': this.model.password
    };
    let ModelReach = {
      'username': this.model.username, 'password': this.model.password
    };
    this.api.postWithDataHeaders('Login', options, Model).subscribe(
      res => {
        if (res.length !== 0) {
          //console.log(res);
          if (res[0].loginresult == "Success") {
            this.api.postWithDataHeadersreach('checkReachPermission', options, ModelReach).subscribe(
              response => {
                localStorage.setItem('Reachpermission', response.d.ReachPermission);
                localStorage.setItem('ReachuserId', response.d.u_id);
              })
            this.loginshow = false;
            this.jwt.setUserDetails(res);
            this.authService.getCall();
            //this.authService.getClubIdforheader();            
            this.getnavigation();
            //this.router.navigate(['/cartmanagement/dashboard']);
          } else {
            this.model.alert = "Invalid Credentials";
            this.spinnerService.hide();
          }          

          if (this.model.rememberme == true) {
            Cookie.set('userEmail', this.model.username);
            Cookie.set('userPassword', this.model.password);
            Cookie.set('rememberMe', this.model.rememberme);
          } else if (this.model.rememberme == false) {
            Cookie.deleteAll();
          }else if(this.model.rememberme == true || this.model.username != Cookie.get('userEmail') || this.model.password != Cookie.get('userPassword'))
          {
            Cookie.deleteAll();
            Cookie.set('userEmail', this.model.username);
            Cookie.set('userPassword', this.model.password);
            Cookie.set('rememberMe', this.model.rememberme);
          }
        }else{
          this.spinnerService.hide();
        }
      },
      error => {
        this.spinnerService.hide();
        //alert(error);
      })    
  }
  decline(): void {
    this.modalRef.hide();
  }
  openModal(template: TemplateRef<any>) {
    this.email = "";
    this.forgotpwdmsg = ""; this.forgotpwdinmsg = false;
    this.modalRef = this.modalService.show(template, { class: 'modal-md' });
  }
  forgotpassword() {
    if (this.emailid != "" && this.emailid != undefined && this.emailid != null) {
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
      let Model = {
        'email': this.emailid
      };
      this.api.postWithDataHeaders('ForgotPassword', options, Model).subscribe(
        res => {
          if (res.ForgotPasswordResult === "Success") {
            this.model.alert = "We have sent you an email. Please check your mail box.";
            this.emailid = "";
            this.modalRef.hide();
          }
          else if (res.ForgotPasswordResult === "No User Found") {
            this.forgotpwdinmsg = true;
            this.forgotpwdmsg = "The email id you entered is invalid. Please enter valid email id";
          }
          else if (res.ForgotPasswordResult === "Fail") {
            this.forgotpwdinmsg = true;
            this.forgotpwdmsg = "Unable to send email. Please try again";
          }

        })
    }
    else {
      this.email = 1;
    }
  }
  getnavigation() {
    this.spinnerService.show();
    if (localStorage.getItem('roleCode') == "SA") {
      let parameters = {
        searchvalue: " where GCB_STATUS='Y'"
      };
      this.api.postOH('getgolfclubaddressddl', parameters).subscribe(
        (response) => {
          localStorage.setItem("clubId", response[0].id);
          localStorage.setItem("clubname", response[0].name);
          localStorage.setItem("clubcode", response[0].clubcode);
          localStorage.setItem("timezone", response[0].timezoneoffset);
          this.spinnerService.show();         
          this.router.navigate(['/cartmanagement/cartsview']);
          //this.spinnerService.hide();
        },error=>{
          this.spinnerService.hide();
        })
    }
    else {
      let parameters = {
        uid: localStorage.getItem('userId'), rcode: localStorage.getItem('roleCode'), expression: " where GCCA_GCCL_ID='" + localStorage.getItem('userId') + "' AND GCB_STATUS='Y' AND GCCA_STATUS='Y'"
      };
      this.api.postOH('getclubassigneddetails', parameters).subscribe(
        (response) => {          
          localStorage.setItem('clubId', response[0].clubid);
          localStorage.setItem('clubname', response[0].clubname);
          localStorage.setItem("clubcode", response[0].clubcode);
          localStorage.setItem("timezone", response[0].timezoneoffset);
          if (response.length === 1) {
            let parameters = {
              searchvalue: " WHERE GC_GCB_ID='" + response[0].clubid + "' and GC_STATUS='Y' "
            };
            this.api.postOH('getgolfcourse', parameters).subscribe(
              (courseresponse) => {
                if (courseresponse.length > 1) {
                  localStorage.setItem('coursecount', courseresponse.length);
                }
                localStorage.setItem('courseId', courseresponse[0].id);
                localStorage.setItem('coursename', courseresponse[0].labelname);
                localStorage.setItem('nineholecourse', courseresponse[0].oddcourse);

              },error=>{
                this.spinnerService.hide();
              })
            this.authService.getCall();
          }
          this.spinnerService.show();
          this.router.navigate(['/cartmanagement/cartsview']);
          //this.spinnerService.hide();
        },error=>{
          this.spinnerService.hide();
        })
    }
  }
  getLogOut() {
    this.jwt.destroyToken();
  }

}
