import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GeofenceviewComponent } from './geofenceview.component';

describe('GeofenceviewComponent', () => {
  let component: GeofenceviewComponent;
  let fixture: ComponentFixture<GeofenceviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GeofenceviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GeofenceviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
