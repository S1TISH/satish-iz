import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Console } from '@angular/core/src/console';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { error } from 'util';
import { parse } from 'url';
import { Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Title } from '@angular/platform-browser';

declare const google: any;

@Component({
  selector: 'app-geofenceview',
  templateUrl: './geofenceview.component.html',
  styleUrls: ['./geofenceview.component.css']
})
export class GeofenceviewComponent implements OnInit {
  modalRef: BsModalRef; popupconfmsg: any = '';
  CoursesInfo: any = []; ddlhole: any; GeofenceInfo: any = []; disableenablehazardid: any; disableenablehdid: any; disableenabletype: any;

  clat: any; clong: any; czoomlevel: any; crotate: any;
  golfclubid: any; courseid: any; holeid: any;
  viewhztypecolor: any; map: any; action: any = 'A'; hzid: any = 0; hazardpolylinecoordinatesview: any = [];
  latlngarry: any; flightPath: any; viewhazardline: any = []; HolesInfo: any; hazardperimeterheader: string;
  hazardtypesdata: any = []; paceOfPlayData: any = []; //paceofPlayHoles: any = [];

  constructor(private title: Title, private modalService: BsModalService, private router: Router, public api: ApiService, public toastr: ToastsManager, public formBuilder: FormBuilder, vcr: ViewContainerRef, private spinnerService: Ng4LoadingSpinnerService) {

    this.title.setTitle("IZON - Geofence");
    this.hazardperimeterheader = localStorage.getItem('clubname');
    this.toastr.setRootViewContainerRef(vcr);
    this.golfclubid = localStorage.getItem('clubId');
    this.courseid = localStorage.getItem('courseId');
  }

  ngOnInit() {
    this.getHoles();
    this.getCourses();
  }

  getgeofencegrid(parameters) {
    this.api.postOH('GetGeofenceHazardsGrid', parameters).subscribe(
      (data) => {
        this.spinnerService.show();
        this.GeofenceInfo = [];
        if (data.length > 0) {
          for (var i = 0; i < data.length; i++) {
            this.GeofenceInfo.push({
              "id": data[i].id,
              "hazardname": data[i].hazardname,
              "holeid": data[i].holeid,
              "holename": data[i].holename,
              "hazardtypename": data[i].hazardtypename,
              "status": data[i].status,
              "date": data[i].date,
            })
          }
          this.gethacoursehazardperimeters();
          this.spinnerService.hide();
        } else {
          this.spinnerService.hide();
        }
      }, error => { this.spinnerService.hide(); }
    );
  }


  getCourses() {
    let parameters = { searchvalue: " WHERE GC_GCB_ID='" + this.golfclubid + "' AND GC_ID='" + this.courseid + "'" };
    this.api.postOH('getgolfcourse', parameters).subscribe(
      response => {
        if (response.length !== 0) {
          this.clat = response[0].latitude;
          this.clong = response[0].longitude;
          this.czoomlevel = (response[0].zoomlevel != '') ? response[0].zoomlevel : '0';
          this.crotate = (response[0].rotate != '') ? response[0].rotate : '0';
        }
        this.maploading();
      })
  }

  getHazardTypesList() {
    this.hazardtypesdata = []; this.paceOfPlayData = [];
    let parameters = {
      searchvalue: " WHERE HZT_GCB_ID='" + this.golfclubid + "' and HZT_STATUS='Y' "
    };
    this.api.postOH('GetHarardTypes', parameters).subscribe(
      (response) => {
        for (var i = 0; i < response.length; i++) {
          let type = response[i].name.toLowerCase();
          if ((type.indexOf('start round') >= 0) || (type.indexOf('end round') >= 0) || (type.indexOf('pop') >= 0)) {
            this.paceOfPlayData.push({
              value: response[i].id,
              name: response[i].name,
              color: response[i].color
            });
          }
          else {
            this.hazardtypesdata.push({
              value: response[i].id,
              name: response[i].name,
              color: response[i].color
            });
          }
        }
        var hazardTypeIds = '';
        hazardTypeIds = this.paceOfPlayData.map(function (obj) { return obj.value; }).join(',');
        if (this.paceOfPlayData.length > 0) {
          let parameters = {
            searchvalue: " where hz_status!='D' and hz_hd_id in (select hd_id from hole_details where hd_gcb_id='" + this.golfclubid + "' and hd_gc_id='" + this.courseid + "' and hd_status='Y') and HZ_HZT_ID not in (" + hazardTypeIds + ")"
          }
          this.getgeofencegrid(parameters);
        }
      }, error => {
      }
    );
  }

  getHoles() {
    let parameters = { searchvalue: " WHERE HD_GCB_ID=" + this.golfclubid + " AND HD_GC_ID = " + this.courseid + " AND HD_STATUS='Y' " };
    this.spinnerService.show();
    this.api.postOH('getholes', parameters).subscribe(
      response => {
        this.HolesInfo = [];
        if (response.length !== 0) {
          for (let i = 0; i < response.length; i++) {
            this.HolesInfo.push({
              "id": response[i].id,
              "holename": response[i].holename
            });
          }
          this.getHazardTypesList();
        }
        this.ddlhole = '0';
        this.spinnerService.hide();
      },
      err => {
        this.spinnerService.hide();
      }
    );
  }

  holechangeevent() {
    if (this.ddlhole > 0) {
      let parameters = {
        searchvalue: " WHERE  HD_GCB_ID='" + this.golfclubid + "' AND HD_GC_ID='" + this.courseid + "' and HD_ID='" + this.ddlhole + "' "
      };
      this.GetHoleLatLongDetails(parameters);
      var hazardTypeIds = '';
      hazardTypeIds = this.paceOfPlayData.map(function (obj) { return obj.value; }).join(',');
      if (this.paceOfPlayData.length > 0) {
        let parameters1 = {
          searchvalue: " where hz_status!='D' and hz_hd_id='" + this.ddlhole + "' and HZ_HZT_ID not in (" + hazardTypeIds + ")"
        }
        this.getgeofencegrid(parameters1);
      }
    } else {
      this.getCourses();
      var hazardTypeIds = '';
      hazardTypeIds = this.paceOfPlayData.map(function (obj) { return obj.value; }).join(',');
      if (this.paceOfPlayData.length > 0) {
        let parameters = {
          searchvalue: " where hz_status!='D' and hz_hd_id in (select hd_id from hole_details where hd_gcb_id='" + this.golfclubid + "' and hd_gc_id='" + this.courseid + "' and hd_status='Y') and HZ_HZT_ID not in (" + hazardTypeIds + ")"
        }
        this.getgeofencegrid(parameters);
      }
    }
  }

  GetHoleLatLongDetails(parameters) {
    this.api.postOH('getholes', parameters).subscribe(
      (response) => {
        this.clat = response[0].clatitude;
        this.clong = response[0].clongitude;
        this.czoomlevel = (response[0].zoomlevel != '') ? response[0].zoomlevel : 0;
        this.crotate = (response[0].rotate == '') ? 0 : response[0].rotate;
        this.map.setCenter(new google.maps.LatLng(parseFloat(this.clat), parseFloat(this.clong)));
        this.map.setZoom(parseInt(this.czoomlevel));
        //this.map.rotate(parseInt(this.crotate));
      }, error => {
      }
    );
  }

  maploading() {
    this.map = new google.maps.Map(document.getElementById('map'), {
      center: { lat: parseFloat(this.clat), lng: parseFloat(this.clong) },
      zoom: parseInt(this.czoomlevel),
      //disableDefaultUI: true,
      mapTypeId: 'satellite',
      heading: parseInt(this.crotate),
      tilt: 0,
      rotateControl: true
    });
    this.setoverlayimage();
    this.spinnerService.hide();
  }

  setoverlayimage() {
    let me = this;
    var imageMapType = new google.maps.ImageMapType({
      getTileUrl: function (coord, zoom) {
        //console.log('http://iadmin.azaz.com/tiles/' + me.golfclubid+ '/' +me.courseid+ '/' + zoom + '/' + coord.x + '/' + coord.y + '.png');
        return ['http://cp.izongolf.com/tiles/' + me.golfclubid + '/' + me.courseid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
        // let clbid=''; let cursid='';
        // if(me.golfclubid=='1002'){clbid='1445'}else{clbid=me.golfclubid};
        // if(me.courseid==2){cursid='539'}else if(me.courseid==3){cursid='540'}else if(me.courseid==4){cursid='541'}else{cursid=me.courseid};
        // return ['http://cp.izongolf.com/tiles/' + clbid + '/' + cursid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
      },
      tileSize: new google.maps.Size(256, 256)
    });
    this.map.overlayMapTypes.push(imageMapType);
  }

  gethacoursehazardperimeters() {
    let parameters = {};
    var hazardTypeIds = '';
    hazardTypeIds = this.paceOfPlayData.map(function (obj) { return obj.value; }).join(',');
    if (this.paceOfPlayData.length > 0) {
      parameters = {
        searchvalue: " where hz_status='Y' and hz_hd_id in (select hd_id from hole_details where hd_gcb_id='" + this.golfclubid + "' and hd_gc_id='" + this.courseid + "' and hd_status='Y') and HZ_HZT_ID not in (" + hazardTypeIds + ")"
      }
    }
    this.viewclearhazardperims();
    this.api.postOH('GetHazardAllCoursePerimeters', parameters).subscribe(
      (data) => {
        if (data.length > 0) {
          for (var i = 0; i < data.length; i++) {
            this.hazardpolylinecoordinatesview = [];
            this.viewhztypecolor = (data[i].color != '') ? data[i].color : data[i].hazardtypecolor;
            for (var j = 0; j < data[i].hazardperimeters.length; j++) {
              this.hazardpolylinecoordinatesview.push({
                lat: parseFloat(data[i].hazardperimeters[j].Latitude),
                lng: parseFloat(data[i].hazardperimeters[j].longitude)
              });
            }
            this.hazardpolylineviews();
          }
          this.spinnerService.hide();
        } else {
          this.viewclearhazardperims();
          this.spinnerService.hide();
        }
      }, error => { this.spinnerService.hide(); }
    );
  }

  hazardpolylineviews() {
    var viewflightPath = new google.maps.Polyline({
      path: this.hazardpolylinecoordinatesview,
      //editable:true,
      geodesic: true,
      strokeColor: this.viewhztypecolor,
      strokeOpacity: 1.0,
      strokeWeight: 5
    });
    this.viewhazardline.push(viewflightPath);
    viewflightPath.setMap(this.map);
  }

  viewclearhazardperims() {
    for (var i = 0; i < this.viewhazardline.length; i++) {
      this.viewhazardline[i].setMap(null);
    }
    this.hazardpolylinecoordinatesview = [];
  }

  addgeofence() {
    localStorage.removeItem('editHazardId');
    this.router.navigate(['/perimeters/geofenceadd']);
  }

  edithazard(hazards) {
    localStorage.setItem('editHazardId', hazards.id);
    this.router.navigate(['/perimeters/geofenceadd']);
  }

  disableenablehazard(hazards, type, template: TemplateRef<any>) {
    this.disableenablehazardid = hazards.id;
    this.disableenablehdid = hazards.holeid;
    this.disableenabletype = type;
    if (type == 'disable') {
      this.popupconfmsg = "Are you sure to disable the geofence?";
    } else {
      this.popupconfmsg = "Are you sure to enable the geofence?";
    }
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }

  confirm(): void {
    this.modalRef.hide();
    var lcstatus = '';
    if (this.disableenabletype == 'disable') {
      lcstatus = 'N';
    } else {
      lcstatus = 'Y';
    }
    var Hazardsinfo = { "action": "U", "id": this.disableenablehazardid, "htid": '0', "hdid": this.disableenablehdid, "name": "test", "status": lcstatus, "showstatus": 'N' };
    this.api.postOH('updatehazardstatus', Hazardsinfo).subscribe(
      (response) => {
        if (response == "Hazard Status Updated Successfully") {
          this.disableenablehazardid = '';
          this.disableenablehdid = '';
          // this.disableenabletype = '';
          if (this.ddlhole > 0) {
            var hazardTypeIds = '';
            hazardTypeIds = this.paceOfPlayData.map(function (obj) { return obj.value; }).join(',');
            if (this.paceOfPlayData.length > 0) {
              let parameters1 = {
                searchvalue: " where hz_status!='D' and hz_hd_id='" + this.ddlhole + "' and HZ_HZT_ID not in (" + hazardTypeIds + ")"
              }
              this.getgeofencegrid(parameters1);
            }
          } else {
            var hazardTypeIds = '';
            hazardTypeIds = this.paceOfPlayData.map(function (obj) { return obj.value; }).join(',');
            if (this.paceOfPlayData.length > 0) {
              let parameters = {
                searchvalue: " where hz_status!='D' and hz_hd_id in (select hd_id from hole_details where hd_gcb_id='" + this.golfclubid + "' and hd_gc_id='" + this.courseid + "' and hd_status='Y') and HZ_HZT_ID not in (" + hazardTypeIds + ")"
              }
              this.getgeofencegrid(parameters);
            }
          }
          let msg: any = '';
          if (this.disableenabletype == 'disable') {
            msg = '<span style="color: green">Geofence Hazard Disabled Successfully</span>';
          } else {
            msg = '<span style="color: green">Geofence Hazard Enabled Successfully</span>';
          }
          this.toastMessage(msg);
          this.disableenabletype = '';
        } else {
          let msg = '<span style="color: red">Something went wrong, please try again</span>';
          this.toastMessage(msg);
        }
      },
      error => {

      }
    );
  }

  decline(): void {
    this.disableenablehazardid = '';
    this.disableenablehdid = '';
    this.disableenabletype = '';
    this.modalRef.hide();
  }

  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',
    };
    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 5000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }

}
