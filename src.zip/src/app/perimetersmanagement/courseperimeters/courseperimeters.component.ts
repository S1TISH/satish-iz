import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Console } from '@angular/core/src/console';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Title } from '@angular/platform-browser';

declare const google: any;

@Component({
  selector: 'app-courseperimeters',
  templateUrl: './courseperimeters.component.html',
  styleUrls: ['./courseperimeters.component.css']
})
export class CourseperimetersComponent implements OnInit {
  courselat: any;
  courselong: any;
  coursezoomlevel: any;
  golfclubid: any;
  courseid: any;
  savebtnshow: any;
  poly: any; map: any; courseperimetersdata: any = [];courseperimeterheader:string;
  polylinecoordinates: any = []; latlngarry: any; flightPath: any; line: any = [];

  constructor(private title: Title,public api: ApiService, public toastr: ToastsManager, vcr: ViewContainerRef,private spinnerService: Ng4LoadingSpinnerService) {
    this.courseperimeterheader="Course Perimeters";
    this.title.setTitle("IZON - Course Perimeters");
    this.toastr.setRootViewContainerRef(vcr);
    this.golfclubid = localStorage.getItem('clubId');
    this.courseid = localStorage.getItem('courseId');        
  }

  ngOnInit() {
    let parameters1 = {
      search: " WHERE  GCP_GCB_ID='" + this.golfclubid + "' and GCP_GC_ID='"+this.courseid+"' "
    }
    this.getcourseperimetersdata(parameters1);
  }

  getcourseperimetersdata(parameters1) {
    this.spinnerService.show();
    this.api.postOH('GetGolfCoursePerimeters', parameters1).subscribe(
      (response) => {
        this.polylinecoordinates = [];
        //console.log(response);
        if (response.length > 0) {
          for (var i = 0; i < response.length; i++) {
            this.polylinecoordinates.push({
              lat: parseFloat(response[i].Latitude),
              lng: parseFloat(response[i].Longitude)
            });
          }
          let parameters = {
            searchvalue: " WHERE  GC_GCB_ID='" + this.golfclubid + "' AND GC_ID='" + this.courseid + "' "
          };
          this.GetCourseLatLongDetails(parameters);
        } else {
          this.savebtnshow = true;
          let parameters = {
            searchvalue: " WHERE  GC_GCB_ID='" + this.golfclubid + "' AND GC_ID='" + this.courseid + "' "
          };
          this.GetCourseLatLongDetails(parameters);
        }
      }, error => {
      }
    );
  }  

  GetCourseLatLongDetails(parameters) {
    this.api.postOH('getgolfcourse', parameters).subscribe(
      (response) => {
        if (response[0].latitude != '') {
          this.courselat = response[0].latitude;
          this.courselong = response[0].longitude;
          this.coursezoomlevel = response[0].zoomlevel;
          this.maploading();
        }else{
          this.spinnerService.hide();
          let msg = '<span style="color: green">Please Update Course Latitude and Longitude</span>';
          this.toastMessage(msg);
        }
      }, error => {
      }
    );
  }

  maploading() {
    this.map = new google.maps.Map(document.getElementById('map'), {
      center: { lat: parseFloat(this.courselat), lng: parseFloat(this.courselong) },
      zoom: parseInt(this.coursezoomlevel),
      //disableDefaultUI: true,
      mapTypeId: 'satellite',
      tilt: 0,
      rotateControl: true
    });
    this.setoverlayimage();
    this.drawpolyline();    
    // this.poly = new google.maps.Polyline({
    //   strokeColor: '#000000',
    //   strokeOpacity: 1.0,
    //   strokeWeight: 3
    // });
    // this.poly.setMap(this.map);
    //Add a listener for the click event
    var me = this;
    this.map.addListener('click', function (event) {
      this.latlngarry = JSON.parse(JSON.stringify(event));
      me.polylinecoordinates.push({
        lat: parseFloat(this.latlngarry.latLng.lat),
        lng: parseFloat(this.latlngarry.latLng.lng)
      });
      me.courseperimetersdata.push({
        'GCBID': me.golfclubid,
        'GCID': me.courseid,
        'LAT': this.latlngarry.latLng.lat,
        'LONG': this.latlngarry.latLng.lng
      })
      //console.log(me.holeperimetersdata);
      //console.log(me.polylinecoordinates);
      me.drawpolyline();
    });
    this.spinnerService.hide();
  }

  setoverlayimage(){
    let me=this;    
    var imageMapType = new google.maps.ImageMapType({
      getTileUrl: function(coord, zoom) {
        //console.log('http://iadmin.azaz.com/tiles/' + me.golfclubid+ '/' +me.courseid+ '/' + zoom + '/' + coord.x + '/' + coord.y + '.png');
        return ['http://cp.izongolf.com/tiles/' + me.golfclubid+ '/' +me.courseid+ '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
        // let clbid=''; let cursid='';
        // if(me.golfclubid=='1002'){clbid='1445'}else{clbid=me.golfclubid};
        // if(me.courseid==2){cursid='539'}else if(me.courseid==3){cursid='540'}else if(me.courseid==4){cursid='541'}else{cursid=me.courseid};
        // return ['http://cp.izongolf.com/tiles/' + clbid + '/' + cursid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
      },
      tileSize: new google.maps.Size(256, 256)
    });
    this.map.overlayMapTypes.push(imageMapType);
  }

  clearpolylinedata() {
    this.savebtnshow = true;
    for (var i = 0; i < this.line.length; i++) {
      this.line[i].setMap(null);
    }
    this.polylinecoordinates = [];
    this.courseperimetersdata = [];
  }

  drawpolyline() {
    this.flightPath = new google.maps.Polyline({
      path: this.polylinecoordinates,
      //editable:true,
      geodesic: true,
      strokeColor: '#FF0000',
      strokeOpacity: 1.0,
      strokeWeight: 2
    });
    this.line.push(this.flightPath);
    this.flightPath.setMap(this.map);
  }

  savecourseperimeters() {    
    if (this.courseperimetersdata.length > 0) {
      this.courseperimetersdata.push({
        'GCBID': this.golfclubid,
        'GCID': this.courseid,        
        'LAT': this.courseperimetersdata[0].LAT,
        'LONG': this.courseperimetersdata[0].LONG
      });
      var model = { "GolfCoursePerimeter": this.courseperimetersdata, "gcbid": this.golfclubid, "gcid": this.courseid };
      //console.log(model);
      this.spinnerService.show();
      this.api.postOH('saveGolfCourseperimeters', model).subscribe(
        (response) => {
          //console.log(response);
          this.savebtnshow = false;
          if (response.saveGolfCourseperimetersResult == "Success") {
            let msg = '<span style="color: green">Course Perimeters saved Successfully.</span>';
            this.toastMessage(msg);
          } else {
            let msg = '<span style="color: green">Something went wrong, please try again.</span>';
            this.toastMessage(msg);
          }
          this.spinnerService.hide();
        },
        error => {
          this.spinnerService.hide();
          console.log(error);
        }
      );
    }else{
      this.spinnerService.hide();
      let msg = '<span style="color: green">Please draw course perimeters.</span>';
      this.toastMessage(msg);
    }
  }


  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',
    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 5000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }

}
