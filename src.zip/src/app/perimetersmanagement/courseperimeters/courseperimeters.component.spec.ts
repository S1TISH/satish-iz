import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CourseperimetersComponent } from './courseperimeters.component';

describe('CourseperimetersComponent', () => {
  let component: CourseperimetersComponent;
  let fixture: ComponentFixture<CourseperimetersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CourseperimetersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CourseperimetersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
