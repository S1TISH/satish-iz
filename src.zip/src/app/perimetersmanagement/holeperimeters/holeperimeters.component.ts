import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Console } from '@angular/core/src/console';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Title } from '@angular/platform-browser';

declare const google: any;

@Component({
  selector: 'app-holeperimeters',
  templateUrl: './holeperimeters.component.html',
  styleUrls: ['./holeperimeters.component.css']
})
export class HoleperimetersComponent implements OnInit {
  holelat: any;
  holelong: any;
  holezoomlevel: any;
  golfclubid: any;
  courseid: any;
  holeid: any; savebtnshow: any;
  poly: any; map: any; holeperimetersdata: any = [];holeperimeterheader:string;
  polylinecoordinates: any = []; latlngarry: any; flightPath: any; line: any = [];
  constructor(private title: Title,public api: ApiService, public toastr: ToastsManager, vcr: ViewContainerRef,private spinnerService: Ng4LoadingSpinnerService) {

    this.title.setTitle("IZON - Hole Perimeters");
    this.holeperimeterheader="Hole Perimeters For Hole #"+localStorage.getItem('holename');
    this.toastr.setRootViewContainerRef(vcr);
    this.golfclubid = localStorage.getItem('clubId');
    this.courseid = localStorage.getItem('courseId');
    this.holeid = localStorage.getItem('holeId');    
  }

  ngOnInit() {
    let parameters1 = {
      expression: " WHERE  HP_GC_ID='" + this.courseid + "' and HP_HD_ID='" + this.holeid + "' "
    }
    this.getholeperimetersdata(parameters1);
  }

  getholeperimetersdata(parameters1) {
    this.spinnerService.show();
    this.api.postOH('GetHolePerimeters', parameters1).subscribe(
      (response) => {
        this.polylinecoordinates = [];
        //console.log(response);
        if (response.length > 0) {
          for (var i = 0; i < response.length; i++) {
            this.polylinecoordinates.push({
              lat: parseFloat(response[i].Latitude),
              lng: parseFloat(response[i].Longitude)
            });
          }
          let parameters = {
            searchvalue: " WHERE  HD_GCB_ID='" + this.golfclubid + "' AND HD_GC_ID='" + this.courseid + "' and HD_ID='" + this.holeid + "' "
          };
          this.GetHoleLatLongDetails(parameters);
        } else {
          this.savebtnshow = true;
          let parameters = {
            searchvalue: " WHERE  HD_GCB_ID='" + this.golfclubid + "' AND HD_GC_ID='" + this.courseid + "' and HD_ID='" + this.holeid + "' "
          };
          this.GetHoleLatLongDetails(parameters);
        }
      }, error => {
        this.spinnerService.hide();
      }
    );
  }  

  GetHoleLatLongDetails(parameters) {
    this.api.postOH('getholes', parameters).subscribe(
      (response) => {
        this.spinnerService.hide();
        this.holelat = response[0].clatitude;
        this.holelong = response[0].clongitude;
        this.holezoomlevel = response[0].zoomlevel;
        this.maploading();
      }, error => {
        this.spinnerService.hide();
      }
    );
  }

  maploading() {
    this.map = new google.maps.Map(document.getElementById('map'), {
      center: { lat: parseFloat(this.holelat), lng: parseFloat(this.holelong) },
      zoom: parseInt(this.holezoomlevel),
      //disableDefaultUI: true,
      mapTypeId: 'satellite',
      tilt: 0,
      rotateControl: true
    });
    this.drawpolyline();
    this.setoverlayimage();
    
    var me = this;    
    //Add a listener for the click event    
    this.map.addListener('click', function (event) {
      this.latlngarry = JSON.parse(JSON.stringify(event));
      me.polylinecoordinates.push({
        lat: parseFloat(this.latlngarry.latLng.lat),
        lng: parseFloat(this.latlngarry.latLng.lng)
      });
      me.holeperimetersdata.push({
        'GCBID': me.golfclubid,
        'CLID': me.courseid,
        'HID': me.holeid,
        'LAT': this.latlngarry.latLng.lat,
        'LONG': this.latlngarry.latLng.lng
      })
      //console.log(me.holeperimetersdata);
      //console.log(me.polylinecoordinates);
      me.drawpolyline();
    });
    this.spinnerService.hide();
  }

  setoverlayimage(){
    let me=this;    
    var imageMapType = new google.maps.ImageMapType({
      getTileUrl: function(coord, zoom) {
        //console.log('http://iadmin.azaz.com/tiles/' + me.golfclubid+ '/' +me.courseid+ '/' + zoom + '/' + coord.x + '/' + coord.y + '.png');
        return ['http://cp.izongolf.com/tiles/' + me.golfclubid+ '/' +me.courseid+ '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
        // let clbid=''; let cursid='';
        // if(me.golfclubid=='1002'){clbid='1445'}else{clbid=me.golfclubid};
        // if(me.courseid==2){cursid='539'}else if(me.courseid==3){cursid='540'}else if(me.courseid==4){cursid='541'}else{cursid=me.courseid};
        // return ['http://cp.izongolf.com/tiles/' + clbid + '/' + cursid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
      },
      tileSize: new google.maps.Size(256, 256)
    });
    this.map.overlayMapTypes.push(imageMapType);
  }

  clearpolylinedata() {
    this.savebtnshow = true;
    for (var i = 0; i < this.line.length; i++) {
      this.line[i].setMap(null);
    }
    this.polylinecoordinates = [];
    this.holeperimetersdata = [];
  }

  drawpolyline() {
    this.flightPath = new google.maps.Polyline({
      path: this.polylinecoordinates,
      //editable:true,
      geodesic: true,
      strokeColor: '#FF0000',
      strokeOpacity: 1.0,
      strokeWeight: 2
    });
    this.line.push(this.flightPath);
    this.flightPath.setMap(this.map);
  }

  saveholeperimeters() {    
    if (this.holeperimetersdata.length > 0) {
      this.holeperimetersdata.push({
        'GCBID': this.golfclubid,
        'CLID': this.courseid,
        'HID': this.holeid,
        'LAT': this.holeperimetersdata[0].LAT,
        'LONG': this.holeperimetersdata[0].LONG
      });
      var model = { "HolePerimeter": this.holeperimetersdata, "gcbid": this.golfclubid, "gcid": this.courseid, "hid": this.holeid };
      //console.log(model);
      this.spinnerService.show();
      this.api.postOH('SaveHolePerimeters', model).subscribe(
        (response) => {
          this.savebtnshow = false;
          if (response.saveholeperimetersResult == "Success") {
            let msg = '<span style="color: green">Hole Perimeters saved Successfully.</span>';
            this.toastMessage(msg);
          } else {
            let msg = '<span style="color: green">Something went wrong, please try again.</span>';
            this.toastMessage(msg);
          }
          this.spinnerService.hide();
        },
        error => {
          this.spinnerService.hide();
          console.log(error);
        }
      );
    }else{
      this.spinnerService.hide();
      let msg = '<span style="color: green">Please draw hole perimeters.</span>';
      this.toastMessage(msg);
    }
  }


  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',
    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 5000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }

}
