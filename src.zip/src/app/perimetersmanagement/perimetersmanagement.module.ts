import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FullCalendarModule } from 'ng-fullcalendar';
//import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { ModalModule } from 'ngx-bootstrap';
import { OrderModule } from 'ngx-order-pipe';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { PopoverModule } from 'ngx-bootstrap';
import { ColorPickerModule } from 'ngx-color-picker';

import { CourseperimetersComponent } from './courseperimeters/courseperimeters.component';
import { HoleperimetersComponent } from './holeperimeters/holeperimeters.component';
import { GeofenceaddComponent } from './geofenceadd/geofenceadd.component';
import { GeofenceviewComponent } from './geofenceview/geofenceview.component';
import { HazardtypeComponent } from './hazardtype/hazardtype.component';
import { AddgeofencepaceofplayComponent } from './addgeofencepaceofplay/addgeofencepaceofplay.component';
import { GeofencepaceofplayComponent } from './geofencepaceofplay/geofencepaceofplay.component';
import { CartpathmanagementComponent } from './cartpathmanagement/cartpathmanagement.component';

const routes: Routes = [  
  {
    path:'courseperimeters',
    component:CourseperimetersComponent
  },
  {
    path:'holeperimeters',
    component:HoleperimetersComponent
  },
  {
    path:'geofenceview',
    component:GeofenceviewComponent
  },
  {
    path:'geofenceadd',
    component:GeofenceaddComponent
  },
  {
    path:'hazardtype',
    component:HazardtypeComponent
  },
  {
   path:'addgeofencepaceofplay',
   component:AddgeofencepaceofplayComponent
 },
  {
    path:'geofencepaceofplay',
    component:GeofencepaceofplayComponent
  },
  {
    path:'cartpath',
    component:CartpathmanagementComponent
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule, ReactiveFormsModule,
    FullCalendarModule,OrderModule,
    ToastModule.forRoot(),
    ModalModule.forRoot(),
    OwlDateTimeModule,PopoverModule.forRoot(),
    OwlNativeDateTimeModule, BsDatepickerModule.forRoot(),
    ColorPickerModule
  ],
  declarations: [CourseperimetersComponent, HoleperimetersComponent, GeofenceaddComponent, GeofenceviewComponent, HazardtypeComponent, AddgeofencepaceofplayComponent, GeofencepaceofplayComponent, CartpathmanagementComponent],
  exports: [RouterModule]
})
export class PerimetersmanagementModule { }
