import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddgeofencepaceofplayComponent } from './addgeofencepaceofplay.component';

describe('AddgeofencepaceofplayComponent', () => {
  let component: AddgeofencepaceofplayComponent;
  let fixture: ComponentFixture<AddgeofencepaceofplayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddgeofencepaceofplayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddgeofencepaceofplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
