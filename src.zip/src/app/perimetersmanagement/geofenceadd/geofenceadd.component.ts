import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Console } from '@angular/core/src/console';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { error } from 'util';
import { parse } from 'url';
import { Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import * as moment from "moment";
import { Title } from '@angular/platform-browser';

declare const google: any;

var mutebtn, volumeslider, audio = new Audio(), soundlblval, gridaudio = new Audio();

@Component({
  selector: 'app-geofenceadd',
  templateUrl: './geofenceadd.component.html',
  styleUrls: ['./geofenceadd.component.css']
})
export class GeofenceaddComponent implements OnInit {
  modalRef: BsModalRef;
  CoursesInfo: any = []; desclength: any;

  savebtndisable: boolean; audiosavebtndisable: boolean;

  clat: any; clong: any; czoomlevel: any; crotate: any;
  golfclubid: any; courseid: any; holeid: any; userid: any;
  hazardtypesdata: any = []; alertaudiolistdata: any = [];

  ddlhazardtypes: any; txthazardlabel: string; //txtcolor: any; 
  ddlhole: any; ddlenable: any; affects: any;
  public txtcolor: string = "#000000";
  //chkshowonmap: any;
  fromdate: any; todate: any; chksts: any; cartTypeCount: any = '0';

  hztypecolor: any; viewhztypecolor: any; datesshowdiv: boolean;
  map: any; addedithazardperimetersdata: any = []; hazardperimeterheader: string; action: any = 'A'; hzid: any = 0;

  hazardpolylinecoordinatesview: any = []; hazarddrawpolylinecoordinates: any = []; latlngarry: any; flightPath: any; hazardline: any = []; viewhazardline: any = [];
  HolesInfo: any;
  public hazardForm: FormGroup; submitAttempt: boolean = false;
  public hazardAudioForm: FormGroup; audiosubmitAttempt: boolean = false;

  audiofilename: any; audiofilepath: any; audiofilecropped: any; checkaudiofile: any;
  audioplaybtn: any; audiostopbtn: any; audiostatus: any = 'Y'; txtmessage: any;
  titlename: any; titlecolor: any; iconname: any; iconcolor: any;
  audioaction: any = 'A'; audiochksts: any; txtdistance: any; ddlhazardaudio: any;
  hasid: any = 0; hazardaudiodata: any = []; disableaudiofiles: boolean = true;
  chkRepeat: any; timeoffset: any; cartType: any = ''; audioInfo: string; hazardType: any = '';

  paceOfPlayData: any = []; minStartDate: any; minEndDate: any;
  currentGolfClubDateTime: any = '';//disabledDates:any=[];
  constructor(private title: Title, private modalService: BsModalService, private router: Router, public api: ApiService, public toastr: ToastsManager, public formBuilder: FormBuilder, vcr: ViewContainerRef, private spinnerService: Ng4LoadingSpinnerService) {
    this.title.setTitle("IZON - Geofence Add");
    this.hazardperimeterheader = localStorage.getItem('clubname');

    this.toastr.setRootViewContainerRef(vcr);
    this.desclength = 180;
    this.chksts = true;
    this.ddlhole = '0';
    this.ddlenable = "0";
    this.affects = "golfers";
    //this.chkshowonmap = true;
    this.datesshowdiv = false;
    this.audioplaybtn = false;
    this.audiostopbtn = false;
    this.golfclubid = localStorage.getItem('clubId');
    this.courseid = localStorage.getItem('courseId');
    this.userid = localStorage.getItem('userId');
    this.audiofilepath = "";
    this.audiofilename = "";
    this.audiofilecropped = "";
    this.txtdistance = 5;
    this.iconname = "Select"; this.cartTypeCount = '0';
  }

  ngOnInit() {
    this.hazardForm = this.formBuilder.group({
      ddlhole: ['0', Validators.compose([Validators.required])],
      ddlhazardtypes: ['0', Validators.compose([Validators.required])],
      txthazardlabel: ['', Validators.compose([Validators.required])],
      ddlenable: ['0', Validators.compose([Validators.required])],
      affects: [''],
      txtcolor: ['', Validators.compose([Validators.required])],
      // chkshowonmap: [''],
      fromdate: [''],
      todate: [''],
      chksts: [''],
    });

    this.hazardAudioForm = this.formBuilder.group({
      ddlhazardaudio: ['-1', Validators.compose([Validators.required])],
      titlename: ['', Validators.compose([Validators.required])],
      titlecolor: [''],
      iconname: ['Select', Validators.compose([Validators.required])],
      iconcolor: [''],
      txtdistance: ['5', Validators.compose([Validators.required])],
      chkRepeat: [''],
      txtmessage: ['', Validators.compose([Validators.required])],
      audiochksts: ['']
    });

    // Set object references
    mutebtn = document.getElementById("mutebtn");
    volumeslider = document.getElementById("volumeslider");
    soundlblval = document.getElementById("txtsoundval");

    // Add Event Handling
    volumeslider.addEventListener("mousemove", this.setvolume);
    mutebtn.addEventListener("click", this.mute);
    soundlblval.textContent = 10;

    this.getHazardTypesList();
    this.getCourses();
    this.getAlertAudioList();
    if (localStorage.getItem('editHazardId') != '' && localStorage.getItem('editHazardId') != undefined && localStorage.getItem('editHazardId') != null) {
      this.hzid = localStorage.getItem('editHazardId');
      this.edithazard();
      // this.getHazardAudiodata();
    } else {
      this.action = 'A';
      this.hzid = 0;
      this.audiosavebtndisable = true;
    }
  }
  onKeyUp(event: any) {
    this.desclength = 180 - event.target.value.length;

  };
  getCourses() {
    let parameters = { searchvalue: " WHERE GC_GCB_ID='" + this.golfclubid + "' AND GC_ID='" + this.courseid + "'" };
    this.api.postOH('getgolfcourse', parameters).subscribe(
      response => {
        if (response.length !== 0) {
          this.clat = response[0].latitude;
          this.clong = response[0].longitude;
          this.timeoffset = response[0].timeoffset;
          this.czoomlevel = (response[0].zoomlevel != '') ? response[0].zoomlevel : '0';
          this.crotate = (response[0].rotate != '') ? response[0].rotate : '0';
        }
        this.maploading();
        this.setdates();
      });
  }

  getHoles() {
    let parameters = { searchvalue: " WHERE HD_GCB_ID=" + this.golfclubid + " AND HD_GC_ID = " + this.courseid + " AND HD_STATUS='Y' " };
    this.spinnerService.show();
    this.api.postOH('getholes', parameters).subscribe(
      response => {
        this.HolesInfo = [];
        if (response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            this.HolesInfo.push({
              "id": response[i].id,
              "holename": response[i].holename
            });
          }
        }
        this.gethacoursehazardperimeters();
        this.spinnerService.hide();
      },
      err => {
        this.spinnerService.hide();
      }
    );
  }

  getHazardTypesList() {
    this.hazardtypesdata = []; this.paceOfPlayData = [];
    this.hazardtypesdata = [{ value: 0, name: '--Select Geo Type--' }];
    let parameters = {
      searchvalue: " WHERE HZT_GCB_ID='" + this.golfclubid + "' and HZT_STATUS='Y' "
    };
    this.api.postOH('GetHarardTypes', parameters).subscribe(
      (response) => {
        for (var i = 0; i < response.length; i++) {
          let type = response[i].name.toLowerCase();
          if ((type.indexOf('start round') >= 0) || (type.indexOf('end round') >= 0) || (type.indexOf('pop') >= 0)) {
            this.paceOfPlayData.push({
              value: response[i].id,
              name: response[i].name,
              color: response[i].color
            });
          }
          else {
            this.hazardtypesdata.push({
              value: response[i].id,
              name: response[i].name,
              color: response[i].color
            });
          }
        }
        this.getHoles();
      }, error => {
      }
    );
    this.ddlhazardtypes = "0";
  }

  holechangeevent() {
    this.ddlhazardtypes = "0"; this.cartTypeCount = '0';
    this.ddlenable = "0";
    if (this.ddlhole > 0) {
      let parameters = {
        searchvalue: " WHERE  HD_GCB_ID='" + this.golfclubid + "' AND HD_GC_ID='" + this.courseid + "' and HD_ID='" + this.ddlhole + "' "
      };
      this.GetHoleLatLongDetails(parameters);
    } else {
      this.getCourses();
    }
  }

  enabledchangeevent() {
    if (this.ddlenable == 'T') {
      this.setdates();
      this.datesshowdiv = true;
    } else {
      this.fromdate = '';
      this.todate = '';
      this.datesshowdiv = false;
    }
  }
  setdates() {
    let currentDate: any = '';
    let d = new Date();
    let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
    currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
    this.currentGolfClubDateTime = currentDate;
    this.fromdate = moment(currentDate).format('MMMM DD, YYYY');
    this.todate = moment(currentDate).add(1, 'd').format('MMMM DD, YYYY');
    this.minStartDate = currentDate; this.minEndDate = currentDate;
  }

  dateformats(val) {
    var strdate = '';
    var datearry = [];
    if (val != '') {
      datearry = val.split("-");
      strdate = datearry[1] + "/" + datearry[2] + "/" + datearry[0];
    }
    return strdate;
  }

  GetHoleLatLongDetails(parameters) {
    this.api.postOH('getholes', parameters).subscribe(
      (response) => {
        this.clat = response[0].clatitude;
        this.clong = response[0].clongitude;
        this.czoomlevel = (response[0].zoomlevel != '') ? response[0].zoomlevel : 0;
        this.crotate = (response[0].rotate == '') ? 0 : response[0].rotate;
        this.map.setCenter(new google.maps.LatLng(parseFloat(this.clat), parseFloat(this.clong)));
        this.map.setZoom(parseInt(this.czoomlevel));
        //this.map.rotate(parseInt(this.crotate));
      }, error => {
      }
    );
  }

  maploading() {
    this.map = new google.maps.Map(document.getElementById('map'), {
      center: { lat: parseFloat(this.clat), lng: parseFloat(this.clong) },
      zoom: parseInt(this.czoomlevel),
      //disableDefaultUI: true,
      mapTypeId: 'satellite',
      heading: parseInt(this.crotate),
      tilt: 0,
      rotateControl: true
    });
    this.setoverlayimage();
    //Add a listener for the click event
    var me = this;
    this.map.addListener('click', function (event) {
      if (me.ddlhole != 0) {
        if (me.ddlhazardtypes != 0) {
          if (me.action == 'A') {
            this.latlngarry = JSON.parse(JSON.stringify(event));
            me.hazarddrawpolylinecoordinates.push({
              lat: parseFloat(this.latlngarry.latLng.lat),
              lng: parseFloat(this.latlngarry.latLng.lng)
            });
            me.addedithazardperimetersdata.push({
              'HZP_LATITUDE': this.latlngarry.latLng.lat,
              'HZP_LONGITUDE': this.latlngarry.latLng.lng
            })
            me.hazarddrawpolyline();
          } else {
            let msg = "<span style='color: red'>Please Delete Previous Hazard and Create New Hazard</span>";
            me.toastMessage(msg);
          }
        } else {
          let msg = "<span style='color: red'>Select Geo Type</span>";
          me.toastMessage(msg);
        }
      } else {
        let msg = "<span style='color: red'>Select Hole</span>";
        me.toastMessage(msg);
      }
    });
    this.spinnerService.hide();
  }

  setoverlayimage() {
    let me = this;
    var imageMapType = new google.maps.ImageMapType({
      getTileUrl: function (coord, zoom) {
        //console.log('http://iadmin.azaz.com/tiles/' + me.golfclubid+ '/' +me.courseid+ '/' + zoom + '/' + coord.x + '/' + coord.y + '.png');
        return ['http://cp.izongolf.com/tiles/' + me.golfclubid + '/' + me.courseid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
        // let clbid=''; let cursid='';
        // if(me.golfclubid=='1002'){clbid='1445'}else{clbid=me.golfclubid};
        // if(me.courseid==2){cursid='539'}else if(me.courseid==3){cursid='540'}else if(me.courseid==4){cursid='541'}else{cursid=me.courseid};
        // return ['http://cp.izongolf.com/tiles/' + clbid + '/' + cursid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
      },
      tileSize: new google.maps.Size(256, 256)
    });
    this.map.overlayMapTypes.push(imageMapType);
  }

  edithazard() {
    this.disableaudiofiles = false;
    this.audiosavebtndisable = false; this.hazardType = '';
    this.action = 'U';
    let parameters = {
      searchvalue: " where hz_id='" + this.hzid + "'  "
    }
    this.api.postOH('GetHazardAllCoursePerimeters', parameters).subscribe(
      (data) => {
        this.addedithazardperimetersdata = [];
        if (data.length > 0) {
          for (var i = 0; i < data.length; i++) {
            this.ddlhole = data[i].holeid;
            let parameters = {
              searchvalue: " WHERE  HD_GCB_ID='" + this.golfclubid + "' AND HD_GC_ID='" + this.courseid + "' and HD_ID='" + this.ddlhole + "' "
            };
            this.GetHoleLatLongDetails(parameters);
            this.ddlhazardtypes = data[i].hazardtypeid;
            this.txthazardlabel = data[i].hazardlabel;
            this.ddlenable = data[i].enabled;
            this.hazardType = data[i].hazardtypename.toLowerCase();
            if (data[i].enabled == 'T') {
              this.fromdate = new Date(data[i].fromdate);
              this.todate = new Date(data[i].todate);
              if (moment(this.fromdate).format('MM/DD/YYYY') > moment(this.currentGolfClubDateTime).format('MM/DD/YYYY')) {
                this.minStartDate = this.currentGolfClubDateTime;
              } else {
                this.minStartDate = new Date(data[i].fromdate);
              }
              if (moment(this.todate).format('MM/DD/YYYY') > moment(this.currentGolfClubDateTime).format('MM/DD/YYYY')) {
                this.minEndDate = this.currentGolfClubDateTime;
              } else {
                this.minEndDate = new Date(data[i].todate);
              }
              this.datesshowdiv = true;
            } else {
              this.fromdate = '';
              this.todate = '';
              this.datesshowdiv = false;
              this.minStartDate = this.currentGolfClubDateTime;
              this.minEndDate = this.currentGolfClubDateTime;
            }
            if (data[i].affectsgolfer == 'Y') {
              this.affects = "golfers";
            } else if (data[i].affectspwd == 'Y') {
              this.affects = "pwd";
            } else if (data[i].affectsvip == 'Y') {
              this.affects = "vip";
            }
            this.txtcolor = data[i].color;
            this.chksts = (data[i].status == 'Y') ? true : false;
            for (var j = 0; j < data[i].hazardperimeters.length; j++) {
              this.addedithazardperimetersdata.push({
                'HZP_LATITUDE': data[i].hazardperimeters[j].Latitude,
                'HZP_LONGITUDE': data[i].hazardperimeters[j].longitude
              });
            }
          }
          if (this.hazardType != 'cart path only') {
            this.getHazardAudiodata(); this.audioInfo = "Block";
          } else {
            this.audioInfo = "none";
          }
          this.spinnerService.hide();
        } else {
          this.spinnerService.hide();
        }
      }, error => { this.spinnerService.hide(); }
    );
  }

  gethacoursehazardperimeters() {
    let parameters = {};
    var hazardTypeIds = '';
    hazardTypeIds = this.paceOfPlayData.map(function (obj) { return obj.value; }).join(',');
    if (this.paceOfPlayData.length > 0 && this.hzid == 0) {
      parameters = {
        searchvalue: " where hz_status<>'D' and hz_hd_id in (select hd_id from hole_details where hd_gcb_id='" + this.golfclubid + "' and hd_gc_id='" + this.courseid + "' and hd_status='Y') and HZ_HZT_ID not in (" + hazardTypeIds + ")"
      }
    } else if (this.paceOfPlayData.length > 0 && this.hzid > 0) {
      parameters = {
        searchvalue: " where hz_status<>'D' and hz_hd_id in (select hz_hd_id from hazard where hz_id='" + this.hzid + "') and hz_id='" + this.hzid + "' and HZ_HZT_ID not in (" + hazardTypeIds + ")"
      }
    }
    this.viewclearhazardperims();
    this.api.postOH('GetHazardAllCoursePerimeters', parameters).subscribe(
      (data) => {
        if (data.length > 0) {
          for (var i = 0; i < data.length; i++) {
            this.hazardpolylinecoordinatesview = [];
            this.viewhztypecolor = (data[i].color != '') ? data[i].color : data[i].hazardtypecolor;
            for (var j = 0; j < data[i].hazardperimeters.length; j++) {
              this.hazardpolylinecoordinatesview.push({
                lat: parseFloat(data[i].hazardperimeters[j].Latitude),
                lng: parseFloat(data[i].hazardperimeters[j].longitude)
              });
            }
            this.hazardpolylineviews();
          }
          this.spinnerService.hide();
        } else {
          this.viewclearhazardperims();
          this.spinnerService.hide();
        }
      }, error => { this.spinnerService.hide(); }
    );
  }

  hazardpolylineviews() {
    var viewflightPath = new google.maps.Polyline({
      path: this.hazardpolylinecoordinatesview,
      //editable:true,
      geodesic: true,
      strokeColor: this.viewhztypecolor,
      strokeOpacity: 1.0,
      strokeWeight: 5
    });
    this.viewhazardline.push(viewflightPath);
    viewflightPath.setMap(this.map);
  }

  viewclearhazardperims() {
    for (var i = 0; i < this.viewhazardline.length; i++) {
      this.viewhazardline[i].setMap(null);
    }
    this.hazardpolylinecoordinatesview = [];
  }

  hzrdtypechangeevent(val) {
    this.ddlenable = "0"; this.cartTypeCount = '0';
    if (val.target.selectedIndex > 0) {
      this.hztypecolor = this.hazardtypesdata[val.target.selectedIndex].color;
      this.txtcolor = this.hazardtypesdata[val.target.selectedIndex].color;
      if (this.hazardtypesdata[val.target.selectedIndex].name.toLowerCase() != 'cart path only') {
        this.audioInfo = "Block";
      } else {
        this.audioInfo = "none"; this.ddlenable = 'T';
      }
    }
    else {
      this.txtcolor = "#000000"; this.audioInfo = "Block";
    }
  }

  hazarddrawpolyline() {
    this.flightPath = new google.maps.Polyline({
      path: this.hazarddrawpolylinecoordinates,
      //editable:true,
      geodesic: true,
      strokeColor: this.txtcolor,
      strokeOpacity: 1.0,
      strokeWeight: 5
    });
    this.hazardline.push(this.flightPath);
    this.flightPath.setMap(this.map);
  }

  clearpolylinedata() {
    this.clearhazardperims();
  }

  clearhazardperims() {
    for (var i = 0; i < this.hazardline.length; i++) {
      this.hazardline[i].setMap(null);
    }
    this.hazarddrawpolylinecoordinates = [];
    this.addedithazardperimetersdata = [];
  }

  cancel() {
    if (audio != undefined) {
      this.audioplaybtn = true;
      this.audiostopbtn = false;
      audio.pause();
    }
    if (gridaudio != undefined) {
      gridaudio.pause();
    }
    this.ddlhole = "0";
    this.ddlhazardtypes = "0";
    this.txtcolor = '';
    this.txthazardlabel = '';
    this.ddlenable = "0";
    this.affects = "golfers";
    this.submitAttempt = false;
    this.clearhazardperims();
    this.router.navigate(['/perimeters/geofenceview']);
  }

  savegeofencedata() {
    if (!this.hazardForm.valid) {

    }
    let rdstatus = ''; this.cartType = '';
    this.submitAttempt = true;
    if (this.hazardForm.valid) {
      if (this.ddlenable != 0) {
        this.savebtndisable = true;
        if (this.addedithazardperimetersdata.length > 0) {
          if (this.action == 'A') {
            const idx = this.hazardtypesdata.findIndex(a => a.value == this.ddlhazardtypes);
            if (this.hazardtypesdata[idx].name.toLowerCase() != 'cart path only') {
              rdstatus = 'Y';
            }
            else {
              rdstatus = 'N';
            }
            this.addedithazardperimetersdata.push({
              'HZP_LATITUDE': this.addedithazardperimetersdata[0].HZP_LATITUDE,
              'HZP_LONGITUDE': this.addedithazardperimetersdata[0].HZP_LONGITUDE
            });
          } else {
            rdstatus = (this.chksts == true) ? 'Y' : 'N';
          }
          this.holeid = this.ddlhole;
          var affects_golfer = ''; var affects_pwd = ''; var affects_vip = '';
          if (this.affects == "golfers") {
            affects_golfer = 'Y';
            affects_pwd = 'N';
            affects_vip = 'N';
          } else if (this.affects == "pwd") {
            affects_golfer = 'N';
            affects_pwd = 'Y';
            affects_vip = 'N';
          } else if (this.affects == "vip") {
            affects_golfer = 'N';
            affects_pwd = 'N';
            affects_vip = 'Y';
          }
          if (this.ddlenable == 'T') {
            this.fromdate = (this.fromdate == null) ? '' : this.fromdate;
            this.todate = (this.todate == null) ? '' : this.todate;
          }
          let fdate = (this.fromdate != '') ? moment(this.fromdate).format('MM/DD/YYYY') : '';
          let todate = (this.todate != '') ? moment(this.todate).format('MM/DD/YYYY') : '';
          var Hazardsinfo = { "action": this.action, "id": this.hzid, "htid": this.ddlhazardtypes, "hdid": this.holeid, "name": this.txthazardlabel, "enabled": this.ddlenable, "fromdate": fdate, "todate": todate, "affectsgolfer": affects_golfer, "affectspwd": affects_pwd, "affectsvip": affects_vip, "color": this.txtcolor, "status": rdstatus, "showstatus": rdstatus, "userid": this.userid };
          var model = { "HazardPerimeters": this.addedithazardperimetersdata, "hz": Hazardsinfo };
          if (this.ddlenable == 'T' && fdate != '' && todate != '') {
            if (fdate <= todate) {
              this.saveHazards(model);
            }
            else {
              let msg = '<span style="color: red">From Date should be less than or equal to To Date</span>';
              this.toastMessage(msg);
              this.savebtndisable = false;
              this.spinnerService.hide();
            }
          } else if (this.ddlenable == 'T' && ((fdate == '' && todate == '') || (fdate != '' && todate == '') || (fdate == '' && todate != ''))) {
            let msg = '<span style="color: red">Please enter valid dates</span>';
            this.toastMessage(msg);
            this.savebtndisable = false;
            this.spinnerService.hide();
          }
          else {
            this.saveHazards(model);
          }
        } else {
          this.savebtndisable = false;
          this.spinnerService.hide();
          let msg = '<span style="color: red">Please draw hazard perimeters</span>';
          this.toastMessage(msg);
        }
      }
    }
  }

  saveHazards(model) {
    this.spinnerService.show();
    this.api.postOH('SaveGeofenceandPerimeters', model).subscribe(
      (response) => {
        if (response.SaveGeofenceandPerimetersResult[2] == "success") {
          if (this.action == 'A') {
            let msg = '<span style="color: green">Hazard Perimeters Saved Successfully.</span>';
            this.toastMessage(msg);
          } else {
            let msg = '<span style="color: green">Hazard Perimeters Updated Successfully.</span>';
            this.toastMessage(msg);
          }
          this.hzid = response.SaveGeofenceandPerimetersResult[0];
          this.cartType = response.SaveGeofenceandPerimetersResult[1].toLowerCase();
          this.edithazard();
          this.gethacoursehazardperimeters();
          if (this.hzid > 0 && this.cartType != 'cart path only') {
            this.getHazardAudiodata(); this.audioInfo = "Block"; this.cartTypeCount = '0';
          }
          else {
            this.audioInfo = "none"; this.cartTypeCount = '1';
          }
        } else {
          let msg = '<span style="color: red">Something went wrong, please try again</span>';
          this.toastMessage(msg);
        }
        this.savebtndisable = false;
        this.spinnerService.hide();
      },
      error => {
        this.savebtndisable = false;
        this.spinnerService.hide();
      }
    );
  }

  deletehazard(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }

  confirm(): void {
    this.modalRef.hide();
    var Hazardsinfo = { "action": "U", "id": this.hzid, "htid": '0', "hdid": this.ddlhole, "name": "test", "status": 'D', "showstatus": 'N' };
    this.api.postOH('updatehazardstatus', Hazardsinfo).subscribe(
      (response) => {
        if (response == "Hazard Status Updated Successfully") {
          let msg = '<span style="color: green">Hazard Deleted Successfully</span>';
          this.toastMessage(msg);
          this.router.navigate(['/perimeters/geofenceview']);
        } else {
          let msg = '<span style="color: red">Something went wrong, please try again</span>';
          this.toastMessage(msg);
        }
      },
      error => {

      }
    );
  }

  decline(): void {
    this.modalRef.hide();
  }

  getAlertAudioList() {
    this.alertaudiolistdata = [];
    this.alertaudiolistdata = [{ value: -1, name: '--Select Audio--', filepath: '' }];
    let parameters = {
      searchvalue: " WHERE AAF_STATUS='Y' "
    };
    this.api.postOH('GetAlertAudioFiles', parameters).subscribe(
      (response) => {
        for (var i = 0; i < response.length; i++) {
          this.alertaudiolistdata.push({
            value: response[i].id,
            name: response[i].filename,
            filepath: response[i].filepath
          });
        }
        this.alertaudiolistdata.push({
          value: '0',
          name: 'Add',
          filepath: ''
        });
      }, error => {
      }
    );
    this.ddlhazardaudio = "-1";
  }

  audiochangeevent(val) {
    this.audiofilepath = "";
    this.audiofilename = "";
    this.audiofilecropped = "";
    if (audio != undefined) {
      audio.pause();
    }
    this.checkaudiofile = '';
    if (this.ddlhazardaudio == "0") {
      this.audioplaybtn = false;
      this.audiostopbtn = false;
    } else {
      this.checkaudiofile = this.alertaudiolistdata[val.target.selectedIndex].filepath;
      this.audioplaybtn = true;
      this.audiostopbtn = false;
    }
  }

  playaudiofile() {
    this.audioplaybtn = false;
    this.audiostopbtn = true;
    audio.src = this.checkaudiofile;
    audio.loop = true;
    audio.play();
  }

  mute() {
    if (audio.muted) {
      audio.muted = false;
      mutebtn.style.background = "url(assets/imgs/speaker.png) no-repeat";
    } else {
      audio.muted = true;
      mutebtn.style.background = "url(assets/imgs/speaker_muted.png) no-repeat";
    }
  }

  setvolume() {
    if (volumeslider.value == 0) {
      audio.muted = true;
      mutebtn.style.background = "url(assets/imgs/speaker_muted.png) no-repeat";
    } else {
      audio.muted = false;
      mutebtn.style.background = "url(assets/imgs/speaker.png) no-repeat";
    }
    if (audio != undefined) {
      audio.volume = volumeslider.value / 100;
      soundlblval.textContent = volumeslider.value;
    } else {
      soundlblval.textContent = 10;
    }
  }

  stopaudiofile() {
    this.audioplaybtn = true;
    this.audiostopbtn = false;
    audio.pause();
  }

  gridplayaudiofile(audiodata, ival) {
    for (let i = 0; i < this.hazardaudiodata.length; i++) {
      if (i == ival) {
        this.hazardaudiodata[i].gridaudioplaybtn = false;
        this.hazardaudiodata[i].gridaudiostopbtn = true;
      } else {
        this.hazardaudiodata[i].gridaudioplaybtn = true;
        this.hazardaudiodata[i].gridaudiostopbtn = false;
      }
    }
    gridaudio.src = audiodata.audiofilepath;
    gridaudio.loop = true;
    gridaudio.volume = (parseInt(audiodata.sound) * 10) / 100;
    gridaudio.play();
  }

  gridstopaudiofile(audiodata, ival) {
    for (let i = 0; i < this.hazardaudiodata.length; i++) {
      if (i == ival) {
        this.hazardaudiodata[i].gridaudioplaybtn = true;
        this.hazardaudiodata[i].gridaudiostopbtn = false;
      }
    }
    gridaudio.pause();
  }


  fileChange(input, audiofile) {
    this.readFiles(input.files, audiofile);
  }

  readFiles(files, audiofile, index = 0) {
    // Create the file reader  
    let reader = new FileReader();
    // If there is a file  
    if (index in files) {
      // Start reading this file  
      this.readFile(files[index], audiofile, reader, (result) => {
        // Create an img element and add the image file data to it  
        var img = document.createElement("img");
        img.src = result;
      });
    } else {
      // When all files are done This forces a change detection  
      // this.changeDetectorRef.detectChanges();
    }
  }

  readFile(file, audiofile, reader, callback) {
    reader.onload = () => {
      callback(reader.result);
      if (audiofile == 'audio') {
        this.audiofilepath = reader.result;
        let base64str = reader.result;
        this.audiofilename = file.name;
        this.audiofilecropped = (base64str != "") ? base64str.replace(/^data:audio\/(mp3|mp4);base64,/, "") : "";
      }
    }
    reader.readAsDataURL(file);
  }

  getHazardAudiodata() {
    let parameters = { searchvalue: " WHERE HAS_HZ_ID=" + this.hzid + " AND HAS_STATUS!='D' " };
    this.spinnerService.show();
    this.api.postOH('GetHazardAudioList', parameters).subscribe(
      response => {
        this.hazardaudiodata = [];
        if (response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            this.hazardaudiodata.push({
              "id": response[i].id,
              "hazardid": response[i].hazardid,
              "audioid": response[i].audioid,
              "audiofilename": response[i].audiofilename,
              "audiofilepath": response[i].audiofilepath,
              "titlename": response[i].titlename,
              "titlecolor": response[i].titlecolor,
              "iconname": (response[i].iconname == "") ? "Select" : response[i].iconname,
              "iconcolor": response[i].iconcolor,
              "message": response[i].message,
              "distance": response[i].distance,
              "audiorepeat": response[i].audiorepeat,
              "sound": response[i].sound,
              "status": response[i].status,
              "gridaudioplaybtn": true,
              "gridaudiostopbtn": false
            });
          }
        }
        this.spinnerService.hide();
      },
      err => {
        this.spinnerService.hide();
      }
    );
  }

  saveaudiodata() {
    if (!this.hazardAudioForm.valid) {

    }
    let audiordstatus = ''; let repeataudio = ''; var locfilename = this.audiofilename;
    this.audiofilename = locfilename.replace(' ', '_');
    this.audiosubmitAttempt = true;
    if (this.hazardAudioForm.valid) {
      if (this.txtdistance >= 3 && this.iconname != "Select") {
        this.audiosavebtndisable = true;
        var soundval = Math.round(volumeslider.value / 10);
        if (this.audioaction == 'A') {
          audiordstatus = 'Y';
        } else {
          audiordstatus = (this.audiochksts == true) ? 'Y' : 'N';
        }
        if (this.audioaction == 'A') {
          repeataudio = 'N';
        } else {
          repeataudio = (this.chkRepeat == true) ? 'Y' : 'N';
        }
        if (this.iconname == "warning") {
          this.iconcolor = "#EE1D26"; this.titlecolor = "#EE1D26";
        }
        if (this.iconname == "information-circle") {
          this.iconcolor = "#fca404"; this.titlecolor = "#fca404";
        }
        var model = {
          "action": this.audioaction, "id": this.hasid, "hazardid": this.hzid,
          "audioid": this.ddlhazardaudio, "titlename": this.titlename,
          "titlecolor": this.titlecolor, "iconname": this.iconname,
          "iconcolor": this.iconcolor, "message": this.txtmessage,
          "distance": this.txtdistance, "sound": soundval, "status": audiordstatus,
          "userid": this.userid, "audiofilename": this.audiofilename,
          "audiobinarypath": this.audiofilecropped, "audiorepeat": repeataudio
        };
        this.spinnerService.show();
        this.api.postOH('SaveHazardAudioList', model).subscribe(
          (response) => {
            if (response[1] == 'success') {
              let msg = '';
              if (this.audioaction == 'A') {
                msg = '<span style="color: green">Hazard Audio File Added Successfully</span>';
              } else if (this.audioaction == 'U') {
                msg = '<span style="color: green">Hazard Audio File Updated Successfully</span>';
              }
              this.toastMessage(msg);
              this.getHazardAudiodata();
              this.hazardAudioForm.reset();
              this.audiosubmitAttempt = false;
              this.ddlhazardaudio = '-1';
              this.titlename = '';
              this.titlecolor = '';
              this.iconname = 'Select';
              this.iconcolor = '';
              this.txtdistance = '';
              this.txtmessage = '';
              this.audioaction = 'A';
              this.hasid = 0;
              volumeslider.value = 10;
              soundlblval.textContent = 10;
            } else {
              let msg = '<span style="color: red">Something went wrong, please try again.</span>';
              this.toastMessage(msg);
            }
            this.audiosavebtndisable = false;
            this.spinnerService.hide();
            this.desclength = 180; this.txtdistance = 5;
          },
          error => {
            this.audiosavebtndisable = false;
            this.spinnerService.hide();
          }
        );
      }
    }
  }

  edithazardaudiofile(lochzaudiodata) {
    this.audioaction = 'U';
    this.hasid = lochzaudiodata.id;
    this.hzid = lochzaudiodata.hazardid;
    this.ddlhazardaudio = lochzaudiodata.audioid;
    this.titlename = lochzaudiodata.titlename;
    this.titlecolor = lochzaudiodata.titlecolor;
    this.iconname = lochzaudiodata.iconname;
    this.iconcolor = lochzaudiodata.iconcolor;
    this.txtdistance = lochzaudiodata.distance;
    this.txtmessage = lochzaudiodata.message;
    this.desclength = 180 - this.txtmessage.length;
    this.chkRepeat = (lochzaudiodata.audiorepeat == 'Y') ? true : false;
    this.audiochksts = (lochzaudiodata.status == 'Y') ? true : false;
    this.audiofilename = lochzaudiodata.audiofilename;
    this.checkaudiofile = lochzaudiodata.audiofilepath;
    this.audiofilecropped = '';
    this.audioplaybtn = true;
    this.audiostopbtn = false;
    volumeslider.value = parseInt(lochzaudiodata.sound) * 10;
    this.setvolume();
  }

  deletehazardaudiofile(hzaudiodata) {
    this.audioaction = 'D';
    var model = {
      "action": this.audioaction, "id": hzaudiodata.id, "hazardid": 0, "audioid": 1,
      "titlename": "", "titlecolor": "", "iconname": "", "iconcolor": "",
      "message": "", "distance": "", "sound": "0", "status": 'D',
      "userid": this.userid, "audiofilename": '', "audiobinarypath": '',
      "audiorepeat": hzaudiodata.audiorepeat
    };
    this.spinnerService.show();
    this.api.postOH('SaveHazardAudioList', model).subscribe(
      (response) => {
        if (response[1] == 'success') {
          let msg = '<span style="color: green">Hazard Audio File Deleted Successfully</span>';
          this.toastMessage(msg);
          this.getHazardAudiodata();
          this.ddlhazardaudio = '-1';
          this.titlename = '';
          this.titlecolor = '';
          this.iconname = 'Select';
          this.iconcolor = '';
          this.txtdistance = '';
          this.txtmessage = '';
          this.audioaction = 'A';
          this.hasid = 0;
          this.audiosubmitAttempt = false;
          this.txtdistance = 5;
        } else {
          let msg = '<span style="color: red">Something went wrong, please try again.</span>';
          this.toastMessage(msg);
        }
        this.spinnerService.hide();
      },
      error => {
        this.spinnerService.hide();
      }
    );
  }


  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',
    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 5000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }

}
