import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CartpathmanagementComponent } from './cartpathmanagement.component';

describe('CartpathmanagementComponent', () => {
  let component: CartpathmanagementComponent;
  let fixture: ComponentFixture<CartpathmanagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CartpathmanagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CartpathmanagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
