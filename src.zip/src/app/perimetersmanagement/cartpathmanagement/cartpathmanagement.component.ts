import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Router } from '@angular/router';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Title } from '@angular/platform-browser';
import * as moment from "moment";

declare const google: any;
var currentZoom; var minZoom; var maxZoom;

@Component({
    selector: 'app-cartpathmanagement',
    templateUrl: './cartpathmanagement.component.html',
    styleUrls: ['./cartpathmanagement.component.css']
})
export class CartpathmanagementComponent implements OnInit {
    modalRef: BsModalRef; modalRef1: BsModalRef;
    clubId: any; courseId: any;
    hazardTypes: any = []; cartPathList: any = []; duplicateCartPathList: any = []; audioSoundList: any = []; courseDetails: any = [];
    public cartPathForm: FormGroup; submitAttempt: boolean = false; subBtn: any;
    courselat: any = ''; courselong: any = ''; temporaryBlock: string; courseValue: any = ''; offset: any = '';
    cartPathHazardId: number; holeId: number; hazardTypeId: number; holeName: any = '';
    enable: any; noOfDays: any; fromDate: any; toDate: any; off: any; on: any;
    firstYard: number; secondYard: number; BCtitleName: any; BCiconName: any; BCtitleColor: any; BCiconColor: any;
    BCmessage: any; hazardStatus: any;
    IStitleName: any; ISmessage: any; ISiconName: any; IStitleColor: any; ISiconColor: any;
    Days: any = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30];
    minStartDate: any; //minEndStartDate: any;
    minEndDate: any; currentGolfClubDateTime: any = ''; hazardMessage: any = ''; audioMessage: any = '';
    timeoffset: any = ''; BCdesclength: any; ISdesclength: any; temp: any; perm: any; userId: any;
    map: any; coursezoomlevel: any; setHazards: string;
    action: any; addedithazardperimetersdata: any = []; hazardpolylinecoordinatesview: any = [];
    viewhztypecolor: any; viewhazardline: any = [];
    hazarddrawpolylinecoordinates: any = []; latlngarry: any; flightPath: any; hazardline: any = [];
    public txtcolor: string = "#FF0000";
    clat: any; clong: any; czoomlevel: any; crotate: any; savebtnshow: any;
    showCartPath: string; hideCartPath: string;
    constructor(private title: Title, private router: Router, public api: ApiService, public toastr: ToastsManager,
        public formBuilder: FormBuilder, vcr: ViewContainerRef, private spinnerService: Ng4LoadingSpinnerService,
        private modalService: BsModalService) {
        this.title.setTitle("IZON - CartPath");
        this.toastr.setRootViewContainerRef(vcr);
        this.clubId = localStorage.getItem('clubId');
        this.off = '1'; this.on = '0'; this.cartPathHazardId = 0; this.enable = ''; this.holeId = 0; this.hazardTypeId = 0;
        this.temp = '0'; this.perm = '0'; this.holeName = '';
        this.BCdesclength = 180; this.ISdesclength = 180; this.firstYard = -1; this.secondYard = -1; this.BCiconName = 'warning';
        this.ISiconName = 'warning';
        this.userId = localStorage.getItem('userId');
        this.setHazards = "none";
    }

    ngOnInit() {
        this.cartPathForm = this.formBuilder.group({
            fFirstYard: [0],
            fBCTitleName: ['', Validators.compose([Validators.required])],
            fBCIconName: [''],
            fBCMessage: ['', Validators.compose([Validators.required])],
            fSecondYard: [0],
            fISTitleName: ['', Validators.compose([Validators.required])],
            fISIconName: [''],
            fISMessage: ['', Validators.compose([Validators.required])],
            fDays: [''],
            fFromDate: [''],
            fToDate: ['']
        });
        this.getCourseDetails();
    }

    getCourseDetails() {
        this.courseDetails = [];
        let parameters = { searchvalue: " WHERE GC_GCB_ID='" + this.clubId + "' AND GC_STATUS='Y'" };
        this.api.postOH('getgolfcourse', parameters).subscribe(
            (response) => {
                if (response.length > 0) {
                    for (let i = 0; i < response.length; i++) {
                        this.courseDetails.push({
                            value: response[i].id,
                            name: response[i].labelname.toUpperCase(),
                            selected: false
                        });
                    }
                    this.courselat = response[0].latitude;
                    this.courselong = response[0].longitude;
                    this.timeoffset = response[0].timeoffset;
                    this.coursezoomlevel = (response[0].zoomlevel != '') ? response[0].zoomlevel : 0;
                    this.courseDetails[0].selected = true;
                    this.getCourseDateTime();
                }
            });
    }

    getCourseDateTime() {
        let currentDate: any = ''; this.currentGolfClubDateTime = '';
        let d = new Date();
        let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
        currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
        this.currentGolfClubDateTime = currentDate;
        this.minStartDate = this.minEndDate = this.fromDate = this.currentGolfClubDateTime;
        this.toDate = moment(this.currentGolfClubDateTime).add(1, 'd').toDate();
        this.noOfDays = moment(this.toDate, 'MM.DD.YY').diff(moment(this.fromDate, 'MM.DD.YY'), 'days');
        this.getHazardTypes();
    }

    setToDate(days) {
        this.toDate = moment(this.currentGolfClubDateTime).add(days, 'd').toDate();
    }

    setNoOfDays() {
        this.noOfDays = moment(this.toDate, 'MM.DD.YY').diff(moment(this.fromDate, 'MM.DD.YY'), 'days');
    }

    onPermanentChange(enable, hazardId, i, sNo) {
        if (this.cartPathList[i].enable == 'checked') {

        }
        else {
            if (enable == 'checked') {
                this.cartPathList[i].enable = '';
                this.cartPathList[i].tempenable = 'checked';
            } else {
                this.cartPathList[i].enable = 'checked';
                this.cartPathList[i].tempenable = '';
            }
        }
        this.getCartPathAudioFiles(hazardId, sNo);
    }

    onTemporaryChange(tempenable, hazardId, i, sNo) {
        if (this.cartPathList[i].tempenable == 'checked') {

        }
        else {
            if (tempenable == 'checked') {
                this.cartPathList[i].tempenable = '';
                this.cartPathList[i].enable = 'checked';
            } else {
                this.cartPathList[i].tempenable = 'checked';
                this.cartPathList[i].enable = '';
            }
        }
        this.getCartPathAudioFiles(hazardId, sNo);
    }

    getHazardTypes() {
        this.hazardTypes = []; this.courseValue = '';
        let parameters = {
            searchvalue: " WHERE HZT_GCB_ID='" + this.clubId + "' and HZT_STATUS='Y'"
        };
        this.api.postOH('GetHarardTypes', parameters).subscribe(
            (response) => {
                if (response.length > 0) {
                    for (var i = 0; i < response.length; i++) {
                        let type = response[i].name.toLowerCase();
                        if ((type.indexOf('cart path only') >= 0)) {
                            this.hazardTypes.push({
                                value: response[i].id,
                                name: response[i].name,
                                color: response[i].color
                            });
                        }
                    }
                    this.courseValue = this.courseDetails[0].value;
                    if (this.hazardTypes.length > 0) {
                        let params = {
                            "ClubId": this.clubId, "CourseId": this.courseDetails[0].value, "HazardTypeId": this.hazardTypes[0].value
                        };
                        this.getCartPaths(params);
                    }
                    else {
                        this.hazardMessage = 'No cart path hazards exists'; this.audioMessage = 'No alerts assigned';
                        this.temporaryBlock = "none";
                    }
                }
                else {
                    this.hazardMessage = 'No cart path hazards exists'; this.audioMessage = 'No alerts assigned';
                    this.temporaryBlock = "none";
                }
            }, error => {
            }
        );
    }

    setCartPathData(course) {
        this.courseValue = '';
        this.submitAttempt = false;
        this.cartPathForm.controls['fBCTitleName'].reset();
        this.cartPathForm.controls['fBCMessage'].reset();
        this.cartPathForm.controls['fISTitleName'].reset();
        this.cartPathForm.controls['fISMessage'].reset();
        this.courseValue = course.value;
        for (var i = 0; i < this.courseDetails.length; i++) {
            if (this.courseValue == this.courseDetails[i].value) {
                this.courseDetails[i].selected = true;
            }
            else {
                this.courseDetails[i].selected = false;
            }
        }
        if (this.hazardTypes.length > 0) {
            let params = {
                "ClubId": this.clubId, "CourseId": this.courseValue, "HazardTypeId": this.hazardTypes[0].value
            };
            this.getCartPaths(params);
        }
        else {
            this.hazardMessage = 'No cart path hazards exists'; this.audioMessage = 'No alerts assigned';
            this.temporaryBlock = "none";
        }
    }

    getCartPaths(params) {
        this.cartPathList = []; this.duplicateCartPathList = []; this.hazardMessage = '';
        this.spinnerService.show();
        this.api.postOH('GetCartPathHazards', params).subscribe(
            (response) => {
                this.cartPathList = []; this.duplicateCartPathList = [];
                if (response.ResponseCode == "Success") {
                    for (var i = 0; i < response.CartPathsList.length; i++) {
                        this.cartPathList.push({
                            sNo: response.CartPathsList[i].sNo,
                            hazardId: response.CartPathsList[i].hazardId,
                            hazardTypeId: response.CartPathsList[i].hazardTypeId,
                            holeId: response.CartPathsList[i].holeId,
                            holeName: response.CartPathsList[i].holeName,
                            hazardName: response.CartPathsList[i].hazardName,
                            enable: (response.CartPathsList[i].enable == 'A') ? 'checked' : '',
                            tempenable: (response.CartPathsList[i].enable == 'T') ? 'checked' : '',
                            fromDate: response.CartPathsList[i].fromDate,
                            toDate: response.CartPathsList[i].toDate,
                            hazardStatus: response.CartPathsList[i].hazardStatus,
                            holeSelected: false
                        });
                        this.duplicateCartPathList.push({
                            sNo: response.CartPathsList[i].sNo,
                            hazardId: response.CartPathsList[i].hazardId,
                            hazardTypeId: response.CartPathsList[i].hazardTypeId,
                            holeId: response.CartPathsList[i].holeId,
                            holeName: response.CartPathsList[i].holeName,
                            hazardName: response.CartPathsList[i].hazardName,
                            enable: (response.CartPathsList[i].enable == 'A') ? 'checked' : '',
                            tempenable: (response.CartPathsList[i].enable == 'T') ? 'checked' : '',
                            fromDate: response.CartPathsList[i].fromDate,
                            toDate: response.CartPathsList[i].toDate,
                            hazardStatus: response.CartPathsList[i].hazardStatus,
                            holeSelected: false
                        });
                    }
                    this.getCartPathAudioFiles(this.cartPathList[0].hazardId, this.cartPathList[0].sNo);
                }
                else if (response.ResponseCode == "Empty") {
                    this.hazardMessage = 'No cart path hazards exists'; this.temporaryBlock = "none";
                    this.audioMessage = 'No alerts assigned';
                }
                this.spinnerService.hide();
                window.scrollTo(0, 0);
            }, error => {
                this.spinnerService.hide();
            }
        );
    }

    getCartPathAudioFiles(hazardId, sNo) {
        this.clearHazardPerimeters();
        this.cartPathHazardId = 0; this.holeId = 0; this.hazardTypeId = 0; this.holeName = '';
        this.setHazards = "none";
        this.enable = ''; this.fromDate = ''; this.toDate = ''; this.minEndDate = '';
        this.temp = '0'; this.perm = '0'; this.submitAttempt = false;
        this.cartPathForm.controls['fBCTitleName'].reset();
        this.cartPathForm.controls['fBCMessage'].reset();
        this.cartPathForm.controls['fISTitleName'].reset();
        this.cartPathForm.controls['fISMessage'].reset();
        for (var i = 0; i < this.cartPathList.length; i++) {
            if (sNo === this.cartPathList[i].sNo) {
                this.cartPathList[i].holeSelected = true;
                if (this.cartPathList[i].tempenable == 'checked') {
                    if (this.cartPathList[i].fromDate == '01/01/1900' && this.cartPathList[i].toDate == '01/01/1900') {
                        this.fromDate = this.currentGolfClubDateTime;
                        this.minStartDate = this.currentGolfClubDateTime;
                        this.toDate = moment(this.currentGolfClubDateTime).add(1, 'd').toDate();
                        this.minEndDate = this.currentGolfClubDateTime;
                        this.temporaryBlock = "block"; //this.minEndStartDate = '';
                    } else {
                        this.fromDate = new Date(this.cartPathList[i].fromDate);
                        this.toDate = new Date(this.cartPathList[i].toDate);
                        if (moment(this.fromDate).format('MM/DD/YYYY') > moment(this.currentGolfClubDateTime).format('MM/DD/YYYY')) {
                            this.minStartDate = this.currentGolfClubDateTime;
                        } else {
                            this.minStartDate = new Date(this.cartPathList[i].fromDate);
                        }
                        if (moment(this.toDate).format('MM/DD/YYYY') > moment(this.currentGolfClubDateTime).format('MM/DD/YYYY')) {
                            this.minEndDate = this.currentGolfClubDateTime;
                        } else {
                            this.minEndDate = new Date(this.cartPathList[i].toDate);
                        }
                        this.temporaryBlock = "block";
                    }
                } else {
                    this.fromDate = this.currentGolfClubDateTime;
                    this.toDate = moment(this.currentGolfClubDateTime).add(1, 'd').toDate();
                    this.temporaryBlock = "none";
                }
                this.enable = (this.cartPathList[i].enable == 'checked') ? 'A' : 'T';
                this.cartPathHazardId = this.cartPathList[i].hazardId;
                this.holeName = this.cartPathList[i].holeName;
                this.holeId = this.cartPathList[i].holeId;
                this.hazardTypeId = this.cartPathList[i].hazardTypeId;
                if (this.cartPathHazardId > 0) {
                    this.showCartPath = "block"; this.hideCartPath = "none";
                } else {
                    this.showCartPath = "none"; this.hideCartPath = "block";
                }
                if (this.cartPathList[i].hazardStatus == 'N') {
                    this.off = '1'; this.on = '0'; this.hazardStatus = 'N';
                }
                else {
                    this.on = '1'; this.off = '0'; this.hazardStatus = 'Y';
                }
            }
            else {
                this.cartPathList[i].holeSelected = false;
            }
        }

        let parameters: any = ''; this.audioMessage = '';
        parameters = {
            "HazardId": hazardId
        };
        this.audioSoundList = [];
        this.spinnerService.show();
        this.api.postOH('GetCartPathAudioFiles', parameters).subscribe(
            (response) => {
                this.audioSoundList = [];
                if (response.ResponseCode == "Success") {
                    this.audioSoundList = response.CartPathAudioFilesList;
                    if (this.audioSoundList.length > 0) {
                        for (let i = 0; i < this.audioSoundList.length; i++) {
                            if (this.audioSoundList[i].audioDistance === 1) {
                                this.firstYard = this.audioSoundList[i].audioFileId;
                                this.BCtitleName = this.audioSoundList[i].audioTitle;
                                this.BCiconName = this.audioSoundList[i].audioIconName;
                                this.BCmessage = this.audioSoundList[i].audioMessage;
                                this.BCdesclength = 180 - this.BCmessage.length;
                                this.BCtitleColor = this.audioSoundList[i].titleColor;
                                this.BCiconColor = this.audioSoundList[i].audioIconColor;
                            }
                            if (this.audioSoundList[i].audioDistance === 0) {
                                this.secondYard = this.audioSoundList[i].audioFileId;
                                this.IStitleName = this.audioSoundList[i].audioTitle;
                                this.ISiconName = this.audioSoundList[i].audioIconName;
                                this.ISmessage = this.audioSoundList[i].audioMessage;
                                this.ISdesclength = 180 - this.ISmessage.length;
                                this.IStitleColor = this.audioSoundList[i].titleColor;
                                this.ISiconColor = this.audioSoundList[i].audioIconColor;
                            }
                        }
                    }
                }
                else if (response.ResponseCode == "Empty") {
                    this.audioSoundList = []; this.audioMessage = 'No alerts assigned';
                    this.firstYard = -1; this.secondYard = -1; this.submitAttempt = false;
                    this.BCmessage = ''; this.BCtitleName = ''; this.BCiconName = 'warning';
                    this.ISmessage = ''; this.IStitleName = ''; this.ISiconName = 'warning';
                    this.BCdesclength = 180; this.ISdesclength = 180;
                }
                this.spinnerService.hide();
            }, error => {
                this.spinnerService.hide();
            }
        );
        for (var i = 0; i < this.cartPathList.length; i++) {
            if (sNo != this.cartPathList[i].sNo) {
                Object.assign(this.cartPathList[i], this.duplicateCartPathList[i]);
            }
        }
    }

    saveCartPath() {
        var cartPathHazardsModal = []; var audioHazardsModal = [];
        if (this.BCiconName == "warning") {
            this.BCiconColor = "#EE1D26"; this.BCtitleColor = "#EE1D26";
        }
        else if (this.BCiconName == "information-circle") {
            this.BCiconColor = "#fca404"; this.BCtitleColor = "#fca404";
        }

        if (this.ISiconName == "warning") {
            this.ISiconColor = "#EE1D26"; this.IStitleColor = "#EE1D26";
        }
        else if (this.ISiconName == "information-circle") {
            this.ISiconColor = "#fca404"; this.IStitleColor = "#fca404";
        }
        this.BCmessage = (this.BCmessage) == (null || undefined) ? '' : this.BCmessage;
        this.BCtitleName = (this.BCtitleName) == (null || undefined) ? '' : this.BCtitleName;
        this.ISmessage = (this.ISmessage) == (null || undefined) ? '' : this.ISmessage;
        this.IStitleName = (this.IStitleName) == (null || undefined) ? '' : this.IStitleName;
        if (this.fromDate != ('' || null) && this.toDate != ('' || null)) {
            if (this.fromDate <= this.toDate) {
                if (!this.cartPathForm.valid) {

                }
                this.submitAttempt = true; this.subBtn = true;
                if (this.BCmessage != '' && this.BCtitleName != '' && this.ISmessage != '' && this.IStitleName != '') {
                    if (this.enable == 'A') {
                        this.fromDate = ''; this.toDate = '';
                    }
                    let fDate = (this.fromDate != '') ? moment(this.fromDate).format('MM/DD/YYYY') : '';
                    let toDate = (this.toDate != '') ? moment(this.toDate).format('MM/DD/YYYY') : '';
                    if (this.perm == '1') {
                        for (var i = 0; i < this.cartPathList.length; i++) {
                            if (this.cartPathList[i].hazardId > 0) {
                                cartPathHazardsModal.push({
                                    "HazardId": this.cartPathList[i].hazardId, "HoleId": this.cartPathList[i].holeId,
                                    "HazardTypeId": this.cartPathList[i].hazardTypeId, "HazardEnabled": this.enable,
                                    "FromDate": fDate, "ToDate": toDate, "HazardStatus": this.hazardStatus,
                                    "UserId": this.userId
                                });
                            }
                        }
                        this.cartPathHazardId = 0; this.holeId = 0; this.hazardTypeId = 0;
                    }
                    if (this.temp == '1') {
                        for (var j = 0; j < this.cartPathList.length; j++) {
                            if (this.cartPathList[j].hazardId > 0) {
                                cartPathHazardsModal.push({
                                    "HazardId": this.cartPathList[j].hazardId, "HoleId": this.cartPathList[j].holeId,
                                    "HazardTypeId": this.cartPathList[j].hazardTypeId, "HazardEnabled": this.enable,
                                    "FromDate": fDate, "ToDate": toDate, "HazardStatus": this.hazardStatus,
                                    "UserId": this.userId
                                });
                            }
                        }
                        this.cartPathHazardId = 0; this.holeId = 0; this.hazardTypeId = 0;
                    }
                    if (this.cartPathHazardId > 0) {
                        cartPathHazardsModal.push({
                            "HazardId": this.cartPathHazardId, "HoleId": this.holeId,
                            "HazardTypeId": this.hazardTypeId, "HazardEnabled": this.enable,
                            "FromDate": fDate, "ToDate": toDate, "HazardStatus": this.hazardStatus,
                            "UserId": this.userId
                        });
                    }
                    audioHazardsModal.push(
                        {
                            "AudioId": 0,
                            "AudioHazardId": this.cartPathHazardId,
                            "AudioFileId": this.firstYard,
                            "AudioMessage": this.BCmessage,
                            "AudioSoundLevel": 10,
                            "AudioRepeat": 'N',
                            "AudioDistance": 1,
                            "AudioTitleName": this.BCtitleName,
                            "AudioTitleColor": this.BCtitleColor,
                            "AudioIconName": this.BCiconName,
                            "AudioIconColor": this.BCiconColor,
                            "AudioStatus": 'Y'
                        }, {
                            "AudioId": 0,
                            "AudioHazardId": this.cartPathHazardId,
                            "AudioFileId": this.secondYard,
                            "AudioMessage": this.ISmessage,
                            "AudioSoundLevel": 10,
                            "AudioRepeat": 'Y',
                            "AudioDistance": 0,
                            "AudioTitleName": this.IStitleName,
                            "AudioTitleColor": this.IStitleColor,
                            "AudioIconName": this.ISiconName,
                            "AudioIconColor": this.ISiconColor,
                            "AudioStatus": 'Y'
                        });
                    if (cartPathHazardsModal.length > 0) {
                        let params = { "CartPathHazardsList": cartPathHazardsModal, "CartPathHazardsAudioList": audioHazardsModal }
                        this.spinnerService.show();
                        this.api.postOH('CartPathHazardsAudioList', params).subscribe(
                            response => {
                                if (response.CartPathHazardsAudioListResult == 'Success') {
                                    window.scrollTo(0, 0);
                                    this.spinnerService.hide();
                                    this.subBtn = false; this.BCdesclength = 180; this.ISdesclength = 180;
                                    let params = {
                                        "ClubId": this.clubId, "CourseId": this.courseValue, "HazardTypeId": this.hazardTypes[0].value
                                    };
                                    this.getCartPaths(params)
                                    let msg = '<span style="color: green">Cart path updated successfully</span>';
                                    this.toastMessage(msg);
                                    this.submitAttempt = false;
                                }
                                else {
                                    this.subBtn = false;
                                    let msg = '<span style="color: red">Falied to save the data, please try again</span>';
                                    this.toastMessage(msg);
                                    this.spinnerService.hide();
                                }
                            },
                            err => {
                                this.spinnerService.hide();
                                this.subBtn = false;
                                let msg = '<span style="color: red">Falied to save the data, please try again</span>';
                                this.toastMessage(msg);
                            }
                        );
                    }
                }
                else {
                    this.spinnerService.hide();
                    this.subBtn = false;
                }
            }
            else {
                let msg = '<span style="color: red">From Date should be less than or equal to To Date</span>';
                this.toastMessage(msg);
            }
        }
        else {
            let msg = '<span style="color: red">Please enter valid date</span>';
            this.toastMessage(msg);
        }
    }

    toastMessage(msg) {
        let options = {
            positionClass: 'toast-top-center',
        };

        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 5000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }

    cancel() {
        let params = {
            "ClubId": this.clubId, "CourseId": this.courseValue, "HazardTypeId": this.hazardTypes[0].value
        };
        this.getCartPaths(params)
    }

    setAllPermanent() {
        this.temp = '0';
        this.showCartPath = "block"; this.hideCartPath = "none";
        this.perm = '1'; this.enable = 'A'; this.temporaryBlock = "none";
        for (let i = 0; i < this.cartPathList.length; i++) {
            Object.assign(this.cartPathList[i], this.duplicateCartPathList[i]);
        }
        for (let i = 0; i < this.cartPathList.length; i++) {
            this.cartPathList[i].enable = 'checked';
            this.cartPathList[i].tempenable = '';
            this.cartPathList[i].holeSelected = false;
        }
        this.firstYard = -1; this.secondYard = -1; this.BCiconName = 'warning'; this.ISiconName = 'warning'; this.audioMessage = '';
        this.cartPathHazardId = 0; this.holeId = 0; this.hazardTypeId = 0; this.holeName = '';
        this.submitAttempt = false;
        this.cartPathForm.controls['fBCTitleName'].reset();
        this.cartPathForm.controls['fBCMessage'].reset();
        this.cartPathForm.controls['fISTitleName'].reset();
        this.cartPathForm.controls['fISMessage'].reset();
        this.BCdesclength = 180; this.ISdesclength = 180;
    }

    setAllTemporary(value) {
        this.temp = '1'; this.enable = 'T';
        this.showCartPath = "block"; this.hideCartPath = "none";
        this.perm = '0'; this.temporaryBlock = "Block";
        for (let i = 0; i < this.cartPathList.length; i++) {
            Object.assign(this.cartPathList[i], this.duplicateCartPathList[i]);
        }
        for (let i = 0; i < this.cartPathList.length; i++) {
            this.cartPathList[i].enable = '';
            this.cartPathList[i].tempenable = 'checked';
            this.cartPathList[i].holeSelected = false;
        }
        let currentDate: any = ''; this.currentGolfClubDateTime = '';
        let d = new Date();
        let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
        currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
        this.currentGolfClubDateTime = currentDate;
        this.minStartDate = this.minEndDate = this.fromDate = this.currentGolfClubDateTime;
        this.toDate = moment(this.currentGolfClubDateTime).add(1, 'd').toDate();
        this.noOfDays = moment(this.toDate, 'MM.DD.YY').diff(moment(this.fromDate, 'MM.DD.YY'), 'days');
        this.firstYard = -1; this.secondYard = -1; this.BCiconName = 'warning'; this.ISiconName = 'warning'; this.audioMessage = '';
        this.cartPathHazardId = 0; this.holeId = 0; this.hazardTypeId = 0; this.holeName = '';
        this.submitAttempt = false
        this.cartPathForm.controls['fBCTitleName'].reset();
        this.cartPathForm.controls['fBCMessage'].reset();
        this.cartPathForm.controls['fISTitleName'].reset();
        this.cartPathForm.controls['fISMessage'].reset();
        this.BCdesclength = 180; this.ISdesclength = 180;
    }

    manual(value) {
        this.hazardStatus = '';
        if (value == '1') {
            this.off = '1';
            this.on = '0';
            this.hazardStatus = 'N';
        }
        else {
            this.on = '1'
            this.off = '0';
            this.hazardStatus = 'Y';
        }
    }

    editHazard(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-md modal-lg-new modal-sm', ignoreBackdropClick: true });
        this.maploading(); this.setHazards = "block";
        let parameters = {
            "HazardId": this.cartPathHazardId
        };
        this.api.postOH('GetHazardPerimeters', parameters).subscribe(
            (response) => {
                if (response.ResponseCode == "Success") {
                    this.hazarddrawpolylinecoordinates = [];
                    for (var i = 0; i < response.HazardPerimetersList.length; i++) {
                        this.hazarddrawpolylinecoordinates.push({
                            lat: parseFloat(response.HazardPerimetersList[i].Latitude),
                            lng: parseFloat(response.HazardPerimetersList[i].Longitude)
                        });
                    }
                    this.txtcolor = (response.HazardPerimetersList[0].HazardColor) ? response.HazardPerimetersList[0].HazardColor : '#FF0000';
                    let parameters = {
                        searchvalue: " WHERE  HD_GCB_ID='" + this.clubId + "' AND HD_GC_ID='" + this.courseValue + "' and HD_ID='" + this.holeId + "' "
                    };
                    this.GetHoleLatLongDetails(parameters);
                    this.hazarddrawpolyline();
                    this.spinnerService.hide();
                    if (response.HazardPerimetersList.length > 0) {
                        this.action = 'U'; this.savebtnshow = false;
                    } else {
                        this.action = 'A';
                    }
                } else {
                    this.spinnerService.hide(); this.savebtnshow = true;
                    let parameters = {
                        searchvalue: " WHERE  HD_GCB_ID='" + this.clubId + "' AND HD_GC_ID='" + this.courseValue + "' and HD_ID='" + this.holeId + "' "
                    };
                    this.GetHoleLatLongDetails(parameters);
                    this.action = 'A';
                }
            }, error => { this.spinnerService.hide(); this.action = 'A'; }
        );
    }

    GetHoleLatLongDetails(parameters) {
        this.api.postOH('getholes', parameters).subscribe(
            (response) => {
                this.clat = response[0].clatitude;
                this.clong = response[0].clongitude;
                this.czoomlevel = (response[0].zoomlevel != '') ? response[0].zoomlevel : 0;
                this.crotate = (response[0].rotate == '') ? 0 : response[0].rotate;
                this.map.setCenter(new google.maps.LatLng(parseFloat(this.clat), parseFloat(this.clong)));
                this.map.setZoom(parseInt(this.czoomlevel));
            }, error => {
            }
        );
    }

    maploading() {
        this.map = new google.maps.Map(document.getElementById('map'), {
            center: { lat: parseFloat(this.courselat), lng: parseFloat(this.courselong) },
            zoom: parseInt(this.coursezoomlevel),
            mapTypeId: 'satellite',
            tilt: 0,
            rotateControl: true
        });
        this.setoverlayimage();

        var me = this;
        this.map.addListener('click', function (event) {
            if (me.action == 'A') {
                this.latlngarry = JSON.parse(JSON.stringify(event));
                me.hazarddrawpolylinecoordinates.push({
                    lat: parseFloat(this.latlngarry.latLng.lat),
                    lng: parseFloat(this.latlngarry.latLng.lng)
                });
                me.addedithazardperimetersdata.push({
                    'HZP_LATITUDE': this.latlngarry.latLng.lat,
                    'HZP_LONGITUDE': this.latlngarry.latLng.lng
                })
                me.hazarddrawpolyline();
            } else {
                let msg = "<span style='color: red'>Please delete previous hazard to create new hazard</span>";
                me.toastMessage(msg);
            }
        });
        this.spinnerService.hide();
    }

    setoverlayimage() {
        let me = this;
        for (let i = 0; i < this.courseDetails.length; i++) {
            var imageMapType = new google.maps.ImageMapType({
                getTileUrl: function (coord, zoom) {
                    return ['http://cp.izongolf.com/tiles/' + me.clubId + '/' + me.courseDetails[i].value + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
                },
                tileSize: new google.maps.Size(256, 256)
            });
            this.map.overlayMapTypes.push(imageMapType);
        }
    }

    hazarddrawpolyline() {
        this.flightPath = new google.maps.Polyline({
            path: this.hazarddrawpolylinecoordinates,
            geodesic: true,
            strokeColor: this.txtcolor,
            strokeOpacity: 1.0,
            strokeWeight: 5
        });
        this.hazardline.push(this.flightPath);
        this.flightPath.setMap(this.map);
    }

    clearHazardPerimeters() {
        this.savebtnshow = true;
        for (var i = 0; i < this.hazardline.length; i++) {
            this.hazardline[i].setMap(null);
        }
        this.hazarddrawpolylinecoordinates = [];
        this.addedithazardperimetersdata = [];
        this.action = 'A';
    }

    saveHazardPerimeters() {
        if (this.addedithazardperimetersdata.length > 0) {
            this.addedithazardperimetersdata.push({
                'HZP_LATITUDE': this.addedithazardperimetersdata[0].HZP_LATITUDE,
                'HZP_LONGITUDE': this.addedithazardperimetersdata[0].HZP_LONGITUDE
            });
            let fDate = (this.fromDate != '') ? moment(this.fromDate).format('MM/DD/YYYY') : '';
            let toDate = (this.toDate != '') ? moment(this.toDate).format('MM/DD/YYYY') : '';
            var hazardsModel = {
                "HazardId": this.cartPathHazardId, "HoleId": this.holeId,
                "HazardTypeId": this.hazardTypeId, "HazardEnabled": this.enable,
                "FromDate": fDate, "ToDate": toDate, "UserId": this.userId
            };
            var model = { "CartPathHazardGeofenceList": this.addedithazardperimetersdata, "hazardsModel": hazardsModel };
            this.spinnerService.show();
            this.api.postOH('SaveCartPathHazardPerimerters', model).subscribe(
                (response) => {
                    this.savebtnshow = false;
                    if (response.SaveCartPathHazardPerimertersResult == "Success") {
                        let msg = '<span style="color: green">Hazard Perimeters created successfully</span>';
                        this.toastMessage(msg);
                    } else {
                        let msg = '<span style="color: red">Something went wrong, please try again</span>';
                        this.toastMessage(msg);
                    }
                    this.spinnerService.hide();
                },
                error => {
                    this.spinnerService.hide();
                }
            );
        } else {
            this.spinnerService.hide();
            let msg = '<span style="color: red">Please draw hazard perimeters</span>';
            this.toastMessage(msg);
        }
    }

    onKeyUp(event: any) {
        this.BCdesclength = 180 - event.target.value.length;
        this.ISdesclength = 180 - event.target.value.length;
    };

    declinetemplate(template1: TemplateRef<any>): void {
        this.modalRef1 = this.modalService.show(template1, { class: 'modal-sm', ignoreBackdropClick: true });
    }

    confirm(): void {
        this.modalRef1.hide(); this.modalRef.hide();
        this.clearHazardPerimeters();
        let params = {
            "ClubId": this.clubId, "CourseId": this.courseValue, "HazardTypeId": this.hazardTypes[0].value
        };
        this.getCartPaths(params);
    }

    decline(): void {
        this.modalRef1.hide();
    }
}

