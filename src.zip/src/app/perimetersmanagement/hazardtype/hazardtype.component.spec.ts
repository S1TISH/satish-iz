import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HazardtypeComponent } from './hazardtype.component';

describe('HazardtypeComponent', () => {
  let component: HazardtypeComponent;
  let fixture: ComponentFixture<HazardtypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HazardtypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HazardtypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
