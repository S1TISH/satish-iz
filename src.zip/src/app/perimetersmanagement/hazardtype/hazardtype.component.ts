import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
//import { ModalService } from 'ng-bootstrap-modal';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-hazardtype',
  templateUrl: './hazardtype.component.html',
  styleUrls: ['./hazardtype.component.css']
})
export class HazardtypeComponent implements OnInit {

  modalRef: BsModalRef;
  public hzdTypeForm: FormGroup; submitAttempt: boolean = false; divheader: string = "Add Hazard Type";
  searchtxt: boolean = true; searchddl: boolean = false;
  hzdtypedetailsdata: any;
  contentShow: string = "none"; gridShow: string = "none"; searchcartdetsearchzddetails: string = "block";
  viewcontentShow: string = "none";
  txtShow: string = "none"; lblShow: string = "none";
  action: string = 'A'; userid: any; clubid: any;
  hzdtypeid: any;
  hzdlbl: string; //txtcolor: string;
  hzdstatus: any; hzdchkstatus: boolean = true;
  stat: any;
  public txtcolor: string = "#000000";

  hzdtxtstatus: string = 'Active'; txtsrch: string = '';
  GridMessage: string = 'Loading, Please wait ... !';
  srchError: string = '0';

  hazardtypeheadername: string; viewheadername: string;
  key: string = 'name';
  reverse: boolean = false;ddlsearch:any;
  nameasc:any="sortgreen"; namedesc:any="sortwhite"; colorasc:any="sortwhite"; colordesc:any="sortwhite";
  selectedoption:any="Active";randomcolor:any="#5cb85c";

  constructor(private title: Title,private modalService: BsModalService, public toastr: ToastsManager, vcr: ViewContainerRef, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService,
    private authService: AuthService, private router: Router) {

    this.title.setTitle("IZON - Hazard Type");
    this.hazardtypeheadername = "Hazard Type";   
    this.ddlsearch="HZT_LABEL";

    this.toastr.setRootViewContainerRef(vcr);
    this.contentShow = "none"; this.gridShow = "none";
    this.hzdtypedetailsdata = [];

    this.userid = localStorage.getItem('userId');
    this.clubid = localStorage.getItem('clubId');
  }

  ngOnInit() {
    this.hzdTypeForm = this.formBuilder.group({
      fhzdlbl: ['', Validators.compose([Validators.required])],
      ftxtcolor: ['', Validators.compose([Validators.required])],
      hzdchkstatus: ['']
    });
    let parameters = {
      searchvalue: " WHERE HZT_GCB_ID='"+this.clubid+"' and HZT_STATUS = 'Y'"
    };
    this.GetHazardTypes(parameters);
    
    this.gridShow = "block";
    this.contentShow = "none";
  }
  
  sort(value : string)
  {
    this.key = value;
    this.nameasc="sortwhite"; this.namedesc="sortwhite"; this.colorasc="sortwhite"; this.colordesc="sortwhite";
      if(this.key == value)
      {
          this.reverse = !this.reverse;
          if(this.key=="name" && this.reverse){
            this.namedesc="sortgreen";
          }
          else  if(this.key=="name" && (!this.reverse)){
            this.nameasc="sortgreen";
          }
          else  if(this.key=="color" && this.reverse){
            this.colordesc="sortgreen";
          }
          else  if(this.key=="color" && (!this.reverse)){
            this.colorasc="sortgreen";
          }
      }
   }
  

  refreshpage() {
    let parameters = {
      searchvalue: " WHERE HZT_GCB_ID='"+this.clubid+"' and HZT_STATUS = 'Y'"
    };
    this.GetHazardTypes(parameters);
    this.txtsrch = "";
    this.srchError ='0';
    this.selectedoption="Active";this.randomcolor="#5cb85c";
  }

  GetHazardTypes(parameters) {
    this.spinnerService.show();
    this.api.postOH('GetHarardTypes', parameters).subscribe(
      (response) => {
        this.hzdtypedetailsdata = [];
        for (let i = 0; i < response.length; i++) {
          var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
          var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
          var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
          var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var confirmshow = "row-icon-inactive";

          this.hzdtypedetailsdata.push({
            "id": response[i].id,
            "name": response[i].name,
            "color": response[i].color,
            "updateddate": response[i].date,
            "status": status,
            "statusclass": statusclass,
            "editshow": editshow,
            "enableshow": enableshow,
            "removeshow": removeshow,
            "confirmshow": confirmshow
          });
        }
        {
          this.GridMessage = "No Data Found";
        }

        this.spinnerService.hide();

      }, error => {
        this.spinnerService.hide();
      }
    );
  }

  search() {
    if (this.txtsrch == '') {
      this.srchError = '1';
    }
    else if (this.txtsrch != '') {
      this.srchError ='0';
      let parameters = {
        searchvalue: " WHERE HZT_GCB_ID='"+this.clubid+"' and "+this.ddlsearch+" LIKE '%" + this.txtsrch + "%' and HZT_STATUS<>'D' "
      };
      this.GetHazardTypes(parameters);
      this.txtsrch = "";
    }
  }

  srchKeyUp(event: any) {
    var keyupcode = event.keyCode;
    if (keyupcode == 13) {
      this.search();
    }
    else if (this.txtsrch != '') {
      this.srchError = '0';
    }
  }
  bindselectedoption(selectedoption) {
    this.srchError ='0';
    if (this.selectedoption == 'Active') {
        this.randomcolor = "#5cb85c";
        this.srchSts('Y');
    }
    else if (this.selectedoption == 'In-Active') {
        this.randomcolor = "#337ab7";
        this.srchSts('N');
    }
    else if (this.selectedoption == 'Deleted') {
        this.randomcolor = "#d9534f";
        this.srchSts('D');
    }
  }
  srchSts(type) {
    let parameters = {
      searchvalue: " WHERE HZT_GCB_ID='"+this.clubid+"' and HZT_STATUS= '" + type + "' "
    };
    this.GetHazardTypes(parameters);
  }

  addHazardType() {
    this.action = 'A';
    this.hzdTypeForm.reset();
    this.divheader = "Add Hazard Type";
    this.gridShow = "none";
    this.contentShow = "block";
    this.txtShow = "block"; this.lblShow = "none";
    this.hzdlbl = ''; this.txtcolor = "#000000";
    this.hzdtypeid = "0";
    this.hzdstatus = "Y";
    this.submitAttempt = false;
  }

  cancel() {
    if (this.action == 'A') {
      this.gridShow = "block";
      this.contentShow = "none";
      this.viewcontentShow = "none";
    }
    else {
      this.gridShow = "none";
      this.contentShow = "none";
      this.viewcontentShow = "block";
    }
  }

  goBack() {
    this.gridShow = "block";
    this.viewcontentShow = "none";
    this.contentShow = "none";
  }

  viewhazardType(hzdtypedata) {
    window.scrollTo(0, 0);
    this.viewheadername = hzdtypedata.name;
    this.action = 'V';
    this.gridShow = "none";
    this.viewcontentShow = "block";
    this.contentShow = "none";
    this.hzdtypeid = hzdtypedata.id;
    this.hzdlbl = (!hzdtypedata.name) ? "" : hzdtypedata.name;
    this.txtcolor = (!hzdtypedata.color) ? "" : hzdtypedata.color;
    if (hzdtypedata.status == 'Active') {
      this.hzdstatus = 'Y';
    }
    else if (hzdtypedata.status == 'In-Active') {
      this.hzdstatus = 'N';
    }
    this.hzdchkstatus = (this.hzdstatus == 'Y') ? true : false;
    this.hzdtxtstatus = (this.hzdstatus == 'Y') ? 'Active' : 'In-Active';
    if (hzdtypedata.status == 'Deleted') {
      this.hzdstatus = 'D';
      this.hzdtxtstatus = 'Deleted';
    }
  }

  editHazardType() {
    this.divheader = "Edit Hazard Type";
    this.action = 'U';
    this.gridShow = "none";
    this.contentShow = "block"; this.viewcontentShow = "none";
    this.txtShow = "block"; this.lblShow = "none";
    let parameters = {
      searchvalue: " WHERE HZT_GCB_ID='"+this.clubid+"' and HZT_ID='" + this.hzdtypeid + "'"
    };
    //this.spinnerService.show();
    let hzdtypedata = [];
    this.api.postOH('GetHarardTypes', parameters).subscribe(
      (response) => {
        for (let i = 0; i < response.length; i++) {
          var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
          var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
          var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
          var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var confirmshow = "row-icon-inactive";

          hzdtypedata.push({
            "id": response[i].id,
            "name": response[i].name,
            "color": response[i].color,
            "updateddate": response[i].date,
            "status": status,
            "statusclass": statusclass,
            "editshow": editshow,
            "enableshow": enableshow,
            "removeshow": removeshow,
            "confirmshow": confirmshow
          });
        }
        this.hzdtypeid = hzdtypedata[0].id;
        this.hzdlbl = (!hzdtypedata[0].name) ? "" : hzdtypedata[0].name;
        this.txtcolor = (!hzdtypedata[0].color) ? "" : hzdtypedata[0].color;
        //this.spinnerService.hide();
      }, error => {
        //this.spinnerService.hide();
      }
    );
  }

  checkBoxChange(status) {
    this.stat = status;
    if (this.stat == true) {
      this.hzdstatus = 'Y';
      this.hzdtxtstatus = 'Active';
    }
    else {
      this.hzdstatus = 'N';
      this.hzdtxtstatus = 'In-Active';
    }
  }

  saveData() {
    if (!this.hzdTypeForm.valid) {
    }
    this.submitAttempt = true;
    if (this.hzdTypeForm.valid) {
      if (this.action == 'A' || this.action == 'U') {
        var hzdtypeInfo = {
          'action': this.action,
          'id': this.hzdtypeid,
          'name': this.hzdlbl,
          'clubid': this.clubid,
          'color': this.txtcolor,
          'status': this.hzdstatus,
          'userid': this.userid
        }
        //console.log(hzdtypeInfo);
        this.spinnerService.show();
        this.api.postOH('savehazardtypes', hzdtypeInfo).subscribe(
          (data) => {
            if (this.action == 'A' || this.action == 'U') {
              if (data[1] != 'Hazard Type Already Exist or Unable to process your request ') {
                let parameters = {
                  searchvalue: " WHERE HZT_GCB_ID='"+this.clubid+"' and HZT_STATUS = 'Y'"
                };
                this.GetHazardTypes(parameters);
                this.gridShow = "block";
                this.contentShow = "none";
                this.viewcontentShow = "none";
                let msg = (this.action == "A") ? '<span style="color: green">Hazard Type added Successfully .</span>' : '<span style="color: green">Hazard Type updated Successfully .</span>';
                this.toastMessage(msg);
              }
              else {
                let msg = "<span style='color: red'>" + data[1] + "</span>";
                this.toastMessage(msg);
              }
            }
            this.spinnerService.hide();
            window.scrollTo(0, 0);
          },error=>{
            this.spinnerService.hide();
          })
      }
    }
  }

  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',

    };
    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 5000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }

  confirm(): void {
    this.modalRef.hide();
    this.action = 'D';
    this.hzdstatus = 'D';
    var hzdtypeInfo = {
      'action': this.action,
      'id': this.hzdtypeid,
      'name': this.hzdlbl,
      'clubid':this.clubid,
      'color': this.txtcolor,
      'status': this.hzdstatus,
      'userid': this.userid
    }
    let msg = '<span style="color: green">Hazard Type deleted Successfully</span>';
    this.DEapicall(hzdtypeInfo, msg);
  }

  enablehazardType(id): void {
    this.action = "E";
    this.hzdstatus = "Y";
    var hzdtypeInfo = {
      'action': this.action,
      'id': id,
      'name': '',
      'clubid': this.clubid,
      'color': '',
      'status': this.hzdstatus,
      'userid': this.userid
    }
    //console.log(cartdetailsinfo);
    let msg = '<span style="color: green">Hazard Type enabled Successfully</span>';
    this.DEapicall(hzdtypeInfo, msg);
  }

  DEapicall(hzdtypeInfo, msg) {
    //console.log(hzdtypeInfo);
    this.api.postOH('savehazardtypes', hzdtypeInfo).subscribe(
      (response) => {
        let parameters = {
          searchvalue: " WHERE HZT_GCB_ID='"+this.clubid+"' and HZT_STATUS = 'Y'"
        };
        this.GetHazardTypes(parameters);
        this.gridShow = "block";
        this.contentShow = "none";
        this.viewcontentShow = "none";
        this.selectedoption="Active";this.randomcolor="#5cb85c";
        this.toastMessage(msg);
      }, error => {
        console.log(error);
      });
  }

  decline(): void {
    this.modalRef.hide();
  }



}
