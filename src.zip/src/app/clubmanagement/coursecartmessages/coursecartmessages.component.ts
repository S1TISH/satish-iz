import { Component, OnInit, ViewContainerRef, TemplateRef, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { AuthService } from '../../services/auth.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Title } from '@angular/platform-browser';
import * as moment from "moment";

@Component({
    selector: 'app-coursecartmessages',
    templateUrl: './coursecartmessages.component.html',
    styleUrls: ['./coursecartmessages.component.css']
})
export class CoursecartmessagesComponent implements OnInit {
        modalRef: BsModalRef; public custommessageForm: FormGroup; submitAttempt: boolean = false;
    divheader: string = "Add Course Message"; GridMessage: string = 'Loading... !'; contactMessages: any = [];
    searchInfo: string = "block"; gridInfo: string = "block"; viewInfo: string = "none"; showStatus: string = "none"; addShow: string = "none";
    contactBtn: any; refreshBtn: any; selectedoption: any = "Active"; randomcolor: any = "#5cb85c";
    //search
    search: any = ''; srchError: string = '0';
    //model values
    action: any = "A"; id: any; courseid: any; clubId: any; description: any; status: any; checkStatus: any; clubname: string;
    //sorting
    key: string = 'description';
    reverse: boolean = false;
    cartkey: string = 'name';
    cartreverse: boolean = false;

    descriptionasc: any = "sortgreen"; descriptiondesc: any = "sortwhite";
    cartsList: any = [];inplaycarts: any = [];IsinplayAllChecked: boolean; errorMessage: any = "none"; messageBtn: any;
     templatemessages: BsModalRef; userId: any; cartMessage: any; msgcolor:any="cartscolor";
     selectedCartIds: string; IsreadyAllChecked:boolean; rangercarts:any=[];bevaragecarts:any=[];bagdropcarts:any=[];
    readycarts:any=[]; inplayselected:string; readyselected:string; rangerselected:string; bevarageselected:string; bagdropselected:string;
    IsrangerAllChecked: boolean; IsbevarageAllChecked: boolean; IsbagdropAllChecked: boolean;
    desclength:any;currentGolfClubDateTime:any; courselat: any;
    courselong: any;timeoffset: any = '';

    @ViewChild('activecartstemplate') msgtemplate: TemplateRef<any>;

    constructor(private title: Title, public toastr: ToastsManager, vcr: ViewContainerRef,
        private router: Router, public formBuilder: FormBuilder,
        private spinnerService: Ng4LoadingSpinnerService,
        private api: ApiService, private authService: AuthService,
        private modalService: BsModalService) {
        this.title.setTitle("IZON - Course Message");
        this.clubId = localStorage.getItem('clubId');
        this.courseid = localStorage.getItem('courseId');
        this.clubname = localStorage.getItem('clubname');
        this.userId = JSON.parse(localStorage.getItem('userId'));
        this.toastr.setRootViewContainerRef(vcr);
        this.viewInfo = "none";
        this.desclength=180;
    }
    ngOnInit() {
        this.custommessageForm = this.formBuilder.group({
            fdescription: ['', Validators.compose([Validators.required])],
            fstatus: ['']
        });
        // this.messageForm = this.formBuilder.group({
        //     fmessage: ['', Validators.compose([Validators.required])],
        // });
        let parameters = { searchvalue: " where CCM_STATUS='Y'  and CCM_GC_ID='" + this.courseid + "'  and CCM_GCB_ID='" + this.clubId + "' " };
        this.getCourseCustomMessages(parameters);
      
        this.viewInfo = "none";
       
    }
    sort(value: string) {
        this.key = value;
        this.descriptionasc = "sortwhite"; this.descriptiondesc = "sortwhite";
        if (this.key == value) {
            this.reverse = !this.reverse;
            if (this.key == "labelname" && this.reverse) {
                this.descriptiondesc = "sortgreen";
            }
            else if (this.key == "labelname" && (!this.reverse)) {
                this.descriptionasc = "sortgreen";
            }
        }

    }

    addContactMessages() {
        this.desclength=180;
        this.divheader = "Add Course Message";
        this.addShow = "block"; this.searchInfo = "none"; this.gridInfo = "none"; this.viewInfo = "none"; this.showStatus = "none";
        this.submitAttempt = false; this.action = "A"; this.description = ""; this.status = true; this.id = 0;
    }

    cancelMessage() {
        this.searchInfo = "block"; this.gridInfo = "block"; this.addShow = "none"; this.viewInfo = "none";
        this.custommessageForm.reset();
        // this.messageForm.reset();
         this.submitAttempt = false;
        // let parameters = { searchvalue: " where CCM_STATUS='Y' AND CCM_GCB_ID =" + this.clubId + "" };
        // this.getCourseCustomMessages(parameters);
    }

    //search functionality
    searchCustomMessage() {
        var status='';
        status= this.selectedoption == 'Active'?'Y':'N';
        if (this.search == '') {
            this.srchError = '1';
        }
        else if (this.search != '') {
            this.srchError = '0';
            let parameters = {
                searchvalue: " WHERE CCM_STATUS='"+status+"' AND CCM_DESCRIPTION LIKE '%" + this.search + "%'AND CCM_GCB_ID =" + this.clubId + "  and CCM_GC_ID='" + this.courseid + "' and CCM_STATUS<>'D' "
            };
            this.getCourseCustomMessages(parameters);
            this.search = "";
        }
    }

    bindselectedoption(selectedoption) {
        this.srchError = '0';
        if (this.selectedoption == 'Active') {
            this.randomcolor = "#5cb85c";
            this.searchStatus('Y');
        }
        else if (this.selectedoption == 'In-Active') {
            this.randomcolor = "#337ab7";
            this.searchStatus('N');
        }
        else if (this.selectedoption == 'Deleted') {
            this.randomcolor = "#d9534f";
            this.searchStatus('D');
        }
    }

    searchStatus(type) {
        let parameters = {
            searchvalue: " WHERE CCM_STATUS= '" + type + "'  and CCM_GC_ID='" + this.courseid + "' AND CCM_GCB_ID =" + this.clubId + ""
        };
        this.getCourseCustomMessages(parameters);
    }

    srchKeyUp(event: any) {
        if (this.search != '') {
            this.srchError = '0';
        }
    }

    refreshpage() {
        this.search = '';
        this.srchError = '0';
        this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
        let parameters = { searchvalue: " where CCM_STATUS='Y'  and CCM_GC_ID='" + this.courseid + "' AND CCM_GCB_ID =" + this.clubId + "" };
        this.getCourseCustomMessages(parameters);
    }

    getCourseCustomMessages(parameters) {
        this.contactMessages = [];
        this.refreshBtn = true;
        this.spinnerService.show();
        this.api.postOH('getcoursecustomcartmessages', parameters).subscribe(
            response => {
                this.contactMessages = [];
                this.spinnerService.hide();
                if (response.length > 0) {
                    for (let i = 0; i < response.length; i++) {
                        var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                        var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                        this.contactMessages.push({
                            "id": response[i].id,
                            "description": response[i].description,
                            "createddate": response[i].createddate,
                            "status": status,
                            "statusclass": statusclass,
                        });
                    }
                    this.refreshBtn = false;
                  
                } else {
                    this.contactMessages = []; this.refreshBtn = false;
                    this.GridMessage = "No Records Found";
                }
            },
            err => {
                this.spinnerService.hide();
            }
        );
    }

    viewMessage(id) {
        this.searchInfo = "none"; this.gridInfo = "none"; this.viewInfo = "block"; this.clubname = localStorage.getItem('clubname');
        this.spinnerService.show();
        let parameters = { searchvalue: ' WHERE CCM_ID=' + id + ' AND CCM_GCB_ID =' + this.clubId + '' };
        this.api.postOH('getcoursecustomcartmessages', parameters).subscribe(
            response => {
                window.scrollTo(0, 0);
                this.spinnerService.hide();
                if (response.length > 0) {
                    this.id = response[0].id;
                    this.description = response[0].description;
                    this.status = (response[0].status == 'Y') ? true : false;
                    this.checkStatus = (response[0].status == 'Y') ? 'Active' : (response[0].status == 'N') ? 'In-Active' : 'Deleted';
                } else {
                    this.contactMessages = [];
                    this.GridMessage = "No Records Found";
                }
            },
            err => {
                this.spinnerService.hide();
            }
        );
    }

    goBack() {
        this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
        this.searchInfo = "block"; this.gridInfo = "block"; this.addShow = "none"; this.viewInfo = "none";
        let parameters = { searchvalue: " where CCM_STATUS='Y' and CCM_GC_ID='" + this.courseid + "' AND CCM_GCB_ID =" + this.clubId + "" };
        this.getCourseCustomMessages(parameters);
    }

    editMessage(id) {
        this.addShow = "block"; this.searchInfo = "none"; this.gridInfo = "none"; this.viewInfo = "none"; this.showStatus = "block";
        this.spinnerService.show(); this.divheader = "Edit Course Message";
        let parameters = { searchvalue: ' WHERE CCM_ID=' + id + ' AND CCM_GC_ID=' + this.courseid + ' AND CCM_GCB_ID =' + this.clubId + '' };
        this.api.postOH('getcoursecustomcartmessages', parameters).subscribe(
            response => {
                this.spinnerService.hide();
                if (response.length > 0) {
                    this.action = "U";
                    this.id = response[0].id;
                    this.description = response[0].description;
                    this.status = (response[0].status == 'Y') ? true : false;
                    this.desclength=180-this.description.length;
                }
            },
            err => {
                this.spinnerService.hide();
            }
        );
    }
   
     onKeyUp(event: any) {
        this.desclength = 180-event.target.value.length;
       
    };


    saveMessage() {
        if (!this.custommessageForm.valid) {

        }
        this.submitAttempt = true;
        if (this.custommessageForm.valid) {
            if(this.courseid !=null){
                this.contactBtn = true;
                var contactMessagesModal = {
                    "action": this.action, "id": this.id, "clubid": this.clubId, "courseid": this.courseid, "description": this.description, "status": (this.status == true) ? "Y" : "N"
                }
                this.spinnerService.show();
                this.api.postOH('savecoursecustomcartmessages', contactMessagesModal).subscribe(
                    response => {
    
                        if (response[0] > 0) {
                            let parameters = { searchvalue: " where CCM_STATUS='Y' and CCM_GC_ID='" + this.courseid + "' AND CCM_GCB_ID =" + this.clubId + "" };
                            this.getCourseCustomMessages(parameters);
                            this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
                            this.searchInfo = "block"; this.gridInfo = "block"; this.addShow = "none"; this.viewInfo = "none";
                            let msg = '<span style="color: green">' + response[1] + '</span>';
                            this.toastMessage(msg); this.custommessageForm.reset();
    
                        }
                        else {
                            let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                            this.toastMessage(msg);
                        }
                        window.scrollTo(0, 0);
                        this.spinnerService.hide();
                        this.contactBtn = false;
                    },
                    err => {
                        this.spinnerService.hide();
                        this.contactBtn = false;
                    }
                );
            }
          else{
            let msg = '<span style="color: red">Please select course to add message</span>';
            this.toastMessage(msg);
          }
        }
    }

    toastMessage(msg) {
        let options = {
            positionClass: 'toast-top-center',
        };

        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 3000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    }

    confirm(): void {
        this.modalRef.hide();
        var contactMessagesModal = {
            "action": "D", "id": this.id, "clubid": this.clubId, "courseid": this.courseid, "description": this.description, "status": "D"
        }
        let msg = '<span style="color: red">Course Message Deleted Successfully</span>';
        this.DEapicall(contactMessagesModal, msg);
    }

    enableMessage(id: any, measurement: any): void {
        var contactMessagesModal = {
            "action": "E", "id": id, "clubid": this.clubId, "courseid": this.courseid, "description": "", "status": "Y"
        }
        let msg = '<span style="color: green">Course Message Enabled Successfully</span>';
        this.DEapicall(contactMessagesModal, msg);
    }

    DEapicall(contactMessagesModal, msg) {
        this.api.postOH('savecoursecustomcartmessages', contactMessagesModal).subscribe(
            (response) => {
                let parameters = { searchvalue: " where CCM_STATUS='Y' and CCM_GC_ID='" + this.courseid + "' AND CCM_GCB_ID =" + this.clubId + "" };
                this.getCourseCustomMessages(parameters);
                this.action = 'A';
                this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
                this.searchInfo = "block"; this.gridInfo = "block"; this.addShow = "none"; this.viewInfo = "none";
                this.showStatus = "none";
                this.toastMessage(msg);
            }, error => {
                let msg = '<span style="color: red">Failed to update the data, please try again</span>';
                this.toastMessage(msg);
            });
    }

    decline(): void {
        this.modalRef.hide();
    }

    getinplaycarts() {
        this.inplayselected = "";
        this.inplaycarts = [];
        let parameters = {
            clubid: this.clubId,
            courseid: localStorage.getItem('courseId'),
            cartid: 0
        };
        this.api.postOH('getinplaycartdetailsv2', parameters).subscribe(
            (response) => {
                if (response.length != 0) {
                    //this.messageBtn = false;
                     for (let i = 0; i < response.length; i++) {
                        // if (response[i].deviceStatus == 'T') {
                        this.inplaycarts.push({
                            value: response[i].id,
                            name: response[i].name,
                            roleId: response[i].cartroletype,
                            deviceid: response[i].deviceid,
                            Selected: true
                        });
                        if (this.inplayselected == "") {
                            this.inplayselected = response[i].id+ ', ' 
                        } else {
                            this.inplayselected = this.inplayselected + response[i].id+ ', ' 
                        }
                    // }
                    }
                  }
                let parameters = {
                    clubid: parseInt(this.clubId)
                };
                this.api.postOH('getreadycartdetails', parameters).subscribe(
                    (response) => {
                       if (response.length != 0) {
                            for (let i = 0; i < response.length; i++) {
                                if(response[i].deviceStatus=='T'){
                                this.inplaycarts.push({
                                    value: response[i].id,
                                    name: response[i].name,
                                    roleId: response[i].cartroletype,
                                    deviceid: response[i].deviceid,
                                    Selected: true
                                });
                            }
                                if (this.inplayselected == "") {
                                    this.inplayselected = response[i].id+ ', '
                                } else {
                                    this.inplayselected = this.inplayselected  + response[i].id+ ', '
                                }
                            }
                        }
                        this.spinnerService.hide();
                        this.inplaycarts.sort(function(a,b)
                        {
                            return a.name.length - b.name.length || (a.name).localeCompare(b.name);
                        })
                        
                    }, error => {
                        this.spinnerService.hide();
                    });

                    this.getRangerBeverageBagDropCartDetails();
               })
           }

   

    // getreadyCartDetails() {
    //     this.spinnerService.show();
    //     this.readyselected="";
    //     let parameters = {
    //         clubid: parseInt(this.clubId)
    //     };
    //     this.api.postOH('getreadycartdetails', parameters).subscribe(
    //         (response) => {
    //             this.readycarts = [];
    //             if (response.length != 0) {
    //                // this.messageBtn=false;
    //                 for (let i = 0; i < response.length; i++) {
    //                     this.readycarts.push({
    //                         value: response[i].id,
    //                         name: response[i].name,
    //                         cssclass: "circle-green",
    //                         roleId: response[i].cartroletype,
    //                         deviceid: response[i].deviceid,
    //                         cartcolor:"green.png",
    //                         Selected: true
    //                     });
    //                     if (this.readyselected == "") {
    //                         this.readyselected = response[i].id+ ', '
    //                     } else {
    //                         this.readyselected = this.readyselected  + response[i].id+ ', '
    //                     }
    //                 }
    //             }
    //             this.spinnerService.hide();
    //         }, error => {
    //             this.spinnerService.hide();
    //         });
    // }
    getRangerBeverageBagDropCartDetails(){
        this.spinnerService.show();
        let parameters = {
            clubid: parseInt(this.clubId)
        };
        this.api.postOH('getrangersbeveragebagdropcartdetails', parameters).subscribe(
            (response) => {
                this.rangercarts = [];
                this.bevaragecarts = [];                
                this.bagdropcarts =[];
                this.rangerselected='';
                this.bevarageselected='';
                this.bagdropselected='';
                if (response.length != 0) {
                    for (let i = 0; i < response.length; i++) {
                        if (response[i].cartroletype == "3") {
                            //this.messageBtn=false;
                            this.rangercarts.push({
                                value: response[i].id,
                                name: response[i].name,
                                Selected: true
                            });
                            if (this.rangerselected == "") {
                                this.rangerselected = response[i].id+ ', '
                            } else {
                                this.rangerselected = this.rangerselected  + response[i].id+ ', '
                            }
                        }else if (response[i].cartroletype == "4") {
                           // this.messageBtn=false;
                            this.bevaragecarts.push({
                                value: response[i].id,
                                name: response[i].name,
                                Selected: true
                            });
                            if (this.bevarageselected == "") {
                                this.bevarageselected = response[i].id+ ', '
                            } else {
                                this.bevarageselected = this.bevarageselected + response[i].id+ ', '
                            }
                        }else if (response[i].cartroletype == "7") {
                            //this.messageBtn=false;
                            this.bagdropcarts.push({
                                value: response[i].id,
                                name: response[i].name,
                                Selected: true
                            });
                            if (this.bagdropselected == "") {
                                this.bagdropselected = response[i].id+ ', '
                            } else {
                                this.bagdropselected = this.bagdropselected  + response[i].id+ ', '
                            }
                        }
                    }
                }
                // if (this.bevaragecarts.length == 0 && this.cartsList.length ==0 && this.bagdropcarts.length==0 && this.rangercarts.length==0 && this.readycarts.length==0) {
                //     this.msgcolor="redcolor";
                // }
                // else{
                //     this.msgcolor="cartscolor";
                // }

                if (this.bevaragecarts.length === 0 && this.inplaycarts.length === 0 && this.bagdropcarts.length === 0 && this.rangercarts.length === 0) {
                    let msg = '<span style="color: red">Carts not found</span>';
                    this.toastMessage(msg);
                    this.spinnerService.hide();
                }
                else {
                    this.IsinplayAllChecked = true;
                    this.IsreadyAllChecked = true;
                    this.IsrangerAllChecked = true;
                    this.IsbevarageAllChecked = true;
                    this.IsbagdropAllChecked = true;
                    this.submitAttempt = false;
                    this.errorMessage = "none";
                    this.spinnerService.hide();
                    this.templatemessages = this.modalService.show(this.msgtemplate, { class: 'modal-lg modal-sm' });
                }
                this.spinnerService.hide();
            },error=>{
                this.spinnerService.hide();
            });
    }
    rangerCheckUncheckAll() {
        this.rangerselected = '';
        for (var i = 0; i < this.rangercarts.length; i++) {
            this.rangercarts[i].Selected = this.IsrangerAllChecked;
        }
        for (var i = 0; i < this.rangercarts.length; i++) {
            if (this.rangercarts[i].Selected == true) {
                if (this.rangerselected == "") {
                    this.rangerselected = this.rangercarts[i].value+ ', '
                } else {
                    this.rangerselected = this.rangerselected  + this.rangercarts[i].value+ ', '
                }
            }
        }
       
        if(this.rangerselected === '' && this.inplayselected===''  && this.bagdropselected==='' && this.bevarageselected==='') {
            this.errorMessage="block";
            // this.messageBtn = true;
           
         }
         else{
             this.errorMessage="none";
            //  this.messageBtn =false ;
           
         }
    }
    rangerCheckUncheckHeader() {
        this.rangerselected = '';
        this.IsrangerAllChecked = false;
        for (var i = 0; i < this.rangercarts.length; i++) {
            if (!this.rangercarts[i].Selected) {
                this.IsrangerAllChecked = false;
                this.errorMessage = "none";
                // this.messageBtn=false;
                break;
            }
            else {
                if(this.rangercarts.length==1){this.errorMessage = "none";}
                this.IsrangerAllChecked = true;
                // this.messageBtn=true;
            }
        };
        for (var i = 0; i < this.rangercarts.length; i++) {
            if (this.rangercarts[i].Selected == true) {
                if (this.rangerselected == "") {
                    this.rangerselected = this.rangercarts[i].value+ ', '
                } else {
                    this.rangerselected = this.rangerselected  + this.rangercarts[i].value+ ', '
                }
            }
        }
    }

    bevarageCheckUncheckAll() {
        this.bevarageselected = '';
        for (var i = 0; i < this.bevaragecarts.length; i++) {
            this.bevaragecarts[i].Selected = this.IsbevarageAllChecked;
        }
        for (var i = 0; i < this.bevaragecarts.length; i++) {
            if (this.bevaragecarts[i].Selected == true) {
                if (this.bevarageselected == "") {
                    this.bevarageselected = this.bevaragecarts[i].value+ ', '
                } else {
                    this.bevarageselected = this.bevarageselected + this.bevaragecarts[i].value+ ', '
                }
            }
        }
        if(this.rangerselected === '' && this.inplayselected===''  && this.bagdropselected==='' && this.bevarageselected==='') {
            this.errorMessage="block";
            // this.messageBtn = true;
           
         }
         else{
             this.errorMessage="none";
            //  this.messageBtn =false ;
           
         }
    }
    bevarageCheckUncheckHeader() {
        this.bevarageselected = '';
        this.IsbevarageAllChecked = false;
        for (var i = 0; i < this.bevaragecarts.length; i++) {
            if (!this.bevaragecarts[i].Selected) {
                this.IsbevarageAllChecked = false;
                this.errorMessage = "none";
                // this.messageBtn=false;
                break;
            }
            else {
                if(this.bevaragecarts.length==1){this.errorMessage = "none";}
                this.IsbevarageAllChecked = true;
                // this.messageBtn=true;
            }
        };
        for (var i = 0; i < this.bevaragecarts.length; i++) {
            if (this.bevaragecarts[i].Selected == true) {
                if (this.bevarageselected == "") {
                    this.bevarageselected = this.bevaragecarts[i].value+ ', '
                } else {
                    this.bevarageselected = this.bevarageselected  + this.bevaragecarts[i].value+ ', '
                }
            }
        }
    }
    bagdropCheckUncheckAll() {
        this.bagdropselected = '';
        for (var i = 0; i < this.bagdropcarts.length; i++) {
            this.bagdropcarts[i].Selected = this.IsbagdropAllChecked;
        }
        for (var i = 0; i < this.bagdropcarts.length; i++) {
            if (this.bagdropcarts[i].Selected == true) {
                if (this.bagdropselected == "") {
                    this.bagdropselected = this.bagdropcarts[i].value+ ', '
                } else {
                    this.bagdropselected = this.bagdropselected  + this.bagdropcarts[i].value+ ', '
                }
            }
        }
        if(this.rangerselected === '' && this.inplayselected==='' && this.bagdropselected==='' && this.bevarageselected==='') {
            this.errorMessage="block";
            // this.messageBtn = true;
           
         }
         else{
             this.errorMessage="none";
            //  this.messageBtn =false ;
           
         }
    }
    bagdropCheckUncheckHeader() {
        this.bagdropselected = '';
        this.IsbagdropAllChecked = false;
        for (var i = 0; i < this.bagdropcarts.length; i++) {
            if (!this.bagdropcarts[i].Selected) {
                this.IsbagdropAllChecked = false;
                this.errorMessage = "none";
                // this.messageBtn=false;
                break;
            }
            else {
                if(this.bagdropcarts.length==1){this.errorMessage = "none";}
                this.IsbagdropAllChecked = true;
                // this.messageBtn=true;
            }
        };
        for (var i = 0; i < this.bagdropcarts.length; i++) {
            if (this.bagdropcarts[i].Selected == true) {
                if (this.bagdropselected == "") {
                    this.bagdropselected = this.bagdropcarts[i].value+ ', '
                } else {
                    this.bagdropselected = this.bagdropselected + this.bagdropcarts[i].value+ ', '
                }
            }
        }
    }


    sendmessagetoactivecarts(activecartsmessage: TemplateRef<any>, descrip) {
        // var array = [{"id":3645,"date":"2018-07-05T13:13:37","date_gmt":"2018-07-05T13:13:37","guid":{"rendered":""},"modified":"2018-07-05T13:13:37","modified_gmt":"2018-07-05T13:13:37","slug":"vpwin","status":"publish","type":"matrix","link":"","title":{"rendered":"VPWIN"},"content":{"rendered":"","protected":false},"featured_media":0,"parent":0,"template":"","better_featured_image":null,"acf":{"domain":"SMB","ds_rating":"3","dt_rating":""},},{"id":3645,"date":"2018-07-05T13:13:37","date_gmt":"2018-07-05T13:13:37","guid":{"rendered":""},"modified":"2018-07-05T13:13:37","modified_gmt":"2018-07-05T13:13:37","slug":"vpwin","status":"publish","type":"matrix","link":"","title":{"rendered":"adfPWIN"},"content":{"rendered":"","protected":false},"featured_media":0,"parent":0,"template":"","better_featured_image":null,"acf":{"domain":"SMB","ds_rating":"3","dt_rating":""}},{"id":3645,"date":"2018-07-05T13:13:37","date_gmt":"2018-07-05T13:13:37","guid":{"rendered":""},"modified":"2018-07-05T13:13:37","modified_gmt":"2018-07-05T13:13:37","slug":"vpwin","status":"publish","type":"matrix","link":"","title":{"rendered":"bbfPWIN"},"content":{"rendered":"","protected":false},"featured_media":0,"parent":0,"template":"","better_featured_image":null,"acf":{"domain":"SMB","ds_rating":"3","dt_rating":""}}];
        // array.sort((a,b) => a.title.rendered.localeCompare(b.title.rendered));
         
        //  console.log(array);
        this.spinnerService.show();
        this.messageBtn = false;
        this.getinplaycarts();
        this.cartMessage = descrip;
        
       // this.getreadyCartDetails();
        //this.getRangerBeverageBagDropCartDetails();
       
//         if (this.bevaragecarts.length === 0 && this.inplaycarts.length ===0 && this.bagdropcarts.length===0 && this.rangercarts.length===0) {
//             // let msg = '<span style="color: red">Carts not found</span>';
//             // this.toastMessage(msg);
//             // this.spinnerService.hide();
//         }
//         else{
//             this.cartMessage = descrip;
//             this.IsinplayAllChecked = true;
//             this.IsreadyAllChecked=true;
//             this.IsrangerAllChecked = true;
//             this.IsbevarageAllChecked=true;
//             this.IsbagdropAllChecked = true;
//             this.submitAttempt = false;
//             this.errorMessage = "none";
//             this.templatemessages = this.modalService.show(activecartsmessage, { class: 'modal-lg modal-sm' });
//             this.spinnerService.hide();
//         }
    }
    closeactivemessgepopup(): void {
       // this.messageForm.reset();
        this.templatemessages.hide();
    }
    
    inplayCheckUncheckAll() {
        this.inplayselected = '';
        for (var i = 0; i < this.inplaycarts.length; i++) {
            this.inplaycarts[i].Selected = this.IsinplayAllChecked;
        }
        for (var i = 0; i < this.inplaycarts.length; i++) {
            if (this.inplaycarts[i].Selected == true) {
                if (this.inplayselected == "") {
                    this.inplayselected = this.inplaycarts[i].value+ ', '
                } else {
                    this.inplayselected = this.inplayselected + this.inplaycarts[i].value+ ', '
                }
            }
        }
        if(this.rangerselected === '' && this.inplayselected==='' && this.bagdropselected==='' && this.bevarageselected==='') {
            this.errorMessage="block";
            // this.messageBtn = true;
           
         }
         else{
             this.errorMessage="none";
            //  this.messageBtn =false ;
           
         }
    }
    inplayCheckUncheckHeader() {
        this.inplayselected = '';
        this.IsinplayAllChecked = false;
        for (var i = 0; i < this.inplaycarts.length; i++) {
            if (!this.inplaycarts[i].Selected) {
                this.IsinplayAllChecked = false;
                this.errorMessage = "none";
                // this.messageBtn=false;
                break;
            }
            else {
                if(this.inplaycarts.length==1){this.errorMessage = "none";}
                this.IsinplayAllChecked = true;
                // this.messageBtn=true;
            }
        };
        for (var i = 0; i < this.inplaycarts.length; i++) {
            if (this.inplaycarts[i].Selected == true) {
                if (this.inplayselected == "") {
                    this.inplayselected = this.inplaycarts[i].value+ ', '
                } else {
                    this.inplayselected = this.inplayselected  + this.inplaycarts[i].value+ ', '
                }
            }
        }
    }

    // readyCheckUncheckAll() {
    //     this.readyselected = '';
    //     for (var i = 0; i < this.readycarts.length; i++) {
    //         this.readycarts[i].Selected = this.IsreadyAllChecked;
    //     }
    //     for (var i = 0; i < this.readycarts.length; i++) {
    //         if (this.readycarts[i].Selected == true) {
    //             if (this.readyselected == "") {
    //                 this.readyselected = this.readycarts[i].value+ ', '
    //             } else {
    //                 this.readyselected = this.readyselected  + this.readycarts[i].value+ ', '
    //             }
    //         }
    //     }
    //     if(this.rangerselected === '' && this.inplayselected==='' && this.readyselected==='' && this.bagdropselected==='' && this.bevarageselected==='') {
    //         this.errorMessage="block";
    //         // this.messageBtn = true;
           
    //      }
    //      else{
    //          this.errorMessage="none";
    //         //  this.messageBtn =false ;
           
    //      }
    // }
    // readyCheckUncheckHeader() {
    //     this.readyselected = '';
    //     this.IsreadyAllChecked = false;
    //     for (var i = 0; i < this.readycarts.length; i++) {
    //         if (!this.readycarts[i].Selected) {
    //             this.IsreadyAllChecked = false;
    //             this.errorMessage = "none";
    //             // this.messageBtn=false;
    //             break;
    //         }
    //         else {
    //             this.IsreadyAllChecked = true;
    //             // this.messageBtn=true;
    //         }
    //     };
    //     for (var i = 0; i < this.readycarts.length; i++) {
    //         if (this.readycarts[i].Selected == true) {
    //             if (this.readyselected == "") {
    //                 this.readyselected = this.readycarts[i].value+ ', '
    //             } else {
    //                 this.readyselected = this.readyselected  + this.readycarts[i].value+ ', '
    //             }
    //         }
    //     }
    // }
  



    // sendMessagetoactivecarts() {
    //     // if (!this.messageForm.valid) {

    //     // }
    //     if(this.rangerselected === '' && this.inplayselected==='' &&  this.bagdropselected==='' && this.bevarageselected==='') {
    //         this.errorMessage="block";
    //     }
    //     this.submitAttempt = true;
    //     // this.messageBtn = true;
    //     this.selectedCartIds=this.inplayselected+this.rangerselected+ this.bevarageselected+this.bagdropselected;
       
    //    // console.log(this.selectedCartIds);
    //     // alert(lastChar);
    //     // if (lastChar == ',') {
    //     //     this.selectedCartIds = this.selectedCartIds.slice(0, -1);
    //     // }
    //     // console.log(this.selectedCartIds);
    //      if (this.selectedCartIds != '') {
    //         // this.messageBtn = false;
    //         var messageModal = { "action": "A", "id": 0, "clubid": this.clubId, "courseid": this.courseid, "fromcartid": 0, "tocartids": this.selectedCartIds, "message": this.cartMessage, "readstatus": "Y", "userid": this.userId }
    //         this.spinnerService.show();
    //         this.api.postOH('savemultiplecartmessages', messageModal).subscribe(
    //             response => {
    //                 this.spinnerService.hide();
    //                 if (response == "Success") {
    //                     this.templatemessages.hide();
    //                     let msg = '<span style="color: green">Message sent successfully</span>';
    //                     this.toastMessage(msg);
    //                     this.authService.getCall();
    //                     this.closeactivemessgepopup();
    //                     this.messageBtn = true;

    //                 } else {
    //                     let msg = '<span style="color: red">Failed to save the data, please try again</span>';
    //                     this.toastMessage(msg);
    //                     this.messageBtn = false;
    //                 }
    //             },
    //             err => {
    //                 this.spinnerService.hide();
    //             }
    //         );
    //      }
    //     else {
    //         this.errorMessage = "block";
    //         this.messageBtn = false;
    //     }
    // }
    sendMessagetoactivecarts() {
        this.currentGolfClubDateTime = "";
        if(this.rangerselected === '' && this.inplayselected==='' &&  this.bagdropselected==='' && this.bevarageselected==='') {
            this.errorMessage="block";
        }
        this.submitAttempt = true;
        this.selectedCartIds=this.inplayselected+this.rangerselected+ this.bevarageselected+this.bagdropselected;
     
         if (this.selectedCartIds != '') {
            var searchexp = " WHERE GC_GCB_ID='" + this.clubId  + "' and GC_STATUS='Y' "
            let parameters1 = { searchvalue: searchexp };
            this.api.postOH('getgolfcourse', parameters1).subscribe(
                response => {
                    if (response.length !== 0) {
                        this.courselat = response[0].latitude;
                        this.courselong = response[0].longitude;
                        this.timeoffset = response[0].timeoffset;
            let currentDate: any = '';
            let d = new Date();
            let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
            currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
            this.currentGolfClubDateTime = moment(currentDate).format('YYYY-MM-DD HH:mm:ss');
            var messageModal = { "action": "A", "id": 0, "clubid": this.clubId, "courseid": this.courseid, "fromcartid": 0, "tocartids": this.selectedCartIds, "message": this.cartMessage, "readstatus": "Y", "userid": this.userId,"datetime":this.currentGolfClubDateTime  }
            this.spinnerService.show();
            this.api.postOH('savemultiplecartmessages', messageModal).subscribe(
                response => {
                    this.spinnerService.hide();
                    if (response == "Success") {
                        this.templatemessages.hide();
                        let msg = '<span style="color: green">Message sent successfully</span>';
                        this.toastMessage(msg);
                        this.authService.getCall();
                        this.closeactivemessgepopup();
                        this.messageBtn = true;

                    } else {
                        let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                        this.toastMessage(msg);
                        this.messageBtn = false;
                    }
                },
                err => {
                    this.spinnerService.hide();
                }
            );
      
}
                },
err => {
    this.spinnerService.hide();
}
);     }
        else {
            this.errorMessage = "block";
            this.messageBtn = false;
        }
    }

}

