import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CoursecartmessagesComponent } from './coursecartmessages.component';

describe('CoursecartmessagesComponent', () => {
  let component: CoursecartmessagesComponent;
  let fixture: ComponentFixture<CoursecartmessagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CoursecartmessagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoursecartmessagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
