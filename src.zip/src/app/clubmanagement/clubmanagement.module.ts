import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FullCalendarModule } from 'ng-fullcalendar';
//import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { ModalModule } from 'ngx-bootstrap';
import { OrderModule } from 'ngx-order-pipe';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { PopoverModule } from 'ngx-bootstrap';

import { GolfclubComponent } from './golfclub/golfclub.component';
import { GolfcourseComponent } from './golfcourse/golfcourse.component';
import { HoledetailsComponent } from './holedetails/holedetails.component';
import { ContactmessagesComponent } from './contactmessages/contactmessages.component';
import { CoursecartmessagesComponent } from './coursecartmessages/coursecartmessages.component';
import { SchedulemessagesComponent } from './schedulemessages/schedulemessages.component';
import { LivefleetComponent } from './livefleet/livefleet.component';
import { LivefleettrackComponent } from './livefleettrack/livefleettrack.component';
import { DashboardnewComponent } from './dashboardnew/dashboardnew.component';
import { CarttrackComponent } from './carttrack/carttrack.component';
import { SchedulecourseComponent } from './schedulecourse/schedulecourse.component';

const routes: Routes = [  
  {
    path:'golfclub',
    component:GolfclubComponent
  },
  {
    path:'golfcourse',
    component:GolfcourseComponent
  },  
  {
    path:'holedetails',
    component:HoledetailsComponent
  },  
  {
    path:'contactmessages',
    component:ContactmessagesComponent
  },
  {
    path: 'coursemessages',
    component: CoursecartmessagesComponent
  },
  {
    path: 'schedulemessages',
    component: SchedulemessagesComponent
  },
  {
    path: 'schedulecourse',
    component: SchedulecourseComponent
  },
  {
    path: 'livefleet',
    component: LivefleetComponent
  },
  {
    path: 'livefleettrack',
    component: LivefleettrackComponent
  },
  {
    path: 'dashboardnew',
    component: DashboardnewComponent
  },
  {
    path: 'carttrack',
    component: CarttrackComponent
  }
];

@NgModule({
  declarations: [GolfclubComponent, GolfcourseComponent, HoledetailsComponent, 
 ContactmessagesComponent, CoursecartmessagesComponent, SchedulemessagesComponent, LivefleetComponent, LivefleettrackComponent, DashboardnewComponent, CarttrackComponent, SchedulecourseComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule, ReactiveFormsModule,
    FullCalendarModule,OrderModule,
    ToastModule.forRoot(),
    ModalModule.forRoot(),
    OwlDateTimeModule,PopoverModule.forRoot(),
    OwlNativeDateTimeModule, BsDatepickerModule.forRoot()
  ],  
  exports: [RouterModule]  
})
export class ClubmanagementModule { }
