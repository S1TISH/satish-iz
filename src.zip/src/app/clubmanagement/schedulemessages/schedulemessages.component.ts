import { Component, OnInit, ViewContainerRef, TemplateRef, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { AuthService } from '../../services/auth.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Title } from '@angular/platform-browser';
import * as moment from "moment";
import * as $ from 'jquery';

var count = 0; var index = []; var removedindexes = [];
declare const google: any;

@Component({
  selector: 'app-schedulemessages',
  templateUrl: './schedulemessages.component.html',
  styleUrls: ['./schedulemessages.component.css']
})
export class SchedulemessagesComponent implements OnInit {
  modalRef: BsModalRef; public schedulemessageForm: FormGroup; submitAttempt: boolean = false;
  divheader: string = "Add Schedule Message"; GridMessage: string = 'Loading... !'; ScheduleMessages: any = [];
  searchInfo: string = "block"; gridInfo: string = "block"; viewInfo: string = "none"; showStatus: string = "none"; addShow: string = "none";
  contactBtn: any = false; refreshBtn: any; selectedoption: any = "Active"; randomcolor: any = "#5cb85c";

  //model values
  action: any = "A"; id: any; courseid: any; clubId: any; message: any; status: any; checkStatus: any; clubname: string;
  //sorting
  key: string = 'message';
  reverse: boolean = false;
  messageasc: any = "sortgreen"; messagedesc: any = "sortwhite";
  triggertypeasc: any = "sortwhite"; triggertypedesc: any = "sortwhite";
  holeidasc: any = "sortwhite"; holeiddesc: any = "sortwhite";
  starttimeasc: any = "sortwhite"; starttimedesc: any = "sortwhite";
  endtimeasc: any = "sortwhite"; endtimedesc: any = "sortwhite";

  cartsList: any = []; IsinplayAllChecked: boolean; errorMessage: any = "none"; messageBtn: any;
  templatemessages: BsModalRef; userId: any; cartMessage: any; msgcolor: any = "cartscolor";
  desclength: any; triggertype: any = '0'; descriptions: any; StartDate: any; EndDate: any; StartTime: any; EndTime: any; holeIds: any;
  showMessageStatus: any = "none"; messagestatus: any = 'N';
  minStartDate: any; minEndDate: any;

  //div show and hide for trigger type
  openStartRoundOptions: any = "none";
  openEndRoundOptions: any = "none";
  openStartHoleOptions: any = "none";
  openEndHoleOptions: any = "none";

  startroundholes: any = []; endroundholes: any = [];
  holedetails: any = [];

  startdateerrormsg: any; enddateerrormsg: any;
  starttimeerrormsg: any; endtimeerrormsg: any;
  dateDifferenceerror: any; timeDifferenceerror: any; totalDuration: any;
  holemessagedetailserrormsg: any; holeexistserrormsg: any = '';
  startroundDescerrormsg: any; endroundDescerrormsg: any;

  editRecordInfo: any; currentRecInfo: any; viewMessageText: any;

  disableMessage: any = false;

  arr: any = [];

  holeslist: any = [];

  geteditrecordInfo: any; holesduringEdit: any;

  MessageduringEdit: any; holeValueduringEdit: any; smreccount: any = false;

  //search
  ddlsearch: any; txtsrch: string = ''; ddlsearchtriggertype: any; ddltriggertypediv: boolean = false; searchtextdiv: boolean = true;
  srchError: string = '0'; timeoffset: any;

  @ViewChild('templateToSave') tempToSave: TemplateRef<any>;


  constructor(private title: Title, public toastr: ToastsManager, vcr: ViewContainerRef,
    private router: Router, public formBuilder: FormBuilder,
    private spinnerService: Ng4LoadingSpinnerService,
    private api: ApiService, private authService: AuthService,
    private modalService: BsModalService) {
    this.title.setTitle("IZON - Schedule Messages");
    this.clubId = localStorage.getItem('clubId');
    this.courseid = localStorage.getItem('courseId');
    this.clubname = localStorage.getItem('clubname');
    this.userId = JSON.parse(localStorage.getItem('userId'));
    this.toastr.setRootViewContainerRef(vcr);
    this.viewInfo = "none";
    this.desclength = 180;
    this.triggertype = '0';
    this.holeIds = [];
    this.startdateerrormsg = ""; this.starttimeerrormsg = ""; this.enddateerrormsg = ""; this.endtimeerrormsg = "";
    this.dateDifferenceerror = ""; this.timeDifferenceerror = "";
    this.ddlsearch = "sm_message";

  }

  ngOnInit() {
    this.schedulemessageForm = this.formBuilder.group({
      ftriggertype: ["0", Validators.compose([Validators.required])],
      ftstartdate: [''],
      ftstarttime: [''],
      ftenddate: [''],
      ftendtime: [''],
      fmessagestatus: [''],
      fstatus: [''],
      fmessage: [''],
      fholeid: ['0']
    });
    this.getcourses();
    this.openStartRoundOptions = "none";
    this.openEndRoundOptions = "none";
    this.openStartHoleOptions = "none";
    this.openEndHoleOptions = "none";

    let parameters = { searchvalue: " where SM_STATUS='Y'  and SM_GC_ID='" + this.courseid + "'  and SM_GCB_ID='" + this.clubId + "' " };
    this.getScheduleMessages(parameters);

    this.viewInfo = "none";

    //this.getHolesList();

  }
  getcourses() {
    let searchexp = "";
    if (localStorage.getItem('courseId') === undefined || localStorage.getItem('courseId') === '' || localStorage.getItem('courseId') === null) {
      searchexp = " WHERE GC_GCB_ID='" + this.clubId + "' and GC_STATUS='Y' "
    }
    else {
      searchexp = " WHERE GC_GCB_ID='" + this.clubId + "' and GC_STATUS='Y' and  GC_ID='" + localStorage.getItem('courseId') + "'"
    }
    let parameters1 = { searchvalue: searchexp };
    this.api.postOH('getgolfcourse', parameters1).subscribe(
      response => {
        this.spinnerService.hide();
        if (response.length !== 0) {
          this.timeoffset = response[0].timeoffset;
          this.setdates();
        }
      }, error => {
        this.spinnerService.hide();
      })
  }
  setdates() {
    let currentDate: any = '';
    let d = new Date();
    let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
    currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
    this.minStartDate = currentDate; this.minEndDate = currentDate;
  } 
  ddlsearchchange() {
    this.srchError = '0'; this.txtsrch = ''; this.ddlsearchtriggertype = "0";
    this.ddltriggertypediv = false; this.searchtextdiv = false;
    if (this.ddlsearch == "sm_message") {
      this.ddltriggertypediv = false;
      this.searchtextdiv = true;
      let parameters = { searchvalue: " where SM_STATUS='Y'  and SM_GC_ID='" + this.courseid + "'  and SM_GCB_ID='" + this.clubId + "' " };
      this.getScheduleMessages(parameters);
    } else if (this.ddlsearch == "sm_trigger_type") {
      this.ddltriggertypediv = true;
      this.searchtextdiv = false;
      this.ddlsearchtriggertypechange();
    }
  }

  searchMessage() {
    if (this.txtsrch == '') {
      this.srchError = '1';
    }
    else if (this.txtsrch != "") {
      this.srchError = '0';
      if (this.ddlsearch == "sm_message") {
        var status;
        if (this.selectedoption == 'Active') { status = 'Y'; }
        else if (this.selectedoption == 'In-Active') { status = 'N'; }
        let parameters = {
          searchvalue: " WHERE SM_MESSAGE LIKE '%" + this.txtsrch + "%'AND SM_GCB_ID =" + this.clubId + "  and SM_GC_ID='" + this.courseid + "' and SM_STATUS<>'D' AND SM_STATUS = '" + status + "'"
        };
        this.getScheduleMessages(parameters);
        this.txtsrch = "";
      }
    }
  }

  ddlsearchtriggertypechange() {
    let parameters = {};
    var status;
    if (this.selectedoption == 'Active') { status = 'Y'; }
    else if (this.selectedoption == 'In-Active') { status = 'N'; }
    if (this.ddlsearchtriggertype == "0") {
      parameters = {
        searchvalue: " WHERE SM_STATUS<>'D' and SM_GC_ID='" + this.courseid + "' AND SM_GCB_ID =" + this.clubId + " AND SM_STATUS = '" + status + "'"
      };
    } else {
      parameters = {
        searchvalue: " WHERE SM_TRIGGER_TYPE = '" + this.ddlsearchtriggertype + "' AND SM_GC_ID='" + this.courseid + "' AND SM_GCB_ID =" + this.clubId + " AND SM_STATUS<>'D' AND SM_STATUS = '" + status + "' "
      };
    }
    this.getScheduleMessages(parameters);
  }

  // getHolesList()
  // {
  //   this.holeslist = [];
  //   for(let i = 0; i < 1; i++)
  //   {
  //     this.holeslist.push({
  //       "id": i,
  //       "holeId":0,
  //       "description": ""
  //     });
  //     this.schedulemessageForm.addControl('fholeId' + i, this.formBuilder.control([0]));
  //     this.schedulemessageForm.addControl('fdescription' + i, this.formBuilder.control(['']));
  //   }
  // }

  // addMoreHoleMessages()
  // {
  //   var holecount = (this.holeslist.length - 1) + 1;
  //   var holecountlength = this.holeslist.length + 1;
  //   for(let i = holecount; i < holecountlength; i++)
  //   {
  //     this.holeslist.push({
  //       "id": i,
  //       "holeId":0,
  //       "description": ""
  //     });
  //     this.schedulemessageForm.addControl('fholeId' + i, this.formBuilder.control([0]));
  //     this.schedulemessageForm.addControl('fdescription' + i, this.formBuilder.control(['']));
  //   }
  // }

  sort(value: string) {
    this.key = value;
    this.messageasc = "sortwhite"; this.messagedesc = "sortwhite";
    this.triggertypeasc = "sortwhite"; this.triggertypedesc = "sortwhite";
    this.holeidasc = "sortwhite"; this.holeiddesc = "sortwhite";
    this.starttimeasc = "sortwhite"; this.starttimedesc = "sortwhite";
    this.endtimeasc = "sortwhite"; this.endtimedesc = "sortwhite";
    if (this.key == value) {
      this.reverse = !this.reverse;
      if (this.key == "labelname" && this.reverse) {
        this.messagedesc = "sortgreen";
      }
      else if (this.key == "labelname" && (!this.reverse)) {
        this.messageasc = "sortgreen";
      }
      if (this.key == "triggertype" && this.reverse) {
        this.triggertypedesc = "sortgreen";
      }
      else if (this.key == "triggertype" && (!this.reverse)) {
        this.triggertypeasc = "sortgreen";
      }
      if (this.key == "holeid" && this.reverse) {
        this.holeiddesc = "sortgreen";
      }
      else if (this.key == "holeid" && (!this.reverse)) {
        this.holeidasc = "sortgreen";
      }
      if (this.key == "starttime" && this.reverse) {
        this.starttimedesc = "sortgreen";
      }
      else if (this.key == "starttime" && (!this.reverse)) {
        this.starttimeasc = "sortgreen";
      }
      if (this.key == "endtime" && this.reverse) {
        this.endtimedesc = "sortgreen";
      }
      else if (this.key == "endtime" && (!this.reverse)) {
        this.endtimeasc = "sortgreen";
      }
    }

  }

  addScheduleMessages() {
    this.getholedetails();
    this.desclength = 180;
    this.schedulemessageForm.reset();
    this.schedulemessageForm.controls['ftriggertype'].reset('0');
    this.divheader = "Add Schedule Message";
    this.openStartRoundOptions = "none";
    this.openEndRoundOptions = "none";
    this.openStartHoleOptions = "none";
    this.openEndHoleOptions = "none";
    this.triggertype = "0";
    this.addShow = "block"; this.searchInfo = "none"; this.gridInfo = "none"; this.viewInfo = "none"; this.showStatus = "none";
    this.submitAttempt = false; this.action = "A"; this.status = 'Y'; this.id = 0; this.MessageduringEdit = ""; this.holeValueduringEdit = "0";
    this.startdateerrormsg = ""; this.starttimeerrormsg = ""; this.enddateerrormsg = ""; this.endtimeerrormsg = "";
    this.holeexistserrormsg = ''; this.startroundDescerrormsg = ""; this.endroundDescerrormsg = ""; this.holemessagedetailserrormsg = "";
    this.dateDifferenceerror = ""; this.timeDifferenceerror = "";
    this.holeIds = []; this.descriptions = [];
    this.messagestatus = 'N';
    count = 0; this.arr = []; index = []; removedindexes = [];
    $('#description1').val(''); $('#description2').val('');
    this.smreccount = true;
  }

  cancelMessage() {
    if (this.action == 'A') {
      this.searchInfo = "block"; this.gridInfo = "block"; this.addShow = "none"; this.viewInfo = "none";
      this.triggertype = "0";
      this.MessageduringEdit = ""; this.holeValueduringEdit = "0";
      this.openStartRoundOptions = "none";
      this.openEndRoundOptions = "none";
      this.openStartHoleOptions = "none";
      this.openEndHoleOptions = "none";
      this.startdateerrormsg = ""; this.starttimeerrormsg = ""; this.enddateerrormsg = ""; this.endtimeerrormsg = "";
      this.dateDifferenceerror = ""; this.timeDifferenceerror = "";
      this.holeexistserrormsg = ""; this.startroundDescerrormsg = ""; this.endroundDescerrormsg = "";
      this.holemessagedetailserrormsg = "";
      this.schedulemessageForm.reset();
      this.submitAttempt = false;
      count = 0; this.holeIds = []; this.descriptions = [];
      this.arr = []; removedindexes = []; index = [];
    }
    else if (this.action == 'U') {
      this.searchInfo = "none"; this.gridInfo = "none"; this.addShow = "none"; this.viewInfo = "block";
      count = 0; this.holeIds = []; this.descriptions = [];
      this.arr = [];
      this.startdateerrormsg = ""; this.starttimeerrormsg = ""; this.enddateerrormsg = ""; this.endtimeerrormsg = "";
      this.dateDifferenceerror = ""; this.timeDifferenceerror = "";
      this.holeexistserrormsg = ""; this.startroundDescerrormsg = ""; this.endroundDescerrormsg = "";
      this.holemessagedetailserrormsg = "";
      this.openStartRoundOptions = "none";
      this.openEndRoundOptions = "none";
      this.openStartHoleOptions = "none";
      this.openEndHoleOptions = "none";
      this.triggertype = "0";
      this.MessageduringEdit = ""; this.holeValueduringEdit = "0";
      this.viewMessage(this.geteditrecordInfo);
    }
    //this.refreshpage();
  }

  bindselectedoption(selectedoption) {
    this.srchError = '0';
    this.txtsrch = ""; this.ddlsearch = "sm_message";
    this.ddlsearchtriggertype = "0";
    this.srchError = '0';
    this.ddltriggertypediv = false;
    this.searchtextdiv = true;
    if (this.selectedoption == 'Active') {
      this.randomcolor = "#5cb85c";
      this.searchStatus('Y');
    }
    else if (this.selectedoption == 'In-Active') {
      this.randomcolor = "#337ab7";
      this.searchStatus('N');
    }
    else if (this.selectedoption == 'Deleted') {
      this.randomcolor = "#d9534f";
      this.searchStatus('D');
    }
  }

  searchStatus(type) {
    let parameters = {
      searchvalue: " WHERE SM_STATUS= '" + type + "'  and SM_GC_ID='" + this.courseid + "' AND SM_GCB_ID =" + this.clubId + ""
    };
    this.getScheduleMessages(parameters);
  }

  srchKeyUp(event: any) {
    if (this.txtsrch != '') {
      this.srchError = '0';
    }
  }

  refreshpage() {
    this.txtsrch = ""; this.ddlsearch = "sm_message";
    this.ddlsearchtriggertype = "0";
    this.srchError = '0';
    this.ddltriggertypediv = false;
    this.searchtextdiv = true;
    this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
    let parameters = { searchvalue: " where SM_STATUS='Y'  and SM_GC_ID='" + this.courseid + "' AND SM_GCB_ID =" + this.clubId + "" };
    this.getScheduleMessages(parameters);
  }

  getScheduleMessages(parameters) {
    this.ScheduleMessages = [];
    this.refreshBtn = true;
    this.spinnerService.show();
    this.api.postOH('getschedulemessages', parameters).subscribe(
      response => {
        this.spinnerService.hide();
        if (response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            var status = (response[i].sm_status == 'Y') ? "Active" : (response[i].sm_status == 'N') ? "In-Active" : "Deleted";
            var statusclass = (response[i].sm_status == 'Y') ? "active-status" : (response[i].sm_status == 'N') ? "inactive-status" : "deleted-status";
            this.ScheduleMessages.push({
              "id": response[i].sm_id,
              "clubid": response[i].sm_gcb_id,
              "courseids": response[i].sm_gc_id,
              "holeid": parseInt(response[i].sm_hd_id),
              "message": response[i].sm_message,
              "startdate": new Date(response[i].sm_start_date),
              "enddate": new Date(response[i].sm_end_date),
              "starttime": new Date(response[i].sm_start_date + ' ' + response[i].sm_start_time),
              "endtime": new Date(response[i].sm_end_date + ' ' + response[i].sm_end_time),
              "messagestatus": response[i].sm_message_status,
              "triggertype": response[i].sm_trigger_type,
              "createddate": response[i].sm_ts,
              "status": status,
              "statusclass": statusclass
            });
          }
          this.refreshBtn = false;

        } else {
          this.ScheduleMessages = []; this.refreshBtn = false;
          this.GridMessage = "No Records Found";
        }
      },
      err => {
        this.spinnerService.hide();
      }
    );
  }

  viewMessage(messageInfo) {
    this.searchInfo = "none"; this.gridInfo = "none"; this.viewInfo = "block"; this.clubname = localStorage.getItem('clubname');
    this.id = messageInfo.sm_id;
    this.triggertype = messageInfo.triggertype;
    this.getholedetails();
    this.viewMessageText = messageInfo.message;
    this.StartDate = messageInfo.startdate;
    this.StartTime = messageInfo.starttime;
    this.EndDate = messageInfo.enddate;
    this.EndTime = messageInfo.endtime;
    this.checkStatus = (messageInfo.status == 'Active') ? 'Active' : (messageInfo.status == 'In-Active') ? 'In-Active' : 'Deleted';
    if (messageInfo.status == 'Active') {
      this.status = 'Y';
    }
    else if (messageInfo.status == 'In-Active') {
      this.status = 'N';
    }
    else if (messageInfo.status == 'Deleted') {
      this.status = 'D';
    }
    this.editRecordInfo = [];
    this.editRecordInfo = messageInfo;
  }

  goBack() {
    this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
    this.searchInfo = "block"; this.gridInfo = "block"; this.addShow = "none"; this.viewInfo = "none";
    let parameters = { searchvalue: " where SM_STATUS='Y' and SM_GC_ID='" + this.courseid + "' AND SM_GCB_ID =" + this.clubId + "" };
    this.getScheduleMessages(parameters);
  }

  editMessage(editRecord) {
    //console.log(editRecord);

    this.action = "U";
    this.holeIds = []; this.descriptions = [];
    this.addShow = "block"; this.searchInfo = "none"; this.gridInfo = "none"; this.viewInfo = "none";
    this.showStatus = "block";
    this.openStartRoundOptions = "none";
    this.openEndRoundOptions = "none";
    this.openStartHoleOptions = "none";
    this.openEndHoleOptions = "none";
    this.divheader = "Edit Schedule Message";
    this.geteditrecordInfo = editRecord;
    count = 0; this.arr = [];
    this.holeValueduringEdit = "0"; this.MessageduringEdit = '';
    //this.changeTriggertype(editRecord.triggertype);
    this.triggertype = editRecord.triggertype;
    this.id = editRecord.id;
    this.StartDate = editRecord.startdate;
    this.StartTime = editRecord.starttime;
    this.EndDate = editRecord.enddate;
    this.EndTime = editRecord.endtime;
    this.messagestatus = 'N'; var recstatus = "";
    if (editRecord.status == "Active") {
      recstatus = 'Y';
    }
    else if (editRecord.status == "In-Active") {
      recstatus = 'N';
    }
    this.status = (recstatus == 'Y') ? true : false;
    if (this.triggertype == "SR") {
      this.openStartRoundOptions = "block";
      this.openEndRoundOptions = "none";
      this.openStartHoleOptions = "none";
      this.openEndHoleOptions = "none";
      $('#description1').val(editRecord.message);
      this.desclength = 180 - editRecord.message.length;
    }
    else if (this.triggertype == "ER") {
      this.openStartRoundOptions = "none";
      this.openEndRoundOptions = "block";
      this.openStartHoleOptions = "none";
      this.openEndHoleOptions = "none";
      $('#description2').val(editRecord.message);
      this.desclength = 180 - editRecord.message.length;

    }
    else if (this.triggertype == "SH") {
      this.openStartRoundOptions = "none";
      this.openEndRoundOptions = "none";
      this.openStartHoleOptions = "block";
      this.openEndHoleOptions = "none";
      count = 0; this.arr = [];
      count = count + 1;
      this.arr.push(count);
      this.holeValueduringEdit = "0"; this.MessageduringEdit = '';
      this.MessageduringEdit = editRecord.message;
      this.holeValueduringEdit = editRecord.holeid;
      this.desclength = 180 - this.MessageduringEdit.length;
    }
    else if (this.triggertype == "EH") {
      this.openStartRoundOptions = "none";
      this.openEndRoundOptions = "none";
      this.openStartHoleOptions = "none";
      this.openEndHoleOptions = "block";
      count = 0; this.arr = [];
      count = count + 1;
      this.arr.push(count);
      this.holeValueduringEdit = "0"; this.MessageduringEdit = '';
      this.MessageduringEdit = editRecord.message;
      this.holeValueduringEdit = editRecord.holeid;
      this.desclength = 180 - this.MessageduringEdit.length;
    }

  }

  onKeyUp(event: any) {
    if (this.triggertype == 'SH' && this.action == 'A') {
      for (var i = 1; i <= count; i++) {
        var current = 'description_' + i;
        if (event.target.id == current) {
          $('#desclength_' + i).text(180 - (event.target.value.length));
        }
      }
    }
    if (this.triggertype == 'EH' && this.action == 'A') {
      for (var i = 1; i <= count; i++) {
        var current = 'description1_' + i;
        if (event.target.id == current) {
          $('#desclength1_' + count).text(180 - (event.target.value.length));
        }
      }
    }
    if (this.triggertype == 'SR' || this.triggertype == 'ER') {
      this.desclength = 180 - event.target.value.length;
      if (this.triggertype == 'SR') {
        if (this.desclength == 180) {
          this.startroundDescerrormsg = "Enter Message";
        }
        else {
          this.startroundDescerrormsg = "";
        }
      }
      if (this.triggertype == 'ER') {
        if (this.desclength == 180) {
          this.endroundDescerrormsg = "Enter Message";
        }
        else {
          this.endroundDescerrormsg = "";
        }
      }

    }
    if ((this.triggertype == 'SH' || this.triggertype == 'EH') && this.action == 'U') {
      this.desclength = 180 - event.target.value.length;
      if (this.triggertype == 'SH') {
        if (this.desclength == 180) {
          this.holeexistserrormsg = "Enter Message";
        }
        else {
          this.holeexistserrormsg = "";
        }

      }
      if (this.triggertype == 'EH') {
        if (this.desclength == 180) {
          this.holeexistserrormsg = "Enter Message";
        }
        else {
          this.holeexistserrormsg = "";
        }
      }
    }
  }

  getDateDifference(startDate, endDate) {
    this.totalDuration = "";
    let diffInMs: number = Date.parse(endDate) - Date.parse(startDate);

    var day, hour, minute, seconds;
    seconds = Math.floor(diffInMs / 1000);
    minute = Math.floor(seconds / 60);
    seconds = seconds % 60;
    hour = Math.floor(minute / 60);
    minute = minute % 60;
    this.totalDuration = hour + 'hours' + " " + minute + 'mins';
  }

  getMessageWithSameDuration() {
    this.smreccount = true;
    let startdate;
    let starttime;
    let enddate;
    let endtime;
    if (!this.schedulemessageForm.valid) {
    }
    this.submitAttempt = true;
    if (this.minStartDate >= this.StartDate || this.minEndDate >= this.EndDate) {
      this.startdateerrormsg = "Start Date cannot be less than Minimum Date in Calendar";
    }
    else {
      this.startdateerrormsg = "";
    }
    if (this.minEndDate >= this.EndDate) {
      this.enddateerrormsg = "End Date cannot be less than Minimum Date in Calendar";
    }
    else {
      this.enddateerrormsg = "";
    }
    if (this.schedulemessageForm.valid) {
      var holeIds = ""; var messages = "";
      this.holeexistserrormsg = "";
      this.startroundDescerrormsg = ""; this.endroundDescerrormsg = "";
      if (this.triggertype == 'SR') {
        this.holeIds = []; this.descriptions = [];
        this.holeIds.push(0);
        if ($('#description1').val() == '') {
          this.startroundDescerrormsg = "Enter Message";
        }
        else {
          this.startroundDescerrormsg = "";
          this.descriptions.push($('#description1').val());
        }
        holeIds = this.holeIds.toString();
        messages = this.descriptions.toString();
      }
      else if (this.triggertype == 'ER') {
        this.holeIds = []; this.descriptions = [];
        this.holeIds.push(0);
        if ($('#description2').val() == '') {
          this.endroundDescerrormsg = "Enter Message";
        }
        else {
          this.endroundDescerrormsg = "";
          this.descriptions.push($('#description2').val());
        }

        holeIds = this.holeIds.toString();
        messages = this.descriptions.toString();
      }
      else if (this.triggertype == 'SH' && this.arr != []) {
        if (this.action == 'U') {
          this.holeIds = []; this.descriptions = [];
          for (var m = 1; m <= count; m++) {
            if (this.MessageduringEdit == '' && this.holeValueduringEdit == '0') {
              this.holeexistserrormsg = "Select hole and enter Message";
            }
            else if (this.MessageduringEdit != '' && this.holeValueduringEdit != '0') {
              this.holeexistserrormsg = "";
              this.holeIds.push(this.holeValueduringEdit);
              this.descriptions.push(this.MessageduringEdit);
            }
          }
        }
        if (this.action == 'A') {
          let checkDuplicateholes = [];
          this.holeexistserrormsg = '';
          this.holeIds = []; this.descriptions = [];
          for (var m = 1; m <= count; m++) {
            this.holeIds.push($('#holeId_' + m).val());
            this.descriptions.push($('#description_' + m).val());
          }
          checkDuplicateholes = this.find_duplicate_in_array(this.holeIds);
          //console.log(checkDuplicateholes);
          if (checkDuplicateholes.includes('undefined')) {
            checkDuplicateholes.splice(-1);
          }
          //console.log(checkDuplicateholes);
          if (checkDuplicateholes.toString() != "" || checkDuplicateholes.toString() != "undefined") {
            this.holeexistserrormsg = "Hole Id(s) " + checkDuplicateholes.toString() + " already exists!!!";
          }
          if (checkDuplicateholes.length == 0) {
            this.holeexistserrormsg = '';
            this.holeIds = this.removeDuplicates(this.holeIds);
          }
        }
        if (this.arr.length != 0 && this.holeexistserrormsg == '') {
          if ((this.holeIds == 0 || this.descriptions == []) || (this.holeIds.toString() == ",0" || this.descriptions.toString() == ",")) {
            this.holeexistserrormsg = "Select Hole and Enter Message";
          }
          if ((this.holeIds != 0 && this.descriptions != []) || (this.holeIds.toString() != ",0" && this.descriptions.toString() != ",")) {
            this.holeexistserrormsg = "";
            holeIds = this.holeIds.toString();
            messages = this.descriptions.toString();

            if (holeIds.includes(",,")) {
              holeIds = holeIds.replace(",,", ",");
            }
            if (holeIds.includes("(,")) {
              holeIds = holeIds.replace(",,", "");
            }
            if (holeIds == ",") {
              holeIds = '';
            }
            if (messages.includes(",,")) {
              messages = messages.replace(",,", ",");
            }
            if (messages.includes("(,")) {
              messages = messages.replace(",,", "");
            }
            if (messages == ",") {
              messages = '';
            }
          }
        }
      }
      else if (this.triggertype == 'EH' && this.arr != []) {
        if (this.action == 'U') {
          this.holeIds = []; this.descriptions = [];
          for (var m = 1; m <= count; m++) {
            if (this.MessageduringEdit == '' || this.holeValueduringEdit == '0') {
              this.holeexistserrormsg = "Select hole and enter Message";
            }
            else if (this.MessageduringEdit != '' || this.holeValueduringEdit != '0') {
              this.holeexistserrormsg = "";
              this.holeIds.push(this.holeValueduringEdit);
              this.descriptions.push(this.MessageduringEdit);
            }
          }
        }
        if (this.action == 'A') {
          let checkDuplicateholes;
          this.holeexistserrormsg = '';
          this.holeIds = []; this.descriptions = [];
          for (var m = 1; m <= count; m++) {
            if ($('#holeId1_' + m).val() != 0 && $('#description1_' + m).val() != '') {
              this.holeIds.push($('#holeId1_' + m).val());
              this.descriptions.push($('#description1_' + m).val());
            }
          }
          checkDuplicateholes = this.find_duplicate_in_array(this.holeIds);
          if (checkDuplicateholes.includes('undefined')) {
            checkDuplicateholes.splice(-1);
          }
          //console.log(checkDuplicateholes.toString());
          if (checkDuplicateholes.toString() != "" || checkDuplicateholes.toString() != "undefined") {
            this.holeexistserrormsg = "Hole Id(s) " + checkDuplicateholes.toString() + " already exists!!!";
          }
          if (checkDuplicateholes.length == 0) {
            this.holeexistserrormsg = '';
            this.holeIds = this.removeDuplicates(this.holeIds);
          }
        }
        if (this.arr.length != 0 && this.holeexistserrormsg == '') {
          if ((this.holeIds == 0 || this.descriptions == []) || (this.holeIds.toString() == ",0" || this.descriptions.toString() == ",")) {
            this.holeexistserrormsg = "Select Hole and Enter Message";
          }
          if ((this.holeIds != 0 && this.descriptions != []) || (this.holeIds.toString() != ",0" && this.descriptions.toString() != ",")) {
            this.holeexistserrormsg = "";
            holeIds = this.holeIds.toString();
            messages = this.descriptions.toString();

            if (holeIds.includes(",,")) {
              holeIds = holeIds.replace(",,", ",");
            }
            if (holeIds.includes("(,")) {
              holeIds = holeIds.replace(",,", "");
            }
            if (holeIds == ",") {
              holeIds = '';
            }
            if (messages.includes(",,")) {
              messages = messages.replace(",,", ",");
            }
            if (messages.includes("(,")) {
              messages = messages.replace(",,", "");
            }
            if (messages == ",") {
              messages = '';
            }
          }
        }

      }

      if (this.StartDate == undefined) {
        this.startdateerrormsg = "Select Start Date";
      }
      else {
        this.startdateerrormsg = "";
      }
      if (this.EndDate == undefined) {
        this.enddateerrormsg = "Select End Date";
      }
      else {
        this.enddateerrormsg = "";
      }
      if (this.StartTime == undefined) {
        this.starttimeerrormsg = "Select Start Time";
      }
      else {
        this.starttimeerrormsg = "";
      }
      if (this.EndTime == undefined) {
        this.endtimeerrormsg = "Select End Time";
      }
      else {
        this.endtimeerrormsg = "";
      }
      if (this.startdateerrormsg == "" && this.enddateerrormsg == "" && this.starttimeerrormsg == "" && this.endtimeerrormsg == "") {
        startdate = moment(this.StartDate).format('MM/DD/YYYY');
        starttime = moment(this.StartTime).format('hh:mm A');
        enddate = moment(this.EndDate).format('MM/DD/YYYY');
        endtime = moment(this.EndTime).format('hh:mm A');
        let presentStartDate = new Date(startdate + ' ' + starttime);
        let presentEndDate = new Date(enddate + ' ' + endtime);
        this.getDateDifference(presentStartDate, presentEndDate);
        if (moment(enddate).isBefore(startdate)) {
          this.timeDifferenceerror = "";
          this.dateDifferenceerror = "End Date cannot be less than Start Date";
        }
        if (moment(enddate).isSame(startdate)) {
          this.dateDifferenceerror = "";
          if (this.totalDuration == '0hours 0mins') {
            this.timeDifferenceerror = "End Time cannot be equal to Start Time for Same Date";
          }
          if (this.StartTime > this.EndTime && this.totalDuration != '0hours 0mins') {
            this.timeDifferenceerror = "End Time cannot be less than Start Time for Same Date";
          }
          else if (this.StartTime < this.EndTime && this.totalDuration != '0hours 0mins') {
            this.timeDifferenceerror = "";
          }
        }
        if (moment(enddate).isAfter(startdate)) {
          this.dateDifferenceerror = "";
          this.timeDifferenceerror = "";
        }
        let parameters: any;
        if (this.action == 'A') {
          parameters = {
            searchvalue: " where SM_STATUS='Y' AND SM_GC_ID=" + this.courseid + " AND SM_GCB_ID=" + this.clubId + " AND SM_HD_ID = " + holeIds + " AND SM_TRIGGER_TYPE = '" + this.triggertype + "' AND SM_START_DATE = '" + startdate + "' AND SM_END_DATE = '" + enddate + "' AND SM_START_TIME = '" + starttime + "' AND SM_END_TIME = '" + endtime + "'"
          };
        }
        else if (this.action == 'U') {
          parameters = {
            searchvalue: " where SM_STATUS='Y' AND SM_GC_ID=" + this.courseid + " AND SM_GCB_ID=" + this.clubId + " AND SM_HD_ID = " + holeIds + " AND SM_TRIGGER_TYPE = '" + this.triggertype + "' AND SM_START_DATE = '" + startdate + "' AND SM_END_DATE = '" + enddate + "' AND SM_START_TIME = '" + starttime + "' AND SM_END_TIME = '" + endtime + "' AND SM_ID != " + this.id + ""
          };
        }

        this.api.postOH('getSMCountforSameDuration', parameters).subscribe(
          (result) => {
            if (this.action == 'A') {
              // if (parseInt(result.getSMCountforSameDurationResult) >= 1) {
              //   this.smreccount = true;
              //   this.openModal1(this.tempToSave);
              // }
              // if (parseInt(result.getSMCountforSameDurationResult) == 0) {
              this.smreccount = false;
              this.saveMessage(holeIds, messages);
              // }
            }
            if (this.action == 'U') {
              // if (parseInt(result.getSMCountforSameDurationResult) >= 1) {
              //   this.smreccount = true;
              //   this.openModal1(this.tempToSave);
              // }
              // if (parseInt(result.getSMCountforSameDurationResult) == 0) {
              this.smreccount = false;
              this.saveMessage(holeIds, messages);
              //}
            }
          }
        )
      }
    }
  }

  confirmSave() {
    this.modalRef.hide();
    this.smreccount = false;
    this.saveMessage(this.holeIds.toString(), this.descriptions.toString());
  }

  declineSave() {
    this.modalRef.hide();
  }

  saveMessage(holeIds, messages) {
    if (((this.triggertype == 'SH' && this.arr.length != 0 && holeIds != "" && messages != "") || (this.triggertype == 'EH' && this.arr.length != 0 && holeIds != "" && messages != "") ||
      (this.triggertype == 'SR' && holeIds != "" && messages != "") || (this.triggertype == 'ER' && holeIds != "" && messages != ""))
      && this.startdateerrormsg == "" && this.enddateerrormsg == "" && this.starttimeerrormsg == "" && this.endtimeerrormsg == "" && this.dateDifferenceerror == '' &&
      this.timeDifferenceerror == '' && this.holeexistserrormsg == '' && this.endroundDescerrormsg == '' && this.startroundDescerrormsg == '' && this.smreccount == false) {
      let startdate = moment(this.StartDate).format('MM/DD/YYYY');
      let starttime = moment(this.StartTime).format('hh:mm A');
      let enddate = moment(this.EndDate).format('MM/DD/YYYY');
      let endtime = moment(this.EndTime).format('hh:mm A');
      var smstatus;
      if (this.action == 'A') { smstatus = 'Y'; }
      else if (this.action == 'U') {
        if (this.status == true) { smstatus = 'Y'; }
        else { smstatus = 'N'; }
      }
      this.contactBtn = true;
      var scheduleMsgModel = {
        "action": this.action, "sm_id": this.id, "sm_gcb_id": this.clubId, "sm_gc_id": this.courseid,
        "sm_hd_id": holeIds, "sm_message": messages,
        "sm_trigger_type": this.triggertype, "sm_start_date": startdate, "sm_end_date": enddate,
        "sm_start_time": starttime, "sm_end_time": endtime,
        "sm_message_status": this.messagestatus, "sm_status": smstatus
      }
      //console.log(scheduleMsgModel);
      this.spinnerService.show();
      this.api.postOH('saveschedulemessages', scheduleMsgModel).subscribe(
        (response) => {
          //console.log(response);
          if (this.action == 'A' || this.action == 'U') {
            if (response[1] == "Schedule Messages Added Successfully" || response[1] == "Schedule Messages Updated Successfully") {
              let parameters = { searchvalue: " where SM_STATUS='Y'  and SM_GC_ID='" + this.courseid + "'  and SM_GCB_ID='" + this.clubId + "' " };
              this.getScheduleMessages(parameters);
              this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
              this.searchInfo = "block"; this.gridInfo = "block"; this.addShow = "none"; this.viewInfo = "none";
              this.openStartRoundOptions = "none";
              this.openEndRoundOptions = "none";
              this.openStartHoleOptions = "none";
              this.openEndHoleOptions = "none";
              this.schedulemessageForm.reset();
              this.descriptions = ""; this.triggertype = "0"; this.holeIds = []; this.StartDate = ""; this.StartTime = ""; this.EndDate = ""; this.EndTime = "";
              count = 0;
              this.arr = []; index = []; removedindexes = [];
              let msg;
              if (this.action == 'A') {
                msg = '<span style="color: green">' + response[1] + '.' + '</span>';
              }
              else if (this.action == 'U') {
                msg = '<span style="color: green"> Schedule Message Updated Successfully.' + '</span>';
              }
              this.toastMessage(msg);
              this.contactBtn = false;
            }
            else {
              this.contactBtn = false;
              let msg = '<span style="color: red">' + response[1] + '.' + '</span>';
              this.toastMessage(msg);
            }
          }
          this.spinnerService.hide();
          window.scrollTo(0, 0);
        }, error => {
          this.spinnerService.hide();
        })
    }
  }

  find_duplicate_in_array(arra1) {
    var object = {};
    var result = [];

    arra1.forEach(function (item) {
      if (!object[item])
        object[item] = 0;
      object[item] += 1;
    })

    for (var prop in object) {
      if (object[prop] >= 2) {
        result.push(prop);
      }
    }

    return result;

  }

  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',
    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 3000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right',
    });
  }

  openModal(template: TemplateRef<any>, recordInfo) {
    this.currentRecInfo = "";
    this.currentRecInfo = recordInfo;
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }

  openModal1(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }

  confirm(): void {
    this.modalRef.hide();
    this.status = "D";
    this.action = "D";
    var scheduleMsgModel = {
      "action": this.action, "sm_id": this.currentRecInfo.id, "sm_gcb_id": this.clubId, "sm_gc_id": this.courseid, "sm_hd_id": "", "sm_message": "",
      "sm_trigger_type": "", "sm_start_date": "", "sm_end_date": "", "sm_start_time": "", "sm_end_time": "",
      "sm_message_status": 'N', "sm_status": this.status
    }
    let msg = '<span style="color: green">Schedule Message Deleted Successfully.</span>';
    this.DEapicall(scheduleMsgModel, msg);
  }

  enableMessage(tobeenabledRecordInfo): void {
    this.modalRef.hide();
    this.status = "Y";
    this.action = "E";
    var scheduleMsgModel = {
      "action": this.action, "sm_id": tobeenabledRecordInfo.id, "sm_gcb_id": this.clubId, "sm_gc_id": this.courseid, "sm_hd_id": "", "sm_message": "",
      "sm_trigger_type": "", "sm_start_date": "", "sm_end_date": "", "sm_start_time": "", "sm_end_time": "",
      "sm_message_status": 'N', "sm_status": this.status
    }
    let msg = '<span style="color: green">Course Message Enabled Successfully.</span>';
    this.DEapicall(scheduleMsgModel, msg);
  }

  DEapicall(scheduleMsgModel, msg) {
    //console.log(scheduleMsgModel);
    this.api.postOH('saveschedulemessages', scheduleMsgModel).subscribe(
      (response) => {
        let parameters = { searchvalue: " where SM_STATUS='Y' and SM_GC_ID='" + this.courseid + "' AND SM_GCB_ID =" + this.clubId + "" };
        this.getScheduleMessages(parameters);
        this.action = 'A';
        this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
        this.searchInfo = "block"; this.gridInfo = "block"; this.addShow = "none"; this.viewInfo = "none";
        this.showStatus = "none";
        this.toastMessage(msg);
      }, error => {
        let msg = '<span style="color: red">Failed to update the data, please try again.</span>';
        this.toastMessage(msg);
      });
  }

  decline(): void {
    this.modalRef.hide();
  }

  removeDuplicates(arr) {
    let unique_array = []
    for (let i = 0; i < arr.length; i++) {
      if (unique_array.indexOf(arr[i]) == -1) {
        unique_array.push(arr[i]);
      }
    }
    return unique_array;
  }

  getholedetails() {
    let parameters = { searchvalue: " WHERE HD_GCB_ID =" + this.clubId + " AND  HD_GC_ID =" + this.courseid + " AND HD_STATUS = 'Y'" };
    this.api.postOH('getholes', parameters).subscribe(
      (result) => {
        // if (this.triggertype == "SR") {
        //   this.startroundholes = [];
        //   for (var i = 0; i < result.length; i++) {
        //     if (result[i].sequence == "1" || result[i].sequence == "10") {
        //       this.startroundholes.push(result[i]);
        //     }
        //   }
        // }
        // else if (this.triggertype == "ER") {
        //   this.endroundholes = [];
        //   for (var i = 0; i < result.length; i++) {
        //     if (result[i].sequence == "9" || result[i].sequence == "18") {
        //       this.endroundholes.push(result[i]);
        //     }
        //   }
        // }
        // if (this.triggertype == "SH" || this.triggertype == "EH") {
        this.holedetails = [];
        for (var i = 0; i < result.length; i++) {
          this.holedetails = result;
        }
        //}
      }
    )
  }

  removeItem(c) {
    index = [];
    index.push(this.arr.indexOf(c));
    removedindexes.push(this.arr.indexOf(c));
    for (var m = 0; m < index.length; m++) {
      if (index[m] > -1) {
        //count = count - 1;
        this.arr.splice(index[m], 1);
      }
    }
    if (this.holeexistserrormsg != "") {
      this.holeexistserrormsg = "";
    }
  }

  addMessageforHole() {
    this.holemessagedetailserrormsg = ''; this.holeexistserrormsg = '';
    if (this.arr.length == 0) {
      count = 0;
      index = [];
    }
    if (this.triggertype == 'SH') {
      count = count + 1;
      if (count > 1) {
        this.holeIds = [];
        this.holemessagedetailserrormsg = ''; this.holeexistserrormsg = '';
        for (var i = 1; i < count; i++) {
          if (($('#holeId_' + (i)).val() != 0 && $('#description_' + (i)).val() != '')) {
            this.holeexistserrormsg = '';
            this.holemessagedetailserrormsg = '';
          }
          else {
            count = count - 1;
            this.holeexistserrormsg = '';
            this.holemessagedetailserrormsg = "Select Hole and Enter Message";
          }
          this.countRepeat();
        }
      }
      else if (count == 1) {
        this.holemessagedetailserrormsg = '';
        this.holeexistserrormsg = '';
        this.countRepeat();
      }
    }
    else if (this.triggertype == 'EH') {
      count = count + 1;
      if (count > 1) {
        this.holeIds = [];
        this.holemessagedetailserrormsg = ''; this.holeexistserrormsg = '';
        for (var i = 1; i < count; i++) {
          if (($('#holeId1_' + (i)).val() != 0 && $('#description1_' + (i)).val() != '')) {
            this.holeexistserrormsg = '';
            this.holemessagedetailserrormsg = '';
          }
          else {
            count = count - 1;
            this.holeexistserrormsg = '';
            this.holemessagedetailserrormsg = "Select Hole and Enter Message";
          }
          this.countRepeat();
        }
      }
      else if (count == 1) {
        this.holemessagedetailserrormsg = '';
        this.holeexistserrormsg = '';
        this.countRepeat();
      }
    }
  }

  countRepeat() {
    this.arr = [];
    for (var i = 1; i <= count; i++) {
      this.arr.push(i);
    }
    this.arr = this.removeDuplicates(this.arr);
    //console.log(this.arr);
    for (var m = 0; m < removedindexes.length; m++) {
      if (removedindexes[m] > -1) {
        this.arr.splice(removedindexes[m], 1);
      }
    }
  }

  changeTriggertype(trigger) {
    if (trigger == "0") {
      this.openStartRoundOptions = "none";
      this.openEndRoundOptions = "none";
      this.openStartHoleOptions = "none";
      this.openEndHoleOptions = "none";
    }
    if (trigger == "SR") {
      this.desclength = 180;
      this.holeIds = []; this.descriptions = [];
      $('#description1').val('');
      this.triggertype = trigger;
      this.openStartRoundOptions = "block";
      this.openEndRoundOptions = "none";
      this.openStartHoleOptions = "none";
      this.openEndHoleOptions = "none";
      if (this.action == 'U') {
        $('#description1').val(this.geteditrecordInfo.message);
        this.desclength = 180 - this.geteditrecordInfo.message.length;
      }
    }
    if (trigger == "ER") {
      this.desclength = 180;
      this.holeIds = []; this.descriptions = [];
      $('#description2').val('');
      this.triggertype = trigger;
      this.openStartRoundOptions = "none";
      this.openEndRoundOptions = "block";
      this.openStartHoleOptions = "none";
      this.openEndHoleOptions = "none";
      if (this.action == 'U') {
        $('#description2').val(this.geteditrecordInfo.message);
        this.desclength = 180 - this.geteditrecordInfo.message.length;
      }
    }
    if (trigger == "SH") {
      this.holeIds = []; this.descriptions = [];
      count = 0;
      this.arr = []; this.holemessagedetailserrormsg = ""; this.holeexistserrormsg = "";
      //this.holeValueduringEdit = "0"; this.MessageduringEdit = '';
      this.triggertype = trigger;
      this.openStartRoundOptions = "none";
      this.openEndRoundOptions = "none";
      this.openStartHoleOptions = "block";
      this.openEndHoleOptions = "none";

      if (this.action == 'U') {
        this.addMessageforHole();
        this.MessageduringEdit = this.geteditrecordInfo.message;
        if (this.geteditrecordInfo.holeid == "0") {
          this.holeValueduringEdit = "0";
        }
        else {
          this.holeValueduringEdit = this.geteditrecordInfo.holeid;
        }
        this.desclength = 180 - this.geteditrecordInfo.message.length;
      }
    }
    if (trigger == "EH") {
      this.holeIds = []; this.descriptions = [];
      count = 0;
      this.arr = []; this.holemessagedetailserrormsg = ""; this.holeexistserrormsg = "";
      //this.holeValueduringEdit = "0"; this.MessageduringEdit = '';
      this.triggertype = trigger;
      this.openStartRoundOptions = "none";
      this.openEndRoundOptions = "none";
      this.openStartHoleOptions = "none";
      this.openEndHoleOptions = "block";

      if (this.action == 'U') {
        this.addMessageforHole();
        this.MessageduringEdit = this.geteditrecordInfo.message;
        if (this.geteditrecordInfo.holeid == "0") {
          this.holeValueduringEdit = "0";
        }
        else {
          this.holeValueduringEdit = this.geteditrecordInfo.holeid;
        }
        this.desclength = 180 - this.geteditrecordInfo.message.length;
      }
    }
  }

  startDatedatePickerChange(value: Date): void {
    this.StartDate = value;
    this.startdateerrormsg = "";
  }

  endDatedatePickerChange(value: Date): void {
    this.EndDate = value;
    this.enddateerrormsg = "";
  }

  startTimeChange(value) {
    this.StartTime = value.value;
    this.starttimeerrormsg = "";
  }

  endTimeChange(value) {
    this.EndTime = value.value;
    this.endtimeerrormsg = "";
  }

}

