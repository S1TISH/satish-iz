import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SchedulemessagesComponent } from './schedulemessages.component';

describe('SchedulemessagesComponent', () => {
  let component: SchedulemessagesComponent;
  let fixture: ComponentFixture<SchedulemessagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SchedulemessagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SchedulemessagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
