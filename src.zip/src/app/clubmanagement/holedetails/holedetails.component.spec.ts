import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoledetailsComponent } from './holedetails.component';

describe('HoledetailsComponent', () => {
  let component: HoledetailsComponent;
  let fixture: ComponentFixture<HoledetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoledetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoledetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
