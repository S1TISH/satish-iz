import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
//import { AsyncLocalStorage } from 'angular-async-local-storage';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Title } from '@angular/platform-browser';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';

declare const google: any;

@Component({
    selector: 'app-holedetails',
    templateUrl: './holedetails.component.html',
    styleUrls: ['./holedetails.component.css']
})
export class HoledetailsComponent implements OnInit {
    modalRef: BsModalRef;

    public holesForm: FormGroup; submitAttempt: boolean = false;
    buttonShow: string = "none"; holesView: string; editView: string;
    clubId: any; courseId: any; holeId: any; userId: any; showStatus: string;
    HolesInfo: any = []; divheader: string = 'Add Hole'; path = ''; overlineimagename: string;
    public file_srcs: string[] = [];
    public debug_size_before: string[] = [];
    public debug_size_after: string[] = [];
    TotalHoles: any = [];

    //model values
    action: string = 'A'; id: number; golfclubid: any; golfcourseid: any; holename: any;
    parval: any; menhandicap: any; womenhandicap: any; clatitude: any; clongitude: any; greenzoomlevel: any; paceofplay: any;
    zoomlevel: any; rotate: any; sequence: any; overlineimage: any = ''; overlineimagepath: any = ''; overlinebinaryimage: any = '';
    updtaedid: any; status: any; holenameheader: string;
    txtgreenfrontlat: any; txtgreenfrontlong: any; txtgreenmiddlelat: any; txtgreenmiddlelong: any; txtgreenbacklat: any; txtgreenbacklong: any;
    contentbox: any; mholelatitude: any; mholelongitude: any; mholezoomlevel: any;
    mholesecondlatitude: any; mholesecondlongitude: any; mholesecondzoomlevel: any;
    mholethirdlatitude: any; mholethirdlongitude: any; mholethirdzoomlevel: any;

    //map values
    courselat: any; courselong: any; coursezoomlevel: any; courserotate: any; map: any; radiobtn: any; markertextname: any; markers: any = [];

    constructor(private title: Title, public toastr: ToastsManager, vcr: ViewContainerRef,
        private router: Router, public formBuilder: FormBuilder,
        private spinnerService: Ng4LoadingSpinnerService, private api: ApiService, private modalService: BsModalService) {

        this.title.setTitle("IZON - Hole Details");
        this.toastr.setRootViewContainerRef(vcr);

        var userId = localStorage.getItem('userId')
        this.userId = userId;
        var clubId = JSON.parse(localStorage.getItem('clubId'));
        this.clubId = clubId;
        var courseId = JSON.parse(localStorage.getItem('courseId'));
        this.courseId = courseId;
        var holeId = JSON.parse(localStorage.getItem('holeId'));
        this.holeId = holeId;
    }

    ngOnInit() {
        this.holesForm = this.formBuilder.group({
            fholename: ['', Validators.compose([Validators.required])],
            fparvalue: ['', Validators.compose([Validators.required])],
            fhandicap: ['', Validators.compose([Validators.required])],
            fladieshandicap: ['', Validators.compose([Validators.required])],
            fclatitude: ['', Validators.compose([Validators.required])],
            fclongitude: ['', Validators.compose([Validators.required])],
            txtgreenfrontlat: ['', Validators.compose([Validators.required])],
            txtgreenfrontlong: ['', Validators.compose([Validators.required])],
            txtgreenmiddlelat: ['', Validators.compose([Validators.required])],
            txtgreenmiddlelong: ['', Validators.compose([Validators.required])],
            txtgreenbacklat: ['', Validators.compose([Validators.required])],
            txtgreenbacklong: ['', Validators.compose([Validators.required])],
            fzoomlevel: ['', Validators.compose([Validators.required])],
            fgreenzoomlevel: ['0', Validators.compose([Validators.required])],
            frotate: ['', Validators.compose([Validators.required])],
            fsequence: ['', Validators.compose([Validators.required])],
            mholelatitude: [''],
            mholelongitude: [''],
            mholezoomlevel: [''],
            mholesecondlatitude: [''],
            mholesecondlongitude: [''],
            mholesecondzoomlevel: [''],
            mholethirdlatitude: [''],
            mholethirdlongitude: [''],
            mholethirdzoomlevel: [''],
            fstatus: [''],
            paceofplay: [''],
            contentbox: ['']
        });

        if (this.clubId != 0 && this.courseId != 0 && this.holeId != 0) {
            this.editView = "none";
            this.holesView = "block";
            this.getHoles(this.holeId);
            this.getTotalHolesDetails();
        }
        else if (this.clubId != 0 && this.courseId != 0 && this.holeId == 0) {
            this.addHole();
        }
        this.GetGolfCourseData();
    }

    GetGolfCourseData() {
        let parameters = { searchvalue: " WHERE GC_GCB_ID='" + this.clubId + "'" };
        this.api.postOH('getgolfcourse', parameters).subscribe(
            (response) => {
                this.courselat = response[0].latitude;
                this.courselong = response[0].longitude;
                this.coursezoomlevel = (response[0].zoomlevel != '') ? response[0].zoomlevel : 0;
                this.courserotate = (response[0].rotate != '') ? response[0].rotate : 0;
                this.maploading();
            }, error => {
            }
        );
    }

    maploading() {
        this.map = new google.maps.Map(document.getElementById('map'), {
            center: { lat: parseFloat(this.courselat), lng: parseFloat(this.courselong) },
            zoom: parseInt(this.coursezoomlevel),
            //disableDefaultUI: true,            
            mapTypeId: 'satellite',
            tilt: 0,
            rotateControl: true
        });
        this.setoverlayimage();
        let cthis = this;
        //to get zoomlevel
        // this.map.addListener('zoom_changed', function () {
        //     cthis.zoomlevel = cthis.map.getZoom();
        // });
    }
    editmaploading() {
        if (this.clatitude != '') {
            this.map = new google.maps.Map(document.getElementById('map'), {
                center: { lat: parseFloat(this.clatitude), lng: parseFloat(this.clongitude) },
                zoom: parseInt(this.zoomlevel),
                //disableDefaultUI: true,
                heading: parseInt(this.rotate),
                mapTypeId: 'satellite',
                tilt: 0,
                rotateControl: true
            });
            this.setoverlayimage();
            let cthis = this;

            //to get zoomlevel
            // this.map.addListener('zoom_changed', function () {
            //     cthis.zoomlevel = cthis.map.getZoom();
            // });
        }
    }

    setoverlayimage() {
        let me = this;
        var imageMapType = new google.maps.ImageMapType({
            getTileUrl: function (coord, zoom) {
                //console.log('http://iadmin.azaz.com/tiles/' + me.golfclubid+ '/' +me.courseid+ '/' + zoom + '/' + coord.x + '/' + coord.y + '.png');
                return ['http://cp.izongolf.com/tiles/' + me.golfclubid + '/' + me.golfcourseid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
                // let clbid=''; let cursid='';
                // if(me.golfclubid=='1002'){clbid='1445'}else{clbid=me.golfclubid};
                // if(me.golfcourseid==2){cursid='539'}else if(me.golfcourseid==3){cursid='540'}else if(me.golfcourseid==4){cursid='541'}else{cursid=me.golfcourseid};
                // return ['http://cp.izongolf.com/tiles/' + clbid + '/' + cursid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
            },
            tileSize: new google.maps.Size(256, 256)
        });
        this.map.overlayMapTypes.push(imageMapType);
    }

    setMarkers(location) {
        var marker = new google.maps.Marker({
            position: location,
            label: {
                text: this.markertextname,
                color: 'white'
            },
            draggable: true,
            map: this.map
        });
        this.markers.push(marker);
        let cthis = this;
        //to get latlong on marker drag
        google.maps.event.addListener(marker, 'dragend', function (event) {
            //alert(marker.label.text);            
            if (marker.label.text == 'C') {
                cthis.clatitude = event.latLng.lat();
                cthis.clongitude = event.latLng.lng();
            } else if (marker.label.text == 'F') {
                cthis.txtgreenfrontlat = event.latLng.lat();
                cthis.txtgreenfrontlong = event.latLng.lng();
            } else if (marker.label.text == 'M') {
                cthis.txtgreenmiddlelat = event.latLng.lat();
                cthis.txtgreenmiddlelong = event.latLng.lng();
            } else if (marker.label.text == 'B') {
                cthis.txtgreenbacklat = event.latLng.lat();
                cthis.txtgreenbacklong = event.latLng.lng();
            } else if (marker.label.text == 'FC') {
                cthis.mholelatitude = event.latLng.lat();
                cthis.mholelongitude = event.latLng.lng();
            } else if (marker.label.text == 'SC') {
                cthis.mholesecondlatitude = event.latLng.lat();
                cthis.mholesecondlongitude = event.latLng.lng();
            } else if (marker.label.text == 'TC') {
                cthis.mholethirdlatitude = event.latLng.lat();
                cthis.mholethirdlongitude = event.latLng.lng();
            } else {
                let msg = '<span style="color: red">Please select a position</span>';
                cthis.toastMessage(msg);
            }
        });
    }

    addmarkeronmap(val) {
        if (val == "C" && this.clatitude != '') {
            let msg = '<span style="color: red">Hole Center Already Exists</span>';
            this.toastMessage(msg);
        } else if (val == "F" && this.txtgreenfrontlat != '') {
            let msg = '<span style="color: red">Green Front Already Exists</span>';
            this.toastMessage(msg);
        } else if (val == "M" && this.txtgreenmiddlelat != '') {
            let msg = '<span style="color: red">Green Middle Already Exists</span>';
            this.toastMessage(msg);
        } else if (val == "B" && this.txtgreenbacklat != '') {
            let msg = '<span style="color: red">Green Back Already Exists</span>';
            this.toastMessage(msg);
        } else if (val == "FC" && this.mholelatitude != '') {
            let msg = '<span style="color: red">Mobile First Hole Center Already Exists</span>';
            this.toastMessage(msg);
        } else if (val == "SC" && this.mholesecondlatitude != '') {
            let msg = '<span style="color: red">Mobile Second Hole Center Already Exists</span>';
            this.toastMessage(msg);
        } else if (val == "TC" && this.mholethirdlatitude != '') {
            let msg = '<span style="color: red">Mobile Third Hole Center Already Exists</span>';
            this.toastMessage(msg);
        } else {
            this.markertextname = val;
            let latlnt = this.map.getCenter();
            this.deletemarker(val);
            this.setMarkers(latlnt);
        }
    }

    deletemarker(val) {
        for (var i = 0; i < this.markers.length; i++) {
            if (this.markers[i].label.text == val) {
                this.markers[i].setMap(null);
            }
        }
    }

    // Sets the map on all markers in the array.
    setMapOnAll(map) {
        for (var i = 0; i < this.markers.length; i++) {
            this.markers[i].setMap(map);
        }
    }

    // Removes the markers from the map, but keeps them in the array.
    clearMarkers() {
        this.setMapOnAll(null);
        this.markers = [];
    }

    goback() {
        localStorage.removeItem('holeId');
        this.router.navigate(['/clubmanagement/golfcourse']);
    }

    addHole() {
        this.submitAttempt = false;
        this.holesForm.reset();
        this.action = 'A'; this.id = 0; this.golfclubid = this.clubId; this.golfcourseid = this.courseId; this.holename = '';
        this.parval = ''; this.menhandicap = ''; this.womenhandicap = ''; this.clatitude = ''; this.clongitude = '';
        this.txtgreenfrontlat = ''; this.txtgreenfrontlong = ''; this.txtgreenmiddlelat = ''; this.txtgreenmiddlelong = ''; this.txtgreenbacklat = ''; this.txtgreenbacklong = '';
        this.greenzoomlevel = ''; this.zoomlevel = ''; this.rotate = ''; this.sequence = ''; this.paceofplay = ''; this.overlineimage = ''; this.overlineimagepath = '';
        this.overlinebinaryimage = ''; this.updtaedid = this.userId; this.status = 'Y'; this.contentbox = 'TR';
        this.mholelatitude = ''; this.mholelongitude = ''; this.mholezoomlevel = '';
        this.mholesecondlatitude = ''; this.mholesecondlongitude = ''; this.mholesecondzoomlevel = '';
        this.mholethirdlatitude = ''; this.mholethirdlongitude = ''; this.mholethirdzoomlevel = '';
        this.editView = "block";
        this.holesView = "none";
        this.showStatus = "none";
    }

    editHole(id) {
        this.editmaploading();
        this.action = 'U';
        this.divheader = 'Edit Hole'
        this.getHoles(id);
        this.editView = "block";
        this.holesView = "none";
        this.showStatus = "block";
    }

    cancelHole() {
        if (this.action == 'A') {
            this.router.navigate(['/clubmanagement/golfcourse']);
        }
        else {
            this.action = 'A';
            this.getHoles(this.holeId);
            this.editView = "none";
            this.holesView = "block";
            this.showStatus = "none";
        }
    }

    getHoles(id: any) {
        let parameters = { searchvalue: ' WHERE HD_GCB_ID=' + this.clubId + ' AND HD_GC_ID = ' + this.courseId + ' AND HD_ID=' + id + '' };
        this.spinnerService.show();
        this.clearMarkers();
        let latlng = {};
        this.api.postOH('getholes', parameters).subscribe(
            response => {
                if (response.length > 0) {
                    this.id = response[0].id;
                    this.golfclubid = response[0].golfclubid;
                    this.golfcourseid = response[0].golfcourseid;
                    this.holenameheader = "Hole #" + response[0].holename + " Info";
                    this.holename = response[0].holename;
                    localStorage.setItem('holename', response[0].holename);
                    this.parval = response[0].parval;
                    this.menhandicap = response[0].menhandicap;
                    this.womenhandicap = response[0].womenhandicap;

                    this.clatitude = response[0].clatitude;
                    this.clongitude = response[0].clongitude;
                    latlng = { lat: parseFloat(this.clatitude), lng: parseFloat(this.clongitude) };
                    this.markertextname = "C";
                    this.setMarkers(latlng);

                    this.txtgreenfrontlat = response[0].gflatitude;
                    this.txtgreenfrontlong = response[0].gflongitude;
                    latlng = { lat: parseFloat(this.txtgreenfrontlat), lng: parseFloat(this.txtgreenfrontlong) };
                    this.markertextname = "F";
                    this.setMarkers(latlng);

                    this.txtgreenmiddlelat = response[0].gmlatitude;
                    this.txtgreenmiddlelong = response[0].gmlongitude;
                    latlng = { lat: parseFloat(this.txtgreenmiddlelat), lng: parseFloat(this.txtgreenmiddlelong) };
                    this.markertextname = "M";
                    this.setMarkers(latlng);

                    this.txtgreenbacklat = response[0].gblatitude;
                    this.txtgreenbacklong = response[0].gblongitude;
                    latlng = { lat: parseFloat(this.txtgreenbacklat), lng: parseFloat(this.txtgreenbacklong) };
                    this.markertextname = "B";
                    this.setMarkers(latlng);

                    this.greenzoomlevel = response[0].gzoomlevel;
                    this.zoomlevel = response[0].zoomlevel;
                    this.rotate = (response[0].rotate != '') ? response[0].rotate : 0;
                    this.sequence = response[0].sequence;
                    this.paceofplay = response[0].paceofplay;
                    this.overlineimage = response[0].overlineimage;
                    this.overlineimagepath = response[0].overlineimagepath;
                    this.overlinebinaryimage = '';
                    this.updtaedid = response[0].updtaedid;
                    this.status = (response[0].status == 'Y') ? true : false;
                    this.contentbox = response[0].contentbox;

                    this.mholelatitude = response[0].mholeclatitude;
                    this.mholelongitude = response[0].mholeclongitude;
                    latlng = { lat: parseFloat(this.mholelatitude), lng: parseFloat(this.mholelongitude) };
                    this.markertextname = "FC";
                    this.setMarkers(latlng);
                    this.mholezoomlevel = response[0].mholezoomlevel;
                    this.mholesecondlatitude = response[0].mholesecondclatitude;
                    this.mholesecondlongitude = response[0].mholesecondclongitude;
                    latlng = { lat: parseFloat(this.mholesecondlatitude), lng: parseFloat(this.mholesecondlongitude) };
                    this.markertextname = "SC";
                    this.setMarkers(latlng);
                    this.mholesecondzoomlevel = response[0].mholesecondzoomlevel;
                    this.mholethirdlatitude = response[0].mholethirdclatitude;
                    this.mholethirdlongitude = response[0].mholethirdclongitude;
                    latlng = { lat: parseFloat(this.mholethirdlatitude), lng: parseFloat(this.mholethirdlongitude) };
                    this.markertextname = "TC";
                    this.setMarkers(latlng);
                    this.mholethirdzoomlevel = response[0].mholethirdzoomlevel;

                } else {
                    //alert('Something went wrong, please try again');
                    this.router.navigate(['/clubmanagement/golfcourse']);
                }
                this.spinnerService.hide();
            },
            err => {
                this.spinnerService.hide();
            }
        );
    }

    saveHole() {
        if (this.greenzoomlevel == '0') {
            this.submitAttempt = true;
        } else {
            if (!this.holesForm.valid) { }
            this.submitAttempt = true;
            if (this.holesForm.valid) {
                this.spinnerService.show();
                let imagecropped = (this.overlineimagepath != "") ? this.overlineimagepath.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
                var holesmodel = {};
                var paceofplay = '';
                if (this.paceofplay != '') {
                    paceofplay = this.paceofplay;
                } else {
                    paceofplay = '15';
                }
                if (this.action == 'A') {
                    holesmodel = {
                        "action": 'A', "id": 0, "golfclubid": this.clubId, "golfcourseid": this.courseId, "holename": this.holename,
                        "parval": this.parval, "menhandicap": this.menhandicap, "womenhandicap": this.womenhandicap, "clatitude": this.clatitude, "clongitude": this.clongitude,
                        "gflatitude": this.txtgreenfrontlat, "gflongitude": this.txtgreenfrontlong, "gmlatitude": this.txtgreenmiddlelat, "gmlongitude": this.txtgreenmiddlelong,
                        "gblatitude": this.txtgreenbacklat, "gblongitude": this.txtgreenbacklong, "gzoomlevel": this.greenzoomlevel,
                        "zoomlevel": this.zoomlevel, "rotate": this.rotate, "sequence": this.sequence, "paceofplay": paceofplay,
                        "overlineimage": this.overlineimagename, "overlinebinaryimage": imagecropped, "updtaedid": this.userId, "status": 'Y', "contentbox": this.contentbox,
                        "mholeclatitude": this.mholelatitude, "mholeclongitude": this.mholelongitude, "mholezoomlevel": this.mholezoomlevel,
                        "mholesecondclatitude": this.mholesecondlatitude, "mholesecondclongitude": this.mholesecondlongitude, "mholesecondzoomlevel": this.mholesecondzoomlevel,
                        "mholethirdclatitude": this.mholethirdlatitude, "mholethirdclongitude": this.mholethirdlongitude, "mholethirdzoomlevel": this.mholethirdzoomlevel
                    }
                }
                else if (this.action == 'U') {
                    holesmodel = {
                        "action": 'U', "id": this.id, "golfclubid": this.clubId, "golfcourseid": this.courseId, "holename": this.holename,
                        "parval": this.parval, "menhandicap": this.menhandicap, "womenhandicap": this.womenhandicap, "clatitude": this.clatitude, "clongitude": this.clongitude,
                        "gflatitude": this.txtgreenfrontlat, "gflongitude": this.txtgreenfrontlong, "gmlatitude": this.txtgreenmiddlelat, "gmlongitude": this.txtgreenmiddlelong,
                        "gblatitude": this.txtgreenbacklat, "gblongitude": this.txtgreenbacklong, "gzoomlevel": this.greenzoomlevel,
                        "zoomlevel": this.zoomlevel, "rotate": this.rotate, "sequence": this.sequence, "paceofplay": paceofplay,
                        "overlineimage": (this.overlineimage != "") ? this.overlineimage : this.overlineimagename,
                        "overlinebinaryimage": imagecropped, "updtaedid": this.userId, "status": this.status == true ? 'Y' : 'N', "contentbox": this.contentbox,
                        "mholeclatitude": this.mholelatitude, "mholeclongitude": this.mholelongitude, "mholezoomlevel": this.mholezoomlevel,
                        "mholesecondclatitude": this.mholesecondlatitude, "mholesecondclongitude": this.mholesecondlongitude, "mholesecondzoomlevel": this.mholesecondzoomlevel,
                        "mholethirdclatitude": this.mholethirdlatitude, "mholethirdclongitude": this.mholethirdlongitude, "mholethirdzoomlevel": this.mholethirdzoomlevel
                    }
                }
                this.api.postOH('saveholes', holesmodel).subscribe(
                    response => {
                        if (response.length !== 0) {
                            if (response[0] > 0 && this.action == 'A') {
                                this.router.navigate(['/clubmanagement/golfcourse']);
                                let msg = '<span style="color: green">Hole Details Added Successfully</span>';
                                this.toastMessage(msg);
                            }
                            else if (response[0] > 0 && this.action == 'U') {
                                this.action = 'A';
                                this.getHoles(this.holeId);
                                this.editView = "none";
                                this.holesView = "block";
                                this.showStatus = "none";
                                let msg = '<span style="color: green">Hole Details Updated Successfully</span>';
                                this.toastMessage(msg);
                            }
                        } else {
                            let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                            this.toastMessage(msg);
                        }
                        window.scrollTo(0, 0);
                        this.spinnerService.hide();
                    },
                    err => {
                        this.spinnerService.hide();
                    }
                );
            }
        }
    }

    //file uplaod function
    fileChange(input, fimg) {
        this.readFiles(input.files, fimg);
    }

    readFile(file, fimg, reader, callback) {
        reader.onload = () => {
            callback(reader.result);
            if (fimg == 'overline') {
                this.overlineimagepath = reader.result;
                this.overlineimagename = file.name;
            }
        }
        reader.readAsDataURL(file);
    }

    readFiles(files, fimg, index = 0) {
        let reader = new FileReader();
        if (index in files) {
            this.readFile(files[index], fimg, reader, (result) => {
                var img = document.createElement("img");
                img.src = result;
            });
        } else {

        }
    }

    resize(img, MAX_WIDTH: number, MAX_HEIGHT: number, callback) {
        return img.onload = () => {
            var width = img.width;
            var height = img.height;
            if (width > height) {
                if (width > MAX_WIDTH) {
                    height *= MAX_WIDTH / width;
                    width = MAX_WIDTH;
                }
            } else {
                if (height > MAX_HEIGHT) {
                    width *= MAX_HEIGHT / height;
                    height = MAX_HEIGHT;
                }
            }
            var canvas = document.createElement("canvas");
            canvas.width = width;
            canvas.height = height;
            var ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0, width, height);
            var dataUrl = canvas.toDataURL('image/jpeg');
            callback(dataUrl, img.src.length, dataUrl.length);
        };
    }

    //alert message
    toastMessage(msg) {
        let options = {
            positionClass: 'toast-top-center',
        };
        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 3000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }

    addholeperimeters() {
        this.router.navigate(['/perimeters/holeperimeters']);
    }

    allowNumbers(event) {
        const charCode = (event.which) ? event.which : event.keyCode;
        if (charCode == 64 || charCode == 16 || event.shiftKey) {
            // to allow numbers  
            return false;
        } else if (charCode >= 48 && charCode <= 57) {
            // to allow numbers  
            return true;
        } else if (charCode >= 96 && charCode <= 105) {
            // to allow numpad number  
            return true;
        } else if ([8, 13, 27, 37, 38, 39, 40, 9, 46].indexOf(charCode) > -1) {
            // to allow backspace, enter, escape, arrows  
            return true;
        } else if ((charCode === 65 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+C
            (charCode === 67 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+V
            (charCode === 86 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+X
            (charCode === 88 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+Y
            (charCode === 89 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+Z
            (charCode === 90 && (event.ctrlKey || event.metaKey))) {
            return true;
        } else {
            event.preventDefault();
            // to stop others  
            return false;
        }
    }

    allowNumbersAndDecimals(event) {
        const charCode = (event.which) ? event.which : event.keyCode;
        if (charCode == 64 || charCode == 16 || event.shiftKey) {
            // to allow numbers  
            return false;
        } else if (charCode >= 48 && charCode <= 57) {
            // to allow numbers  
            return true;
        }
        else if (charCode >= 96 && charCode <= 105) {
            // to allow numpad number  
            return true;
        } else if ([8, 13, 27, 37, 38, 39, 40, 9, 46].indexOf(charCode) > -1) {
            // to allow backspace, enter, escape, arrows  
            return true;
        } else if ([110, 190, 109, 189, 173].indexOf(charCode) > -1) {
            //to allow dots, dash  
            return true;
        } else if ((charCode === 65 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+C
            (charCode === 67 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+V
            (charCode === 86 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+X
            (charCode === 88 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+Y
            (charCode === 89 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+Z
            (charCode === 90 && (event.ctrlKey || event.metaKey))) {
            return true;
        } else {
            event.preventDefault();
            // to stop others  
            return false;
        }
    }

    getTotalHolesDetails() {
        this.TotalHoles = [];
        let parameters = { searchvalue: " WHERE HD_GCB_ID='" + this.clubId + "' AND HD_GC_ID = '" + this.courseId + "' AND HD_STATUS='Y'" };
        this.spinnerService.show();
        this.api.postOH('getholes', parameters).subscribe(
            response => {
                if (response.length > 0) {
                    this.TotalHoles = response;
                } else {
                    this.TotalHoles = [];
                }
                this.spinnerService.hide();
            },
            err => {
                this.spinnerService.hide();
            }
        );
    }

    getNextHole(sequence) {
        var nextHoleIndex = "";
        if (sequence != "") {
            nextHoleIndex = this.TotalHoles.findIndex(hole => hole.sequence === sequence);
            var i = this.getIndex(nextHoleIndex, 1);
            this.holeId = this.TotalHoles[i].id;
            localStorage.setItem('holeId', this.TotalHoles[i].id);
            return this.getHoles(this.TotalHoles[i].id);
        }
    }

    getPreviousHole(sequence) {
        var previousHoleIndex = "";
        if (sequence != "") {
            previousHoleIndex = this.TotalHoles.findIndex(hole => hole.sequence === sequence);
            var j = this.getIndex(previousHoleIndex, -1);
            this.holeId = this.TotalHoles[j].id;
            localStorage.setItem('holeId', this.TotalHoles[j].id);
            return this.getHoles(this.TotalHoles[j].id);
        }
    }

    getIndex(currentIndex, shift) {
        var len = this.TotalHoles.length;
        return (((currentIndex + shift) + len) % len)
    }

    //confiramtion alert
    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    }

    confirm(): void {
        this.modalRef.hide();
        var holesmodel = {
            "action": 'D', "id": this.holeId, "golfclubid": this.clubId, "golfcourseid": this.courseId, "holename": "",
            "parval": "0", "menhandicap": "0", "womenhandicap": "0", "clatitude": "", "clongitude": "",
            "gflatitude": "", "gflongitude": "", "gmlatitude": "", "gmlongitude": "",
            "gblatitude": "", "gblongitude": "", "gzoomlevel": "0",
            "zoomlevel": "0", "rotate": "0", "sequence": "0", "paceofplay": "",
            "overlineimage": "", "overlinebinaryimage": "", "updtaedid": this.userId, "status": 'D', "contentbox": "",
            "mholeclatitude": "", "mholeclongitude": "", "mholezoomlevel": "",
            "mholesecondclatitude": "", "mholesecondclongitude": "", "mholesecondzoomlevel": "",
            "mholethirdclatitude": "", "mholethirdclongitude": "", "mholethirdzoomlevel": ""
        }
        let msg = '<span style="color: green">Hole Deleted Successfully</span>';
        this.DEapicall(holesmodel, msg);
    }

    DEapicall(holesmodel, msg) {
        this.api.postOH('saveholes', holesmodel).subscribe(
            (response) => {
                localStorage.setItem('holedeletestatus', 'HD');
                this.router.navigate(['/clubmanagement/golfcourse']);
            }, error => {
                //console.log(error);
            });
    }

    decline(): void {
        this.modalRef.hide();
    }

    geofencepaceofplay() {
        this.router.navigate(['/perimeters/geofencepaceofplay']);
    }

}
