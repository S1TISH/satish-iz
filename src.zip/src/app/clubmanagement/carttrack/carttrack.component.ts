import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { getLocaleDateFormat } from '@angular/common';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import * as moment from "moment";
import { Title } from '@angular/platform-browser';

declare const google: any;

@Component({
  selector: 'app-carttrack',
  templateUrl: './carttrack.component.html',
  styleUrls: ['./carttrack.component.css']
})
export class CarttrackComponent implements OnInit {
  map: any;
  courselat: any;
  courselong: any;
  coursezoomlevel: any;
  polylinecoordinates: any = [];
  idialtrack: any = [];
  firstround: any = [];
  secondround: any = [];
  golfclubid: any;
  cartid: any;
  cartDetails: any = []; srchError: string = '0';cartcounterror:any="";
  fromdate: any; todate: any; datearry: any; bluecircleimage: any; cartroleid: any; iconnameonmap: any;
  day: string; month: any; carttrackheader: string; CoursesInfo: any = []; polylines: any = []; circlemarkers: any = []; markers: any = [];
  image: any; HazardsInfo: any = []; tabversion: boolean = false; timeoffset: any = '';
  maxStartDate: any;cartname:any;
  constructor(private title: Title, public toastr: ToastsManager, vcr: ViewContainerRef, public api: ApiService, private router: Router, private spinnerService: Ng4LoadingSpinnerService) {
    this.toastr.setRootViewContainerRef(vcr);
    this.title.setTitle("IZON - Cart Tracking Info");
    this.carttrackheader = "Cart Tracking";
    this.golfclubid = localStorage.getItem('clubId');
    this.cartroleid = localStorage.getItem('cartroleId');
    this.bluecircleimage = 'assets/imgs/blue_circle.png';
    // this.fromdate = new Date();
    // this.todate = new Date();
  }

  ngOnInit() {
    let searchexp = ""; this.cartid = 0;
    if (localStorage.getItem('courseId') === undefined || localStorage.getItem('courseId') === '' || localStorage.getItem('courseId') === null) {
      searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' "
    }
    else {
      searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' and  GC_ID='" + localStorage.getItem('courseId') + "'"
    }
    let parameters1 = { searchvalue: searchexp };
    this.getcourses(parameters1);

    let parameters = {
      searchvalue: " WHERE CD_GCB_ID='" + this.golfclubid + "' AND CD_DEVICE_TYPE='T' AND CD_STATUS = 'Y'"
    };
    this.GetCartDetailsData(parameters);

  }

  GetCartDetailsData(parameters) {
    this.spinnerService.show();
    this.api.postOH('getcartdetails', parameters).subscribe(
      (response) => {
        this.cartDetails = [];
        if(response.length>0){
        for (let i = 0; i < response.length; i++) {
          if (response[i].deviceStatus == 'T') {
            this.cartDetails.push({
              "id": response[i].id,
              "name": response[i].name,
            });
          }
        }
      }
        else{
          this.cartcounterror="No Carts Available";
        }
        this.spinnerService.hide();
      }, error => {
        this.spinnerService.hide();
      }
    );
  }

  getcourses(parameters) {
    this.CoursesInfo = [];
    this.api.postOH('getgolfcourse', parameters).subscribe(
      response => {
        this.spinnerService.hide();
        if (response.length !== 0) {
          for (let i = 0; i < response.length; i++) {
            this.CoursesInfo.push({
              "id": response[i].id
            })
          }
          this.courselat = response[0].latitude;
          this.courselong = response[0].longitude;
          this.timeoffset = response[0].timeoffset;
          this.coursezoomlevel = (response[0].zoomlevel != '') ? response[0].zoomlevel : 0;

          //gets course currentdatetime
          let currentDate: any = '';
          let d = new Date();
          let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
          currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
          this.fromdate = currentDate;
          this.todate = currentDate;
          this.maxStartDate = this.fromdate;
          this.maploading();
        }

      })
  }

  dateformats(val) {
    this.datearry = val.split("-");
    var strdate = this.datearry[1] + "/" + this.datearry[2] + "/" + this.datearry[0];
    return strdate;
  }

  getcarttrackingdata() {
    this.setMapOnAll(null);
    if (this.markers.length > 0) {
      this.clearMarkers();
    }
    this.clearallpolylines();
    this.spinnerService.show();
    if (this.cartid == "0") {
      this.srchError = '1';
    }
  
    this.spinnerService.show();
    //var locfromdate = new Date(this.fromdate);
    var locfromdate = new Date(this.todate);
    var loctodate = new Date(this.todate);

    if (this.cartid != "0" && (this.todate != undefined && this.todate != null && this.todate != '')) {
      this.fromdate = locfromdate;
      this.todate = loctodate;
      this.getpolylinedetails();
   

    }
    this.spinnerService.hide();
  }

  maploading() {
    this.map = new google.maps.Map(document.getElementById('map'), {
      center: { lat: parseFloat(this.courselat), lng: parseFloat(this.courselong) },
      zoom: parseInt(this.coursezoomlevel),
      //disableDefaultUI: true,
      mapTypeId: 'satellite',
      tilt: 0,
      rotateControl: true
    });
    this.setoverlayimage();
    // this.getpolylinedetails();
  }

  carthazards() {
    // this.setMapOnAll(null);
    this.HazardsInfo = [];
    let fdate = moment(this.fromdate).format('MM-DD-YYYY');
    var getcarthazarddetails = {
      "clubid": this.golfclubid, "dateString": fdate, "cartid": this.cartid, "Flag": "A"
    }
    this.api.postOH('GetCartHazardAlerts', getcarthazarddetails).subscribe(
      response => {
        if (response.GetCartHazardAlertsResult.length !== 0) {
          for (let i = 0; i < response.GetCartHazardAlertsResult.length; i++) {
            let latlng2 = { lat: parseFloat(response.GetCartHazardAlertsResult[i].latitude), lng: parseFloat(response.GetCartHazardAlertsResult[i].longitude) };
            this.addMarker(latlng2, i, response.GetCartHazardAlertsResult[i].date, response.GetCartHazardAlertsResult[i].type);
          }
        }
      })
  }
  addMarker(location, i, datetime, type) {
    let me = this;
    type = type == "HZ" ? "HZ" : "OB";
    var infowindow = new google.maps.InfoWindow();
    var marker = new google.maps.Marker({
      position: location,
      label: {
        text: type,
        color: 'white'
      },
      draggable: false,
      map: this.map
    });
    this.markers.push(marker);
    google.maps.event.addListener(marker, 'mouseover', (function (marker, i) {
      return function () {
        var content = "";
        content += '<div style="color:green;font-weight:bold;padding-bottom:10px;">Cart Position At:</div>'
        content += datetime + "\n";
        infowindow.setContent(content);
        infowindow.open(me.map, marker);
      }
    })(marker, i));

    google.maps.event.addListener(marker, 'mouseout', function () {
      infowindow.close();
    });
  }

  setoverlayimage() {
    let me = this;
    for (let i = 0; i < this.CoursesInfo.length; i++) {
      var imageMapType = new google.maps.ImageMapType({
        getTileUrl: function (coord, zoom) {
          //console.log('http://iadmin.azaz.com/tiles/' + me.golfclubid+ '/' +me.CoursesInfo[i].id+ '/' + zoom + '/' + coord.x + '/' + coord.y + '.png');
          // let clbid=''; let cursid='';
          // if(me.golfclubid=='1002'){clbid='1445'}else{clbid=me.golfclubid};
          // if(me.CoursesInfo[i].id==2){cursid='539'}else if(me.CoursesInfo[i].id==3){cursid='540'}else if(me.CoursesInfo[i].id==4){cursid='541'}else{cursid=me.CoursesInfo[i].id};
          // return ['http://cp.izongolf.com/tiles/' + clbid + '/' + cursid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
          return ['http://cp.izongolf.com/tiles/' + me.golfclubid + '/' + me.CoursesInfo[i].id + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
        },
        tileSize: new google.maps.Size(256, 256)
      });
      me.map.overlayMapTypes.push(imageMapType);
    }
  }

  getpolylinedetails() {
    this.spinnerService.show();
    let fdate = moment(this.fromdate).format('MM/DD/YYYY');
    let todate = moment(this.todate).format('MM/DD/YYYY');
    var getcarttrackdetails = {
      "CartId": this.cartid, "FromDate": fdate, "Todate": todate, "Flag": 'A'
    }
    this.polylinecoordinates = [];
    this.clearallpolylines();
    this.api.postOH('GetCartTrack', getcarttrackdetails).subscribe(
      (response) => {
        if (response[0].ResponseCode == "Success") {
          if (response[0].CartTrackData.length > 0) {
            var k = 0; var currentgroupid = 0;
            for (var i = 0; i < response[0].CartTrackData.length; i++) {
              this.polylinecoordinates.push({
                lat: parseFloat(response[0].CartTrackData[i].Latitude),
                lng: parseFloat(response[0].CartTrackData[i].Langitude),
                timestamp: response[0].CartTrackData[i].Datetime,
              });
              this.polylinecoordinates = this.polylinecoordinates;
             }
            this.drawpolyline();
            this.spinnerService.hide();
          } else {
            this.spinnerService.hide();
            let msg = "<span style='color: red'>No tracking found</span>";
            this.toastMessage(msg);
          }
        } else {
          this.polylinecoordinates = this.polylinecoordinates;
          this.spinnerService.hide();
        }
        this.carthazards();
      }, error => {
        this.spinnerService.hide();
      }
    );
  }

  drawpolyline() {
    let cartPresentPosition = this.polylinecoordinates.length - 1;
    if (this.markers.length > 0) {
      this.clearMarkers();
    }
    if (this.cartroleid == '3') {
      this.bluecircleimage = 'assets/imgs/star_view.png';
      this.iconnameonmap = '';
    } else if (this.cartroleid == '4') {
      this.bluecircleimage = 'assets/imgs/beverage_view.png';
      this.iconnameonmap = '';
    } else {
      this.bluecircleimage = 'assets/imgs/blue_circle.png';
      this.iconnameonmap = {
        text: this.cartname,
        color: 'white'
      };
    }
    var marker1 = new google.maps.Marker({
      position: { lat: parseFloat(this.polylinecoordinates[cartPresentPosition].lat), lng: parseFloat(this.polylinecoordinates[cartPresentPosition].lng) },
      icon: this.bluecircleimage,
      label: this.iconnameonmap
    });
    marker1.setMap(this.map);
    this.markers.push(marker1);
    this.map.setCenter(new google.maps.LatLng(parseFloat(this.polylinecoordinates[cartPresentPosition].lat), parseFloat(this.polylinecoordinates[cartPresentPosition].lng)));
   
      var flightPaths = new google.maps.Polyline({
        path: this.polylinecoordinates,
        geodesic: true,
        strokeColor: '#FF0000',
        strokeOpacity: 1.0,
        strokeWeight: 2
      });
      this.polylines.push(flightPaths);
      flightPaths.setMap(this.map);
    let me = this;
    var infowindow = new google.maps.InfoWindow();
    var marker, i;
    for (i = 0; i < me.polylinecoordinates.length; i++) {
      marker = new google.maps.Marker({
        position: new google.maps.LatLng(me.polylinecoordinates[i].lat, me.polylinecoordinates[i].lng),
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 4.5,
          fillColor: "#F00",
          fillOpacity: 0.4,
          strokeWeight: 0.4
        },
        map: me.map
      });
      this.circlemarkers.push(marker);

      google.maps.event.addListener(marker, 'mouseover', (function (marker, i) {
        return function () {
          var content = "";
          content += '<div style="color:green;font-weight:bold;padding-bottom:10px;">Cart Position At:</div>'
          content += me.polylinecoordinates[i].timestamp + "\n";
          infowindow.setContent(content);
          infowindow.open(me.map, marker);
        }
      })(marker, i));

      google.maps.event.addListener(marker, 'mouseout', function () {
        infowindow.close();
      });
    }

  }
  // Removes the markers from the map, but keeps them in the array.
  clearMarkers() {
    this.setMapOnAll(null);
    this.markers = [];
  }
  // Sets the map on all markers in the array.
  setMapOnAll(map) {
    for (var i = 0; i < this.markers.length; i++) {
      this.markers[i].setMap(map);
    }
  }

  clearallpolylines() {
    for (var i = 0; i < this.polylines.length; i++) {
      this.polylines[i].setMap(null);
    }
    for (var i = 0; i < this.circlemarkers.length; i++) {
      this.circlemarkers[i].setMap(null);
    }
    this.polylinecoordinates = [];
    this.circlemarkers = [];
  }

  goBack() {
    this.router.navigate(['/cartmanagement/cartdetails']);
  }
  ddlcartchange(val) {
    if (this.cartid != "0"){
      this.srchError = "0";
    }
    this.cartname=val.target.options[val.target.selectedIndex].text;
  }
  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',
    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 3000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }
}

