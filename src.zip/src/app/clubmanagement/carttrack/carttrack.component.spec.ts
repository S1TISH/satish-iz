import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CarttrackComponent } from './carttrack.component';

describe('CarttrackComponent', () => {
  let component: CarttrackComponent;
  let fixture: ComponentFixture<CarttrackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarttrackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CarttrackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
