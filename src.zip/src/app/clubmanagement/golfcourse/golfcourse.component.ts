import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
//import { AsyncLocalStorage } from 'angular-async-local-storage';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { AuthService } from '../../services/auth.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Title } from '@angular/platform-browser';

declare const google: any;

@Component({
    selector: 'app-golfcourse',
    templateUrl: './golfcourse.component.html',
    styleUrls: ['./golfcourse.component.css']
})
export class GolfcourseComponent implements OnInit {
    modalRef: BsModalRef;
    public coursesForm: FormGroup; submitAttempt: boolean = false;
    divheader: string = "Add Golf Course";
    addShow: string; gridShow: string; infoShow: string; courseTable: any; searchShow: any; buttonShow: string = "none";
    CoursesInfo: any = []; HolesInfo: any = []; clubId: any; courseId: any; userId: any; path = ''; overlineimagename: string = '';
    public file_srcs: string[] = []; showStatus: string; alertMessage: string;
    public debug_size_before: string[] = [];
    public debug_size_after: string[] = [];
    searchvalues: any = []; searchstatus: any = [];
    headername: string; viewheaderlabelname: string;
    //model values
    action: string; id: number; golfclubid: any; labelname: any; rotate: any; latitude: any; longitude: any;
    zoomlevel: any; measurement: any; overlineimage: any = ''; overlineimagepath: any = ''; overlinebinaryimage: any = '';
    updtaedid: any; status: any; createdby: any; createddate: any; updateddate: any; statusclass: any; search: any = ''; adskey: any = '';
    srchError: string = '0'; checkStatus: any;
    GridMessage: string = 'Loading... !';
    imagecropped: string = ''; ddlflag: any; mapcallingval: any = false;
    key: string = 'name';
    reverse: boolean = false;
    nameasc: any = "sortgreen"; namedesc: any = "sortwhite";
    selectedoption: any = "Active"; randomcolor: any = "#5cb85c";
    oddcourse: any; mc: any; timeoffset: any;

    constructor(private title: Title, public toastr: ToastsManager, vcr: ViewContainerRef,
        private router: Router, public formBuilder: FormBuilder,
        private spinnerService: Ng4LoadingSpinnerService,
        private api: ApiService, private authService: AuthService,
        private modalService: BsModalService) {

        this.title.setTitle("IZON - Golf Courses");
        window.scrollTo(0, 0);
        this.headername = localStorage.getItem('clubname') + " >> Courses";
        this.toastr.setRootViewContainerRef(vcr);
        this.addShow = "none"; this.gridShow = "none"; this.infoShow = "none"; this.courseTable = "none"; this.searchShow = "none";

        var clubId = JSON.parse(localStorage.getItem('clubId'));
        this.clubId = clubId;
        var courseId = JSON.parse(localStorage.getItem('courseId'));
        this.courseId = courseId;
        var userId = JSON.parse(localStorage.getItem('userId'));
        this.userId = userId;

        this.ddlflag = "0";
    }

    ngOnInit() {
        this.coursesForm = this.formBuilder.group({
            fclabel: ['', Validators.compose([Validators.required, Validators.maxLength(150)])],
            fcrotate: ['', Validators.compose([Validators.required, Validators.maxLength(3)])],
            fczoomlevel: ['', Validators.compose([Validators.required, Validators.maxLength(2)])],
            fclatitude: ['', Validators.compose([Validators.required, Validators.maxLength(50)])],
            fclongitude: ['', Validators.compose([Validators.required, Validators.maxLength(50)])],
            fcmeasurement: [''],
            fcstatus: [''],
            fcmc: [''],
            fcoddcourse: [''],
            adskey: ['']
        });

        if (this.clubId != 0 && this.courseId != 0 && (this.courseId != null || this.courseId != undefined)) {
            this.viewCourse(this.courseId);
        }
        else if (this.clubId != 0 && this.courseId == "0" && (this.courseId != null || this.courseId != undefined)) {
            this.addCourse();
        }
        else if (this.clubId != 0) {
            this.courseTable = "block"; this.addShow = "none"; this.gridShow = "none"; this.infoShow = "none"; this.searchShow = "block";
            this.getCourse();
        }
        this.rotate = 0;
        this.initialize(37.2582812, -104.6538703, 10);

        if (localStorage.getItem('holedeletestatus') == "HD") {
            let msg = '<span style="color: green">Hole Deleted Successfully</span>';
            this.toastMessage(msg);
            localStorage.removeItem('holedeletestatus');
        }
    }

    sort(value: string) {
        this.key = value;
        this.nameasc = "sortwhite"; this.namedesc = "sortwhite";
        if (this.key == value) {
            this.reverse = !this.reverse;
            if (this.key == "labelname" && this.reverse) {
                this.namedesc = "sortgreen";
            }
            else if (this.key == "labelname" && (!this.reverse)) {
                this.nameasc = "sortgreen";
            }
        }

    }


    //search functionality
    searchCourse() {
        if (this.search == '') {
            this.srchError = '1';
        }
        else if (this.search != '') {
            this.srchError = '0';
            let parameters = {
                searchvalue: " WHERE GC_GCB_ID='" + this.clubId + "' AND GC_LABEL LIKE '%" + this.search + "%' AND GC_STATUS<>'D' "
            };
            this.searchGrid(parameters);
            this.search = "";
        }
    }

    bindselectedoption(selectedoption) {
        this.srchError = '0';
        if (this.selectedoption == 'Active') {
            this.randomcolor = "#5cb85c";
            this.searchStatus('Y');
        }
        else if (this.selectedoption == 'In-Active') {
            this.randomcolor = "#337ab7";
            this.searchStatus('N');
        }
        else if (this.selectedoption == 'Deleted') {
            this.randomcolor = "#d9534f";
            this.searchStatus('D');
        }
    }

    searchStatus(type) {
        let parameters = {
            searchvalue: " WHERE GC_GCB_ID='" + this.clubId + "' AND GC_STATUS= '" + type + "' "
        };
        this.searchGrid(parameters);
    }

    srchKeyUp(event: any) {
        if (this.search != '') {
            this.srchError = '0';
        }
    }

    searchGrid(parameters) {
        this.CoursesInfo = [];
        this.spinnerService.show();
        this.api.postOH('getgolfcourse', parameters).subscribe(
            response => {
                if (response.length > 0) {
                    for (let i = 0; i < response.length; i++) {
                        var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                        var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                        this.CoursesInfo.push({
                            "id": response[i].id,
                            "golfclubid": response[i].golfclubid,
                            "golfclubname": response[i].golfclubname,
                            "labelname": response[i].labelname,
                            "createdby": response[i].updatedby,
                            "createddate": response[i].createddate,
                            "updateddate": response[i].updateddate,
                            "rotate": response[i].rotate,
                            "zoomlevel": response[i].zoomlevel,
                            "latitude": response[i].latitude,
                            "longitude": response[i].longitude,
                            "measurement": response[i].measurement,
                            "timeoffset": response[i].timeoffset,
                            "adskey": response[i].adsid,
                            "overlineimage": response[i].overlineimage,
                            "overlineimagepath": response[i].overlineimagepath,
                            "overlinebinaryimage": response[i].overlinebinaryimage,
                            "status": status,
                            "statusclass": statusclass,
                        });
                    }
                } else {
                    this.CoursesInfo = [];
                    this.GridMessage = "No Records Found";
                }
                this.spinnerService.hide();
            },
            err => {
                this.spinnerService.hide();
            }
        );
    }

    refreshpage() {
        this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
        this.search = ''; this.srchError = '0';
        this.getCourse();
    }

    getCourse() {
        this.CoursesInfo = [];
        let parameters = { searchvalue: " WHERE GC_GCB_ID='" + this.clubId + "'" };
        this.spinnerService.show();
        this.api.postOH('getgolfcourse', parameters).subscribe(
            response => {
                if (response.length > 0) {
                    for (let i = 0; i < response.length; i++) {
                        var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                        var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                        this.CoursesInfo.push({
                            "id": response[i].id,
                            "golfclubid": response[i].golfclubid,
                            "golfclubname": response[i].golfclubname,
                            "labelname": response[i].labelname,
                            "createdby": response[i].updatedby,
                            "createddate": response[i].createddate,
                            "updateddate": response[i].updateddate,
                            "rotate": response[i].rotate,
                            "zoomlevel": response[i].zoomlevel,
                            "latitude": response[i].latitude,
                            "longitude": response[i].longitude,
                            "measurement": response[i].measurement,
                            "timeoffset": response[i].timeoffset,
                            "adskey": response[i].adsid,
                            "overlineimage": response[i].overlineimage,
                            "overlineimagepath": response[i].overlineimagepath,
                            "overlinebinaryimage": response[i].overlinebinaryimage,
                            "status": status,
                            "statusclass": statusclass,
                        });
                    }
                } else {
                    this.CoursesInfo = [];
                    this.GridMessage = "No Records Found";
                }
                this.spinnerService.hide();
            },
            err => {
                this.spinnerService.hide();
            }
        );
    }

    viewCourse(id: any) {
        window.scrollTo(0, 0);
        this.addShow = "none"; this.gridShow = "block"; this.infoShow = "block"; this.courseTable = "none"; this.searchShow = "none";
        localStorage.setItem('courseId', id);
        this.authService.getCourseIdforheader();
        let parameters = { searchvalue: ' WHERE GC_GCB_ID=' + this.clubId + ' AND GC_ID=' + id + '' };
        this.spinnerService.show();
        this.api.postOH('getgolfcourse', parameters).subscribe(
            response => {
                if (response.length > 0) {
                    this.action = 'U';
                    this.id = response[0].id;
                    this.golfclubid = response[0].golfclubid;
                    this.labelname = response[0].labelname;
                    this.viewheaderlabelname = "Course & Holes Information";
                    localStorage.setItem('coursename', response[0].labelname);
                    this.rotate = response[0].rotate;
                    this.latitude = response[0].latitude;
                    this.longitude = response[0].longitude;
                    this.zoomlevel = response[0].zoomlevel;
                    this.measurement = response[0].measurement;
                    this.timeoffset = response[0].timeoffset;
                    this.adskey = response[0].adsid;
                    this.overlineimage = response[0].overlineimage;
                    this.overlineimagepath = response[0].overlineimagepath;
                    this.overlinebinaryimage = response[0].overlinebinaryimage;
                    this.updtaedid = response[0].updatedid;
                    this.status = (response[0].status == 'Y') ? true : false;
                    this.mc = (response[0].mc == 'Y') ? true : false;
                    this.oddcourse = (response[0].oddcourse == 'Y') ? true : false;
                    this.checkStatus = (response[0].status == 'Y') ? 'Active' : (response[0].status == 'N') ? 'In-Active' : 'Deleted';
                    this.getHoles(id);

                    this.mapcallingval = true;
                    let loclat = (response[0].latitude != '') ? response[0].latitude : 37.2582812;
                    let loclng = (response[0].longitude != '') ? response[0].longitude : -104.6538703;
                    let loczm = (response[0].zoomlevel != '') ? response[0].zoomlevel : 10;
                    this.initialize(parseFloat(loclat), parseFloat(loclng), parseInt(loczm));
                } else {
                    this.GridMessage = "No Records Found";
                }
                this.spinnerService.hide();
            },
            err => {
                this.spinnerService.hide();
            }
        );
    }

    getHoles(id: any) {
        let parameters = { searchvalue: " WHERE HD_GCB_ID=" + this.clubId + " AND HD_GC_ID = " + id + " AND HD_STATUS='Y' " };
        this.spinnerService.show();
        this.HolesInfo = [];
        this.api.postOH('getholes', parameters).subscribe(
            response => {
                if (response.length > 0) {
                    for (let i = 0; i < response.length; i++) {
                        this.HolesInfo.push({
                            "id": response[i].id,
                            "holename": response[i].holename,
                            "flagpostion": response[i].flagpostion
                        });
                    }
                } else {
                    this.GridMessage = "No Records Found";
                }
                this.spinnerService.hide();
            },
            err => {
                this.spinnerService.hide();
            }
        );
    }

    getTimeOffset(lat, lng) {
        var currentDate = new Date()
        var timestamp = currentDate.getTime() / 1000 + currentDate.getTimezoneOffset() * 60
        this.api.getDateTime(lat, lng, timestamp).subscribe(
            (response) => {
                if (response.timeZoneId != null) {
                    var offsets = response.dstOffset * 1000 + response.rawOffset * 1000
                    this.timeoffset = offsets / 3600000;
                    if (this.action == 'A') {
                        var golfcoursedetailsmodel = {
                            "action": 'A', "id": 0, "golfclubid": this.clubId, "labelname": this.labelname, "updtaedid": this.userId,
                            "rotate": this.rotate, "zoomlevel": this.zoomlevel, "latitude": this.latitude, "longitude": this.longitude, "measurement": this.measurement,
                            "timeoffset": this.timeoffset,
                            "adsid": this.adskey, "overlinebinaryimage": this.imagecropped, "overlineimage": this.overlineimagename, "status": 'Y', "oddcourse": this.oddcourse == true ? 'Y' : 'N', "mc": this.mc == true ? 'Y' : 'N'
                        }
                    }
                    else if (this.action == 'U') {
                        golfcoursedetailsmodel = {
                            "action": 'U', "id": this.id, "golfclubid": this.golfclubid, "labelname": this.labelname, "updtaedid": this.userId,
                            "rotate": this.rotate, "zoomlevel": this.zoomlevel, "latitude": this.latitude, "longitude": this.longitude,
                            "measurement": this.measurement, "timeoffset": this.timeoffset, "adsid": this.adskey, "overlinebinaryimage": this.imagecropped,
                            "overlineimage": (this.overlineimage != "") ? this.overlineimage : this.overlineimagename,
                            "status": this.status == true ? 'Y' : 'N', "oddcourse": this.oddcourse == true ? 'Y' : 'N', "mc": this.mc == true ? 'Y' : 'N'
                        }
                    }
                    this.spinnerService.show();
                    this.api.postOH('savegolfcourse', golfcoursedetailsmodel).subscribe(
                        response => {
                            if (response.length > 0) {
                                if (response[0] > 0 && this.action == 'A') {
                                    this.getCourse();
                                    this.gridShow = "none";
                                    this.addShow = "none";
                                    this.infoShow = "none";
                                    this.courseTable = "block";
                                    this.searchShow = "block";
                                    this.showStatus = "none";
                                    let msg = '<span style="color: green">Golf Course Added Successfully</span>';
                                    this.toastMessage(msg);
                                }
                                else if (response[0] > 0 && this.action == 'U') {
                                    this.action = 'A';
                                    this.viewCourse(golfcoursedetailsmodel.id);
                                    this.gridShow = "block";
                                    this.addShow = "none";
                                    this.infoShow = "block";
                                    this.showStatus = "none";
                                    let msg = '<span style="color: green">Golf Course Updated Successfully</span>';
                                    this.toastMessage(msg);
                                }
                                this.spinnerService.hide();
                            } else {
                                let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                                this.toastMessage(msg);
                                this.spinnerService.hide();
                            }
                            window.scrollTo(0, 0);
                        },
                        err => {
                            this.spinnerService.hide();
                            // console.log(err);
                        }
                    );
                }
            },
            (error) => {

            });
    }

    saveCourses() {
        if (!this.coursesForm.valid) {

        }
        this.submitAttempt = true;
        if (this.coursesForm.valid) {
            this.getTimeOffset(this.latitude, this.longitude);
        }
    }

    addCourse() {
        this.coursesForm.reset();
        this.divheader = "Add Golf Course"
        this.action = 'A';
        this.id = 0;
        this.golfclubid = this.clubId;
        this.labelname = '';
        this.rotate = 0;
        this.latitude = '';
        this.longitude = '';
        this.zoomlevel = '';
        this.measurement = 'Y';
        this.timeoffset = "";
        this.overlineimage = '';
        this.overlineimagepath = '';
        this.overlinebinaryimage = '';
        this.adskey = '';
        this.updtaedid = this.userId;
        this.status = 'Y';
        this.oddcourse = false;
        this.mc = false;
        this.submitAttempt = false;
        this.addShow = "block";
        this.gridShow = "none";
        this.infoShow = "none";
        this.courseTable = "none";
        this.searchShow = "none";
        this.showStatus = "none";
        if (this.mapcallingval == true) {
            this.initialize(37.2582812, -104.6538703, 10);
        }
    }

    editCourse(id) {
        this.divheader = "Edit Golf Course";
        this.action = 'U';
        this.viewCourse(id);
        this.gridShow = "none";
        this.addShow = "block";
        this.infoShow = "none";
        this.courseTable = "none";
        this.searchShow = "none";
        this.showStatus = "block";
        this.imagecropped = "";
        this.mapcallingval = true;
    }

    cancelCourse() {
        if (this.action == 'A') {
            this.coursesForm.reset();
            this.action = 'A';
            this.getCourse();
            this.gridShow = "none";
            this.addShow = "none";
            this.infoShow = "none";
            this.showStatus = "none";
            this.courseTable = "block";
            this.searchShow = "block";
        }
        else if (this.action == 'U') {
            this.coursesForm.reset();
            this.action = 'A';
            this.viewCourse(this.id);
            this.gridShow = "block";
            this.addShow = "none";
            this.infoShow = "block";
            this.showStatus = "none";
        }
    }

    backToCourse() {
        //localStorage.removeItem('courseId');
        //localStorage.removeItem('coursename');
        this.coursesForm.reset();
        this.getCourse();
        this.addShow = "none";
        this.gridShow = "none";
        this.infoShow = "none";
        this.searchShow = "block";
        this.courseTable = "block";
    }

    backToClub() {
        // localStorage.removeItem('clubId');
        // localStorage.removeItem('clubname');
        // this.authService.getCall();
        this.router.navigate(['/clubmanagement/golfclub']);
    }

    deleteCourse() {

    }

    addHoles() {
        if (this.latitude != '' && this.longitude != '') {
            localStorage.setItem('holeId', '0');
            this.router.navigate(['/clubmanagement/holedetails']);
        } else {
            let msg = '<span style="color: red">Please Update Course Latitude & Longitude</span>';
            this.toastMessage(msg);
        }
    }

    viewHoles(hole) {
        localStorage.setItem('holeId', hole.id);
        this.router.navigate(['/clubmanagement/holedetails']);
    }


    //file upload function
    fileChange(input, fimg) {
        this.overlineimage = '';
        this.readFiles(input.files, fimg);
    }

    readFile(file, fimg, reader, callback) {
        reader.onload = () => {
            callback(reader.result);
            if (fimg == 'overline') {
                this.overlineimagepath = reader.result;
                this.overlineimagename = file.name;
                this.imagecropped = (this.overlineimagepath != "") ? this.overlineimagepath.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
            }
        }
        reader.readAsDataURL(file);
    }

    readFiles(files, fimg, index = 0) {
        let reader = new FileReader();
        if (index in files) {
            this.readFile(files[index], fimg, reader, (result) => {
                var img = document.createElement("img");
                img.src = result;
            });
        } else {

        }
    }

    resize(img, MAX_WIDTH: number, MAX_HEIGHT: number, callback) {
        return img.onload = () => {
            var width = img.width;
            var height = img.height;
            if (width > height) {
                if (width > MAX_WIDTH) {
                    height *= MAX_WIDTH / width;
                    width = MAX_WIDTH;
                }
            } else {
                if (height > MAX_HEIGHT) {
                    width *= MAX_HEIGHT / height;
                    height = MAX_HEIGHT;
                }
            }
            var canvas = document.createElement("canvas");
            canvas.width = width;
            canvas.height = height;
            var ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0, width, height);
            var dataUrl = canvas.toDataURL('image/jpeg');
            callback(dataUrl, img.src.length, dataUrl.length);
        };
    }

    //alert message
    toastMessage(msg) {
        let options = {
            positionClass: 'toast-top-center',
        };

        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 3000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }

    //confiramtion alert
    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    }

    confirm(): void {
        this.modalRef.hide();
        var golfcoursedetailsmodel = {
            "action": "D", "id": this.id, "golfclubid": this.clubId, "labelname": "", "updtaedid": this.userId,
            "rotate": "", "zoomlevel": "", "latitude": "", "longitude": "",
            "measurement": "Y", "timeoffset": this.timeoffset, "adsid": "", "overlinebinaryimage": "", "overlineimage": "", "status": "D"
        }
        let msg = '<span style="color: green">Golf Course deleted Successfully</span>';
        this.DEapicall(golfcoursedetailsmodel, msg);
    }

    enableCourse(id: any, measurement: any): void {
        var golfcoursedetailsmodel = {
            "action": "E", "id": id, "golfclubid": this.clubId, "labelname": "", "updtaedid": this.userId,
            "rotate": "", "zoomlevel": "", "latitude": "", "longitude": "",
            "measurement": measurement, "timeoffset": this.timeoffset, "adsid": "", "overlinebinaryimage": "", "overlineimage": "", "status": "Y"
        }
        let msg = '<span style="color: green">Golf Club Enabled Successfully</span>';
        this.DEapicall(golfcoursedetailsmodel, msg);
    }

    DEapicall(golfcoursedetailsmodel, msg) {
        this.api.postOH('savegolfcourse', golfcoursedetailsmodel).subscribe(
            (response) => {
                this.getCourse();
                this.action = 'A';
                this.gridShow = "none";
                this.addShow = "none";
                this.infoShow = "none";
                this.showStatus = "none";
                this.courseTable = "block";
                this.searchShow = "block";
                this.toastMessage(msg);
            }, error => {
                console.log(error);
            });
    }

    decline(): void {
        this.modalRef.hide();
    }

    addcourseperimeters() {
        this.router.navigate(['/perimeters/courseperimeters']);
    }

    // allowNumbers(event) {
    //     if (event.keyCode < 48 || event.keyCode > 57) {
    //         event.preventDefault();
    //     }
    // }

    // allowNumbersAndDecimals(e) {
    //     if (e.which != 46 && e.which != 45 && e.which != 46 &&
    //         !(e.which >= 48 && e.which <= 57)) {
    //         return false;
    //     }
    // }

    allowNumbers(event) {
        const charCode = (event.which) ? event.which : event.keyCode;
        if (charCode == 64 || charCode == 16 || event.shiftKey) {
            // to allow numbers  
            return false;
        } else if (charCode >= 48 && charCode <= 57) {
            // to allow numbers  
            return true;
        } else if (charCode >= 96 && charCode <= 105) {
            // to allow numpad number  
            return true;
        } else if ([8, 13, 27, 37, 38, 39, 40, 9, 46].indexOf(charCode) > -1) {
            // to allow backspace, enter, escape, arrows  
            return true;
        } else if ((charCode === 65 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+C
            (charCode === 67 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+V
            (charCode === 86 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+X
            (charCode === 88 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+Y
            (charCode === 89 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+Z
            (charCode === 90 && (event.ctrlKey || event.metaKey))) {
            return true;
        } else {
            event.preventDefault();
            // to stop others  
            return false;
        }
    }

    allowNumbersAndDecimals(event) {
        const charCode = (event.which) ? event.which : event.keyCode;
        if (charCode == 64 || charCode == 16 || event.shiftKey) {
            // to allow numbers  
            return false;
        } else if (charCode >= 48 && charCode <= 57) {
            // to allow numbers  
            return true;
        }
        else if (charCode >= 96 && charCode <= 105) {
            // to allow numpad number  
            return true;
        } else if ([8, 13, 27, 37, 38, 39, 40, 9, 46].indexOf(charCode) > -1) {
            // to allow backspace, enter, escape, arrows  
            return true;
        } else if ([110, 190, 109, 189, 173].indexOf(charCode) > -1) {
            //to allow dots, dash  
            return true;
        } else if ((charCode === 65 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+C
            (charCode === 67 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+V
            (charCode === 86 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+X
            (charCode === 88 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+Y
            (charCode === 89 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+Z
            (charCode === 90 && (event.ctrlKey || event.metaKey))) {
            return true;
        } else {
            event.preventDefault();
            // to stop others  
            return false;
        }
    }

    addholeperimeters(hole) {
        localStorage.setItem('holeId', hole.id);
        localStorage.setItem('holename', hole.holename);
        this.router.navigate(['/perimeters/holeperimeters']);
    }
    addflagpositions(hole) {
        localStorage.setItem('holeId', hole.id);
        localStorage.setItem('holename', hole.holename);
        this.router.navigate(['/clubmanagement/holeflagposition']);
    }
    teeboxassignment(hole) {
        localStorage.setItem('holeId', hole.id);
        localStorage.setItem('holename', hole.holename);
        this.router.navigate(['/placements/teeboxholedetails']);
    }
    addhazardperimeters(hole) {
        localStorage.setItem('holeId', hole.id);
        localStorage.setItem('holename', hole.holename);
        this.router.navigate(['/perimeters/hazardperimeters']);
    }

    updateholeflagpositions() {
        if (this.ddlflag > 0) {
            let updateddata = '';
            let unupdateddata = '';
            let msg = '';
            let flagpositionmodel = {
                "golfclubid": parseInt(this.clubId), "golfcourseid": parseInt(localStorage.getItem('courseId')), "sequence": parseInt(this.ddlflag)
            }
            this.api.postOH('updatecourseflagposition', flagpositionmodel).subscribe(
                (response) => {
                    if (response[0].unupdatedHoles.length > 0) {
                        for (let i = 0; i < response[0].unupdatedHoles.length; i++) {
                            unupdateddata = unupdateddata + response[0].unupdatedHoles[i].holename;
                            if (i != response[0].unupdatedHoles.length - 1) {
                                unupdateddata = unupdateddata + ", ";
                            }
                        }
                    }
                    if (response[0].updatedHoles.length > 0) {
                        for (let j = 0; j < response[0].updatedHoles.length; j++) {
                            updateddata = updateddata + response[0].updatedHoles[j].holename;
                            if (j != response[0].updatedHoles.length - 1) {
                                updateddata = updateddata + ", ";
                            }
                        }
                    }
                    if (updateddata != '') {
                        msg = '<span style="color: green">Updated for these holes: ' + updateddata + '</span></br></br>';
                    }
                    if (unupdateddata != '') {
                        msg = msg + '<span style="color: red">Not updated for these holes: ' + unupdateddata + '</span>';
                    }
                    this.toastMessagewithouttime(msg);
                    this.getHoles(localStorage.getItem('courseId'));
                }, error => {
                    console.log(error);
                }
            );
        } else {
            let msg = '<span style="color: red">Please Select Flag</span>';
            this.toastMessage(msg);
        }
    }

    //alert message with out time
    toastMessagewithouttime(msg) {
        let options = {
            positionClass: 'toast-top-center',
        };

        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 300000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }

    initialize(lat, long, zoom) {  //Get Google Map
        var rotateval = '';
        if (this.rotate != '') {
            rotateval = this.rotate;
        } else {
            rotateval = '0';
        }
        var geocoder = new google.maps.Geocoder();
        var lat = lat;
        var lng = long;
        var latlng = new google.maps.LatLng(lat, lng);
        var myOptions = {
            zoom: zoom,
            center: latlng,
            // disableDefaultUI: true,
            mapTypeId: 'satellite',
            //tilt: 0,
            rotateControl: true,
            heading: parseInt(rotateval),
        }
        var map = new google.maps.Map(document.getElementById('map'), myOptions),
            marker = new google.maps.Marker({
                draggable: true,
                position: latlng,
                map: map,
            });
        let cthis = this;

        //to get latlong on map click
        google.maps.event.addListener(map, 'click', function (event) {
            cthis.latitude = event.latLng.lat();
            cthis.longitude = event.latLng.lng()
            if (marker) {
                marker.setPosition(event.latLng);
            } else {
                marker = new google.maps.Marker({
                    position: event.latLng,
                    map: map
                });
            }
        }),
            //to get latlong on marker drag
            google.maps.event.addListener(marker, 'dragend', function (event) {
                cthis.latitude = event.latLng.lat();
                cthis.longitude = event.latLng.lng()
            });

        //to get zoomlevel
        google.maps.event.addListener(map, 'zoom_changed', function () {
            cthis.zoomlevel = map.getZoom();
        });

        google.maps.event.addListener(map, 'rotate_changed', function () {
            cthis.rotate = map.getHeading();
        });

        // to get places
        var input = document.getElementById('pac-input');
        var searchBox = new google.maps.places.SearchBox(input);
        var autocomplete = new google.maps.places.Autocomplete(input);

        autocomplete.addListener('place_changed', function () {
            // infowindow.close();
            marker.setVisible(false);
            var place = autocomplete.getPlace();
            if (!place.geometry) {
                // User entered the name of a Place that was not suggested and
                // pressed the Enter key, or the Place Details request failed.
                //window.alert("No details available for : '" + place.name + "'");
                return;
            }

            // If the place has a geometry, then present it on a map.
            if (place.geometry.viewport) {
                map.fitBounds(place.geometry.viewport);
            } else {
                map.setCenter(place.geometry.location);
                map.setZoom(17);  // Why 17? Because it looks good.
            }
            marker.setPosition(place.geometry.location);
            marker.setVisible(true);
            cthis.latitude = place.geometry.location.lat();
            cthis.longitude = place.geometry.location.lng()
            cthis.zoomlevel = '17';
        });
    }
}
