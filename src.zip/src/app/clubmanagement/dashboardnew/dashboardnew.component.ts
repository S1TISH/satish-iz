import { Component, OnInit, ViewChild, TemplateRef, ViewContainerRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { Observable } from 'rxjs/Rx';
import { CalendarComponent } from 'ng-fullcalendar';
import { Options } from 'fullcalendar';
import { CalendarService } from '../../services/calendar.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { JwtService } from '../../services/jwt.service';
import { Title } from '@angular/platform-browser';
import * as moment from "moment";
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { error } from 'util';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';


declare const google: any;
declare var require: any;
var currentZoom; var minZoom; var maxZoom;

const RapidAPI = require('rapidapi-connect');
const rapid = new RapidAPI('default-application_5afbd63be4b0215c45324b01', 'f38a902a-95c2-4dc1-b38b-d4c4cf342348');

//var wunderground = require('node-wunderground')('my-api-key');

var SunCalc = require('suncalc');
var m_names = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

var daystarttime; var dayendtime; var daytemp; var daytempin;
var nightstarttime; var nightendtime; var nighttemp; var nighttempin;
var starttime; var endtime; var currtemp; var tempunit; var shortForecast; var isDayTime; var hightemp; var iconurl; var lowtemp;


@Component({
  selector: 'app-dashboardnew',
  templateUrl: './dashboardnew.component.html',
  styleUrls: ['./dashboardnew.component.css']
})
export class DashboardnewComponent implements OnInit {
  courselat: any;
  courselong: any;
  coursezoomlevel: any;
  courserotate: any = 0;
  cartsarry: any = [];
  ddlcourse: any;
  ddlcarts: string; cartsviewheadername: string;
  golfclubid: any; soursename: any = false; map: any; golfcourseid: any; golfclubname: any; userId: any;
  sub: any;
  courseddl: boolean = false; coursecount: any;
  headername: any; pagename: any; lastOpenedInfoWindow: any = ""; inplayDetails: any = []; startinghole: any; starttime: any;
  //calendar
  calendarOptions: Options; bluecircleimage: any; iconnameonmap: any;
  displayEvent: any; CoursesInfo: any = []; Coursesddl: any = [];
  activecartscount: any; availablecartscount: any; rangerscount: any; totalrounds: any; markers: any = []
  lastupdateddate: any; day: string; month: any; hh: any; mm: any; ss: any;
  todaydate: any; todaytime: any; daylightremaining: any;

  ranbavname: any; cartlabelname: any; ranbavId: any; fleetRoleId: any; paceofplayavg: any;

  //weather report
  weathertype: any; weatherTemp: any; description: any; icon: any; weathercurrentday: any;
  minTemp: any; maxTemp: any; weatherDistanceunit: any; humidity: any; visibility: any; windspeed: any; winddirection: any;
  weatherPressure: any; WeatherSpeed: any; weatherPressureunit: any; WeatherSpeedunit: any;
  showforecastDiv: boolean = false; weatherdiv: boolean = false; endtime: any;
  weekforecastTemp: Array<{ day: any, day_temp: any, night_temp: any, Icon: any, desc: any, pop: any; wind: any; snow: any; humidity: any }>;
  next6hrforecast: Array<{ time: any, temp: any, icon: any, description: any, nexthour: any }>;
  weekDays: Array<{ dayName: any, dateString: any }>;
  errorforecast: any; errorforecasthourly: any; errorcurrentWeather: any; errorWeather: any;

  forecastWeatherHourlyData: any; eachhourforecast: any;
  forecastlist: Array<{ ICON: any, CURRENTHOUR: any, TEMPERATURE: any, DESCRIPTION: any, NEXTHOURSTARTTIME: any }>;


  currentdayDate: any; sunrise: any; sunset: any; pop: any; wind: any;
  currentDaySunrise: any; currentDaySunset: any;

  //weatherCalendardiv --> to show and hide weather and calendar divs. in order to expand the map width
  showWCdiv: boolean = true;

  //cart message 
  messagepopup: boolean = false; public messageForm: FormGroup; submitAttempt: boolean = false;
  messageBtn: any; cartId: any; cartMessage: any;
  @ViewChild('messagetemplate') msgtemplate: TemplateRef<any>;


  @ViewChild(CalendarComponent) ucCalendar: CalendarComponent;


  modalRef: BsModalRef;

  constructor(private title: Title, private router: Router, private authService: AuthService, public api: ApiService, protected calendarService: CalendarService,
      private spinnerService: Ng4LoadingSpinnerService, public modalService: BsModalService,
      private jwt: JwtService, public toastr: ToastsManager, vcr: ViewContainerRef, public formBuilder: FormBuilder) {
      this.spinnerService.hide();
      this.title.setTitle("IZON - Dashboard");
      window.scrollTo(0, 0);
      this.ddlcourse = 0;

      this.toastr.setRootViewContainerRef(vcr);

      this.golfclubid = localStorage.getItem('clubId'); this.golfclubname = localStorage.getItem('clubname');
      this.golfcourseid = localStorage.getItem('courseId');
      this.coursecount = localStorage.getItem('coursecount');
      this.headername = localStorage.getItem('clubname');
      this.userId = JSON.parse(localStorage.getItem('userId'));
      this.pagename = "Dashboard";

      if (this.coursecount > "1") {
          this.courseddl = true;
      }
      else { this.courseddl = false; }

      this.weekforecastTemp = [];
      this.next6hrforecast = [];
      this.forecastWeatherHourlyData = [];
      this.eachhourforecast = [];
      this.forecastlist = [];
  }

  ngOnInit() {
      //message sending
      this.messageForm = this.formBuilder.group({
          fmessage: ['', Validators.compose([Validators.required])],
      });
      //calendar
      this.calendarService.getEvents().subscribe(data => {
          this.calendarOptions = {
              editable: false,
              eventLimit: false,
              header: {
                  //left: 'prev,next today',
                  left: 'prev, title ,next',
                  center: '',
                  right: 'month,agendaDay,listMonth'
                  //right: 'month,agendaDay,listMonth'
              },
              events: data
          };
      });

      let searchexp = "";
      if (localStorage.getItem('courseId') === undefined || localStorage.getItem('courseId') === '' || localStorage.getItem('courseId') === null) {
          searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' "
      }
      else {
          this.golfcourseid = localStorage.getItem('courseId');
          searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' and  GC_ID='" + localStorage.getItem('courseId') + "'"
      }
      let parameters1 = { searchvalue: searchexp };

      this.spinnerService.show();
      this.getcourses(parameters1);
      this.todaydateandtime();
      this.getlastupdateddatetime();
      this.getcartscount();
      this.getWeather();
      this.getWeatherHourlyForecast();

      this.sub = Observable.interval(1000 * 60).subscribe(x => {
          this.getDayLight();
          var searchexp = "";
          if (localStorage.getItem('courseId') === undefined || localStorage.getItem('courseId') === '' || localStorage.getItem('courseId') === null) {
              searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' "
          }
          else {
              searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' and  GC_ID='" + localStorage.getItem('courseId') + "'"
          }
          let parameters = { searchvalue: searchexp };
          this.soursename = true;
          this.getcourses(parameters);
          this.getcartscount();
          this.getlastupdateddatetime();
          this.getWeather();
          this.getWeatherHourlyForecast();
      });
  }

  getWeather() {
      this.spinnerService.show();
      let params = { clubid: this.golfclubid };
      this.api.postOH('getWeatherConditions', params).subscribe(
          (data) => {
              if (data.length == 0) {
                  this.spinnerService.show();
                  let parameters = {
                      searchvalue: " where GCB_STATUS='Y' and GCB_ID='" + this.golfclubid + "' "
                  };
                  this.api.postOH('getgolfclubaddressddl', parameters).subscribe(
                      (response) => {
                          if (response.length > 0) {
                              var clublat = response[0].latitude;
                              var clublong = response[0].longitude;
                              this.api.getWeather(clublat, clublong, '').subscribe(
                                  (response) => {
                                      this.api.getWeather(clublat, clublong, 'forecast').subscribe(
                                          (response1) => {
                                              let number; var mins = "";
                                              var date = new Date();
                                              let utc = date.getTime() + (date.getTimezoneOffset() * 60000);
                                              let utcdate2 = new Date(utc);
                                              var today = utcdate2.getDate() + "-" + (utcdate2.getMonth() + 1) + "-" + utcdate2.getFullYear();
                                              if (utcdate2.getMinutes() < 10) { mins = "0" + utcdate2.getMinutes() }
                                              else { mins = utcdate2.getMinutes().toString() };
                                              var presentTime = utcdate2.getHours() + ":" + mins;


                                              for (var i = 0; i < response1.properties.periods.length; i++) {
                                                  var start = this.utctime(response1.properties.periods[i].startTime);
                                                  var startdate = start.getDate() + "-" + (start.getMonth() + 1) + "-" + start.getFullYear();
                                                  var startTime = start.getHours() + ":00";

                                                  var end = this.utctime(response1.properties.periods[i].endTime);
                                                  var enddate = end.getDate() + "-" + (end.getMonth() + 1) + "-" + end.getFullYear();
                                                  var endTime = end.getHours() + ":00";

                                                  if (startdate == today) {
                                                      if ((startTime < presentTime)) {
                                                          number = response1.properties.periods[i].number;
                                                      }
                                                      break;
                                                  }
                                                  else {
                                                      number = response1.properties.periods[i].number;
                                                  }
                                              }
                                              for (var j = 0; j < response1.properties.periods.length; j++) {
                                                  if (j == (number - 1)) {
                                                      if (response1.properties.periods[j].name == "Tonight" || response1.properties.periods[j].name == "Overnight") {
                                                          nightstarttime = response1.properties.periods[j].startTime;
                                                          nightendtime = response1.properties.periods[j].endTime;
                                                          nighttemp = response1.properties.periods[j].temperature;
                                                          nighttempin = response1.properties.periods[j].temperatureUnit;
                                                          daystarttime = response1.properties.periods[j + 1].startTime;
                                                          dayendtime = response1.properties.periods[j + 1].endTime;
                                                          daytemp = response1.properties.periods[j + 1].temperature;
                                                          daytempin = response1.properties.periods[j + 1].temperatureUnit;
                                                          lowtemp = response1.properties.periods[j].temperature;
                                                      }
                                                      else {
                                                          daystarttime = response1.properties.periods[j].startTime;
                                                          dayendtime = response1.properties.periods[j].endTime;
                                                          daytemp = response1.properties.periods[j].temperature;
                                                          daytempin = response1.properties.periods[j].temperatureUnit;
                                                          nightstarttime = response1.properties.periods[j + 1].startTime;
                                                          nightendtime = response1.properties.periods[j + 1].endTime;
                                                          nighttemp = response1.properties.periods[j + 1].temperature;
                                                          nighttempin = response1.properties.periods[j + 1].temperatureUnit;
                                                          hightemp = response1.properties.periods[j].temperature;
                                                      }
                                                  }
                                                  break;
                                              }
                                              if (daytemp != undefined) {
                                                  this.maxTemp = daytemp;
                                              }
                                              else {
                                                  this.maxTemp = hightemp;
                                              }
                                              if (nighttemp != undefined) {
                                                  this.minTemp = nighttemp;
                                              }
                                              else {
                                                  this.minTemp = lowtemp;
                                              }
                                              this.weatherdiv = true;
                                          },
                                          (error) => {
                                              this.weatherdiv = false;
                                              this.errorforecast = (error._body);
                                              this.saveWeatherErrorLog(clublat, clublong, this.errorforecast);
                                          }
                                      )
                                      this.api.getWeather(clublat, clublong, 'forecast/hourly').subscribe(
                                          (response2) => {
                                              let number1; var min = "";
                                              var date1 = new Date();
                                              let utc1 = date1.getTime() + (date1.getTimezoneOffset() * 60000);
                                              let utcdate3 = new Date(utc1);
                                              var today1 = utcdate3.getDate() + "-" + (utcdate3.getMonth() + 1) + "-" + utcdate3.getFullYear();
                                              if (utcdate3.getMinutes() < 10) { min = "0" + utcdate3.getMinutes() }
                                              else { min = utcdate3.getMinutes().toString() };
                                              var presentTime1 = utcdate3.getHours() + ":" + min;

                                              for (var i = 0; i < response2.properties.periods.length; i++) {
                                                  var start1 = this.utctime(response2.properties.periods[i].startTime);
                                                  var startdate1 = start1.getDate() + "-" + (start1.getMonth() + 1) + "-" + start1.getFullYear();
                                                  var startTime1 = start1.getHours() + ":00";

                                                  var end1 = this.utctime(response2.properties.periods[i].endTime);
                                                  var enddate1 = end1.getDate() + "-" + (end1.getMonth() + 1) + "-" + end1.getFullYear();
                                                  var endTime1 = end1.getHours() + ":00";

                                                  if (startdate1 == today1 && enddate1 == today1) {
                                                      if (start1.getHours() == utcdate3.getHours()) {
                                                          if ((start1.getMinutes() - utcdate3.getMinutes() < 60) && (end1.getMinutes() - utcdate3.getMinutes() < 60)) {
                                                              number1 = response2.properties.periods[i].number;
                                                          }
                                                      }
                                                  }
                                              }
                                              for (var j = 0; j < response2.properties.periods.length; j++) {
                                                  if (j == (number1 - 1)) {
                                                      starttime = response2.properties.periods[j].startTime;
                                                      endtime = response2.properties.periods[j].endTime;
                                                      currtemp = response2.properties.periods[j].temperature;
                                                      tempunit = response2.properties.periods[j].temperatureUnit;
                                                      var icon = response2.properties.periods[j].icon;
                                                      shortForecast = response2.properties.periods[j].shortForecast;
                                                      isDayTime = response2.properties.periods[j].isDaytime;
                                                      var displayIcon = [];
                                                      if (icon.includes(',')) {
                                                          displayIcon = icon.split(',');
                                                          if (displayIcon[1].charAt(0) != '?') {
                                                              var iconname = displayIcon[1].split('?');
                                                              var iconsize = iconname[1].split('=');
                                                              if (iconsize[1] == 'large' || iconsize[1] == 'small' || iconsize[1] == 'medium') {
                                                                  iconsize[1] = 'medium';
                                                              }
                                                          }
                                                          iconurl = displayIcon[0] + '?' + iconsize[0] + "=" + iconsize[1];
                                                      }
                                                      else {
                                                          displayIcon = icon.split('=');
                                                          if (displayIcon[1] == 'large' || displayIcon[1] == 'small' || iconsize[1] == 'medium') {
                                                              displayIcon[1] = 'medium';
                                                          }
                                                          iconurl = displayIcon[0] + "=" + displayIcon[1];
                                                      }
                                                      this.weatherTemp = currtemp;
                                                      this.icon = iconurl;
                                                      this.description = shortForecast;
                                                      this.endtime = endtime;

                                                      this.windspeed = response2.properties.periods[j].windSpeed;
                                                      var windVal = (this.windspeed).split(' ');
                                                      if (windVal.length > 2) {
                                                          this.windspeed = windVal[0] + "-" + windVal[windVal.length - 2];
                                                      }
                                                      else if (windVal.length == 2) {
                                                          this.windspeed = windVal[0];
                                                      }
                                                      this.winddirection = response2.properties.periods[j].windDirection;
                                                      this.weatherdiv = true;
                                                  }
                                                  break;
                                              }

                                          },
                                          (error) => {
                                              this.weatherdiv = false;
                                              this.errorforecasthourly = (error._body);
                                              this.saveWeatherErrorLog(clublat, clublong, this.errorforecasthourly);
                                          }
                                      )
                                      this.spinnerService.hide();
                                  },
                                  (error) => {
                                      this.spinnerService.hide();
                                      this.weatherdiv = false;
                                      this.errorWeather = (error._body);
                                      this.saveWeatherErrorLog(clublat, clublong, this.errorWeather);
                                  }
                              )
                          }
                          this.spinnerService.hide();
                      },
                      (error) => {
                          this.spinnerService.hide();
                          this.weatherdiv = false;
                      }
                  )
                  if (this.weatherTemp != undefined || this.minTemp != undefined || this.maxTemp != undefined ||
                      this.icon != undefined || this.description != undefined || this.windspeed != undefined || this.winddirection != undefined) {
                      this.spinnerService.show();
                      var weatherinfo = {
                          'action': 'A',
                          'weatherid': 0,
                          'clubid': this.golfclubid,
                          'currenttemp': this.weatherTemp,
                          'mintemp': this.minTemp,
                          'maxtemp': this.maxTemp,
                          'icon': this.icon,
                          'description': this.description,
                          'hourendtime': this.endtime,
                          'windspeed': this.windspeed,
                          'winddirection': this.winddirection
                      }

                      this.api.postOH('saveweatherforecast', weatherinfo).subscribe(
                          (response) => {
                              if (response[1] == "Weather added Successfully") {
                                  this.weatherTemp = ''; this.minTemp = ''; this.maxTemp = ''; this.icon = '';
                                  this.description = ''; this.endtime = ''; this.windspeed = ''; this.winddirection = '';
                                  this.spinnerService.hide();
                              }
                          },
                          (error) => {
                              this.spinnerService.hide();
                          }
                      )
                  }
              }
              else if (data.length > 0) {
                  var date = new Date();
                  let utc = date.getTime() + (date.getTimezoneOffset() * 60000);
                  let utcdate = new Date(utc);
                  let hendtime = this.utctime(data[0].hourendtime);
                  if (hendtime <= utcdate) {
                      this.spinnerService.show();
                      let parameters = {
                          searchvalue: " where GCB_STATUS='Y' and GCB_ID='" + this.golfclubid + "' "
                      };
                      this.api.postOH('getgolfclubaddressddl', parameters).subscribe(
                          (response) => {
                              if (response.length > 0) {
                                  var clublat = response[0].latitude;
                                  var clublong = response[0].longitude;
                                  this.api.getWeather(clublat, clublong, '').subscribe(
                                      (response) => {
                                          this.api.getWeather(clublat, clublong, 'forecast').subscribe(
                                              (response1) => {
                                                  let number;
                                                  var date = new Date();
                                                  let utc = date.getTime() + (date.getTimezoneOffset() * 60000);
                                                  let utcdate2 = new Date(utc);
                                                  var today = utcdate2.getDate() + "-" + (utcdate2.getMonth() + 1) + "-" + utcdate2.getFullYear();
                                                  var presentTime = utcdate2.getHours() + ":" + utcdate2.getMinutes();
                                                  for (var i = 0; i < response1.properties.periods.length; i++) {
                                                      var start = this.utctime(response1.properties.periods[i].startTime);
                                                      var startdate = start.getDate() + "-" + (start.getMonth() + 1) + "-" + start.getFullYear();
                                                      var startTime = start.getHours() + ":00";

                                                      var end = this.utctime(response1.properties.periods[i].endTime);
                                                      var enddate = end.getDate() + "-" + (end.getMonth() + 1) + "-" + end.getFullYear();
                                                      var endTime = end.getHours() + ":00";

                                                      if (startdate == today) {
                                                          if ((startTime < presentTime)) {
                                                              number = response1.properties.periods[i].number;
                                                          }
                                                          break;
                                                      }
                                                      else {
                                                          number = response1.properties.periods[i].number;
                                                      }
                                                  }
                                                  for (var j = 0; j < response1.properties.periods.length; j++) {
                                                      if (j == (number - 1)) {
                                                          if (response1.properties.periods[j].name == "Tonight" || response1.properties.periods[j].name == "Overnight") {
                                                              nightstarttime = response1.properties.periods[j].startTime;
                                                              nightendtime = response1.properties.periods[j].endTime;
                                                              nighttemp = response1.properties.periods[j].temperature;
                                                              nighttempin = response1.properties.periods[j].temperatureUnit;
                                                              daystarttime = response1.properties.periods[j + 1].startTime;
                                                              dayendtime = response1.properties.periods[j + 1].endTime;
                                                              daytemp = response1.properties.periods[j + 1].temperature;
                                                              daytempin = response1.properties.periods[j + 1].temperatureUnit;
                                                              lowtemp = response1.properties.periods[j].temperature;
                                                          }
                                                          else {
                                                              daystarttime = response1.properties.periods[j].startTime;
                                                              dayendtime = response1.properties.periods[j].endTime;
                                                              daytemp = response1.properties.periods[j].temperature;
                                                              daytempin = response1.properties.periods[j].temperatureUnit;
                                                              nightstarttime = response1.properties.periods[j + 1].startTime;
                                                              nightendtime = response1.properties.periods[j + 1].endTime;
                                                              nighttemp = response1.properties.periods[j + 1].temperature;
                                                              nighttempin = response1.properties.periods[j + 1].temperatureUnit;
                                                              hightemp = response1.properties.periods[j].temperature;
                                                          }
                                                      }
                                                  }
                                                  if (daytemp != undefined) {
                                                      this.maxTemp = daytemp;
                                                  }
                                                  else {
                                                      this.maxTemp = hightemp;
                                                  }
                                                  if (nighttemp != undefined) {
                                                      this.minTemp = nighttemp;
                                                  }
                                                  else {
                                                      this.minTemp = lowtemp;
                                                  }

                                                  this.weatherdiv = true;

                                              },
                                              (error) => {
                                                  this.weatherdiv = false;
                                                  this.errorforecast = (error._body);
                                                  this.saveWeatherErrorLog(clublat, clublong, this.errorforecast);
                                              }
                                          )
                                          this.api.getWeather(clublat, clublong, 'forecast/hourly').subscribe(
                                              (response2) => {
                                                  let number1;
                                                  var date1 = new Date();
                                                  let utc1 = date1.getTime() + (date1.getTimezoneOffset() * 60000);
                                                  let utcdate3 = new Date(utc1);
                                                  var today1 = utcdate3.getDate() + "-" + (utcdate3.getMonth() + 1) + "-" + utcdate3.getFullYear();
                                                  var minshour;
                                                  if (utcdate3.getMinutes() < 10) { minshour = '0' + utcdate3.getMinutes() }
                                                  else { minshour = utcdate3.getMinutes() };
                                                  var presentTime1 = utcdate3.getHours() + ":" + minshour;

                                                  for (var i = 0; i < response2.properties.periods.length; i++) {
                                                      var start1 = this.utctime(response2.properties.periods[i].startTime);
                                                      var startdate1 = start1.getDate() + "-" + (start1.getMonth() + 1) + "-" + start1.getFullYear();
                                                      var startTime1 = start1.getHours() + ":00";

                                                      var end1 = this.utctime(response2.properties.periods[i].endTime);
                                                      var enddate1 = end1.getDate() + "-" + (end1.getMonth() + 1) + "-" + end1.getFullYear();
                                                      var endTime1 = end1.getHours() + ":00";

                                                      if (startdate1 == today1 && enddate1 == today1) {
                                                          if (start1.getHours() == utcdate3.getHours()) {
                                                              if ((start1.getMinutes() - utcdate3.getMinutes() < 60) && (end1.getMinutes() - utcdate3.getMinutes() < 60)) {
                                                                  number1 = response2.properties.periods[i].number;
                                                              }
                                                          }
                                                      }
                                                  }
                                                  for (var j = 0; j < response2.properties.periods.length; j++) {
                                                      if (j == (number1 - 1)) {
                                                          starttime = response2.properties.periods[j].startTime;
                                                          endtime = response2.properties.periods[j].endTime;
                                                          currtemp = response2.properties.periods[j].temperature;
                                                          tempunit = response2.properties.periods[j].temperatureUnit;
                                                          var icon = response2.properties.periods[j].icon;
                                                          shortForecast = response2.properties.periods[j].shortForecast;
                                                          isDayTime = response2.properties.periods[j].isDaytime;
                                                          var displayIcon = [];
                                                          if (icon.includes(',')) {
                                                              displayIcon = icon.split(',');
                                                              if (displayIcon[1].charAt(0) != '?') {
                                                                  var iconname = displayIcon[1].split('?');
                                                                  var iconsize = iconname[1].split('=');
                                                                  if (iconsize[1] == 'large' || iconsize[1] == 'small' || iconsize[1] == 'medium') {
                                                                      iconsize[1] = 'medium';
                                                                  }
                                                              }
                                                              iconurl = displayIcon[0] + '?' + iconsize[0] + "=" + iconsize[1];
                                                          }
                                                          else {
                                                              displayIcon = icon.split('=');
                                                              if (displayIcon[1] == 'large' || displayIcon[1] == 'small' || iconsize[1] == 'medium') {
                                                                  displayIcon[1] = 'medium';
                                                              }
                                                              iconurl = displayIcon[0] + "=" + displayIcon[1];
                                                          }
                                                          this.weatherTemp = currtemp;
                                                          this.icon = iconurl;
                                                          this.description = shortForecast;
                                                          this.endtime = endtime;

                                                          this.windspeed = response2.properties.periods[j].windSpeed;
                                                          var windVal = (this.windspeed).split(' ');
                                                          if (windVal.length > 2) {
                                                              this.windspeed = windVal[0] + "-" + windVal[windVal.length - 2];
                                                          }
                                                          else if (windVal.length == 2) {
                                                              this.windspeed = windVal[0];
                                                          }
                                                          this.winddirection = response2.properties.periods[j].windDirection;


                                                          this.weatherdiv = true;
                                                      }
                                                  }
                                              },
                                              (error) => {
                                                  this.weatherdiv = false;
                                                  this.errorforecasthourly = (error._body);
                                                  this.saveWeatherErrorLog(clublat, clublong, this.errorforecasthourly);
                                              }
                                          )
                                          this.spinnerService.hide();
                                      },
                                      (error) => {
                                          this.spinnerService.hide();
                                          this.weatherdiv = false;
                                          this.errorWeather = (error._body);
                                          this.saveWeatherErrorLog(clublat, clublong, this.errorWeather);
                                      }
                                  )
                              }
                              this.spinnerService.hide();
                          },
                          (error) => {
                              this.spinnerService.hide();
                              this.weatherdiv = false;
                          }
                      )
                      if ((this.weatherTemp == undefined || this.minTemp == undefined || this.maxTemp == undefined ||
                          this.icon == undefined || this.description == undefined || this.windspeed == undefined || this.winddirection == undefined)) {
                          this.weatherTemp = data[0].currenttemp;
                          this.icon = data[0].icon;
                          this.minTemp = data[0].mintemp;
                          this.maxTemp = data[0].maxtemp;
                          this.description = data[0].description;
                          this.endtime = this.endtime;
                          this.windspeed = data[0].windspeed;
                          this.winddirection = data[0].winddirection;
                      }
                      if (this.weatherTemp != undefined || this.minTemp != undefined || this.maxTemp != undefined ||
                          this.icon != undefined || this.description != undefined || this.windspeed != undefined || this.winddirection != undefined) {
                          this.spinnerService.show();
                          var weatherinfo = {
                              'action': 'U',
                              'weatherid': parseInt(data[0].weatherid),
                              'clubid': this.golfclubid,
                              'currenttemp': this.weatherTemp,
                              'mintemp': this.minTemp,
                              'maxtemp': this.maxTemp,
                              'icon': this.icon,
                              'description': this.description,
                              'hourendtime': this.endtime,
                              'windspeed': this.windspeed,
                              'winddirection': this.winddirection
                          }

                          this.api.postOH('saveweatherforecast', weatherinfo).subscribe(
                              (response) => {
                                  if (response[1] == "Weather updated Successfully") {
                                      this.weatherTemp = ''; this.minTemp = ''; this.maxTemp = ''; this.icon = '';
                                      this.description = ''; this.endtime = ''; this.windspeed = ''; this.winddirection = '';
                                      this.spinnerService.hide();
                                  }
                              },
                              (error) => {
                                  this.spinnerService.hide();
                              }
                          )
                      }
                  }
                  else {
                      this.spinnerService.show();
                      this.weatherTemp = data[0].currenttemp;
                      this.icon = data[0].icon;
                      this.minTemp = data[0].mintemp;
                      this.maxTemp = data[0].maxtemp;
                      this.description = data[0].description;
                      this.endtime = data[0].endtime;
                      this.windspeed = data[0].windspeed;
                      var windVal = (this.windspeed).split(' ');
                      if (windVal.length > 2) {
                          this.windspeed = windVal[0] + "-" + windVal[windVal.length - 2];
                      }
                      else if (windVal.length == 2) {
                          this.windspeed = windVal[0];
                      }
                      this.winddirection = data[0].winddirection;
                      this.weatherdiv = true;
                  }
                  this.spinnerService.hide();
              }

              this.spinnerService.hide();
          },
          (error) => {
              this.spinnerService.hide();
          }
      )
  }

  viewWeekForecast() {
      this.weekforecastTemp = [];
      this.weekDays = [];
      this.spinnerService.show();
      let parameters = {
          searchvalue: " where GCB_STATUS='Y' and GCB_ID='" + this.golfclubid + "' "
      };
      this.api.postOH('getgolfclubaddressddl', parameters).subscribe(
          (response) => {
              if (response.length > 0) {
                  var clublat = response[0].latitude;
                  var clublong = response[0].longitude;
                  var timezoneoffset = response[0].timezoneoffset;

                  var date = new Date();
                  let utc = date.getTime() + (date.getTimezoneOffset() * 60000);
                  var currentDate = new Date(utc + (3600000 * timezoneoffset));

                  for (var i = 0; i < 6; i++) {
                      var day = (new Date(currentDate.setDate(currentDate.getDate() + 1)).getDay());
                      var dates = (new Date(currentDate.setDate(currentDate.getDate())));
                      var month; var getdate;
                      if (dates.getMonth() + 1 < 10) month = "0" + (dates.getMonth() + 1)
                      else month = (dates.getMonth() + 1);
                      if (dates.getDate() < 10) getdate = "0" + (dates.getDate())
                      else getdate = (dates.getDate());
                      var dateStr = dates.getFullYear() + "-" + month + "-" + getdate;
                      this.weekDays.push({ 'dayName': days[day], 'dateString': dateStr });
                  }
                  this.api.getWeather(clublat, clublong, 'forecast').subscribe(
                      (response) => {
                          this.weekforecastTemp = [];
                          var dayname; var day_temp; var night_temp; var Icon; var description; var iconurl;
                          var windofDay; var windValue; var popofDay; var snow; var humidity;
                          for (var i = 0; i < this.weekDays.length; i++) {
                              var day = this.weekDays[i].dayName;
                              var nextDay = this.weekDays[i].dateString;

                              for (var j = 0; j < response.properties.periods.length; j++) {
                                  var nextforecastday = (response.properties.periods[j].startTime).split('T');
                                  if (response.properties.periods[0].name == "Overnight" || response.properties.periods[0].name == "Tonight") {
                                      if (response.properties.periods[j].number % 2 == 0 && nextDay == nextforecastday[0]) {
                                          dayname = day;
                                          day_temp = response.properties.periods[j].temperature;
                                          description = response.properties.periods[j].shortForecast;
                                          windofDay = response.properties.periods[j].windSpeed;
                                          windValue = windofDay.split(' ');
                                          if (windValue.length > 2) {
                                              windofDay = windValue[0] + "-" + windValue[windValue.length - 2];
                                          }
                                          else if (windValue.length == 2) {
                                              windofDay = windValue[0];
                                          }
                                          popofDay = response.properties.periods[j].detailedForecast;
                                          var arr = [];
                                          arr = popofDay.split('.');
                                          var vals = '';
                                          for (var x = 0; x < arr.length; x++) {
                                              if (arr[x].includes('precipitation')) {
                                                  var str;
                                                  str = arr[x].split(' ');
                                                  vals = str[str.length - 1];
                                                  popofDay = vals;
                                                  break;
                                              }
                                              else {
                                                  popofDay = "0";
                                              }
                                          }
                                          Icon = response.properties.periods[j].icon;
                                          snow = 0;
                                          humidity = 0;

                                      }
                                      else if (nextDay == nextforecastday[0] && response.properties.periods[j].number % 2 != 0) {
                                          night_temp = response.properties.periods[j].temperature;
                                          description = response.properties.periods[j].shortForecast;
                                      }
                                  }
                                  else {
                                      if (response.properties.periods[j].number % 2 != 0 && nextDay == nextforecastday[0]) {
                                          dayname = day;
                                          day_temp = response.properties.periods[j].temperature;
                                          description = response.properties.periods[j].shortForecast;
                                          windofDay = response.properties.periods[j].windSpeed;
                                          windValue = windofDay.split(' ');
                                          if (windValue.length > 2) {
                                              windofDay = windValue[0] + "-" + windValue[windValue.length - 2];
                                          }
                                          else if (windValue.length == 2) {
                                              windofDay = windValue[0];
                                          }
                                          popofDay = response.properties.periods[j].detailedForecast;
                                          var arr = [];
                                          arr = popofDay.split('.');
                                          var vals = '';
                                          for (var x = 0; x < arr.length; x++) {
                                              if (arr[x].includes('precipitation')) {
                                                  var str;
                                                  str = arr[x].split(' ');
                                                  vals = str[str.length - 1];
                                                  popofDay = vals;
                                                  break;
                                              }
                                              else {
                                                  popofDay = "0";
                                              }
                                          }
                                          Icon = response.properties.periods[j].icon;
                                          snow = 0;
                                          humidity = 0;
                                      }
                                      else if (nextDay == nextforecastday[0] && response.properties.periods[j].number % 2 == 0) {
                                          night_temp = response.properties.periods[j].temperature;
                                          description = response.properties.periods[j].shortForecast;
                                      }
                                  }
                              }
                              if (day_temp != undefined && night_temp != undefined) {
                                  this.weekforecastTemp.push({
                                      'day': day,
                                      'day_temp': day_temp,
                                      'night_temp': night_temp,
                                      'Icon': Icon,
                                      'desc': description,
                                      'pop': popofDay,
                                      'wind': windofDay,
                                      'snow': snow,
                                      'humidity': humidity
                                  })
                              }

                              for (var k = 0; k < this.weekforecastTemp.length; k++) {
                                  if (this.weekforecastTemp[k].day == 'Sunday') { this.weekforecastTemp[k].day = "Sun" }
                                  else if (this.weekforecastTemp[k].day == 'Monday') { this.weekforecastTemp[k].day = "Mon" }
                                  else if (this.weekforecastTemp[k].day == 'Tuesday') { this.weekforecastTemp[k].day = "Tue" }
                                  else if (this.weekforecastTemp[k].day == 'Wednesday') { this.weekforecastTemp[k].day = "Wed" }
                                  else if (this.weekforecastTemp[k].day == 'Thursday') { this.weekforecastTemp[k].day = "Thu" }
                                  else if (this.weekforecastTemp[k].day == 'Friday') { this.weekforecastTemp[k].day = "Fri" }
                                  else if (this.weekforecastTemp[k].day == 'Saturday') { this.weekforecastTemp[k].day = "Sat" }
                              }
                          }
                          this.spinnerService.hide();
                      }, error => {
                          this.spinnerService.hide();
                      });
              }
              this.spinnerService.hide();
          }, error => {
              this.spinnerService.hide();
          });
  }

  viewForecast() {
      var utcdate;
      this.next6hrforecast = [];
      this.eachhourforecast = [];
      this.forecastlist = [];
      this.spinnerService.show();
      let parameters = {
          searchvalue: " where GCB_STATUS='Y' and GCB_ID='" + this.golfclubid + "' "
      };
      this.api.postOH('getgolfclubaddressddl', parameters).subscribe(
          (response1) => {
              if (response1.length > 0) {
                  this.next6hrforecast = [];
                  this.eachhourforecast = [];
                  this.forecastlist = [];
                  var clublat = response1[0].latitude;
                  var clublong = response1[0].longitude;
                  var date = new Date();
                  let utc = date.getTime() + (date.getTimezoneOffset() * 60000);
                  utcdate = new Date(utc);
                  this.api.getWeather(clublat, clublong, 'forecast/hourly').subscribe(
                      (response) => {
                          var currenthourNumber; var currenthourstarttime; var currenthourendtime;

                          for (var n = 0; n < response.properties.periods.length; n++) {

                              currenthourstarttime = this.utctime(response.properties.periods[n].startTime);
                              currenthourendtime = this.utctime(response.properties.periods[n].endTime);
                              if (currenthourstarttime <= utcdate && utcdate <= currenthourendtime) {
                                  currenthourNumber = response.properties.periods[n].number;
                              }
                          }
                          for (var k = currenthourNumber; k < currenthourNumber + 4; k++) {
                              var wiconurl = "";

                              var currenthourfulltime = response.properties.periods[k].startTime;

                              var weathericon = response.properties.periods[k].icon;
                              var currenthourTemp = response.properties.periods[k].temperature;
                              var currenthourDesc = response.properties.periods[k].shortForecast;
                              var displayIcon = [];
                              if (weathericon.includes(',')) {
                                  displayIcon = weathericon.split(',');
                                  if (displayIcon[1].charAt(0) != '?') {
                                      var iconname = displayIcon[1].split('?');
                                      var iconsize = iconname[1].split('=');
                                      if (iconsize[1] == 'large' || iconsize[1] == 'small' || displayIcon[1] == 'medium') {
                                          iconsize[1] = 'small';
                                      }
                                  }
                                  wiconurl = displayIcon[0] + '?' + iconsize[0] + "=" + iconsize[1];
                              }
                              else {
                                  displayIcon = weathericon.split('=');
                                  if (displayIcon[1] == 'large' || displayIcon[1] == 'small' || displayIcon[1] == 'medium') {
                                      displayIcon[1] = 'small';
                                  }
                                  wiconurl = displayIcon[0] + "=" + displayIcon[1];
                              }
                              var currenthour = currenthourfulltime.split('T');
                              var time = currenthour[1].split(":");
                              var hour;
                              if (time[0] == 0 || time[0] == "00") {
                                  hour = "12:00 AM";
                              }
                              else if (time[0] < 12) {
                                  hour = time[0] + ":00 AM";
                              }
                              else if (time[0] == 12) {
                                  hour = time[0] + ":00 PM";
                              }
                              else if (time[0] > 12) {
                                  hour = (time[0] - 12) + ":00 PM";
                                  if (hour < 10) {
                                      hour = "0" + (time[0] - 12) + ":00 PM";
                                  }
                                  else if (hour >= 10) {
                                      hour = (time[0] - 12) + ":00 PM";
                                  }
                              }
                              this.next6hrforecast.push({
                                  'time': hour,
                                  'temp': currenthourTemp,
                                  'icon': wiconurl,
                                  'description': currenthourDesc,
                                  'nexthour': currenthourfulltime
                              })
                              this.eachhourforecast = this.next6hrforecast;
                          }
                          if (this.eachhourforecast.length > 0) {
                              for (var z = 0; z < this.eachhourforecast.length; z++) {
                                  this.forecastlist.push({
                                      'ICON': this.eachhourforecast[z].icon,
                                      'CURRENTHOUR': this.eachhourforecast[z].time,
                                      'TEMPERATURE': this.eachhourforecast[z].temp,
                                      'DESCRIPTION': this.eachhourforecast[z].description,
                                      'NEXTHOURSTARTTIME': this.eachhourforecast[z].nexthour
                                  })
                              }

                          }
                          this.spinnerService.show();
                          var model = { 'HourlyForecast': this.forecastlist, 'gcbid': this.golfclubid };

                          this.api.postOH('saveWeatherHourlyForecast', model).subscribe(
                              (response) => {
                                  if (response.saveWeatherHourlyForecastResult == "Success") {

                                  }
                                  this.spinnerService.hide();
                              },
                              (error) => {
                                  this.spinnerService.hide();
                              }
                          )
                          this.spinnerService.hide();
                      },
                      (error) => {
                          this.spinnerService.hide();
                      });
              }
              this.spinnerService.hide();
          }, error => {
              this.spinnerService.hide();
          });
  }

  msToTime(duration) {
      var d, h, m, s;
      s = Math.floor(duration / 1000);
      m = Math.floor(s / 60);
      s = s % 60;
      h = Math.floor(m / 60);
      m = m % 60;
      return { h: h, m: m, s: s };
  }

  getDayLight() {

      this.sunset = ""; this.sunrise = "";

      var newdate = new Date();
      var times = SunCalc.getTimes(newdate, this.courselat, this.courselong);

      var sunriseend = times.sunriseEnd; var sunrisestart = times.sunrise;
      var sunsetend = times.sunset; var sunsetstart = times.sunsetStart;

      this.sunrise = sunrisestart;
      this.sunset = sunsetstart;

      var difference = this.msToTime(sunsetstart - sunriseend);
      var daylighttime = difference.h + ":" + difference.m + ":" + difference.s;

      var d = new Date();
      var currenttime = d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();

      var daylighthours; var daylightmins;
      var remaininglight = sunsetstart.getTime() - d.getTime();
      if (d.getTime() >= sunriseend.getTime()) {
          var hours = Math.floor((remaininglight % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
          if (hours < 0) {
              hours = 0;
          }
          var minutes = Math.floor((remaininglight % (1000 * 60 * 60)) / (1000 * 60));
          if (minutes < 0) {
              minutes = 0;
          }
          //var seconds = Math.floor((remaininglight % (1000 * 60)) / 1000);
          if (hours < 10) { daylighthours = hours.toString(); }
          else { daylighthours = hours.toString(); }
          if (minutes < 10) { daylightmins = "0" + minutes.toString(); }
          else { daylightmins = minutes.toString(); }
      }
      else if (d.getTime() < sunriseend.getTime() || remaininglight < 0 || d.getTime() > sunsetstart.getTime()) {
          daylighthours = "0";
          daylightmins = "00";
      }
      this.daylightremaining = daylighthours + " hr. " + daylightmins + " min. ";
  }

  todaydateandtime() {
      var date1 = new Date();
      var dd = (date1.getDate()).toString();
      var mm = m_names[date1.getMonth()];
      var yyyy = date1.getFullYear();
      if (dd.length == 1) { dd = '0' + dd };
      this.todaydate = mm + ' ' + dd + ', ' + yyyy;
      this.todaytime = Observable.interval(1000).map(() => new Date());
  }

  formatAMPM(date) {
      var hours = date.getHours();
      var minutes = date.getMinutes();
      var ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12; // the hour '0' should be '12'
      minutes = minutes < 10 ? '0' + minutes : minutes;
      var strTime = hours + ':' + minutes + ' ' + ampm;
      return strTime;
  }

  getlastupdateddatetime() {
      let date = new Date(Date.now());
      let day1 = date.getDate();
      if (day1 < 10) {
          this.day = "0" + day1.toString();
      } else {
          this.day = day1.toString();
      }
      let month1 = date.getMonth() + 1;
      if (month1 < 10) {
          this.month = "0" + month1.toString();
      } else {
          this.month = month1.toString();
      }
      let hours = date.getHours();
      if (hours < 10) {
          this.hh = "0" + hours;
      }
      else { this.hh = hours; }

      let minuts = date.getMinutes();
      if (minuts < 10) {
          this.mm = "0" + minuts;
      }
      else { this.mm = minuts; }

      let seconds = date.getSeconds();
      if (seconds < 10) {
          this.ss = "0" + seconds;
      }
      else { this.ss = seconds; }


      let year = date.getFullYear();
      let todaydate = this.month + "-" + this.day + "-" + year + ' ' + this.hh + ":" + this.mm + ":" + this.ss;
      this.lastupdateddate = todaydate;
  }

  ngOnDestroy() {
      this.sub.unsubscribe();
  }

  over() {
      this.sub.unsubscribe();
  }

  mouseLeave() {
      this.sub = Observable.interval(1000 * 60).subscribe(x => {
          this.getDayLight();
          var searchexp = "";
          if (localStorage.getItem('courseId') === undefined || localStorage.getItem('courseId') === '' || localStorage.getItem('courseId') === null) {
              searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' "
          }
          else {
              searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' and  GC_ID='" + localStorage.getItem('courseId') + "'"
          }
          let parameters = { searchvalue: searchexp };
          this.soursename = true;
          this.getcourses(parameters);
          this.getcartscount();
          this.getlastupdateddatetime();
          this.getWeather();
      });
  }


  getcartscount() {
      this.activecartscount = 0;
      if (localStorage.getItem('courseId') === undefined || localStorage.getItem('courseId') === '' || localStorage.getItem('courseId') === null) {
      } else {
          let parameters = {
              searchvalue: " WHERE CD_GCB_ID='" + this.golfclubid + "' AND (CD_DEVICE_TOKEN!='' or CD_DEVICE_TOKEN !=null) AND CD_ASSIGN_STATUS='Y' AND CD_STATUS = 'Y' AND CD_ROLE_TYPE='0'",
              "courseid": localStorage.getItem('courseId')
          };
          this.api.postOH('getcartdetails', parameters).subscribe(
              (response) => {
                 // this.activecartscount = response.length;
              });
      }

      let parameters1 = {
          searchvalue: " WHERE CD_GCB_ID='" + this.golfclubid + "' AND (CD_DEVICE_TOKEN!='' or CD_DEVICE_TOKEN !=null) AND CD_ASSIGN_STATUS='N' AND CD_STATUS = 'Y' AND CD_ROLE_TYPE='0'",
          "courseid": 0
      };
      this.api.postOH('getcartdetails', parameters1).subscribe(
          (response) => {
              this.availablecartscount = response.length;
          });

      var clubinfo = {
          "clubid": this.golfclubid,
          "courseid": localStorage.getItem('courseId')
      }
      this.api.postOH('gettotalroundsv1', clubinfo).subscribe(
          (response) => {
              this.totalrounds = response.gettotalroundsv1Result;
          });

      this.api.postOH('getpaceofplayv1', clubinfo).subscribe(
          (response) => {
              this.paceofplayavg = response.getpaceofplayv1Result;
          });

      this.api.postOH('getrangerscount', clubinfo).subscribe(
          (response) => {
              this.rangerscount = response.getrangerscountResult;
          });

  }

  getcourses(parameters) {
      this.spinnerService.show();
      this.CoursesInfo = [];
      this.api.postOH('getgolfcourse', parameters).subscribe(
          response => {
              if (response.length !== 0) {
                  for (let i = 0; i < response.length; i++) {
                      this.CoursesInfo.push({
                          "id": response[i].id,
                          "name": response[i].labelname
                      })
                  }
                  // this.ddlcourse = response[0].id;
                  // localStorage.setItem('courseId', this.ddlcourse);
                  // localStorage.setItem('coursename', response[0].labelname);
                  if (localStorage.getItem('courseId') === undefined || localStorage.getItem('courseId') === '' || localStorage.getItem('courseId') === null) {
                      localStorage.setItem('courseId', response[0].id);
                  }
                  this.courselat = response[0].latitude;
                  this.courselong = response[0].longitude;
                  this.coursezoomlevel = (response[0].zoomlevel != '') ? response[0].zoomlevel : 0;
                  this.courserotate = (response[0].rotate != '') ? response[0].rotate : 0;
                  this.getDayLight();
                  this.GetCarts();
                  this.spinnerService.hide();
              }
          }, error => {
              this.spinnerService.hide();
          })
  }

  backToClub() {
      this.authService.getCall();
      this.router.navigate(['/clubmanagement/golfclub']);
  }

  GetCarts() {
      this.cartsarry = [];
      let parameters = {
          clubid: parseInt(this.golfclubid),
          courseid: localStorage.getItem('courseId'),
          cartid: 0
      };
      this.api.postOH('getinplaycartdetailsv1', parameters).subscribe(
          (response) => {
            this.activecartscount = response.length;
              this.spinnerService.show();
              for (var i = 0; i < response.length; i++) {
                  if (response[i].latitude != '') {
                      var cartcolorname = "";
                      if (response[i].cartcolor === 'tournament') {
                          cartcolorname = 'blue_circle.png';
                      }
                      else {
                          cartcolorname = response[i].cartcolor;
                      }

                      this.cartsarry.push([
                          response[i].name,
                          response[i].latitude,
                          response[i].longitude,
                          response[i].id,
                          response[i].cartroletype,
                          cartcolorname
                      ]);
                  }
              }
              let parameters1 = {
                  clubid: parseInt(this.golfclubid)
              };
              this.api.postOH('getrangersbeveragebagdropcartdetails', parameters1).subscribe(
                  (response1) => {
                      if (response1.length != 0) {
                          for (let j = 0; j < response1.length; j++) {
                              if (response1[j].latitude != '') {
                                  this.cartsarry.push([
                                      response1[j].name,
                                      response1[j].latitude,
                                      response1[j].longitude,
                                      response1[j].id,
                                      response1[j].cartroletype,
                                      ''
                                  ]);
                              }
                          }
                      }
                      this.cartsarry = this.cartsarry;
                      if (this.soursename == false) {
                          this.maploading();
                      } else {
                          this.setMarkers();
                      }
                  });
              this.spinnerService.hide();
          }, error => {
              this.spinnerService.hide();
          }
      );
  }

  maploading() {
      this.spinnerService.show();
      var stylecontrols = document.getElementById('styleControls');
      this.map = new google.maps.Map(document.getElementById('map'), {
          center: { lat: parseFloat(this.courselat), lng: parseFloat(this.courselong) },
          zoom: parseInt(this.coursezoomlevel),
          //disableDefaultUI: true,
          mapTypeId: 'satellite',
          tilt: 0,
          rotateControl: true,
          zoomControl: false,
          streetViewControl: false,
          mapTypeControl: false,
          //heading:parseInt(this.courserotate)
      });
      // let cthis=this;
      // this.map.addListener('zoom_changed', function () {
      //     var zoomlevel = cthis.map.getZoom();
      //     if (zoomlevel >= 18) {
      //         var rotateValue = cthis.courserotate;
      //         cthis.map.setHeading(parseInt(rotateValue));
      //     }
      // });
      currentZoom = this.map.getZoom();
      minZoom = 0;
      maxZoom = 21;
      this.setoverlayimage();
      this.setMarkers();
      this.map.controls[google.maps.ControlPosition.TOP_LEFT].push(stylecontrols);
      this.spinnerService.hide();
  }

  setoverlayimage() {
      let me = this;
      for (let i = 0; i < this.CoursesInfo.length; i++) {
          var imageMapType = new google.maps.ImageMapType({
              getTileUrl: function (coord, zoom) {
                  //console.log('http://cp.izongolf.com/tiles/' + me.golfclubid + '/' + me.CoursesInfo[i].id + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png');
                  // let clbid=''; let cursid='';
                  // if(me.golfclubid=='1002'){clbid='1445'}else{clbid=me.golfclubid};
                  // if(me.CoursesInfo[i].id==2){cursid='539'}else if(me.CoursesInfo[i].id==3){cursid='540'}else if(me.CoursesInfo[i].id==4){cursid='541'}else{cursid=me.CoursesInfo[i].id};
                  // return ['http://cp.izongolf.com/tiles/' + clbid + '/' + cursid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
                  return ['http://cp.izongolf.com/tiles/' + me.golfclubid + '/' + me.CoursesInfo[i].id + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
              },
              tileSize: new google.maps.Size(256, 256)
          });
          this.map.overlayMapTypes.push(imageMapType);
      }
  }

  closeLastOpenedInfoWindow() {
      if (this.lastOpenedInfoWindow) {
          this.lastOpenedInfoWindow.close();
      }
  }

  setMarkers() {
      this.spinnerService.show();
      //var infowindow = null;
      let me = this;
      this.clearMarkers();
      for (var i = 0; i < this.cartsarry.length; i++) {
          var carts = this.cartsarry[i];
          if (carts[4] == '3' || carts[4] == '7') {
              this.bluecircleimage = 'assets/imgs/star_view.png';
              this.iconnameonmap = '';
          } else if (carts[4] == '4') {
              this.bluecircleimage = 'assets/imgs/beverage_view.png';
              this.iconnameonmap = '';
          } else {
              //     if( carts[5]==='tournament'){
              //         this.bluecircleimage = 'assets/imgs/blue_circle.png';
              //     }
              //    else{
              //     this.bluecircleimage = 'assets/imgs/' +  carts[5];
              //    }
              this.bluecircleimage = 'assets/imgs/' + carts[5];
              this.iconnameonmap = {
                  text: carts[0],
                  color: 'white'
              };
          }
          var marker = new google.maps.Marker({
              position: { lat: parseFloat(carts[1]), lng: parseFloat(carts[2]) },
              label: me.iconnameonmap,
              icon: this.bluecircleimage,
              zIndex: parseInt(carts[3]),
              id: parseInt(carts[3]),
          });
          marker.setMap(this.map);
          this.markers.push(marker);
          var infowindow = new google.maps.InfoWindow();
          google.maps.event.addListener(marker, 'click', (function (marker, infowindow) {
              return function () {
                  this.cartlabelname = marker.label.text;

                  for (var i = 0; i < me.cartsarry.length; i++) {
                      if (this.cartlabelname == me.cartsarry[i][0]) {
                          this.fleetCartId = me.cartsarry[i][3];
                          this.fleetRoleId = me.cartsarry[i][4];
                      }
                  }
                  var content = "";
                  me.closeLastOpenedInfoWindow();
                  if (this.fleetCartId > 0 && this.fleetRoleId == 0) {
                      let parameters = { searchvalue: " WHERE SC_CD_ID='" + this.fleetCartId + "' AND SC_GAME_STATUS='L'" };
                      me.inplayDetails = [];
                      me.api.postOH('getcartassignedusers', parameters).subscribe(
                          (response) => {
                              me.inplayDetails = [];
                              if (response.length != 0) {
                                  for (let i = 0; i < response.length; i++) {
                                      me.inplayDetails.push({
                                          "cartid": response[i].cartid,
                                          "cartname": response[i].cartname,
                                          "frontnine": response[i].frontnine,
                                          "izonuseremail": response[i].izonuseremail,
                                          "izonusername": response[i].izonusername,
                                          "createddateinampm": response[i].createddate,
                                          "starttime": response[i].starttime,
                                          "endtime": response[i].endtime,
                                          "izonusermobile": response[i].izonusermobile,
                                          "izonuserpwd": response[i].izonuserpwd,
                                      })
                                  }
                                  me.startinghole = response[0].frontnine === "Y" ? "1st" : "10th";
                                  if (response[0].starttime != "") {
                                      var st = new Date(response[0].starttime);
                                      st.setMinutes(st.getMinutes() - 4);
                                      me.starttime = moment(st).format('MM.DD.YYYY @ hh:mm A');
                                  }
                                  else {
                                      var cd = new Date(response[0].createddateinampm);
                                      cd.setMinutes(cd.getMinutes() - 4);
                                      me.starttime = moment(cd).format('MM.DD.YYYY @ hh:mm A');
                                  }

                                  // content to display in infowindow
                                  content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Cart Details:</div>'
                                  content += '<div style="color:green;font-weight: bold;">Riders:</div>' +
                                      '<div class="horizontalline"></div>'
                                  for (let inplayuser of me.inplayDetails) {
                                      content += '<div class="username">' + inplayuser.izonusername + '</div>'
                                  }
                                  content += '<div style="margin-top:15px;">' +
                                      '<div style="color:green;font-weight:bold">Start Time:</div>' +
                                      '<div class="fontweight">' + me.starttime + '</div>' +
                                      '</div>' +
                                      '<div class="horizontalline"></div>'
                                  content += '<span style="cursor:pointer;float:left;"><a id="messageWindowButton" style="color:#ed9325de;"><i class="fa fa-envelope"></i>&nbsp;Message</a></span>'
                                  content += '<span style="color:green;cursor:pointer;float:right;" id="infoWindowButton"><a style="font-weight: bold;">More Info</a></span>';
                                  var cartId = me.inplayDetails[0].cartid;
                                  //Before Companion Inplay
                                  // var cartName = me.inplayDetails[0].cartname;
                                  var cartName = this.cartlabelname;

                                  infowindow.setContent(content);
                                  infowindow.open(this.map, marker);

                                  //calling angular2 function from a google map infowindow
                                  infowindow.addListener('domready', () => {
                                      document.getElementById("infoWindowButton").addEventListener("click", () => {
                                          me.navigateCartPlayTrack(cartId, cartName, 0);
                                      });
                                  });

                                  //calling angular2 function from a google map infowindow
                                  let i=0;
                                  infowindow.addListener('domready', () => {
                                      i++;
                                      document.getElementById("messageWindowButton").addEventListener("click", () => {
                                          if(i===1){
                                          me.messageopenModal(cartId);
                                          }
                                      });
                                  });

                                  me.lastOpenedInfoWindow = infowindow;
                              }
                          });
                  } else {
                      for (var i = 0; i < me.cartsarry.length; i++) {
                          if (marker.id == me.cartsarry[i][3]) {
                              me.fleetRoleId = me.cartsarry[i][4];
                          }
                      }
                      let parameters = {
                          searchvalue: " where CLL_GCB_ID=" + me.golfclubid + " AND CLL_CD_ID=" + marker.id + " AND CLL_ACTION='I' AND CLL_U_TYPE=" + me.fleetRoleId + " "
                      };
                      me.api.postOH('rangerandbeveragedetails', parameters).subscribe(
                          (response) => {
                              if (response.length > 0) {
                                  me.ranbavname = response[0].name;
                                  me.ranbavId = response[0].uid;
                                  me.cartlabelname = response[0].cartname;
                                  //me.fleetRoleId = response[0].roleid;
                                  localStorage.setItem('rangerBeverageName', me.ranbavname);
                                  localStorage.setItem('rangerBeverageId', me.ranbavId);

                                  // content to display in infowindow
                                  if (me.fleetRoleId == 3) {
                                      content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Cart Details (' + me.cartlabelname + '):</div>'
                                      content += '<div style="color:green;font-weight:bold">Ranger:</div>'
                                  }
                                  else if (me.fleetRoleId == 4) {
                                      content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Cart Details (' + me.cartlabelname + '):</div>'
                                      content += '<div style="color:green;font-weight:bold">Beverage:</div>'
                                  }
                                  else if (me.fleetRoleId == 7) {
                                      content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Cart Details (' + me.cartlabelname + '):</div>'
                                      content += '<div style="color:green;font-weight:bold">Bag Drop:</div>'
                                  }
                                  content += '<div class="username" style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;">' + me.ranbavname + '</div>'
                                  content += ' <div class="horizontalline"></div>'
                                  content += '<span style="cursor:pointer;float:left;margin-right:7px;margin-top: 4px;"><a id="messageWindowButton" style="color:#ed9325de;"><i class="fa fa-envelope"></i>&nbsp;Message</a></span>'
                                  content += '<span style="color:green;cursor:pointer;float:right;margin-top: 4px;" id="infoWindowButton"><a style="font-weight: bold;">More Info</a></span>';
                                  var cartId = marker.id;
                                  var cartName = me.cartlabelname;
                                  var roleId = me.fleetRoleId;

                                  infowindow.setContent(content);
                                  infowindow.open(me.map, marker);

                                  infowindow.addListener('domready', () => {
                                      document.getElementById("infoWindowButton").addEventListener("click", () => {
                                          me.navigateCartPlayTrack(cartId, cartName, roleId);
                                      });
                                  });

                                 let i=0;
                                  //calling angular2 function from a google map infowindow
                                  infowindow.addListener('domready', () => {
                                      i++;
                                      
                                      document.getElementById("messageWindowButton").addEventListener("click", () => {
                                        if(i===1){
                                          me.messageopenModal(cartId);
                                        }
    
                                      });
                                  });

                                  me.lastOpenedInfoWindow = infowindow;

                              }
                              else {
                                  me.ranbavname = "";
                                  if (me.ranbavname == "") {
                                      if (me.fleetRoleId == 3) {
                                          content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Ranger Details (' + carts[0] + '):</div>'
                                      }
                                      else if (me.fleetRoleId == 4) {
                                          content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Beverage Details (' + carts[0] + '):</div>'
                                      }
                                      else if (me.fleetRoleId == 7) {
                                          content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Bag Drop Details (' + carts[0] + '):</div>'
                                      }
                                      content += '<div><span>No data found</span></div>'
                                      infowindow.setContent(content);
                                      infowindow.open(me.map, marker);
                                      me.lastOpenedInfoWindow = infowindow;
                                  }
                              }
                          }, error => {

                          }
                      );
                  }
              };
          })(marker, infowindow));
      }
      this.spinnerService.hide();
  }

  messageopenModal(cid) {
      this.cartId = cid;
   this.cartMessage='';
      this.modalRef = this.modalService.show(this.msgtemplate, { class: 'modal-sm' });
      this.lastOpenedInfoWindow.close();
      this.messageForm.reset();
      this.submitAttempt = false;
  }
  closemessgepopup() {
   this.modalRef.hide();
  }
  ngAfterViewInit() {
      this.modalRef.hide();
  }
  sendMessage() {
      if (!this.messageForm.valid) {

      }
      this.submitAttempt = true;
      this.messageBtn = true;
      if (this.messageForm.valid) {
          var messageModal = { "action": "A", "id": 0, "clubid": this.golfclubid, "courseid": localStorage.getItem('courseId'), "fromcartid": 0, "tocartid": this.cartId, "message": this.cartMessage, "readstatus": "N", "userid": this.userId }
          this.spinnerService.show();
          this.api.postOH('savecartmessages', messageModal).subscribe(
              response => {
                  this.spinnerService.hide();
                  if (response == "Success") {
                      let msg = '<span style="color: green">Message sent successfully</span>';
                      this.toastMessage(msg);
                      this.closemessgepopup();
                      this.messageBtn = false;
                  } else {
                      let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                      this.toastMessage(msg);
                      this.messageBtn = false;
                  }
              },
              err => {
                  this.spinnerService.hide();
              }
          );
      }
      else {
          this.messageBtn = false;
      }
  }

  navigateCartPlayTrack(cartId, cartName, roleid) {
      localStorage.setItem('playcartId', cartId);
      localStorage.setItem('playcartname', cartName);
      localStorage.setItem('userType', roleid);
      localStorage.setItem('sourceFrom', 'dashboard');
      this.router.navigate(['/clubmanagement/livefleettrack']);
  }
  // Sets the map on all markers in the array.
  setMapOnAll(map) {
      for (var i = 0; i < this.markers.length; i++) {
          this.markers[i].setMap(map);
      }
  }

  // Removes the markers from the map, but keeps them in the array.
  clearMarkers() {
      this.setMapOnAll(null);
      this.markers = [];
  }

  refreshpage() {
      var searchexp = "";
      if (localStorage.getItem('courseId') === undefined || localStorage.getItem('courseId') === '' || localStorage.getItem('courseId') === null) {
          searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' "
      }
      else {
          searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' and  GC_ID='" + localStorage.getItem('courseId') + "'"
      }
      let parameters = { searchvalue: searchexp };
      this.soursename = true;
      this.getcourses(parameters);
      this.getcartscount();
      this.getlastupdateddatetime();
      this.getDayLight();
      this.getWeather();
      //this.getWeatherHourlyForecast();
  }
  //calendar
  clickButton(model: any) {
      this.displayEvent = model;
  }

  eventClick(model: any) {
      model = {
          event: {
              id: model.event.id,
              start: model.event.start,
              end: model.event.end,
              title: model.event.title,
              allDay: model.event.allDay
              // other params
          },
          duration: {}
      }
      this.displayEvent = model;
  }

  updateEvent(model: any) {
      model = {
          event: {
              id: model.event.id,
              start: model.event.start,
              end: model.event.end,
              title: model.event.title
              // other params
          },
          duration: {
              _data: model.duration._data
          }
      }
      this.displayEvent = model;
  }

  widenmap() {
      this.soursename = false
      if (this.showWCdiv == true) {
          this.showWCdiv = false;
          this.GetCarts();
      }
      else {
          this.showWCdiv = true;
          this.GetCarts();
      }
  }

  increaseZoom() {
      if (currentZoom <= maxZoom) {
          currentZoom = currentZoom + 1;
          this.map.setZoom(currentZoom);
      }
      else if (currentZoom > maxZoom) {
          currentZoom = currentZoom;
          this.map.setZoom(currentZoom);
      }
  }

  decreaseZoom() {
      if (currentZoom >= minZoom) {
          currentZoom = currentZoom - 1;
          this.map.setZoom(currentZoom);
      }
      else if (currentZoom < minZoom) {
          currentZoom = currentZoom;
          this.map.setZoom(currentZoom);
      }
  }

  openModal(template: TemplateRef<any>) {
      this.currentdayDate = ''; this.wind = ''; this.pop = '';
      this.currentDaySunrise = ''; this.currentDaySunset = '';
      var utctodaydate; var utcstartdate; var utcenddate;
      this.modalRef = this.modalService.show(template, { class: 'modal-weather' });
      this.spinnerService.show();
      let parameters = {
          searchvalue: " where GCB_STATUS='Y' and GCB_ID='" + this.golfclubid + "' "
      };
      this.api.postOH('getgolfclubaddressddl', parameters).subscribe(
          (response) => {
              this.viewWeekForecast();
              var clublat = response[0].latitude;
              var clublong = response[0].longitude;
              var timezoneoffset = response[0].timezoneoffset;
              var date = new Date();
              let utc = date.getTime() + (date.getTimezoneOffset() * 60000);
              var currentDate = new Date(utc + (3600000 * timezoneoffset));
              this.currentdayDate = days[currentDate.getDay()] + ", " +
                  (currentDate.getDate() < 10 ? "0" + currentDate.getDate() : currentDate.getDate()) +
                  " " + m_names[currentDate.getMonth()] + ", " + currentDate.getFullYear();

              let sunriseutc = this.sunrise.getTime() + (this.sunrise.getTimezoneOffset() * 60000);
              this.currentDaySunrise = new Date(sunriseutc + (3600000 * timezoneoffset));
              let sunsetutc = this.sunset.getTime() + (this.sunset.getTimezoneOffset() * 60000);
              this.currentDaySunset = new Date(sunsetutc + (3600000 * timezoneoffset));
              var hours; var minutesSunset; var minutesSunrise;
              if (this.currentDaySunset.getHours() > 12) {
                  hours = this.currentDaySunset.getHours() - 12;
              }
              if (this.currentDaySunset.getMinutes() < 10) {
                  minutesSunset = "0" + this.currentDaySunset.getMinutes();
              }
              else {
                  minutesSunset = this.currentDaySunset.getMinutes();
              }
              if (this.currentDaySunrise.getMinutes() < 10) {
                  minutesSunrise = "0" + this.currentDaySunrise.getMinutes();
              }
              else {
                  minutesSunrise = this.currentDaySunrise.getMinutes();
              }
              this.currentDaySunrise = this.currentDaySunrise.getHours() + ":" + minutesSunrise + " AM";
              this.currentDaySunset = hours + ":" + minutesSunset + " PM";

              this.api.getWeather(clublat, clublong, '').subscribe((res) => {
                  var radarStation = res.properties.radarStation;
                  this.api.getWeatherStation(radarStation, '/observations/current').subscribe(
                      (result) => {
                          var windspeedvalue = result.properties.windSpeed.value;
                          var windspeedunit = result.properties.windSpeed.unitCode;
                          if (windspeedunit.includes('unit:')) {
                              windspeedunit = windspeedunit.split('unit:');
                          }
                          if (windspeedunit[1] == "m_s-1") {
                              this.wind = windspeedvalue * 2.23694;
                              this.wind = (this.wind).toFixed(2);
                          }
                          var precipationvalue = result.properties.precipitationLastHour.value;
                          var precipitationunit = result.properties.precipitationLastHour.unitCode;
                          if (precipitationunit.includes('unit:')) {
                              precipitationunit = precipitationunit.split('unit:');
                          }
                          if (precipationvalue == null) {
                              this.pop = 0;
                          }
                          else {
                              this.pop = precipationvalue + " m";
                          }
                      },
                      (error) => {
                          var errortxt1 = (error._body);
                          this.saveWeatherErrorLog(clublat, clublong, errortxt1);
                          let parameters = {
                              searchvalue: " where GCB_STATUS='Y' and GCB_ID='" + this.golfclubid + "' "
                          };
                          this.api.postOH('getgolfclubaddressddl', parameters).subscribe(
                              (response1) => {
                                  if (response1.length > 0) {
                                      var clublat = response1[0].latitude;
                                      var clublong = response1[0].longitude;
                                      var date = new Date();
                                      let utc = date.getTime() + (date.getTimezoneOffset() * 60000);
                                      let currentHour = new Date(utc);
                                      var now = currentHour.getDate() + "-" + (currentHour.getMonth() + 1) + "-" + currentHour.getFullYear();
                                      var nowTime = currentHour.getHours() + ":" + currentHour.getMinutes();
                                      this.api.getWeather(clublat, clublong, 'forecast').subscribe(
                                          (response2) => {
                                              var num;
                                              for (var i = 0; i < response2.properties.periods.length; i++) {
                                                  var start = this.utctime(response2.properties.periods[i].startTime);
                                                  var startdate = start.getDate() + "-" + (start.getMonth() + 1) + "-" + start.getFullYear();
                                                  var startTime = start.getHours() + ":00";

                                                  var end = this.utctime(response2.properties.periods[i].endTime);
                                                  var enddate = end.getDate() + "-" + (end.getMonth() + 1) + "-" + end.getFullYear();
                                                  var endTime = end.getHours() + ":00";

                                                  if (startdate == now && enddate == now) {
                                                      if ((startTime < nowTime) && ((currentHour.getMinutes() - start.getMinutes()) < 60)) {
                                                          num = response2.properties.periods[i].number;
                                                      }
                                                  }
                                              }
                                              for (var j = 0; j < response2.properties.periods.length; j++) {
                                                  if (j == (num - 1)) {
                                                      if (response2.properties.periods[j].name == "Tonight" || response2.properties.periods[j].name == "Overnight") {
                                                          this.wind = response2.properties.periods[j].windSpeed;
                                                          var windVal = (this.wind).split(' ');
                                                          if (windVal.length > 2) {
                                                              this.wind = windVal[0] + "-" + windVal[windVal.length - 2];
                                                          }
                                                          else if (windVal.length == 2) {
                                                              this.wind = windVal[0];
                                                          }
                                                          this.pop = response2.properties.periods[j].detailedForecast;
                                                          var arr = [];
                                                          arr = (this.pop).split('.');
                                                          var vals = '';
                                                          for (var x = 0; x < arr.length; x++) {
                                                              if (arr[x].includes('precipitation')) {
                                                                  var str;
                                                                  str = arr[x].split(' ');
                                                                  vals = str[str.length - 1];
                                                                  this.pop = vals;
                                                                  break;
                                                              }
                                                              else {
                                                                  this.pop = "0";
                                                              }
                                                          }
                                                      }
                                                      else {
                                                          this.wind = response2.properties.periods[j].windSpeed;
                                                          var windVal = (this.wind).split(' ');
                                                          if (windVal.length > 2) {
                                                              this.wind = windVal[0] + "-" + windVal[windVal.length - 2];
                                                          }
                                                          else if (windVal.length == 2) {
                                                              this.wind = windVal[0];
                                                          }
                                                          this.pop = response2.properties.periods[j].detailedForecast;
                                                          var arr = [];
                                                          arr = (this.pop).split('.');
                                                          var vals = '';
                                                          for (var x = 0; x < arr.length; x++) {
                                                              if (arr[x].includes('precipitation')) {
                                                                  var str;
                                                                  str = arr[x].split(' ');
                                                                  vals = str[str.length - 1];
                                                                  this.pop = vals;
                                                                  break;
                                                              }
                                                              else {
                                                                  this.pop = "0";
                                                              }
                                                          }
                                                      }

                                                  }
                                              }
                                          }
                                      );
                                  }
                              }
                          );
                      }
                  )
                  this.spinnerService.hide();
              },
                  (error) => {
                      this.spinnerService.hide();
                  })
          });

  }

  decline(): void {
      this.weekforecastTemp = [];
      this.weekDays = [];
      this.modalRef.hide();
  }

  saveWeatherErrorLog(lat, long, error) {
      var clubcoordinates = lat + "," + long;
      var date = new Date(); var dateString;
      dateString = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate() + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();

      var errorlogObj = {
          'action': 'A',
          'wel_clubid': this.golfclubid,
          'wel_club_coordinates': clubcoordinates.toString(),
          'wel_error': JSON.stringify(error),
          'date': dateString
      };

      this.api.postOH("saveWeatherErrorLog", errorlogObj).subscribe(
          (response) => {
              if (response[0] != 0) {
                  //call for errorlog grid
              }
          }
      )
  }

  utctime(dateVal) {
      var str = dateVal;
      // var m = str.lastIndexOf("-");
      // var d = new Date(str.substring(0, m));
      var d = new Date(str);
      var utcts = d.getTime() + (d.getTimezoneOffset() * 60000);
      return new Date(utcts);
  }

  getWeatherHourlyForecast() {
      this.spinnerService.show();
      let params = { clubid: this.golfclubid };
      this.next6hrforecast = [];
      this.api.postOH('GetHourlyForecast', params).subscribe(
          (data) => {
              if (data.length > 0) {
                  this.next6hrforecast = [];
                  this.forecastWeatherHourlyData = data;
                  var getRunninghour = new Date();
                  let getRunninghourutc = getRunninghour.getTime() + (getRunninghour.getTimezoneOffset() * 60000);
                  let getRunninghourutcdate = new Date(getRunninghourutc);
                  var nextHour = this.forecastWeatherHourlyData[0].wh_nexthourstarttime;
                  var nextHourutcdate = this.utctime(nextHour);
                  if (nextHourutcdate < getRunninghourutcdate) {
                      this.spinnerService.show();
                      this.viewForecast();
                      this.spinnerService.hide();
                  }
                  else {
                      for (var p = 0; p < this.forecastWeatherHourlyData.length; p++) {
                          this.next6hrforecast.push({
                              'time': this.forecastWeatherHourlyData[p].wh_hour,
                              'temp': this.forecastWeatherHourlyData[p].wh_temp,
                              'icon': this.forecastWeatherHourlyData[p].wh_icon,
                              'description': this.forecastWeatherHourlyData[p].wh_description,
                              'nexthour': this.forecastWeatherHourlyData[p].wh_nexthourstarttime
                          })
                      }
                  }

              }
              else if (data.length == 0) {
                  this.viewForecast();
              }
              this.spinnerService.hide();
          },
          (error) => {
              this.spinnerService.hide();
          }
      )
  }

  toastMessage(msg) {
      let options = {
          positionClass: 'toast-top-center',
      };

      this.toastr.custom(msg, null, {
          enableHTML: true, toastLife: 3000,
          showCloseButton: true, 'positionClass': 'toast-bottom-right'
      });
  }
}