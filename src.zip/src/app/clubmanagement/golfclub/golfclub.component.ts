import { Component, OnInit, ViewContainerRef, TemplateRef, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
//import { ModalService } from 'ng-bootstrap-modal';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Title, DomSanitizer } from '@angular/platform-browser';

@Component({
    selector: 'app-golfclub',
    templateUrl: './golfclub.component.html',
    styleUrls: ['./golfclub.component.css']
})
export class GolfclubComponent implements OnInit {
    modalRef: BsModalRef;
    public base64textString: String = "";
    public clubsForm: FormGroup; submitAttempt: boolean = false; divheader: string = "Add Club";
    searchtxt: boolean = true; searchddl: boolean = false;
    golfclubsdata: any; golfcoursesdetailsdata: any;
    contentShow: string = "none"; gridShow: string = "none";
    viewcontentShow: string = "none"; coursegridShow: string = "none";
    txtShow: string = "none"; lblShow: string = "none";
    action: string = 'A'; gcid: string = "0"; statesdata: any;
    searchvalues: any = []; searchstatus: any = [];
    clubname: string; clubcode: string; clubstate: string = "0"; clubsts: string;
    email: string = ''; website: string = ''; rotate: string; address: string; city: string; cntry: string = "0"; state: string; country: any;
    zipcode: string; contact: string; zoomlevel: string; lat: string; long: string; tzone: string = "0"; desc: string;
    emergencycontact: string; clubstatus: any = '';

    status: boolean = false; chksts: string = 'Y';
    clubtxtsts: string = 'Active'; txtsrch: string = '';
    GridMessage: string = 'Loading... !';
    editClubInfo: any = [];
    TimeZonesDate: any = [];
    USstates: any; CAstates: any;
    path = '';
    public file_srcs: string[] = [];
    public debug_size_before: string[] = [];
    public debug_size_after: string[] = [];
    logoimagepath: any; overlineimagepath: any;
    logoimagename: any = ""; overlineimagename: any;
    srchError: string = '0'; addbtnshow: any; deletebtnshow: any;

    imagecropped1: string = ''; imagecropped2: string = '';
    key: string = 'name';
    reverse: boolean = false;
    ddlsearch: any; selectedoption: any = "Active"; randomcolor: any = "#5cb85c";
    nameasc: any = "sortgreen"; namedesc: any = "sortwhite"; codeasc: any = "sortwhite"; codedesc: any = "sortwhite"; cityasc: any = "sortwhite"; citydesc: any = "sortwhite";

    showAvalability: boolean = false; showTick: boolean = false; clubinformation: any = [];
    shownameAvalability: boolean = false; shownameTick: boolean = false; clubnameinformation: any = [];

    bckimagepath: any; bckimagename: any = ""; bckimagecropped: string = '';
    updateemergencycontactfromcontactmessage: any = false;

    bckimageValidation: any = "";
    @ViewChild('input1') bckimageinput : ElementRef;
    @ViewChild('input') txtlogoinput : ElementRef;


    constructor(private sanitizer: DomSanitizer, private title: Title, private modalService: BsModalService, public toastr: ToastsManager, vcr: ViewContainerRef, private _router: Router, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService, private authService: AuthService, private router: Router,
    ) {
        window.scrollTo(0, 0);
        this.title.setTitle("IZON - Golf Clubs");
        this.ddlsearch = "GCB_NAME";
        this.toastr.setRootViewContainerRef(vcr);
        this.USstates = []; this.CAstates = [];
        this.contentShow = "none"; this.gridShow = "none";
        this.golfclubsdata = []; this.statesdata = []; this.golfcoursesdetailsdata = []; this.TimeZonesDate = [];
    }

    ngOnInit() {
        this.getStates('US'); this.getStates('CA');
        this.clubsForm = this.formBuilder.group({
            fclubname: ['', Validators.compose([Validators.required]),],
            fclubcode: ['', Validators.compose([Validators.required]),],
            fstate: ['0', Validators.compose([Validators.required])],
            femail: ['', Validators.compose([Validators.required])],
            fwebsite: ['', Validators.compose([Validators.required])],

            frotate: ['', Validators.compose([Validators.required])],
            faddress: ['', Validators.compose([Validators.required])],
            fcity: ['', Validators.compose([Validators.required])],
            fcntry: ['0', Validators.compose([Validators.required])],
            fzipcode: ['', Validators.compose([Validators.required])],

            fcontact: ['', Validators.compose([Validators.required])],

            fzoomlevel: ['', Validators.compose([Validators.required])],
            flat: ['', Validators.compose([Validators.required])],
            flong: ['', Validators.compose([Validators.required])],
            ftimezone: ['0', Validators.compose([Validators.required])],
            fdesc: ['', Validators.compose([Validators.required])],
            fecontact: [''],
            //ftxtlogo: ['' && this.submitAttempt == true, Validators.compose([Validators.required])],
            fbckimage: [''],
            status: ['']
        })//, { validator: formvalidators.MatchURL }

        let parameters = {
            searchvalue: " where TZ_STATUS='Y'"
        };
        this.gettimezones(parameters);

        if (localStorage.getItem('roleCode') == "SA") {
            this.addbtnshow = "block";
            let parameters = {
                searchvalue: " where GCB_STATUS='Y'"
            };
            this.GetGolfClubsData(parameters);
        } else {
            this.addbtnshow = "none";
            let parameters = {
                uid: localStorage.getItem('userId'), rcode: localStorage.getItem('roleCode'), expression: " where GCCA_GCCL_ID='" + localStorage.getItem('userId') + "' AND GCB_STATUS='Y' AND GCCA_STATUS='Y'"
            };
            this.getclubsdataforgrid(parameters);
        }
        //localStorage.removeItem('courseId');

        if (localStorage.getItem('emergencyContactClubId') != null) {
            this.gcid = localStorage.getItem('emergencyContactClubId');
            localStorage.removeItem('emergencyContactClubId');
            this.updateemergencycontactfromcontactmessage = true;
            this.editgolfclubs();
        }
        else {
            this.updateemergencycontactfromcontactmessage = false;
            this.gridShow = "block";
            this.contentShow = "none";
        }
        this.txtlogoinput.nativeElement.value = "";
        this.bckimageinput.nativeElement.value = "";

    }
    gettimezones(parameters) {
        this.api.postOH('GetTimeZones', parameters).subscribe(
            (response) => {
                //console.log(response);
                this.TimeZonesDate = [];
                for (let i = 0; i < response.length; i++) {
                    this.TimeZonesDate.push({
                        "id": response[i].id,
                        "shortname": response[i].shortname,
                        "fullname": response[i].fullname,
                        "timeoffset": response[i].timeoffset,
                        "location": response[i].location,
                        "status": status
                    });
                }
            }, error => {
            }
        );
    }
    sort(value: string) {
        this.key = value;
        this.nameasc = "sortwhite"; this.namedesc = "sortwhite"; this.codeasc = "sortwhite"; this.codedesc = "sortwhite"; this.cityasc = "sortwhite"; this.citydesc = "sortwhite";
        if (this.key == value) {
            this.reverse = !this.reverse;
            if (this.key == "name" && this.reverse) {
                this.namedesc = "sortgreen";
            }
            else if (this.key == "name" && (!this.reverse)) {
                this.nameasc = "sortgreen";
            }
            else if (this.key == "clubcode" && this.reverse) {
                this.codedesc = "sortgreen";
            }
            else if (this.key == "clubcode" && (!this.reverse)) {
                this.codeasc = "sortgreen";
            }
            else if (this.key == "city" && this.reverse) {
                this.citydesc = "sortgreen";
            }
            else if (this.key == "city" && (!this.reverse)) {
                this.cityasc = "sortgreen";
            }
        }

    }
    refreshpage() {
        this.ddlsearch = "GCB_NAME"; this.txtsrch = ''; this.srchError = '0';
        this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
        if (localStorage.getItem('roleCode') == "SA") {
            let parameters = {
                searchvalue: " where GCB_STATUS='Y'"
            };
            this.GetGolfClubsData(parameters);
        } else {
            let parameters = {
                uid: localStorage.getItem('userId'), rcode: localStorage.getItem('roleCode'), expression: " where GCCA_GCCL_ID='" + localStorage.getItem('userId') + "' AND GCB_STATUS='Y' AND GCCA_STATUS='Y'"
            };
            this.getclubsdataforgrid(parameters);
        }
    }

    search() {
        var status = '';
        status = this.selectedoption == 'Active' ? 'Y' : 'N';
        if (this.txtsrch == '') {
            this.srchError = '1';
        }
        else if (this.txtsrch != '') {
            this.srchError = '0';
            if (localStorage.getItem('roleCode') == "SA") {
                let parameters = {
                    searchvalue: " WHERE " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND GCB_STATUS='" + status + "'"
                };
                this.GetGolfClubsData(parameters);
            } else {
                var expr = " WHERE GCCA_GCCL_ID='" + localStorage.getItem('userId') + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND GCCA_STATUS<>'Y'"
                let parameters = {
                    uid: localStorage.getItem('userId'), rcode: localStorage.getItem('roleCode'), expression: expr
                };
                this.getclubsdataforgrid(parameters);
            }
            this.txtsrch = "";
        }
    }
    bindselectedoption(selectedoption) {
        this.srchError = '0';
        if (this.selectedoption == 'Active') {
            this.randomcolor = "#5cb85c";
            this.srchSts('Y');
        }
        else if (this.selectedoption == 'In-Active') {
            this.randomcolor = "#337ab7";
            this.srchSts('N');
        }
        else if (this.selectedoption == 'Deleted') {
            this.randomcolor = "#d9534f";
            this.srchSts('D');
        }
    }
    srchSts(type) {
        this.ddlsearch = "GCB_NAME";
        this.txtsrch = '';
        if (localStorage.getItem('roleCode') == "SA") {
            let parameters = {
                searchvalue: " WHERE  GCB_STATUS= '" + type + "' "
            };
            this.GetGolfClubsData(parameters);
        } else {
            var expr = " WHERE GCCA_GCCL_ID='" + localStorage.getItem('userId') + "' AND GCB_STATUS= '" + type + "' AND GCCA_STATUS='Y' "
            let parameters = {
                uid: localStorage.getItem('userId'), rcode: localStorage.getItem('roleCode'), expression: expr
            };
            this.getclubsdataforgrid(parameters);
        }
    }

    srchKeyUp(event: any) {
        if (this.txtsrch != '') {
            this.srchError = '0';
        }
    }

    getclubsdataforgrid(parameters) {
        this.spinnerService.show();
        this.api.postOH('getclubassigneddetails', parameters).subscribe(
            (response) => {
                //console.log(response);
                this.golfclubsdata = [];
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var locimgpath = '';
                    if (response[i].logoimagepath != '') {
                        locimgpath = response[i].logoimagepath + "?w=45";
                    }
                    this.golfclubsdata.push({
                        "id": response[i].clubid,
                        "name": response[i].clubname,
                        "clubcode": response[i].clubcode,
                        "city": response[i].city,
                        "logoimagepath": locimgpath,
                        "status": status,
                        "statusclass": statusclass
                    });
                }
                {
                    this.GridMessage = "No Data Found";
                }
                this.spinnerService.hide();
            }, error => {
                this.spinnerService.hide();
            }
        );
    }
    viewdashboard(golfclubs) {
        localStorage.setItem('clubId', golfclubs.id);
        localStorage.setItem('clubname', golfclubs.name);
        this.authService.getCall();
        this.authService.getClubIdforheader();
        let parameters = {
            searchvalue: " WHERE GC_GCB_ID='" + golfclubs.id + "' AND GC_STATUS='Y'"
        };
        this.api.postOH('getgolfcourse', parameters).subscribe(
            (response) => {
                localStorage.setItem('coursecount', response.length);
                this.router.navigate(['/cartmanagement/dashboard']);
            })

    }

    GetGolfClubsData(parameters) {
        this.spinnerService.show();
        this.api.postOH('getgolfclubaddress', parameters).subscribe(
            (response) => {
                this.golfclubsdata = [];
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                    var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var confirmshow = "row-icon-inactive";

                    var locimgpath = '';
                    if (response[i].logoimagepath != '') {
                        locimgpath = response[i].logoimagepath + "?w=45";
                    }
                    this.golfclubsdata.push({
                        "id": response[i].id,
                        "name": response[i].name,
                        "clubcode": response[i].clubcode,
                        "email": response[i].email,
                        "website": response[i].website,
                        "rotate": response[i].rotate,
                        "address": response[i].address,
                        "city": response[i].city,
                        "state": response[i].state,
                        "country": response[i].country,
                        "zipcode": response[i].zipcode,
                        "contact": response[i].contact,
                        "emergencycontact": response[i].emergencycontact,
                        "latitude": response[i].latitude,
                        "longitude": response[i].longitude,
                        "zoomlevel": response[i].zoomlevel,
                        "timezone": response[i].timezone,
                        "measurement": response[i].measurement,
                        "description": response[i].description,
                        "logoimage": response[i].logoimage,
                        "logoimagepath": locimgpath,
                        "logobinaryimage": response[i].logobinaryimage,
                        "overlineimage": response[i].overlineimage,
                        "overlineimagepath": response[i].overlineimagepath,
                        "overlinebinaryimage": response[i].overlinebinaryimage,
                        "bckimage": response[i].bckimage,
                        "bckimagepath": response[i].bckimagepath,
                        "bckbinaryimage": response[i].bckbinaryimage,
                        "createdby": response[i].updatedby,
                        "createddate": response[i].createddate,
                        "updateddate": response[i].updateddate,
                        "status": status,
                        "statusclass": statusclass,
                        "editshow": editshow,
                        "enableshow": enableshow,
                        "removeshow": removeshow,
                        "confirmshow": confirmshow
                    });
                }
                {
                    this.GridMessage = "No Data Found";
                }
                this.spinnerService.hide();
            }, error => {
                this.spinnerService.hide();
            }
        );
    }

    //get golf Course table
    getgolfcoursesdetailstable() {
        this.golfcoursesdetailsdata = [];
        this.spinnerService.show();
        let parameters = {
            searchvalue: " WHERE GC_STATUS='Y' AND GC_GCB_ID='" + this.gcid + "'"
        };
        this.api.postOH('getgolfcourse', parameters).subscribe(
            (response) => {
                if (response.length > 0) {
                    this.golfcoursesdetailsdata = [];
                    for (let i = 0; i < response.length; i++) {
                        var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                        var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                        var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                        var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                        var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                        var confirmshow = "row-icon-inactive";

                        this.golfcoursesdetailsdata.push({
                            "id": response[i].id,
                            "golfclubid": response[i].golfclubid,
                            "golfclubname": response[i].golfclubname,
                            "labelname": response[i].labelname,
                            "createdby": response[i].updatedby,
                            "createddate": response[i].createddate,
                            "updateddate": response[i].updateddate,
                            "rotate": response[i].rotate,
                            "zoomlevel": response[i].zoomlevel,
                            "latitude": response[i].latitude,
                            "longitude": response[i].longitude,
                            "measurement": response[i].measurement,
                            "overlineimage": response[i].overlineimage,
                            "overlineimagepath": response[i].overlineimagepath,
                            "overlinebinaryimage": response[i].overlinebinaryimage,
                            "status": status,
                            "statusclass": statusclass,
                            "editshow": editshow,
                            "enableshow": enableshow,
                            "removeshow": removeshow,
                            "confirmshow": confirmshow
                        });
                    }
                    this.spinnerService.hide();
                }
                else {
                    this.golfcoursesdetailsdata = [];
                    this.spinnerService.hide();
                }
            }, function (response) {
                this.spinnerService.hide();
            });
    }

    viewclub(clubId) {
        window.scrollTo(0, 0);
        if (localStorage.getItem('roleCode') == "SA") {
            this.deletebtnshow = "block";
        } else {
            this.deletebtnshow = "none";
        }
        this.action = 'V';
        this.viewcontentShow = "block"; this.contentShow = "none";
        this.gridShow = "none"; this.coursegridShow = "block";

        let parameters = {
            searchvalue: ' WHERE GCB_ID=' + clubId + ''
        };
        this.gcid = clubId;
        // this.spinnerService.show();
        let golfclubdata: any = [];
        this.api.postOH('getgolfclubaddress', parameters).subscribe(
            (response) => {
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                    var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var confirmshow = "row-icon-inactive";

                    if (status == "Active") {
                        localStorage.setItem('clubId', response[i].id);
                        localStorage.setItem('clubname', response[i].name);
                        localStorage.setItem('clubcode', response[i].clubcode);
                        this.authService.getCall();
                        localStorage.removeItem('courseId');
                        this.authService.getClubIdforheader();
                    }

                    golfclubdata.push({
                        "id": response[i].id,
                        "name": response[i].name,
                        "clubcode": response[i].clubcode,
                        "email": response[i].email,
                        "website": response[i].website,
                        "rotate": response[i].rotate,
                        "address": response[i].address,
                        "city": response[i].city,
                        "state": response[i].state,
                        "country": response[i].country,
                        "zipcode": response[i].zipcode,
                        "contact": response[i].contact,
                        "emergencycontact": response[i].emergencycontact,
                        "latitude": response[i].latitude,
                        "longitude": response[i].longitude,
                        "zoomlevel": response[i].zoomlevel,
                        "timezone": response[i].timezone,
                        "measurement": response[i].measurement,
                        "description": response[i].description,
                        "logoimage": response[i].logoimage,
                        "logoimagepath": response[i].logoimagepath,
                        "logobinaryimage": response[i].logobinaryimage,
                        "overlineimage": response[i].overlineimage,
                        "overlineimagepath": response[i].overlineimagepath,
                        "overlinebinaryimage": response[i].overlinebinaryimage,
                        "bckimage": response[i].bckimage,
                        "bckimagepath": response[i].bckimagepath,
                        "bckbinaryimage": response[i].bckbinaryimage,
                        "createdby": response[i].updatedby,
                        "createddate": response[i].createddate,
                        "updateddate": response[i].updateddate,
                        "status": status,
                        "statusclass": statusclass,
                        "editshow": editshow,
                        "enableshow": enableshow,
                        "removeshow": removeshow,
                        "confirmshow": confirmshow
                    });
                }

                this.clubname = (!golfclubdata[0].name) ? "" : golfclubdata[0].name;
                this.clubcode = (!golfclubdata[0].clubcode) ? "" : golfclubdata[0].clubcode;
                this.email = (!golfclubdata[0].email) ? "" : golfclubdata[0].email;
                this.website = (!golfclubdata[0].website) ? "" : golfclubdata[0].website;
                this.rotate = (!golfclubdata[0].rotate) ? "" : golfclubdata[0].rotate;
                this.address = (!golfclubdata[0].address) ? "" : golfclubdata[0].address;
                this.city = (!golfclubdata[0].city) ? "" : golfclubdata[0].city;
                this.clubsts = status;
                this.clubtxtsts = status;
                this.zipcode = (!golfclubdata[0].zipcode) ? "" : golfclubdata[0].zipcode;
                this.contact = (!golfclubdata[0].contact) ? "" : golfclubdata[0].contact;
                this.emergencycontact = (!golfclubdata[0].emergencycontact) ? "" : golfclubdata[0].emergencycontact;
                this.lat = (!golfclubdata[0].latitude) ? "" : golfclubdata[0].latitude;
                this.long = (!golfclubdata[0].longitude) ? "" : golfclubdata[0].longitude;
                this.zoomlevel = (!golfclubdata[0].zoomlevel) ? "" : golfclubdata[0].zoomlevel;
                this.desc = (!golfclubdata[0].description) ? "" : golfclubdata[0].description;
                this.logoimagename = (!golfclubdata[0].logoimage) ? "" : golfclubdata[0].logoimage;
                this.logoimagepath = (!golfclubdata[0].logoimagepath) ? "" : golfclubdata[0].logoimagepath;
                this.bckimagename = (!golfclubdata[0].bckimage) ? "" : golfclubdata[0].bckimage;
                this.bckimagepath = (!golfclubdata[0].bckimagepath) ? "" : golfclubdata[0].bckimagepath;
                this.state = (!golfclubdata[0].state) ? "" : golfclubdata[0].state;
                this.country = (!golfclubdata[0].country) ? "" : golfclubdata[0].country;
            }, error => {
                // this.spinnerService.hide();
            }
        );
        this.getgolfcoursesdetailstable();
    }

    addgolfclubs() {
        //this.clubsForm.reset();
        window.scrollTo(0, 0);
        this.submitAttempt = false;
        this.bckimagename = ""; this.bckimagecropped = ""; this.bckimagepath = "";
        this.logoimagepath = "";
        this.overlineimagepath = "";
        this.divheader = "Add Club";
        this.action = 'A';
        this.gcid = "0"; this.clubcode = ""; this.logoimagename = "";
        this.overlineimagename = "";
        this.gridShow = "none"; this.viewcontentShow = "none";
        this.contentShow = "block"; this.coursegridShow = "none";
        this.txtShow = "block"; this.lblShow = "none";
        this.clubname = "";
        this.email = "";
        this.website = "";
        this.rotate = "";
        this.address = "";
        this.city = "";
        this.cntry = "0";
        this.clubstate = "0";
        this.tzone = "0";
        this.zipcode = "";
        this.contact = ""; this.emergencycontact = "";
        this.lat = "";
        this.long = "";
        this.zoomlevel = "";
        this.desc = "";
        this.statesdata = this.USstates;
        this.logoimagepath = "";
        this.overlineimagepath = "";
        this.showAvalability = false;
        this.shownameAvalability = false;
    }

    //edit record
    editgolfclubs() {
        this.imagecropped1 = "";
        this.imagecropped2 = "";
        this.logoimagepath = "";
        this.overlineimagepath = "";
        this.logoimagename = "";
        this.bckimagename = ""; this.bckimagecropped = ""; this.bckimagepath = "";
        this.overlineimagename = "";
        this.divheader = "Edit Club";
        this.action = 'U';
        this.gridShow = "none";
        this.contentShow = "block"; this.viewcontentShow = "none"; this.coursegridShow = "none";
        this.txtShow = "block"; this.lblShow = "none";
        let parameters = {
            searchvalue: ' WHERE GCB_ID=' + this.gcid + ''
        };
        // this.spinnerService.show();
        let golfclubdata = [];
        this.api.postOH('getgolfclubaddress', parameters).subscribe(
            (response) => {
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                    var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var confirmshow = "row-icon-inactive";

                    golfclubdata.push({
                        "id": response[i].id,
                        "name": response[i].name,
                        "clubcode": response[i].clubcode,
                        "email": response[i].email,
                        "website": response[i].website,
                        "rotate": response[i].rotate,
                        "address": response[i].address,
                        "city": response[i].city,
                        "state": response[i].state,
                        "country": response[i].country,
                        "zipcode": response[i].zipcode,
                        "contact": response[i].contact,
                        "emergencycontact": response[i].emergencycontact,
                        "latitude": response[i].latitude,
                        "longitude": response[i].longitude,
                        "zoomlevel": response[i].zoomlevel,
                        "timezone": response[i].timezone,
                        "measurement": response[i].measurement,
                        "description": response[i].description,
                        "logoimage": response[i].logoimage,
                        "logoimagepath": response[i].logoimagepath,
                        "logobinaryimage": response[i].logobinaryimage,
                        "overlineimage": response[i].overlineimage,
                        "overlineimagepath": response[i].overlineimagepath,
                        "overlinebinaryimage": response[i].overlinebinaryimage,
                        "bckimage": response[i].bckimage,
                        "bckimagepath": response[i].bckimagepath,
                        "bckbinaryimage": response[i].bckbinaryimage,
                        "createdby": response[i].updatedby,
                        "createddate": response[i].createddate,
                        "updateddate": response[i].updateddate,
                        "status": status,
                        "statusclass": statusclass,
                        "editshow": editshow,
                        "enableshow": enableshow,
                        "removeshow": removeshow,
                        "confirmshow": confirmshow
                    });
                }
                this.clubstatus = response[0].status;
                this.clubname = (!golfclubdata[0].name) ? "" : golfclubdata[0].name;
                this.clubcode = (!golfclubdata[0].clubcode) ? "" : golfclubdata[0].clubcode;
                this.email = (!golfclubdata[0].email) ? "" : golfclubdata[0].email;
                this.website = (!golfclubdata[0].website) ? "" : golfclubdata[0].website;
                this.rotate = (!golfclubdata[0].rotate) ? "" : golfclubdata[0].rotate;
                this.address = (!golfclubdata[0].address) ? "" : golfclubdata[0].address;
                this.city = (!golfclubdata[0].city) ? "" : golfclubdata[0].city;
                this.cntry = (!golfclubdata[0].country) ? "0" : golfclubdata[0].country.toString();
                this.statesdata = (this.cntry == 'US') ? this.USstates : this.CAstates;
                this.clubstate = (!golfclubdata[0].state) ? "0" : golfclubdata[0].state.toString();
                this.zipcode = (!golfclubdata[0].zipcode) ? "" : golfclubdata[0].zipcode;
                this.contact = (!golfclubdata[0].contact) ? "" : golfclubdata[0].contact;
                this.emergencycontact = (!golfclubdata[0].emergencycontact) ? "" : golfclubdata[0].emergencycontact;
                this.lat = (!golfclubdata[0].latitude) ? "" : golfclubdata[0].latitude;
                this.long = (!golfclubdata[0].longitude) ? "" : golfclubdata[0].longitude;
                this.zoomlevel = (!golfclubdata[0].zoomlevel) ? "" : golfclubdata[0].zoomlevel;
                this.desc = (!golfclubdata[0].description) ? "" : golfclubdata[0].description;
                this.logoimagename = (!golfclubdata[0].logoimage) ? "" : golfclubdata[0].logoimage;
                this.overlineimagename = (!golfclubdata[0].overlineimage) ? "" : golfclubdata[0].overlineimage;
                this.logoimagepath = (!golfclubdata[0].logoimagepath) ? "" : golfclubdata[0].logoimagepath;
                this.overlineimagepath = (!golfclubdata[0].overlineimagepath) ? "" : golfclubdata[0].overlineimagepath;
                this.bckimagename = (!golfclubdata[0].bckimage) ? "" : golfclubdata[0].bckimage;
                this.bckimagepath = (!golfclubdata[0].bckimagepath) ? "" : golfclubdata[0].bckimagepath;
                this.status = (golfclubdata[0].status == 'Active') ? true : false;
                this.tzone = (!golfclubdata[0].timezone) ? "0" : golfclubdata[0].timezone.toString();
                this.showAvalability = true; this.shownameAvalability = true; this.showTick = true; this.shownameTick = true;
                this.onclubcodeChange();
                this.onclubnameChange();

            }, error => {
                // this.spinnerService.hide();
            }
        );
    }

    changests(e) {
        this.chksts = (e == true) ? 'Y' : 'N';
        if (this.chksts == 'Y') {
            this.status = true;
        }
        else if (this.chksts == 'N') {
            this.status = false;
        }
    }

    cancel() {
        if (this.action == 'A') {
            this.clubsForm.reset();
            this.gridShow = "block";
            this.contentShow = "none";
            this.viewcontentShow = "none";
            this.coursegridShow = "none";
        }
        else {
            this.gridShow = "none";
            this.contentShow = "none";
            this.viewcontentShow = "block";
            this.coursegridShow = "block";
            this.viewclub(localStorage.getItem('clubId'));
        }
    }

    goBack() {
        this.clubsForm.reset();
        this.authService.getCall();
        this.gridShow = "block";
        this.contentShow = "none";
        this.viewcontentShow = "none";
        this.coursegridShow = "none";
        this.action = 'A';
    }

    saveData() {
        if (!this.clubsForm.valid) {

        }
        this.submitAttempt = true;
        if(this.clubsForm.controls.fcntry.value == "0") { this.clubsForm.controls['fcntry'].setErrors({'incorrect': true});}
        if(this.clubsForm.controls.fstate.value == "0") { this.clubsForm.controls['fstate'].setErrors({'incorrect': true});}
        if(this.clubsForm.controls.ftimezone.value == "0") { this.clubsForm.controls['ftimezone'].setErrors({'incorrect': true});}
        if (this.clubsForm.valid && this.showTick == true && this.shownameTick == true && this.logoimagename != "") {
            //this.spinnerService.show();
            var golfclubinfo = {
                "action": this.action, "id": this.gcid, "name": this.clubname, "clubcode": this.clubcode, "email": this.email, "website": this.website, "rotate": this.rotate,
                "address": this.address, "city": this.city, "state": this.clubstate, "country": this.cntry, "zipcode": this.zipcode, "contact": this.contact,
                "latitude": this.lat, "longitude": this.long, "zoomlevel": this.zoomlevel, "timezone": this.tzone, "emergencycontact": this.emergencycontact,
                "description": this.desc,
                "logoimage": this.logoimagename, "logobinaryimage": this.imagecropped1,
                "overlineimage": this.overlineimagename, "overlinebinaryimage": this.imagecropped2,
                "bckimage": this.bckimagename, "bckbinaryimage": this.bckimagecropped,
                "updtaedid": localStorage.getItem('userId'), "status": this.chksts
            }
            //console.log(golfclubinfo);

            this.api.postOH('savegolfclub', golfclubinfo).subscribe(
                (response) => {
                    if (response[1] != 'Golf Club Already Exist or Unable to process your request ') {
                        if (this.updateemergencycontactfromcontactmessage == false) {
                            this.gridShow = "block";
                            this.contentShow = "none"; this.coursegridShow = "none";
                            let msg = (this.action == "A") ? '<span style="color: green">Golf Club added Successfully.</span>' : '<span style="color: green">Golf Club updated Successfully.</span>';
                            this.toastMessage(msg);


                            if (this.action === "U" && this.chksts === "N") {
                                localStorage.removeItem('clubId');
                                localStorage.removeItem('clubname');
                                localStorage.removeItem('courseId');
                                this.authService.getCall();
                            }
                            if (this.clubstatus === "N" && this.action === "U" && this.chksts === "Y") {
                                this.authService.getCall();
                            }

                            if (localStorage.getItem('roleCode') == "SA") {
                                let parameters = {
                                    searchvalue: " where GCB_STATUS='Y'"
                                };
                                this.GetGolfClubsData(parameters);
                                // localStorage.removeItem('clubId');
                                // localStorage.removeItem('clubname');
                                // localStorage.removeItem('courseId');
                                // this.authService.getCall();
                            } else {
                                let parameters = {
                                    uid: localStorage.getItem('userId'), rcode: localStorage.getItem('roleCode'), expression: " where GCCA_GCCL_ID='" + localStorage.getItem('userId') + "' AND GCB_STATUS='Y' AND GCCA_STATUS='Y'"
                                };
                                this.getclubsdataforgrid(parameters);
                            }
                        }
                        else if (this.updateemergencycontactfromcontactmessage == true) {
                            this.router.navigate(["/clubmanagement/contactmessages"]);
                            localStorage.setItem('ecstatus', 'success');
                        }
                    } else {
                        if (this.updateemergencycontactfromcontactmessage == false) {
                            let msg = "<span style='color: red'>" + response[1] + "</span>";
                            this.toastMessage(msg);
                        }
                        else if (this.updateemergencycontactfromcontactmessage == true) {
                            this.router.navigate(["/clubmanagement/contactmessages"]);
                            localStorage.setItem('ecstatus', 'failure');
                        }
                    }
                    window.scrollTo(0, 0);
                    this.spinnerService.hide();
                    this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
                }, error => {
                    this.spinnerService.hide();
                });
        }
    }

    getStates(val) {
        let parameters = {
            searchvalue: " WHERE  S_ACTIVE = 'Y' and S_COUNTRY_ID='" + val + "'"
        };
        // let config = { params: parameters };
        this.api.postOH('getstates', parameters).subscribe(
            (response) => {
                for (let i = 0; i < response.length; i++) {
                    if (val == 'US') {
                        this.USstates.push({
                            value: response[i].statecode,
                            name: response[i].description
                        });
                    }
                    else {
                        this.CAstates.push({
                            value: response[i].statecode,
                            name: response[i].description
                        });
                    }
                }
            });
    }

    getselectedstates(val) {
        let parameters = {
            searchvalue: " WHERE  S_ACTIVE = 'Y' and S_COUNTRY_ID='" + val.value + "'"
        };
        // let config = { params: parameters };
        this.api.postOH('getstates', parameters).subscribe(
            (response) => {
                this.statesdata = [];
                for (let i = 0; i < response.length; i++) {
                    this.statesdata.push({
                        value: response[i].statecode,
                        name: response[i].description
                    });
                }
                //e.statesdata = statesdata;
            });
    }

    viewcourse(golfcoursesdetails) {
        localStorage.setItem('courseId', golfcoursesdetails.id);
        this._router.navigate(['/clubmanagement/golfcourse']);
    }

    addcourse() {
        localStorage.setItem('courseId', '0');
        this._router.navigate(['/clubmanagement/golfcourse']);
    }

    onclubcodeChange() {
        this.showAvalability = true;
        var parameters = {};
        //this.clubcode = event.target.value;
        if (this.action == 'A') {
            parameters = {
                searchvalue: " where GCB_CLUB_CODE='" + this.clubcode + "' and GCB_STATUS<>'D'"
            };
        }
        else if (this.action == 'U') {
            parameters = {
                searchvalue: " where GCB_CLUB_CODE='" + this.clubcode + "' and GCB_STATUS<>'D' AND GCB_ID != " + this.gcid + ""
            };
        }
        this.api.postOH('getgolfclubaddress', parameters).subscribe(
            (response) => {
                if (response.length == 0) {
                    this.clubinformation.length = response.length;
                    this.showTick = true;
                }
                else if (response.length > 0) {
                    this.clubinformation.length = response.length;
                    this.showTick = false;
                }
            })
    }
    onclubnameChange() {
        this.shownameAvalability = true;
        var parameters = {};
        //this.clubname = event.target.value;
        if (this.action == 'A') {
            parameters = {
                searchvalue: " where GCB_NAME='" + this.clubname + "' and GCB_STATUS<>'D'"
            };
        }
        else if (this.action == 'U') {
            parameters = {
                searchvalue: " where GCB_NAME='" + this.clubname + "' and GCB_STATUS<>'D' AND GCB_ID != " + this.gcid + ""
            };
        }
        this.api.postOH('getgolfclubaddress', parameters).subscribe(
            (response) => {
                if (response.length == 0) {
                    this.clubnameinformation.length = response.length;
                    this.shownameTick = true;
                }
                else if (response.length > 0) {
                    this.clubnameinformation.length = response.length;
                    this.shownameTick = false;
                }
            })
    }

    fileChange(input, fimg) {
        this.readFiles(input.files, fimg);
    }

    // safeUrl(base64String)
    // {
    //     return this.sanitizer.bypassSecurityTrustUrl(base64String);
    // }

    readFile(file, fimg, reader, callback) {
        reader.onload = () => {
            callback(reader.result);
            if (fimg == 'logo') {
                this.txtlogoinput.nativeElement.value = "";
                this.logoimagepath = reader.result;
                let base64str:any;
                base64str = reader.result;
                this.logoimagename = file.name;
                this.imagecropped1 = (base64str != "") ? base64str.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
            }
            if (fimg == 'bckimage') {
                var img = document.createElement("img");
                img.src = reader.result;
                img.onload = () => {
                    if (img.width != 1200 || img.height != 1920) {
                        let msg = '<span style="color: red">The image uploaded should has dimensions exactly 1200 X 1920 pixels.</span>';
                        this.toastMessage(msg);
                    }
                    else if (img.width == 1200 && img.height == 1920) {
                        this.bckimagepath = reader.result;
                        let base64str = reader.result;
                        this.bckimagename = file.name;
                        this.bckimagecropped = (base64str != "") ? base64str.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
                    }
                }
                this.bckimageinput.nativeElement.value = "";
            }
            else {
                this.overlineimagepath = reader.result;
                let base64str = reader.result;
                this.overlineimagename = file.name;
                this.imagecropped2 = (base64str != "") ? base64str.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
            }

        }
        reader.readAsDataURL(file);
    }
    readFiles(files, fimg, index = 0) {
        // Create the file reader  
        let reader = new FileReader();
        // If there is a file  
        if (index in files) {
            var extn = (files[index].name).split('.');
            if (extn[1].toLowerCase() == "jpg" || extn[1].toLowerCase() == "png" || extn[1].toLowerCase() == "gif" || extn[1].toLowerCase() == "jpeg") {
                this.readFile(files[index], fimg, reader, (result) => {
                    var img = document.createElement("img");
                    img.src = result;
                })
            }
            else {
                let msg = '<span style="color:red"> Browse image with extensions .jpg, .jpeg, .png, .gif only.</span>';
                this.toastMessage(msg);
            }
        } else {
            // When all files are done This forces a change detection  
            // this.changeDetectorRef.detectChanges();
        }
    }
    resize(img, MAX_WIDTH: number, MAX_HEIGHT: number, callback) {
        // This will wait until the img is loaded before calling this function  
        return img.onload = () => {
            // Get the images current width and height  
            var width = img.width;
            var height = img.height;
            // Set the WxH to fit the Max values (but maintain proportions)  
            if (width > height) {
                if (width > MAX_WIDTH) {
                    height *= MAX_WIDTH / width;
                    width = MAX_WIDTH;
                }
            } else {
                if (height > MAX_HEIGHT) {
                    width *= MAX_HEIGHT / height;
                    height = MAX_HEIGHT;
                }
            }
            // create a canvas object  
            var canvas = document.createElement("canvas");
            // Set the canvas to the new calculated dimensions  
            canvas.width = width;
            canvas.height = height;
            var ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0, width, height);
            // Get this encoded as a jpeg  
            // IMPORTANT: 'jpeg' NOT 'jpg'  
            var dataUrl = canvas.toDataURL('image/jpeg');
            // callback with the results  
            callback(dataUrl, img.src.length, dataUrl.length);
        };
    }

    toastMessage(msg) {
        let options = {
            positionClass: 'toast-top-center',
        };

        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 3000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    }

    confirm(): void {
        this.modalRef.hide();
        var golfclubinfo = {
            "action": 'D', "id": this.gcid, "name": "", "clubcode": "", "email": "", "website": "", "rotate": "0", "address": "",
            "city": "", "state": "0", "country": "0", "zipcode": "", "contact": "", "latitude": "", "longitude": "",
            "zoomlevel": "0", "timezone": "", "emergencycontact": "", "description": "", "logoimage": "", "logobinaryimage": "", "overlineimage": "", "overlinebinaryimage": "",
            "bckimagename": "", "bckbinaryimage": "",
            "updtaedid": localStorage.getItem('userId'), "status": 'D'
        }
        let msg = '<span style="color: green">Golf Club deleted Successfully</span>';
        this.DEapicall(golfclubinfo, msg);
    }

    enableclub(id): void {
        var golfclubinfo = {
            "action": 'E', "id": id, "name": "", "clubcode": "", "email": "", "website": "", "rotate": "0", "address": "",
            "city": "", "state": "0", "country": "0", "zipcode": "", "contact": "", "latitude": "", "longitude": "",
            "zoomlevel": "0", "timezone": "", "emergencycontact": "", "description": "", "logoimage": "", "logobinaryimage": "", "overlineimage": "", "overlinebinaryimage": "",
            "bckimagename": "", "bckbinaryimage": "",
            "updtaedid": localStorage.getItem('userId'), "status": 'Y'
        }
        let msg = '<span style="color: green">Golf Club enabled Successfully</span>';
        this.DEapicall(golfclubinfo, msg);
    }

    DEapicall(golfclubinfo, msg) {
        //console.log(golfclubinfo);
        this.api.postOH('savegolfclub', golfclubinfo).subscribe(
            (response) => {
                if (localStorage.getItem('roleCode') == "SA") {
                    let parameters = {
                        searchvalue: " where GCB_STATUS='Y'"
                    };
                    this.GetGolfClubsData(parameters);
                    // localStorage.removeItem('clubId');
                    // localStorage.removeItem('clubname');
                    // localStorage.removeItem('courseId');
                    // this.authService.getCall();
                } else {
                    let parameters = {
                        uid: localStorage.getItem('userId'), rcode: localStorage.getItem('roleCode'), expression: " where GCCA_GCCL_ID='" + localStorage.getItem('userId') + "' AND GCB_STATUS='Y' AND GCCA_STATUS='Y'"
                    };
                    this.getclubsdataforgrid(parameters);
                }
                this.gridShow = "block"; this.viewcontentShow = "none";
                this.contentShow = "none"; this.coursegridShow = "none";
                this.toastMessage(msg);
            }, error => {
                //console.log(error);
            });
    }

    decline(): void {
        this.modalRef.hide();
    }

    allowNumbers(event) {
        const charCode = (event.which) ? event.which : event.keyCode;
        if (charCode == 64 || charCode == 16 || event.shiftKey) {
            // to allow numbers  
            return false;
        } else if (charCode >= 48 && charCode <= 57) {
            // to allow numbers  
            return true;
        } else if (charCode >= 96 && charCode <= 105) {
            // to allow numpad number  
            return true;
        } else if ([8, 13, 27, 37, 38, 39, 40, 9, 46].indexOf(charCode) > -1) {
            // to allow backspace, enter, escape, arrows  
            return true;
        } else if ((charCode === 65 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+C
            (charCode === 67 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+V
            (charCode === 86 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+X
            (charCode === 88 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+Y
            (charCode === 89 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+Z
            (charCode === 90 && (event.ctrlKey || event.metaKey))) {
            return true;
        } else {
            event.preventDefault();
            // to stop others  
            return false;
        }
    }

    allowNumbersAndDecimals(event) {
        const charCode = (event.which) ? event.which : event.keyCode;
        if (charCode == 64 || charCode == 16 || event.shiftKey) {
            // to allow numbers  
            return false;
        } else if (charCode >= 48 && charCode <= 57) {
            // to allow numbers  
            return true;
        }
        else if (charCode >= 96 && charCode <= 105) {
            // to allow numpad number  
            return true;
        } else if ([8, 13, 27, 37, 38, 39, 40, 9, 46].indexOf(charCode) > -1) {
            // to allow backspace, enter, escape, arrows  
            return true;
        } else if ([110, 190, 109, 189, 173].indexOf(charCode) > -1) {
            //to allow dots, dash  
            return true;
        } else if ((charCode === 65 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+C
            (charCode === 67 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+V
            (charCode === 86 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+X
            (charCode === 88 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+Y
            (charCode === 89 && (event.ctrlKey || event.metaKey)) ||
            // Allow: Ctrl+Z
            (charCode === 90 && (event.ctrlKey || event.metaKey))) {
            return true;
        } else {
            event.preventDefault();
            // to stop others  
            return false;
        }
    }

    mobileFormat(e) {
        if (e.keyCode < 48 || e.keyCode > 57) {
            e.preventDefault();
        }
        if (e.target.value.length != "") {
            e.target.value = e.target.value.replace(/[^0-9]/g, '');

            if (!e.target.value) { return ''; }

            var number = String(e.target.value);
            e.target.value = number;

            var front = number.substring(0, 3);
            var center = number.substring(3, 6);
            var end = number.substring(6, 10);

            if (center) {
                e.target.value = (front + "-" + center);
            }
            if (end) {
                e.target.value += ("-" + end);
            }
            return e.target.value;
        }
    }

    clearBackGroundImageforClub() {
        this.bckimagepath = "";
        this.bckimagename = "";
        this.bckimagecropped = "";
        this.bckimageinput.nativeElement.value = "";
    }
}
