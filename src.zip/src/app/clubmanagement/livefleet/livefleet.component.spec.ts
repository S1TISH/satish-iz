import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LivefleetComponent } from './livefleet.component';

describe('LivefleetComponent', () => {
  let component: LivefleetComponent;
  let fixture: ComponentFixture<LivefleetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LivefleetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LivefleetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
