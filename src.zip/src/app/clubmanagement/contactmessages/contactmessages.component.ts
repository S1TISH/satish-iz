import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { AuthService } from '../../services/auth.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Title } from '@angular/platform-browser';

@Component({
    selector: 'app-contactmessages',
    templateUrl: './contactmessages.component.html',
    styleUrls: ['./contactmessages.component.css']
})
export class ContactmessagesComponent implements OnInit {
    modalRef: BsModalRef; public contactForm: FormGroup; public ecupdateForm: FormGroup; submitAttempt: boolean = false;
    divheader: string = "Add Contact Message"; GridMessage: string = 'Loading... !'; contactMessages: any = [];
    searchInfo: string = "block"; gridInfo: string = "block"; viewInfo: string = "none"; showStatus: string = "none"; addShow: string = "none";
    contactBtn: any; refreshBtn: any; selectedoption: any = "Active"; randomcolor: any = "#5cb85c";
    //search
    search: any = ''; srchError: string = '0';
    //model values
    action: any = "A"; id: any; clubId: any; description: any; status: any; checkStatus: any; clubname: string; modalRef1: BsModalRef;
    //sorting
    key: string = 'description';
    reverse: boolean = false;
    descriptionasc: any = "sortgreen"; descriptiondesc: any = "sortwhite";

    emergencyContactNo: any; updateecBtn: any = false;
    constructor(private title: Title,public toastr: ToastsManager, vcr: ViewContainerRef,        
        private router: Router, public formBuilder: FormBuilder,
        private spinnerService: Ng4LoadingSpinnerService,
        private api: ApiService, private authService: AuthService,
        private modalService: BsModalService) {
            
        this.title.setTitle("IZON - Contact Messages");
        this.clubId = localStorage.getItem('clubId');
        this.clubname = localStorage.getItem('clubname');
        this.toastr.setRootViewContainerRef(vcr);        
    }

    ngOnInit() {
        this.contactForm = this.formBuilder.group({
            fdescription: ['', Validators.compose([Validators.required])],
            fstatus: ['']
        });
        this.ecupdateForm = this.formBuilder.group({
            fecontact: ['']
        });
        
        let parameters = { searchvalue: " where CMA_STATUS='Y' and CMA_GCB_ID='"+this.clubId+"' " };
        this.getContactMessages(parameters); 
        if(localStorage.getItem('ecstatus') != null)
            {
                this.displayMessage(localStorage.getItem('ecstatus'));
            }
    }

    sort(value: string) {
        this.key = value;
        this.descriptionasc = "sortwhite"; this.descriptiondesc = "sortwhite";
        if (this.key == value) {
            this.reverse = !this.reverse;
            if (this.key == "labelname" && this.reverse) {
                this.descriptiondesc = "sortgreen";
            }
            else if (this.key == "labelname" && (!this.reverse)) {
                this.descriptionasc = "sortgreen";
            }
        }

    }

    addContactMessages() {
        this.divheader = "Add Contact Message";
        this.addShow = "block"; this.searchInfo = "none"; this.gridInfo = "none"; this.viewInfo = "none"; this.showStatus = "none";
        this.submitAttempt = false; this.action = "A"; this.description = ""; this.status = true; this.id = 0;
    }

    cancelMessage() {
        this.searchInfo = "block"; this.gridInfo = "block"; this.addShow = "none"; this.viewInfo = "none";
        this.contactForm.reset(); this.submitAttempt = false;
        // let parameters = { searchvalue: " where CMA_STATUS='Y' AND CMA_GCB_ID =" + this.clubId + "" };
        // this.getContactMessages(parameters);
    }

    //search functionality
    searchContactMessage() {
        if (this.search == '') {
            this.srchError = '1';
        }
        else if (this.search != '') {
            this.srchError = '0';
            let parameters = {
                searchvalue: " WHERE CMA_DESCRIPTION LIKE '%" + this.search + "%'AND CMA_GCB_ID =" + this.clubId + " and CMA_STATUS<>'D' "
            };
            this.getContactMessages(parameters);
            this.search = "";
        }
    }

    bindselectedoption(selectedoption) {
        this.srchError = '0';
        if (this.selectedoption == 'Active') {
            this.randomcolor = "#5cb85c";
            this.searchStatus('Y');
        }
        else if (this.selectedoption == 'In-Active') {
            this.randomcolor = "#337ab7";
            this.searchStatus('N');
        }
        else if (this.selectedoption == 'Deleted') {
            this.randomcolor = "#d9534f";
            this.searchStatus('D');
        }
    }

    searchStatus(type) {
        let parameters = {
            searchvalue: " WHERE CMA_STATUS= '" + type + "' AND CMA_GCB_ID =" + this.clubId + ""
        };
        this.getContactMessages(parameters);
    }

    srchKeyUp(event: any) {
        if (this.search != '') {
            this.srchError = '0';
        }
    }

    refreshpage() {
        this.search='';
        this.srchError = '0';
        this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
        let parameters = { searchvalue: " where CMA_STATUS='Y' AND CMA_GCB_ID =" + this.clubId + "" };
        this.getContactMessages(parameters);
    }

    getContactMessages(parameters) {
        this.contactMessages = [];
        this.refreshBtn = true;
        this.spinnerService.show();
        this.api.postOH('getclubcontactmessages', parameters).subscribe(
            response => {
                this.spinnerService.hide();
                if (response.length > 0) {
                    for (let i = 0; i < response.length; i++) {
                        var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                        var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                        this.contactMessages.push({
                            "id": response[i].id,
                            "description": response[i].description,
                            "createddate": response[i].createddate,
                            "status": status,
                            "statusclass": statusclass,
                        });
                    }
                    this.refreshBtn = false;
                } else {
                    this.contactMessages = []; this.refreshBtn = false;
                    this.GridMessage = "No Records Found";
                }
            },
            err => {
                this.spinnerService.hide();
            }
        );
    }

    viewMessage(id) {
        this.searchInfo = "none"; this.gridInfo = "none"; this.viewInfo = "block"; this.clubname = localStorage.getItem('clubname');
        this.spinnerService.show();
        let parameters = { searchvalue: ' WHERE CMA_ID=' + id + ' AND CMA_GCB_ID =' + this.clubId + '' };
        this.api.postOH('getclubcontactmessages', parameters).subscribe(
            response => {
                window.scrollTo(0,0);
                this.spinnerService.hide();
                if (response.length > 0) {
                    this.id = response[0].id;
                    this.description = response[0].description;
                    this.status = (response[0].status == 'Y') ? true : false;
                    this.checkStatus = (response[0].status == 'Y') ? 'Active' : (response[0].status == 'N') ? 'In-Active' : 'Deleted';
                } else {
                    this.contactMessages = [];
                    this.GridMessage = "No Records Found";
                }
            },
            err => {
                this.spinnerService.hide();
            }
        );
    }

    goBack() {
        this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
        this.searchInfo = "block"; this.gridInfo = "block"; this.addShow = "none"; this.viewInfo = "none";
        let parameters = { searchvalue: " where CMA_STATUS='Y' AND CMA_GCB_ID =" + this.clubId + "" };
        this.getContactMessages(parameters);
    }

    editMessage(id) {
        this.addShow = "block"; this.searchInfo = "none"; this.gridInfo = "none"; this.viewInfo = "none"; this.showStatus = "block";
        this.spinnerService.show(); this.divheader = "Edit Contact Message";
        let parameters = { searchvalue: ' WHERE CMA_ID=' + id + ' AND CMA_GCB_ID =' + this.clubId + '' };
        this.api.postOH('getclubcontactmessages', parameters).subscribe(
            response => {
                this.spinnerService.hide();
                if (response.length > 0) {
                    this.action = "U";
                    this.id = response[0].id;
                    this.description = response[0].description;
                    this.status = (response[0].status == 'Y') ? true : false;
                }
            },
            err => {
                this.spinnerService.hide();
            }
        );
    }

    saveMessage() {
        if (!this.contactForm.valid) {

        }
        this.submitAttempt = true;
        if (this.contactForm.valid) {
            this.contactBtn = true;
            var contactMessagesModal = {
                "action": this.action, "id": this.id, "clubid": this.clubId, "description": this.description, "status": (this.status == true) ? "Y" : "N"
            }
            this.spinnerService.show();
            this.api.postOH('saveclubcontactmessages', contactMessagesModal).subscribe(
                response => {                    
                    if (response.length > 0) {
                        if (response[0] > 0 && this.action == 'A') {
                            let parameters = { searchvalue: " where CMA_STATUS='Y' AND CMA_GCB_ID =" + this.clubId + "" };
                            this.getContactMessages(parameters);
                            this.searchInfo = "block"; this.gridInfo = "block"; this.addShow = "none"; this.viewInfo = "none";
                            let msg = '<span style="color: green">Contact Message Added Successfully</span>';
                            this.toastMessage(msg); this.contactForm.reset();
                        }
                        else if (response[0] > 0 && this.action == 'U') {
                            this.action = 'A';
                            this.viewMessage(contactMessagesModal.id);
                            this.addShow = "none"; this.showStatus = "none";
                            let msg = '<span style="color: green">Contact Message Updated Successfully</span>';
                            this.toastMessage(msg); this.contactForm.reset();
                        }
                    } else {
                        let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                        this.toastMessage(msg);
                    }
                    window.scrollTo(0, 0);
                    this.spinnerService.hide();
                    this.contactBtn = false;
                },
                err => {
                    this.spinnerService.hide();
                    this.contactBtn = false;
                }
            );
        }
    }

    toastMessage(msg) {
        let options = {
            positionClass: 'toast-top-center',
        };

        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 3000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    }

    confirm(): void {
        this.modalRef.hide();
        var contactMessagesModal = {
            "action": "D", "id": this.id, "clubid": this.clubId, "description": this.description, "status": "D"
        }
        let msg = '<span style="color: red">Contact Message Deleted Successfully</span>';
        this.DEapicall(contactMessagesModal, msg);
    }

    enableMessage(id: any, measurement: any): void {
        var contactMessagesModal = {
            "action": "E", "id": id, "clubid": this.clubId, "description": "", "status": "Y"
        }
        let msg = '<span style="color: green">Contact Message Enabled Successfully</span>';
        this.DEapicall(contactMessagesModal, msg);
    }

    DEapicall(contactMessagesModal, msg) {
        this.api.postOH('saveclubcontactmessages', contactMessagesModal).subscribe(
            (response) => {
                let parameters = { searchvalue: " where CMA_STATUS='Y' AND CMA_GCB_ID =" + this.clubId + "" };
                this.getContactMessages(parameters);
                this.action = 'A';
                this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
                this.searchInfo = "block"; this.gridInfo = "block"; this.addShow = "none"; this.viewInfo = "none";
                this.showStatus = "none";
                this.toastMessage(msg);
            }, error => {
                let msg = '<span style="color: red">Failed to update the data, please try again</span>';
                this.toastMessage(msg);
            });
    }

    decline(): void {
        this.modalRef.hide();
    }
   
    displayMessage(stat)
    {
        let msg;
        if(stat == 'success')
        {
            msg = '<span style="color: green">Emergency Contact Updated Successfully.</span>';
        }
        else
        {
            msg = '<span style="color: red">Problem while updating Emergency Contact.</span>';
        }
        localStorage.removeItem('ecstatus');
        this.toastMessage(msg);
    }

    openModaltoUpdate(contacttemplate: TemplateRef<any>) {
        //this.confirmecupdate = false;
        this.submitAttempt = false;
        this.updateecBtn = false;
        this.modalRef1 = this.modalService.show(contacttemplate, { class: 'modal-sm' });
        this.getECContactforClub();
    }

    getECContactforClub()
    {
        let parameters = {
            searchvalue: " WHERE GCB_ID='" + this.clubId + "'"
        };
        this.api.postOH('getgolfclubaddress', parameters).subscribe((res) => 
        {
            if(res.length > 0)
            {
                this.emergencyContactNo = res[0].emergencycontact;
            }
            else
            {
                this.emergencyContactNo = '';
            }
        })
    }

    confirmtoUpdate() : void
    {
        //this.confirmecupdate = true;
        this.emergencyContactNo = this.emergencyContactNo;
    }

    confirmtoUpdateValue(): void{
        if(!this.ecupdateForm.valid)
        {

        }
        this.submitAttempt = true;
        if (this.ecupdateForm.valid) {
            this.updateecBtn = true;
            var ecupdateModel = {
                'emergencycontact': this.emergencyContactNo,
                'clubid': this.clubId
            }
            //console.log(ecupdateModel);
            this.api.postOH('updategolfclubemergencycontact', ecupdateModel).subscribe(
                (result) => {
                    this.updateecBtn = false;
                    this.displayMessage(result);
                    this.declinetoUpdate();
                }
            )
        }
    }

    


    declinetoUpdate() : void
    {
        this.modalRef1.hide();
        //this.confirmecupdate = false;
    }

    mobileFormat(e) {
        if (e.keyCode < 48 || e.keyCode > 57) {
            e.preventDefault();
        }
        if (e.target.value.length != "") {
            e.target.value = e.target.value.replace(/[^0-9]/g, '');

            if (!e.target.value) { return ''; }

            var number = String(e.target.value);
            e.target.value = number;

            var front = number.substring(0, 3);
            var center = number.substring(3, 6);
            var end = number.substring(6, 10);

            if (center) {
                e.target.value = (front + "-" + center);
            }
            if (end) {
                e.target.value += ("-" + end);
            }
            return e.target.value;
        }
    }
}
