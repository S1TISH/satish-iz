import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactmessagesComponent } from './contactmessages.component';

describe('ContactmessagesComponent', () => {
  let component: ContactmessagesComponent;
  let fixture: ComponentFixture<ContactmessagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContactmessagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactmessagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
