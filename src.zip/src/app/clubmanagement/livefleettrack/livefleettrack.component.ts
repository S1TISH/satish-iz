import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { getLocaleDateFormat } from '@angular/common';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Observable } from 'rxjs/Rx';
import { Title } from '@angular/platform-browser';
import * as moment from "moment";
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';

declare const google: any;
var currentZoom; var minZoom; var maxZoom;

@Component({
  selector: 'app-livefleettrack',
  templateUrl: './livefleettrack.component.html',
  styleUrls: ['./livefleettrack.component.css']
})
export class LivefleettrackComponent implements OnInit {
  templatecmprund: BsModalRef;templatecartsignout:BsModalRef; templatemessages: BsModalRef;
  

  courselat: any;
  courselong: any;
  coursezoomlevel: any;
  courserotate:any=0;
  polylinecoordinates: any = [];
  golfclubid: any;invalidcls:any =0;
  cartid: any; ddCartsList: any = []; ddlcarts: string; clubcartmessages: any = []; allclubcartmessages: any = [];cartMessage: any;
  cartcolor:any;cartcolorcss:any;elapsedtime:any;aheadordeny:any;aheadordenymins:any;aheadordenycolor:any;
  userType: any;iconnameonmap:any;
  holenumber:any;
  fromdate: any; todate: any; datearry: any; mapdiv: any; cartname: any; bluecircleimage: any; rangerBeverageName: any = ""; rangerBeverageId: any = "";
  carttrackheader: string; CoursesInfo: any = []; inplayDetails: any = []; startinghole: any; starttime: any;
  lastupdateddate: any; day: string; month: any; hh: any; mm: any; ss: any; sub: any; map: any; gameBtn: any; markers:any=[];
  polylinsonmap:any=[]; mapcirclepoints:any=[];viewall: boolean = false;
  public messageForm: FormGroup; submitAttempt: boolean = false;userId: any;tournamentcart:boolean=true;
  buttontext:any;SourceFrom:any;

  showhistory:boolean=false;
  showcartsddl:boolean=true;
  scorecardgroupid:any;
  constructor(private title: Title, vcr: ViewContainerRef,public api: ApiService, private router: Router, private spinnerService: Ng4LoadingSpinnerService,private modalService: BsModalService, public formBuilder: FormBuilder,public toastr: ToastsManager) {
      this.title.setTitle("IZON - Cart Tracking Info");
      this.carttrackheader = "Cart Tracking Info";
      this.golfclubid = localStorage.getItem('clubId');
      this.cartid = localStorage.getItem('playcartId');
      if(this.cartid=='' || this.cartid==null || this.cartid==undefined){
          this.router.navigate(['clubmanagement/livefleet']);
      }
      this.cartname = localStorage.getItem('playcartname');
      this.userType = localStorage.getItem('userType');
      this.rangerBeverageName = localStorage.getItem('rangerBeverageName');
      this.rangerBeverageId = localStorage.getItem('rangerBeverageId');  
      this.SourceFrom=localStorage.getItem('sourceFrom');    
      this.userId = JSON.parse(localStorage.getItem('userId')); 
  }

  ngOnInit() {
      window.scrollTo(0, 0);
      this.buttontext="Send";
      this.ddlcarts=this.cartid;
      this.bluecircleimage = 'assets/imgs/blue_circle.png';
      let date = new Date(Date.now());
      let day1 = date.getDate();
      if (day1 < 10) {
          this.day = "0" + day1.toString();
      } else {
          this.day = day1.toString();
      }
      let month1 = date.getMonth() + 1;
      if (month1 < 10) {
          this.month = "0" + month1.toString();
      } else {
          this.month = month1.toString();
      }
      let year = date.getFullYear();
      let todaydate = year + "-" + this.month + "-" + this.day;
      this.fromdate = todaydate;
      this.todate = todaydate;
      this.mapdiv = true;
      this.getcarttrackingdata();        
      this.getlastupdateddatetime();
      this.getCartsList();
      this.getclubcartmessages();
      this.sub = Observable.interval(1000 * 60).subscribe(x => {            
          this.getcartcolor();
          this.getlastupdateddatetime();
          this.getCartsList();
          this.getclubcartmessages();
      });
      this.messageForm = this.formBuilder.group({
          fmessage: ['', Validators.compose([Validators.required])],
      });
  }

  ngOnDestroy() {
      if(this.cartid!=null){
          this.sub.unsubscribe();
      }        
  }

  getCartMap(event: any) {
      this.spinnerService.show();
      this.getcartcolor();
      for (let i = 0; i < this.ddCartsList.length; i++) {
          if (this.ddCartsList[i].value == this.ddlcarts) {
              localStorage.setItem('playcartId',this.ddlcarts);
              localStorage.setItem('playcartname',this.ddCartsList[i].name);
              this.userType=this.ddCartsList[i].cartroletype;
              localStorage.setItem('userType',this.ddCartsList[i].cartroletype); 
              this.cartid=localStorage.getItem('playcartId');
              this.cartname = localStorage.getItem('playcartname');
              if(this.ddCartsList[i].cartroletype>0){
                  let parameters = {
                      searchvalue: " where CLL_GCB_ID=" + this.golfclubid + " AND CLL_CD_ID=" + this.ddlcarts + " AND CLL_ACTION='I' AND CLL_U_TYPE=" + this.ddCartsList[i].cartroletype + " "
                  };
                  this.api.postOH('rangerandbeveragedetails', parameters).subscribe(
                      (response) => {
                          if (response.length > 0) {
                              this.rangerBeverageName = response[0].name;
                          }
                          else {
                              this.spinnerService.hide();
                          }
                      }, error => {
          
                      }
                  );
              }
              this.clearpolylines();
              this.clearMarkers();
              this.getcarttrackingdata();        
              this.getlastupdateddatetime();
              this.getCartsList();  
              this.getclubcartmessages();
              this.spinnerService.hide();              
          }
      }
  }

 getcarttrackingdata() {
      if (this.fromdate == undefined || this.fromdate == null || this.fromdate == '') {
          this.mapdiv = false;
          // alert("Choose From Date");
      } else {
          this.mapdiv = true;
          let searchexp = "";
          if (localStorage.getItem('courseId') === undefined || localStorage.getItem('courseId') === '' || localStorage.getItem('courseId') === null) {
              searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' "
          }
          else {
              searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' and  GC_ID='" + localStorage.getItem('courseId') + "'"
          }
          let parameters1 = { searchvalue: searchexp };
          //let parameters1 = { searchvalue: " WHERE GC_GCB_ID='" + this.golfclubid + "'" };
          this.getcourses(parameters1);
      }        
  }   

  getcourses(parameters) {
      this.CoursesInfo = [];
      this.api.postOH('getgolfcourse', parameters).subscribe(
          response => {
              this.spinnerService.hide();
              if (response.length !== 0) {
                  for (let i = 0; i < response.length; i++) {
                      this.CoursesInfo.push({
                          "id": response[i].id
                      })
                  }
                  this.courselat = response[0].latitude;
                  this.courselong = response[0].longitude;
                  this.coursezoomlevel = (response[0].zoomlevel != '') ? response[0].zoomlevel : 0;
                  this.courserotate = (response[0].rotate != '') ? response[0].rotate : 0;
                  this.maploading();
              }
          }, error => {
              this.spinnerService.hide();
          })
  }

  maploading() {
      var stylecontrols = document.getElementById('styleControls');
      this.spinnerService.show();
      this.map = new google.maps.Map(document.getElementById('map'), {
          center: { lat: parseFloat(this.courselat), lng: parseFloat(this.courselong) },
          zoom: parseInt(this.coursezoomlevel),
          //disableDefaultUI: true,
          mapTypeId: 'satellite',
          tilt: 0,
          rotateControl: true,
          fullscreenControl: false,
          zoomControl: false,
          streetViewControl: false,
          mapTypeControl: false,
      });
      // let cthis=this;
      // this.map.addListener('zoom_changed', function () {
      //     var zoomlevel = cthis.map.getZoom();
      //     if (zoomlevel >= 18) {
      //         var rotateValue = cthis.courserotate;
      //         cthis.map.setHeading(parseInt(rotateValue));
      //     }
      // });
      currentZoom = this.map.getZoom();
      minZoom = 0;
      maxZoom = 21;
      this.setoverlayimage();
      if(this.userType=="0"){
          this.inplayuser();
      }else{
          this.getpolylinedetails();
      }
      this.map.controls[google.maps.ControlPosition.TOP_RIGHT].push(stylecontrols);
  }

  inplayuser() {
      this.spinnerService.show();
      this.inplayDetails = [];
      let parameters = { searchvalue: " WHERE SC_CD_ID='" + this.cartid + "' AND SC_GAME_STATUS='L'" };
      this.api.postOH('getcartassignedusers', parameters).subscribe(
          (response) => {
              if (response.length != 0) {
                  for (let i = 0; i < response.length; i++) {
                      this.inplayDetails.push({
                          "cartid": response[i].cartid,
                          "cartname": response[i].cartname,
                          "frontnine": response[i].frontnine,
                          "izonuseremail": response[i].izonuseremail,
                          "izonuserid": response[i].izonuserid,
                          "izonusername": response[i].izonusername,
                          "createddateinampm": response[i].createddate,
                          "starttime": response[i].starttime,
                          "endtime":response[i].endtime,
                          "izonusermobile": response[i].izonusermobile,
                          "izonuserpwd": response[i].izonuserpwd,
                          "gamestatus":response[i].gamestatus,
                          "scorecardgroupid": response[i].scorecardgroupid
                      })
                      this.startinghole = response[0].frontnine === "Y" ? "1st" : "10th";
                      if(response[0].starttime !=""){
                          // let time = response[0].starttime.split(' ');
                          // this.starttime = time[0].replace('/', '.').replace('/', '.') + ' @ ' + time[1] + time[2];

                          var st = new Date(response[0].starttime);
                          st.setMinutes(st.getMinutes() - 4);
                          this.starttime = moment(st).format('MM.DD.YYYY @ hh:mm A');
                      }
                      else{
                          // let date = response[0].createddateinampm.split(' ');
                          // this.starttime = date[0].replace('/', '.').replace('/', '.') + ' @ ' + date[1] + date[2];

                          var cd = new Date(response[0].createddateinampm);
                          cd.setMinutes(cd.getMinutes() - 4);
                          this.starttime = moment(cd).format('MM.DD.YYYY @ hh:mm A');
                      }
                  }
              }
              this.getcartcolor();
          }, error => {
              this.spinnerService.hide();
          }
      );
  }
  getstartinghole(){
      this.scorecardgroupid=this.inplayDetails[0].scorecardgroupid;
      let parameters = {
          clubid:this.golfclubid,
          courseid:localStorage.getItem('courseId'),
          cartid: this.cartid,
          scorecardgroupid: this.scorecardgroupid
      };
      this.api.postOH('gettournamentstartinghole', parameters).subscribe(
          (response) => {
              this.startinghole=response[0].startinghole;
              this.holenumber=response[0].currenthole;
          }, error => {
              this.spinnerService.hide();
          })
  }

  getcartcolor(){
      let parameters = {
          searchvalue: this.cartid,
          courseid: localStorage.getItem('courseId')
      };
      this.api.postOH('getcarttrackcolorv1', parameters).subscribe(
          (response) => {
              if (response.length > 0) {
                  // this.holenumber = response[0].holenumber;
                  // this.cartcolor = response[0].cartcolor;
                  this.cartcolor = response[0].cartcolor;
                  if(this.cartcolor==='tournament'){
                    this.tournamentcart=false; 
                    this.getstartinghole();
                  } 
                  else{
                      this.tournamentcart=true;
                      this.holenumber = response[0].holenumber;
                    }
                  if (this.cartcolor === "blue_circle.png") { this.cartcolorcss = "blue1.png"; }
                  else if (this.cartcolor === "yellow_circle.png") { this.cartcolorcss = "yellow1.png"; }
                  else if (this.cartcolor === "red_circle.png") { this.cartcolorcss = "red1.png"; }
                  else { this.cartcolorcss = "blue1.png"; }
                  this.elapsedtime = response[0].elapsedtime;
                  this.aheadordeny = response[0].aheadordeny;
                  this.aheadordenymins = response[0].aheadordenymins;
                  this.aheadordenycolor = response[0].aheadordenycolor;
              } else {
                  localStorage.setItem('gameStatus', 'CM');
                  this.router.navigate(['/cartmanagement/livefleet']);
              }
              this.getpolylinedetails();                
          }, error => {
              this.spinnerService.hide();
          })
  }    

  setoverlayimage() {
      let me = this;
      for (let i = 0; i < this.CoursesInfo.length; i++) {
          var imageMapType = new google.maps.ImageMapType({
              getTileUrl: function (coord, zoom) {
                  //console.log('http://iadmin.azaz.com/tiles/' + me.golfclubid+ '/' +me.CoursesInfo[i].id+ '/' + zoom + '/' + coord.x + '/' + coord.y + '.png');
                  // let clbid=''; let cursid='';
                  // if(me.golfclubid=='1002'){clbid='1445'}else{clbid=me.golfclubid};
                  // if(me.CoursesInfo[i].id==2){cursid='539'}else if(me.CoursesInfo[i].id==3){cursid='540'}else if(me.CoursesInfo[i].id==4){cursid='541'}else{cursid=me.CoursesInfo[i].id};
                  // return ['http://cp.izongolf.com/tiles/' + clbid + '/' + cursid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
                  return ['http://cp.izongolf.com/tiles/' + me.golfclubid + '/' + me.CoursesInfo[i].id + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
              },
              tileSize: new google.maps.Size(256, 256)
          });
          this.map.overlayMapTypes.push(imageMapType);
      }
  }

  getpolylinedetails() {  
      var fdate=""; var todate="";var flag = '';
      // let fdate = this.dateformats(this.fromdate);
      // let todate = this.dateformats(this.todate);
     
      // if(this.userType=='0'){
      //     flag='C';
      // }else{
      //     flag='A';
      // }
      if(this.showhistory){
          fdate = moment(this.fromdate).format('MM/DD/YYYY');
          todate = moment(this.todate).format('MM/DD/YYYY');
          flag = 'A';
      }
      else{
         fdate = moment(new Date(Date.now())).format('MM/DD/YYYY');
         todate = moment(new Date(Date.now())).format('MM/DD/YYYY');
         if (this.userType == '0') {
             flag = 'C';
           } else {
             flag = 'A';
          }
      }
      var getcarttrackdetails = {
          "CartId": this.cartid, "FromDate": fdate, "Todate": todate, "Flag":flag
      }
      this.clearpolylines();
      this.polylinecoordinates = [];
      this.api.postOH1('GetCartTrack', getcarttrackdetails).subscribe(
          (response) => {
              //console.log(response);
              if (response[0].ResponseCode == "Success") {
                  if (response[0].CartTrackData.length > 0) {
                      for (var i = 0; i < response[0].CartTrackData.length; i++) {
                          this.polylinecoordinates.push({
                              lat: (response[0].CartTrackData[i].Latitude != '') ? parseFloat(response[0].CartTrackData[i].Latitude) : 0,
                              lng: (response[0].CartTrackData[i].Langitude != '') ? parseFloat(response[0].CartTrackData[i].Langitude) : 0,
                              timestamp: response[0].CartTrackData[i].Datetime,
                          });
                          this.polylinecoordinates = this.polylinecoordinates;
                      }
                      
                  }

                  // else{
                  //     alert( this.courselat);
                  //     this.polylinecoordinates.push({
                  //         lat:  parseFloat( this.courselat),
                  //         lng:  parseFloat(this.courselong),
                  //     });
                  //     this.polylinecoordinates = this.polylinecoordinates;
                  // }

                  this.drawpolyline();

                  
                  this.spinnerService.hide();
              } else {
                  this.polylinecoordinates = this.polylinecoordinates;
                  this.spinnerService.hide();
              }                
          }, error => {
              this.spinnerService.hide();
          }
      );
  }

  drawpolyline() {
      this.spinnerService.hide();
      let lengthval=this.polylinecoordinates.length-1;
     if (this.markers.length > 0) {
          this.clearMarkers();
      }
      if (this.userType == '3' || this.userType == '7' ) {
          this.bluecircleimage = 'assets/imgs/star_view.png';
          this.iconnameonmap = '';
        } else if (this.userType == '4') {
          this.bluecircleimage = 'assets/imgs/beverage_view.png';
          this.iconnameonmap = '';
        } else {
          if(this.cartcolor==='tournament'){
              this.bluecircleimage = 'assets/imgs/blue_circle.png';
          }
         else{
          this.bluecircleimage = 'assets/imgs/' + this.cartcolor;
         }
          this.iconnameonmap = {
              text: this.cartname,
              color: 'white'
          };
      }
      var marker1 = new google.maps.Marker({
          position: { lat: parseFloat(this.polylinecoordinates[lengthval].lat), lng: parseFloat(this.polylinecoordinates[lengthval].lng) },
          icon: this.bluecircleimage,
          label: this.iconnameonmap
      });
      marker1.setMap(this.map);
      this.markers.push(marker1);
      this.map.setCenter(new google.maps.LatLng(parseFloat(this.polylinecoordinates[lengthval].lat), parseFloat(this.polylinecoordinates[lengthval].lng)));

      var flightPath = new google.maps.Polyline({
          path: this.polylinecoordinates,
          //editable:true,      
          geodesic: true,
          strokeColor: '#FF0000',
          strokeOpacity: 1.0,
          strokeWeight: 2
      });
      this.polylinsonmap.push(flightPath);
      flightPath.setMap(this.map);

      let me = this;
      var infowindow = new google.maps.InfoWindow();
      var marker, i;
      for (i = 0; i < me.polylinecoordinates.length; i++) {
          marker = new google.maps.Marker({
              position: new google.maps.LatLng(me.polylinecoordinates[i].lat, me.polylinecoordinates[i].lng),
              icon: {
                  path: google.maps.SymbolPath.CIRCLE,
                  scale: 4.5,
                  fillColor: "#F00",
                  fillOpacity: 0.4,
                  strokeWeight: 0.4
              },
              map: me.map
          });
          this.mapcirclepoints.push(marker);

          google.maps.event.addListener(marker, 'mouseover', (function (marker, i) {
              return function () {
                  var content = "";
                  content += '<div style="color:green;font-weight:bold;padding-bottom:10px;">Cart Position At:</div>'
                  content += me.polylinecoordinates[i].timestamp + "\n";
                  infowindow.setContent(content);
                  infowindow.open(me.map, marker);
              }
          })(marker, i));

          google.maps.event.addListener(marker, 'mouseout', function () {
              infowindow.close();
          });
      }
  }

  clearpolylines() {
      for (var i = 0; i < this.polylinsonmap.length; i++) {
        this.polylinsonmap[i].setMap(null);
      }
      
      for (var j = 0; j < this.mapcirclepoints.length; j++) {
          this.mapcirclepoints[j].setMap(null);
      }
      this.polylinsonmap=[];
      this.mapcirclepoints=[];
    }

  completeTheGame() {
      var enddate = moment(new Date()).format('MM/DD/YYYY hh:mm A');
      this.gameBtn = true;
      if (this.inplayDetails.length > 1) {
          var gamemodel = { "cartid": this.inplayDetails[0].cartid, "player1": this.inplayDetails[0].izonuserid, "player2": this.inplayDetails[1].izonuserid, "enddate":enddate }
      }
      else {
          gamemodel = { "cartid": this.inplayDetails[0].cartid, "player1": this.inplayDetails[0].izonuserid, "player2": '0', "enddate":enddate }
      }
      this.spinnerService.show();
      this.api.postOH('updategamestatus', gamemodel).subscribe(
          response => {
              this.spinnerService.hide();
              if (response == "Game Status Updated Successfully") {
                  localStorage.setItem('gameStatus', 'C');
                  this.router.navigate(['/clubmanagement/livefleet']);
              }
              else if (response == "Error, While Updating Game Status") {
                  //let msg = '<span style="color: green">Failed to Update the data, please try again</span>';
                  //this.toastMessage(msg);
              }
              this.gameBtn = false;
          },
          err => {
              this.spinnerService.hide();
              this.gameBtn = false;
          }
      );
  }

  clearCart() {
      this.gameBtn = true;
      var clearmodel = { "clubid": this.golfclubid, "cartid": this.cartid, "userid": this.rangerBeverageId, "roleid": this.userType }
      this.spinnerService.show();
      this.api.postOH('clearrangerbevaragecart', clearmodel).subscribe(
          response => {
              if (response == "Ranger Cart Cleared Successfully") {
                  localStorage.setItem('gameStatus', 'S');
                  this.router.navigate(['/clubmanagement/livefleet']);
              }
              else if (response == "Error While Clearing Ranger Cart") {
                 
              }
              this.gameBtn = false;
              this.spinnerService.hide();
          },
          err => {
              this.gameBtn = false;
              this.spinnerService.hide();
          }
      );
  }    

  dateformats(val) {
      this.datearry = val.split("-");
      var strdate = this.datearry[1] + "/" + this.datearry[2] + "/" + this.datearry[0];
      return strdate;
  }

  // Removes the markers from the map, but keeps them in the array.
  clearMarkers() {
      this.setMapOnAll(null);
      this.markers=[];
  }
  // Sets the map on all markers in the array.
  setMapOnAll(map) {
      for (var i = 0; i < this.markers.length; i++) {
          this.markers[i].setMap(map);
      }
  }

  goBack() {
      localStorage.removeItem('playcartId');
      localStorage.removeItem('cartcolor');
      localStorage.removeItem('playcartname');
      localStorage.removeItem('sourceFrom');
      if(this.SourceFrom=="dashboard"){
          this.router.navigate(['/clubmanagement/dashboardnew']);
      }else{
          this.router.navigate(['/clubmanagement/livefleet']);
      }
  }

  over() {
      this.sub.unsubscribe();
  }

  mouseLeave() {
      this.sub = Observable.interval(1000 * 60).subscribe(x => {
          this.getcartcolor();
          this.getlastupdateddatetime();
          this.getclubcartmessages();
      });
  }

  getlastupdateddatetime() {
      let date = new Date(Date.now());
      let day1 = date.getDate();
      if (day1 < 10) {
          this.day = "0" + day1.toString();
      } else {
          this.day = day1.toString();
      }
      let month1 = date.getMonth() + 1;
      if (month1 < 10) {
          this.month = "0" + month1.toString();
      } else {
          this.month = month1.toString();
      }
      let hours = date.getHours();
      if (hours < 10) {
          this.hh = "0" + hours;
      }
      else { this.hh = hours; }

      let minuts = date.getMinutes();
      if (minuts < 10) {
          this.mm = "0" + minuts;
      }
      else { this.mm = minuts; }

      let seconds = date.getSeconds();
      if (seconds < 10) {
          this.ss = "0" + seconds;
      }
      else { this.ss = seconds; }

      let year = date.getFullYear();
      let todaydate = this.month + "." + this.day + "." + year + ' ' + this.hh + ":" + this.mm + ":" + this.ss;
      this.lastupdateddate = todaydate;
  }

  refreshpage() {
      this.getcartcolor();
      this.getlastupdateddatetime();
      this.getCartsList(); 
      this.invalidcls=1;
      this.getclubcartmessages();
  }

  //cart complete round confirmation
  openModalforCmpRound(template1: TemplateRef<any>) {
      this.templatecmprund = this.modalService.show(template1, { class: 'modal-sm' });        
  }

  confirmforcompleteround(): void {
      this.templatecmprund.hide();
      this.completeTheGame();
  }

  declineforcompleteround(): void {
      this.templatecmprund.hide();
  }

  //cart sign out confirmation
  openModalforCartsignout(template1: TemplateRef<any>) {
      this.templatecartsignout = this.modalService.show(template1, { class: 'modal-sm' });        
  }

  confirmforsignout(): void {
      this.templatecartsignout.hide();
      this.clearCart();
  }

  declineforsignout(): void {
      this.templatecartsignout.hide();
  }
  getCartsList() {
      let parameters = {
          clubid: parseInt(this.golfclubid),
          courseid: localStorage.getItem('courseId'),
          cartid: 0
      };
      this.api.postOH('getinplaycartdetailsv1', parameters).subscribe(
          (response) => {
              this.ddCartsList = [];
              for (var i = 0; i < response.length; i++) {
                  if (response[i].latitude != '') {
                      this.ddCartsList.push({
                          value: response[i].id,
                          name: response[i].name,
                          cartroletype:response[i].cartroletype
                      });
                  }
                 
              }
              let parameters1 = {
                  clubid: parseInt(this.golfclubid)
              };
              this.api.postOH('getrangersbeveragebagdropcartdetails', parameters1).subscribe(
                  (response1) => {
                      if (response1.length != 0) {
                          for (let j = 0; j < response1.length; j++) {
                              if (response1[j].latitude != '') {
                                  this.ddCartsList.push({
                                      value: response1[j].id,
                                      name: response1[j].name,
                                      cartroletype:response1[j].cartroletype
                                  });
                              }
                          }
                      }                  
                  });  
                  this.spinnerService.hide();              
          }, error => {
              this.spinnerService.hide();
          }
      );          
  }

  increaseZoom()
  {
      if(currentZoom <= maxZoom)
      {
          currentZoom = currentZoom + 1;
          this.map.setZoom(currentZoom);
      }
      else if(currentZoom > maxZoom)
      {
          currentZoom = currentZoom;
          this.map.setZoom(currentZoom);
      }
  }

  decreaseZoom()
  {
      if(currentZoom >= minZoom)
      {
          currentZoom = currentZoom - 1;
          this.map.setZoom(currentZoom);
      }
      else if(currentZoom < minZoom)
      {
          currentZoom = currentZoom;
          this.map.setZoom(currentZoom);
      }
  }

  getclubcartmessages() {
      this.clubcartmessages = [];
      this.allclubcartmessages = [];
      let parameters = {
          "clubid": this.golfclubid, "fromcartid": "0", "tocartid": this.cartid, "totalcount": "0"
      }
      this.api.postOH('Getclubcartmessages', parameters).subscribe(
          response => {
              if (response.length !== 0) {
                  if (response.length <= 9) {
                      this.viewall = false;
                  }
                  else if (response.length > 9) {
                      this.viewall = true;
                  }
                  this.spinnerService.hide();
                  for (let i = 0; i < response.length && i <= 9; i++) {
                      this.clubcartmessages.push({
                          "message": response[i].message,
                          "fromcartid": response[i].fromcartid,
                          "tocartid": response[i].tocartid,
                          "createddate": response[i].createddate,
                      })
                  }
                  for (let i = 0; i < response.length; i++) {
                      this.allclubcartmessages.push({
                          "message": response[i].message,
                          "fromcartid": response[i].fromcartid,
                          "tocartid": response[i].tocartid,
                          "createddate": response[i].createddate,
                      })
                  }
              }
          }, error => {
              this.spinnerService.hide();
          })
  }
  viewallmessages(template2: TemplateRef<any>) {
      this.templatemessages = this.modalService.show(template2, { class: 'modal-lg modal-sm' });
  }
  declineformessages(): void {
      this.templatemessages.hide();
  }
  sendMessage() {
     
      if (!this.messageForm.valid) {
          this.invalidcls=0;
      }
      this.submitAttempt = true;        
      var lcmessage=this.cartMessage;
      lcmessage=lcmessage.trim();
      if (lcmessage != '') {
          if (this.messageForm.valid) {
              this.buttontext = "Sending";
              var messageModal = { "action": "A", "id": 0, "clubid": this.golfclubid, "courseid": localStorage.getItem('courseId'), "fromcartid": 0, "tocartid": this.cartid, "message": this.cartMessage, "readstatus": "N", "userid": this.userId }
              this.api.postOH('savecartmessages', messageModal).subscribe(
                  response => {
                      this.spinnerService.hide();
                      if (response == "Success") {
                          this.invalidcls = 1;
                          let msg = '<span style="color: green">Message sent successfully</span>';
                          this.getclubcartmessages();
                          this.cartMessage = '';
                          this.toastMessage(msg);
                      } else {
                          let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                          this.toastMessage(msg);
                      }
                      this.buttontext = "Send";
                  },
                  err => {
                      this.spinnerService.hide();
                  }
              );
          }
      } else {
          this.cartMessage = '';
          this.invalidcls = 0;
          this.submitAttempt = true;
      }
  }
  toastMessage(msg) {
      let options = {
          positionClass: 'toast-top-center',
      };

      this.toastr.custom(msg, null, {
          enableHTML: true, toastLife: 3000,
          showCloseButton: true, 'positionClass': 'toast-bottom-right'
      });
  }
  showhidedata(val){
      if(val==1){
 
         this.fromdate = new Date();
         this.todate = new Date();
          this.showhistory=true;
          this.showcartsddl=false;
      }
      else if(val==2){
         this.showhistory=false;
         this.showcartsddl=true;
         
         this.maploading();
      }
     }
     trackCart() {
      this.spinnerService.show();
       //var fromdate = new Date(this.fromdate);
       var fromdate = new Date(this.todate);
      var todate = new Date(this.todate);
      if (fromdate > todate) {
          this.toastMessage('<span style="color: red">From date should be less than or equal to To date.</span>');
      }
      else {
          this.fromdate = fromdate;
          this.todate = todate;
          this.getpolylinedetails();
      }
    
  }
}
