import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router'
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Title } from '@angular/platform-browser';
import * as moment from "moment";

@Component({
  selector: 'app-schedulecourse',
  templateUrl: './schedulecourse.component.html',
  styleUrls: ['./schedulecourse.component.css']
})
export class SchedulecourseComponent implements OnInit {
  public courseSchedulingForm: FormGroup; submitAttempt: boolean = false;
  clubId: any = ''; courseId: any = '';
  action: any; scheduleId: number; frontNineCourseId: number; backNineCourseId: number; standAloneCourseId: number;
  fromDate: any; toDate: any; status: any;
  schBtn: any; scheduledCourseDates: any = []; courseDetails: any = [];
  showStatus: string = "none"; currentGolfClubDateTime: any; timeOffset: any;
  minStartDate: any; minEndDate: any;
  back9: any = []; front9: any = []; standAlone9: any = []; errorMessage: any = '';
  constructor(private title: Title, public toastr: ToastsManager, vcr: ViewContainerRef,
    private router: Router, public formBuilder: FormBuilder,
    private spinnerService: Ng4LoadingSpinnerService,
    private api: ApiService) {
    this.title.setTitle("IZON - Golf Course Schedule Dates");
    window.scrollTo(0, 0);
    this.toastr.setRootViewContainerRef(vcr);
    this.clubId = localStorage.getItem('clubId');
    this.action = "A";
  }

  ngOnInit() {
    this.courseSchedulingForm = this.formBuilder.group({
      fFNineCourseId: [0, Validators.compose([Validators.required])],
      fBNineCourseId: [0, Validators.compose([Validators.required])],
      fSACourseId: [0, Validators.compose([Validators.required])],
      fFromDate: ['', Validators.compose([Validators.required])],
      fToDate: ['', Validators.compose([Validators.required])],
      fStatus: ['']
    });
    this.getCourseDetails();
  }

  getCourseDetails() {
    this.courseDetails = []; this.timeOffset = ''; this.errorMessage = '';
    let parameters = { searchvalue: " WHERE GC_GCB_ID='" + this.clubId + "' AND GC_STATUS='Y'" };
    this.api.postOH('getgolfcourse', parameters).subscribe(
      (response) => {
        if (response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            this.courseDetails.push({
              value: response[i].id,
              name: response[i].labelname,
              timeoffset: response[i].timeoffset
            });
          }
        }

        if (this.courseDetails.length >= 2) {
          this.front9 = this.courseDetails;
          this.back9 = this.courseDetails;
          this.standAlone9 = this.courseDetails;
          this.frontNineCourseId = 0; this.backNineCourseId = 0; this.standAloneCourseId = 0;
          this.timeOffset = this.courseDetails[0].timeoffset;
          this.getCourseDateTime();
        } else {
          if(localStorage.getItem("nineholecourse")){
            this.router.navigate(['/cartmanagement/dashboard']);
          }
          else{
          this.errorMessage = "Not Applicable to schedule course";
          }
        }
      });
  }

  getCourseDateTime() {
    let currentDate: any = ''; this.currentGolfClubDateTime = '';
    let d = new Date();
    let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
    currentDate = new Date(utc + (3600000 * parseInt(this.timeOffset)));
    this.currentGolfClubDateTime = currentDate;
    this.minStartDate = this.minEndDate = this.fromDate = this.currentGolfClubDateTime;
    this.toDate = moment(this.currentGolfClubDateTime).add(1, 'd').toDate();
    this.getScheduledDates();
  }

  courseChange(val) {
    if (val == 1) {
      this.back9 = []; this.standAlone9 = [];
      this.backNineCourseId = 0; this.standAloneCourseId = 0;
    }
    else if (val == 2) {
      this.standAlone9 = [];
      this.standAloneCourseId = 0;
    }

    for (let i = 0; i < this.courseDetails.length; i++) {
      if (val == 1 && this.courseDetails[i].value != this.frontNineCourseId) {
        this.back9.push({
          value: this.courseDetails[i].value,
          name: this.courseDetails[i].name,
          timeoffset: this.courseDetails[i].timeoffset
        });
        this.standAlone9.push({
          value: this.courseDetails[i].value,
          name: this.courseDetails[i].name,
          timeoffset: this.courseDetails[i].timeoffset
        });
      }
      else if (val == 2 && this.courseDetails[i].value != this.frontNineCourseId && this.courseDetails[i].value != this.backNineCourseId) {
        this.standAlone9.push({
          value: this.courseDetails[i].value,
          name: this.courseDetails[i].name,
          timeoffset: this.courseDetails[i].timeoffset
        });
      }
    }
  }

  saveShceduleDates() {
    if (this.fromDate != ('' || null) && this.toDate != ('' || null)) {
      if (moment(this.fromDate).format('MM/DD/YYYY') <= moment(this.toDate).format('MM/DD/YYYY')) {
        if (!this.courseSchedulingForm.valid) {

        }
        this.submitAttempt = true;
        if (this.frontNineCourseId > 0 && this.backNineCourseId > 0) {
          this.schBtn = true;
          var scheduledDatesModel = {
            "Action": this.action, "ScheduledId": this.scheduleId, "ClubId": this.clubId,
            "FrontNineCourseId": this.frontNineCourseId, "BackNineCourseId": this.backNineCourseId,
            "StandAloneCourseId": this.standAloneCourseId, "FromDate": moment(this.fromDate).format('MM/DD/YYYY HH:mm:ss'),
            "ToDate": moment(this.toDate).format('MM/DD/YYYY HH:mm:ss'), "Status": (this.status == true) ? "Y" : "N"
          }
          this.spinnerService.show();
          this.api.postOH('saveGolfCourseScheduledDates', scheduledDatesModel).subscribe(
            response => {
              if (response.length > 0) {
                if (response[0] > 0) {
                  this.getScheduledDates();
                  let msg = '<span style="color: green">Golf course scheduled successfully</span>';
                  this.toastMessage(msg); this.courseSchedulingForm.reset();
                }
                else {
                  let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                  this.toastMessage(msg);
                }
              } else {
                let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                this.toastMessage(msg);
              }
              window.scrollTo(0, 0);
              this.spinnerService.hide();
              this.schBtn = false;
            },
            err => {
              this.spinnerService.hide();
              this.schBtn = false;
            }
          );
        }
      } else {
        let msg = '<span style="color: red">From Date should be less than or equal to To Date</span>';
        this.toastMessage(msg);
      }
    }
    else {
      let msg = '<span style="color: red">Please enter valid dates</span>';
      this.toastMessage(msg);
    }
  }

  getScheduledDates() {
    this.submitAttempt = false; let fromDate: any = ''; let toDate: any = '';
    this.scheduledCourseDates = []; this.spinnerService.show();
    let params = { "ClubId": this.clubId }
    this.api.postOH('GetGolfCourseScheduledDates', params).subscribe(
      response => {
        this.scheduledCourseDates = [];
        this.spinnerService.hide();
        if (response.ResponseCode == 'Success') {
          this.action = "U";
          this.scheduleId = response.ScheduledDatesList[0].ScheduledId;
          this.clubId = response.ScheduledDatesList[0].ClubId;
          this.frontNineCourseId = response.ScheduledDatesList[0].FrontNineCourseId;
          this.courseChange('1');
          this.backNineCourseId = response.ScheduledDatesList[0].BackNineCourseId;
          this.courseChange('2');
          this.standAloneCourseId = (response.ScheduledDatesList[0].StandAloneCourseId > 0) ? response.ScheduledDatesList[0].StandAloneCourseId : 0;
          this.fromDate = new Date(response.ScheduledDatesList[0].FromDate);
          this.toDate = new Date(response.ScheduledDatesList[0].ToDate);
          if (moment(this.fromDate).format('MM/DD/YYYY') > moment(this.currentGolfClubDateTime).format('MM/DD/YYYY')) {
            this.minStartDate = this.currentGolfClubDateTime;
          } else {
            this.minStartDate =  new Date(response.ScheduledDatesList[0].FromDate);
          }
          if (moment(this.toDate).format('MM/DD/YYYY') > moment(this.currentGolfClubDateTime).format('MM/DD/YYYY')) {
            this.minEndDate = this.currentGolfClubDateTime;
          } else {
            this.minEndDate = new Date(response.ScheduledDatesList[0].ToDate);
          }
          this.minStartDate = this.currentGolfClubDateTime;
          this.minEndDate = this.currentGolfClubDateTime;
          this.status = (response.ScheduledDatesList[0].Status == 'Y') ? true : false;
          this.showStatus = "block";
        } else {
          this.action = "A"; this.scheduleId = 0; this.frontNineCourseId = 0;
          this.backNineCourseId = 0; this.standAloneCourseId = 0; this.showStatus = "none";
          this.fromDate = this.currentGolfClubDateTime;
          this.minEndDate = this.currentGolfClubDateTime;
          this.minStartDate = this.currentGolfClubDateTime;
          this.toDate = moment(this.currentGolfClubDateTime).add(1, 'd').toDate();
        }
      },
      err => {
        this.spinnerService.hide();
      }
    );
  }

  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',
    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 3000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }


}
