import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SchedulecourseComponent } from './schedulecourse.component';

describe('SchedulecourseComponent', () => {
  let component: SchedulecourseComponent;
  let fixture: ComponentFixture<SchedulecourseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SchedulecourseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SchedulecourseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
