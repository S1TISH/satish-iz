import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-versionlog',
  templateUrl: './versionlog.component.html',
  styleUrls: ['./versionlog.component.css']
})
export class VersionlogComponent implements OnInit {

  constructor() {
    window.scrollTo(0, 0);
   }

  ngOnInit() {
  }

}
