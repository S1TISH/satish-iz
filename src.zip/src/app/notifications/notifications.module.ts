import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

//import { NotificationsComponent } from './notifications/notifications.component';

const routes: Routes = [
  // {
  //   path:'',
  //   component:NotificationsComponent
  // }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule, ReactiveFormsModule
  ],
  exports: [RouterModule],
  //declarations: [NotificationsComponent]
})
export class NotificationsModule { }
