import { ApiService } from '../../services/api.service';
import { Component, OnInit, ElementRef, ViewChild, AfterViewChecked } from '@angular/core';
import { Http, RequestOptions, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { AuthService } from '../../services/auth.service';
import * as moment from "moment";


@Component({
    selector: 'app-notifications',
    templateUrl: './notifications.component.html',
    styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit, AfterViewChecked {
    @ViewChild('scrollMe') public elementRef: ElementRef;
    faminus: any = true;
    faclose: any = true; clubid: string; sub: any;
    reasons: any = [];timeoffset: any = '';
    currentGolfClubDateTime: any; courselat: any; courselong: any;
    constructor(private http: Http, private elem: ElementRef, private apiService: ApiService, private authService: AuthService, ) {
        this.authService.getClubIdForHeader.subscribe(
            (name: string) => {
                if (name === undefined || name === '' || name === null) {
                    this.reasons = [];
                } else {
                    this.LoadMessages();
                }
            }
        );
    }

    ngOnInit() {
        if (localStorage.getItem('clubId') != null && localStorage.getItem('clubId') != '' && localStorage.getItem('clubId') != undefined) {
            this.clubid = localStorage.getItem('clubId');
        } else {
            this.clubid = '0';
        }
        this.sub = Observable.interval(1000 * 60).subscribe(x => {
            if (localStorage.getItem('clubId') != null && localStorage.getItem('clubId') != '' && localStorage.getItem('clubId') != undefined) {
                this.LoadMessages();
            }
        });
    }
    ngAfterViewChecked() {
        this.scrollToBottom();
    }
    scrollToBottom(): void {
        try {
            this.elementRef.nativeElement.scrollTop = this.elementRef.nativeElement.scrollHeight;
        } catch (err) { }
    }

    LoadMessages() {
        this.clubid = localStorage.getItem('clubId');
        this.currentGolfClubDateTime = "";
        var searchexp = " WHERE GC_GCB_ID='" + this.clubid + "' and GC_STATUS='Y' "
        let parameters1 = { searchvalue: searchexp };
        this.apiService.postOH('getgolfcourse', parameters1).subscribe(
            response => {
                if (response.length !== 0) {
                    this.courselat = response[0].latitude;
                    this.courselong = response[0].longitude;
                    this.timeoffset = response[0].timeoffset;
                    let currentDate: any = '';
                    let d = new Date();
                    let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
                    currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
                    this.currentGolfClubDateTime = moment(currentDate).format('YYYY-MM-DD');
                  
                    // this.apiService.getDateTime(this.courselat, this.courselong, timestamp).subscribe(
                    //     (response) => {
                    //         if (response.timeZoneId != null) {
                    //             var offsets = response.dstOffset * 1000 + response.rawOffset * 1000
                    //             var localdate = new Date(timestamp * 1000 + offsets)
                    //             this.currentGolfClubDateTime = moment(localdate).format('YYYY-MM-DD');
                    //         }
                    //         else {
                    //             this.currentGolfClubDateTime = moment(currentDate).format('YYYY-MM-DD');
                    //         }
                            var obj = {
                                "clubid": parseInt(this.clubid),
                                "dateString":this.currentGolfClubDateTime
                            };
                            this.apiService.postOH('GetCartMessageAlerts', obj).subscribe(
                                (data) => {
                                    //console.log(data);
                                    this.reasons = [];
                                    if (data.GetCartMessageAlertsResult.length !== 0) {
                                        for (let i = 0; i < data.GetCartMessageAlertsResult.length; i++) {
                                            if (data.GetCartMessageAlertsResult[i].clubid == this.clubid) {
                                                this.reasons.push({
                                                    "Id": data.GetCartMessageAlertsResult[i].id,
                                                    "message": data.GetCartMessageAlertsResult[i].message,
                                                    "clubid": data.GetCartMessageAlertsResult[i].clubid,
                                                    "cartname": data.GetCartMessageAlertsResult[i].carname,
                                                    "date": moment(data.GetCartMessageAlertsResult[i].date).format('MMM DD, YYYY, hh:mm:ss A')
                                                });
                                            }
                                        }
                                    } else {
                                    }
                                }
                            );

                        // }, error => {
                        // }
                   // );
                }
            });


    }

    getDateTime(date,offset) {
        let d = new Date(date);
        let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
        var currentDate = new Date(utc + (3600000 * offset));
        return currentDate;
    }

    removeReason(reason, index, type) {
        if (type == 'A') {
            var alertinfo = {
                "clubid": this.clubid,
                "alertid": reason.Id
            }
            this.apiService.postOH('SaveAlertStatus', alertinfo).subscribe(
                (response) => {
                    if (response.SaveAlertStatusResult == "Success") {
                        this.reasons.splice(index, 1);
                    }
                }, error => {
                    console.log(error);
                });
        } else {
            this.reasons.splice(index, 1);
        }
    }

    faminusclick() {
        this.faminus = !this.faminus;
    }
    facloseclick() {
        this.faclose = !this.faclose;
    }

}
