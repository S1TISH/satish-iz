import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoodbeverageComponent } from './foodbeverage.component';

describe('FoodbeverageComponent', () => {
  let component: FoodbeverageComponent;
  let fixture: ComponentFixture<FoodbeverageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoodbeverageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoodbeverageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
