import { Component, OnInit, ViewContainerRef, TemplateRef, Query, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';
import { Router, ChildrenOutletContexts } from '@angular/router';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Title } from '@angular/platform-browser';
import * as $ from 'jquery';
import { DomSanitizer } from '@angular/platform-browser';
import { query } from '@angular/animations';
import { NumberFormatStyle } from '@angular/common';
import { last } from 'rxjs/operator/last';
import * as html2canvas from 'html2canvas';
//import { NgxPicaService, NgxPicaErrorInterface } from 'ngx-pica';


var filename; var count = 0; var index = [];
var mainMenuCount = 0; var mainindex = []; var deleteditem = []; var divdblclickcount = 0;
var mainiddeletefromgrid = 0; var subiddeletefromgrid = 0; 


var editedbrandlogo = ''; var editedclublogo = '';

@Component({
    selector: 'app-foodbeverage',
    templateUrl: './foodbeverage.component.html',
    styleUrls: ['./foodbeverage.component.css']
})
export class FoodbeverageComponent implements OnInit {
    modalRef: BsModalRef;
    public modulesForm: FormGroup; submitAttempt: boolean = false; divheader: string = "Add Food Type";
    searchtxt: boolean = true; searchddl: boolean = false;
    modulesdata: any; submodulesdata: any;
    contentShow: string = "none"; gridShow: string = "none";
    viewcontentShow: string = "none"; coursegridShow: string = "none";

    action: string = 'A'; mdid: string = "0"; smdid: string = "0"; mainmodid: string = "0"; searchvalue: string = '  WHERE MOD_M_ID=0 ';
    mdname: string; brandname: string; glyphicon: string; description: string; price: string = '0.00'; profileimage: any = ''; profileimagepath: any = ''; profilebinaryimage: any = ''; profileimagename: string;
    lblmdname: string; lblbrandname: string; lblglyphicon: string; lbldesc: string; lblprice: string;
    clubtxtsts: string = 'Active'; txtsrch: string = '';
    GridMessage: string = 'Loading, Please wait ... !'; showmenustatus: any = 'N';
    srchError: string = '0'; status: boolean = false; chksts: string = 'Y'; chkshowonmenu: string = 'Y';
    editModData: any = []; type: string = 'M'; lblname: string = "Menu Name";
    golfclubid: any;
    key: string = 'name';
    reverse: boolean = false; reverse1: boolean = false; ddlsearch: any;
    brandHide: string = "none"; priceHide: string = "none";
    selectedoption: any = "Active"; randomcolor: any = "#5cb85c";

    //for beverages
    usersdata: any; roledata: any; clubusers: any; beverageData: any;
    id: any; modifiedUid: any; modifyingUid: any; previousRoleid: any; modifiedRoleid: any;
    beveragestatus: any; beveragechkstatus: any; initialroleid: any;
    nameasc: any = "sortwhite"; namedesc: any = "sortgreen"; roleasc: any = "sortwhite"; roledesc: any = "sortwhite";
    priceasc: any = "sortwhite"; pricedesc: any = "sortgreen";

    dataobjforcancel: any; menuimage: any = ''; menuimagepath: any = ''; menubinaryimage: any = ''; menuimagename: string;
    imagecropped: any; menuimagecropped: any; templatetype: any; templateid: any = 0; editTmpId: any;

    menuimagedivhide: any = "none";
    menutemplatedivhide: any = "none"; showTemplateDesign: any = "none"; editTemplateDesign: any = "none";

    //template
    templateId: any; arr: any = []; innerHTML: any = '';
    sampledesign1: any; sampledesign2: any; sampledesign3: any; mainarr = [];
    submenuarr = [];
    viewtemplate: any; edittemplate: any; tempdata: any;

    brandlogoimagepath: any = ''; brandlogoimagename: any = ''; imagecropped1: any = '';
    clublogoimagepath: any = ''; clublogoimagename: any = ''; imagecropped2: any = '';
    editbrandlogoimagepath: any; editclublogoimagepath: any; editbrandlogoimagename: any; editclublogoimagename: any;
    imagecropped3: any; imagecropped4: any; editClubLogoImagepath: any;

    dblclicked: any = false;  browsingImage: any = false; templateerrormsg: any;
    previewtemplate: any;

    htmltemplateimage: any;

    constructor(private sanitizer: DomSanitizer, private title: Title, private modalService: BsModalService, public toastr: ToastsManager, vcr: ViewContainerRef, private _router: Router, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService, private authService: AuthService) {

        this.title.setTitle("IZON - Beverage Cart");
        this.toastr.setRootViewContainerRef(vcr);
        this.ddlsearch = "MT_NAME";
        this.contentShow = "none"; this.gridShow = "none";
        this.modulesdata = []; this.submodulesdata = [];
        this.golfclubid = localStorage.getItem('clubId');

        //for beverages
        this.usersdata = []; this.roledata = []; this.clubusers = []; this.beverageData = []; this.initialroleid = [];
        this.modifyingUid = localStorage.getItem('userId');
    }

    ngOnInit() {
        this.modulesForm = this.formBuilder.group({
            fmdname: ['', Validators.compose([Validators.required])],
            fbrandname: [''],
            fdesc: ['', Validators.compose([Validators.required])],
            fprice: [''],
            status: [''],
            templatetype: ['' && this.action == 'A', Validators.compose([Validators.required])]
        });

        this.templateid = 0;

        this.searchvalue = " WHERE MT_MT_ID= 0 AND MT_GCB_ID=" + this.golfclubid + " AND MT_STATUS= 'Y'";
        let parameters = { searchvalue: this.searchvalue };
        this.GetFoodtypesData(parameters);


        this.getClubUsers();
        let parameters1 = { searchvalue: " WHERE U_STATUS = 'Y' " };
        this.getUsers(parameters1);

        this.getRoles();

        this.viewgetBeverages();

        this.gridShow = "block";
        this.contentShow = "none";
    }

    refreshpage() {
        this.srchError = '0';
        this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
        let parameters = { searchvalue: " WHERE MT_MT_ID= 0 AND MT_GCB_ID=" + this.golfclubid + " AND MT_STATUS= 'Y'" };
        this.GetFoodtypesData(parameters);
        this.ddlsearch = "MT_NAME";
    }

    search() {
        if (this.txtsrch == '') {
            this.srchError = '1';
        }
        else if (this.txtsrch != '') {
            let parameters = {
                searchvalue: " WHERE MT_MT_ID=0 AND MT_GCB_ID=" + this.golfclubid + " AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' and MT_STATUS<>'D' "
            };
            this.GetFoodtypesData(parameters);
            this.txtsrch = "";
            this.srchError = '0';
        }
    }

    sortFood(value: string) {
        this.key = value;
        this.nameasc = "sortwhite"; this.namedesc = "sortwhite";
        this.priceasc = "sortwhite"; this.pricedesc = "sortwhite";
        if (this.key == value) {
            this.reverse1 = !this.reverse1;
            if (this.key == "name" && this.reverse1) {
                this.namedesc = "sortgreen";
            }
            else if (this.key == "name" && (!this.reverse1)) {
                this.nameasc = "sortgreen";
            } else if (this.key == "price" && this.reverse1) {
                this.priceasc = "sortgreen";
            }
            else if (this.key == "price" && (!this.reverse1)) {
                this.pricedesc = "sortgreen";
            }
        }
    }

    bindselectedoption(selectedoption) {
        this.srchError = '0';
        if (this.selectedoption == 'Active') {
            this.randomcolor = "#5cb85c";
            this.srchSts('Y');
        }
        else if (this.selectedoption == 'In-Active') {
            this.randomcolor = "#337ab7";
            this.srchSts('N');
        }
        else if (this.selectedoption == 'Deleted') {
            this.randomcolor = "#d9534f";
            this.srchSts('D');
        }
    }

    srchSts(type) {
        let parameters = {
            searchvalue: " WHERE MT_MT_ID=0 AND MT_GCB_ID=" + this.golfclubid + " AND MT_STATUS='" + type + "'"
        };
        this.GetFoodtypesData(parameters);
    }

    srchKeyUp(event: any) {
        if (this.txtsrch != '') {
            this.srchError = '0';
        }
    }

    GetFoodtypesData(parameters) {
        this.spinnerService.show();
        this.api.postOH('getfoodmenutypes', parameters).subscribe(
            (response) => {
                this.modulesdata = [];
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                    var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var confirmshow = "row-icon-inactive";

                    this.modulesdata.push({
                        "id": response[i].id,
                        "subid": response[i].subid,
                        "name": response[i].name,
                        "brandname": response[i].brandname,
                        "description": response[i].description,
                        "createdby": response[i].updatedby,
                        "createddate": response[i].createddate,
                        "status": status,
                        "statusclass": statusclass,
                        "image": response[i].image,
                        "imagepath": response[i].imagepath,
                        "menuimage": response[i].menuimage,
                        "menuimagepath": response[i].menuimagepath,
                        "templatetype": response[i].templatetype,
                        "templateimage": response[i].templateimage,
                        "htmltext": response[i].htmltext,
                        "templateid": response[i].templateid,
                        "price": '0.00'
                    });
                }
                {
                    this.GridMessage = "No Data Found";
                }
                this.spinnerService.hide();

            }, error => {
                this.spinnerService.hide();
            }
        );
    }

    getfooditemsdetailstable(parameters) {
        this.submodulesdata = [];
        this.spinnerService.show();
        this.api.postOH('getfoodmenutypes', parameters).subscribe(
            (response) => {
                this.submodulesdata = [];
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                    var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var confirmshow = "row-icon-inactive";

                    this.submodulesdata.push({
                        "id": response[i].id,
                        "subid": response[i].subid,
                        "name": response[i].name,
                        "brandname": response[i].brandname,
                        "description": response[i].description,
                        "createdby": response[i].updatedby,
                        "createddate": response[i].createddate,
                        "status": status,
                        "statusclass": statusclass,
                        "price": response[i].price,
                        "image": response[i].image,
                        "imagepath": response[i].imagepath,
                        "menuimage": response[i].menuimage,
                        "menuimagepath": response[i].menuimagepath,
                        "templatetype": response[i].templatetype,
                        "templateimage": response[i].templateimage,
                        "htmltext": response[i].htmltext,
                        "templateid": response[i].templateid
                    });
                }
                {
                    this.GridMessage = "No Data Found";
                }
                this.spinnerService.hide();

            }, error => {
                this.spinnerService.hide();
            }
        );
    }

    viewfoods(moduledata, type) {
        let parameters = { searchvalue: "  WHERE MT_ID=" + moduledata.id + " AND MT_GCB_ID=" + this.golfclubid + "" };
        this.api.postOH('getfoodmenutypes', parameters).subscribe(
            (response) => {
                let foodmodulesdata: any = [];
                if (response.length > 0) {
                    foodmodulesdata = [];
                    for (let i = 0; i < response.length; i++) {
                        var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                        var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                        var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                        var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                        var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                        var confirmshow = "row-icon-inactive";

                        foodmodulesdata.push({
                            "id": response[i].id,
                            "subid": response[i].subid,
                            "name": response[i].name,
                            "brandname": response[i].brandname,
                            "description": response[i].description,
                            "createdby": response[i].updatedby,
                            "createddate": response[i].createddate,
                            "status": status,
                            "statusclass": statusclass,
                            "image": response[i].image,
                            "imagepath": response[i].imagepath,
                            "menuimage": response[i].menuimage,
                            "menuimagepath": response[i].menuimagepath,
                            "templatetype": response[i].templatetype,
                            "templateimage": response[i].templateimage,
                            "htmltext": response[i].htmltext,
                            "templateid": response[i].templateid,
                            "price": response[i].price
                        });
                    }
                    //this.spinnerService.hide();
                    window.scrollTo(0, 0);
                    this.type = type;
                    this.editModData = foodmodulesdata[0];
                    this.mainmodid = foodmodulesdata[0].id;
                    this.action = 'V';
                    this.viewcontentShow = "block"; this.contentShow = "none";
                    this.gridShow = "none"; this.coursegridShow = "block";

                    this.mdid = foodmodulesdata[0].id;
                    this.lblmdname = (!foodmodulesdata[0].name) ? "" : foodmodulesdata[0].name;
                    this.lblbrandname = (!foodmodulesdata[0].brandname) ? "" : foodmodulesdata[0].brandname;
                    this.lbldesc = (!foodmodulesdata[0].description) ? "" : foodmodulesdata[0].description;
                    this.lblprice = (!foodmodulesdata[0].price) ? "" : foodmodulesdata[0].price;
                    this.clubtxtsts = foodmodulesdata[0].status;
                    this.profileimagepath = (!foodmodulesdata[0].imagepath) ? "" : foodmodulesdata[0].imagepath;

                    this.menuimagename = (!foodmodulesdata[0].menuimage) ? "" : foodmodulesdata[0].menuimage;
                    this.menuimagepath = (!foodmodulesdata[0].menuimagepath) ? "" : foodmodulesdata[0].menuimagepath;
                    this.templatetype = foodmodulesdata[0].templatetype;
                    this.templateid = foodmodulesdata[0].templateid;
                    if(this.type == 'M' && (foodmodulesdata[0].templatetype == 'TM' || foodmodulesdata[0].templatetype == 'IM'))
                    {
                        this.dataobjforcancel = foodmodulesdata[0];
                    }
                    
                    if (type == 'M' && foodmodulesdata[0].templatetype == 'FM') {
                        this.dataobjforcancel = foodmodulesdata[0];
                        let parameters = { searchvalue: "  WHERE MT_MT_ID=" + foodmodulesdata[0].id + " AND MT_GCB_ID=" + this.golfclubid + " and MT_STATUS<>'D' " };
                        this.getfooditemsdetailstable(parameters);
                    }
                    else if (type == 'S' && foodmodulesdata[0].templatetype == 'FM') {
                        this.viewcontentShow = "block"; this.contentShow = "none";
                        this.gridShow = "none"; this.coursegridShow = "none";
                        this.getfooditemsdetailstable(parameters);
                    }
                    this.viewtemplate = (!foodmodulesdata[0].templateimage) ? "" : foodmodulesdata[0].templateimage;
                    this.templatetype = foodmodulesdata[0].templatetype;
                 }
                else {
                    this.GridMessage = "No Data Found";
                }
            }, error => {
                this.spinnerService.hide();
            }
        );
    }

    cancel() {
        this.templateId = 0;
        this.modulesForm.controls['fmdname'].reset();
        this.modulesForm.controls['fbrandname'].reset();
        this.modulesForm.controls['fdesc'].reset();
        this.modulesForm.controls['templatetype'].reset();
        this.modulesForm.controls['templatetype'].enable();
        $('.container').css('opacity', '1');
        $('.container').css('cursor', 'pointer');

        this.browsingImage = false;
        this.menuimagepath = ""; this.menuimagecropped = "";
        this.profileimagepath = ""; this.imagecropped = "";

        index = []; mainindex = []; deleteditem = []; count = 0; mainMenuCount = 0; divdblclickcount = 0;
        this.arr = []; this.mainarr = []; this.submenuarr = [];

        if (this.type == 'M' && this.action == 'A') {
            this.menuimagepath = ""; this.menuimagecropped = "";
            this.profileimagepath = ""; this.imagecropped = "";
            this.brandlogoimagename = ''; this.imagecropped1 = ''; this.brandlogoimagepath = '';
            this.clublogoimagename = ''; this.imagecropped2 = ''; this.clublogoimagepath = '';
            this.editbrandlogoimagename = ''; this.imagecropped3 = ''; this.editbrandlogoimagepath = '';
            this.editclublogoimagename = ''; this.imagecropped4 = ''; this.editclublogoimagepath = ''; this.editClubLogoImagepath = '';
            this.htmltemplateimage = "";
            this.gridShow = "block";
            this.contentShow = "none";
            this.viewcontentShow = "none";
            this.coursegridShow = "none";
            this.menuimagedivhide = "none";
            this.showTemplateDesign = "none";
            this.menutemplatedivhide = "none";
            this.editTemplateDesign = "none";
            this.templateid = 0;
            this.dblclicked = false;
            this.templateerrormsg = '';
        }
        else if (this.type == 'M' && this.action == 'U') {
            this.templateerrormsg = '';
            this.gridShow = "none";
            this.contentShow = "none";
            this.viewcontentShow = "block";
            this.coursegridShow = "block";
            this.menuimagedivhide = "none";
            this.showTemplateDesign = "none";
            this.menutemplatedivhide = "none";
            this.editTemplateDesign = "none";
            this.editTmpId = 0;
            this.templateid = 0;
            this.dblclicked = false;
            this.viewfoods(this.dataobjforcancel, 'M');
            this.menuimagepath = ""; this.menuimagecropped = "";
            this.profileimagepath = ""; this.imagecropped = "";
            this.htmltemplateimage = "";
            this.templateerrormsg = '';
        }
        else {           
            this.templateerrormsg = '';
            this.htmltemplateimage = "";
            this.gridShow = "none";
            this.contentShow = "none";
            this.viewcontentShow = "block";
            this.coursegridShow = "block";
            this.viewfoods(this.dataobjforcancel, 'M');
        }

    }

    addfoods(type) {
        this.templateerrormsg = "";
        this.htmltemplateimage = "";
        this.modulesForm.controls['templatetype'].enable();
        $('.container').css('opacity', '1');
        $('.container').css('cursor', 'pointer');
        this.browsingImage = false;
        index = []; mainindex = []; deleteditem = []; count = 0; mainMenuCount = 0; divdblclickcount = 0;
        this.arr = []; this.mainarr = []; this.submenuarr = [];
        this.editTemplateDesign = false;
        this.templateid = 0;
        count = 0;
        $('#mainitem').val('');
        this.brandlogoimagename = ''; this.imagecropped1 = ''; this.brandlogoimagepath = '';
        this.clublogoimagename = ''; this.imagecropped2 = ''; this.clublogoimagepath = '';
        this.editbrandlogoimagename = ''; this.imagecropped3 = ''; this.editbrandlogoimagepath = '';
        this.editclublogoimagename = ''; this.imagecropped4 = ''; this.editclublogoimagepath = ''; this.editClubLogoImagepath = '';
        this.arr = [];

        this.profileimage = "";
        this.profileimagepath = "";
        this.profilebinaryimage = "";
        this.profileimagename = "";

        this.menuimage = "";
        this.menuimagepath = "";
        this.menubinaryimage = "";
        this.menuimagename = "";
        this.templatetype = "";
        this.type = type;
        //this.modulesForm.reset();
        this.gridShow = "none"; this.viewcontentShow = "none";
        this.contentShow = "block"; this.coursegridShow = "none";

        this.divheader = (type == 'M') ? "Add Food Type" : "Add Food Item";
        this.action = 'A';
        if (type == 'M') {
            this.divheader = "Add Food Type";
            this.mdid = "0"; this.smdid = "0";
            this.lblname = "Menu Name";
            this.brandHide = "none";
            this.priceHide = "none";
        }
        else {
            this.divheader = "Add Food Item";
            this.smdid = this.mainmodid; this.mdid = "0";
            this.lblname = "Menu Name";
            this.brandHide = "none";
            this.priceHide = "block";
            this.templatetype = "FM";
        }
        this.submitAttempt = false;
        this.mdname = "";
        this.brandname = "";
        this.glyphicon = "";
        this.description = "";
        this.showmenustatus = false;
        this.chkshowonmenu = "N";
        this.price = "0.00";
        this.imagecropped = "";
        this.menuimagecropped = "";
        this.chksts = 'Y';
    }

    allowNumbersAndDecimals(e) {
        if (e.which != 46 && e.which != 45 && e.which != 46 &&
            !(e.which >= 48 && e.which <= 57)) {
            return false;
        }
    }

    allowNumbersDecimalsSpecialCharacters(e) {
        if (e.which != 46 && e.which != 45 && e.which != 46 &&
            !(e.which >= 33 && e.which <= 57)) {
            return false;
        }
    }

    //edit record
    editfoods() {
        //console.log(this.editModData);
        // this.imagecropped = "";
        // this.menuimagecropped = "";
        // this.htmltemplateimage = "";
        this.templateerrormsg = "";
        this.innerHTML = '';
        if (this.type == 'M') {
            this.divheader = "Edit Food Type";
            this.lblname = "Menu Name";
            this.brandHide = "none";
            this.priceHide = "none";
            this.templatetype = this.editModData.templatetype;
            var selectedoption = $("input[name='templatetype']:checked").val();
            for(var i = 0; i < $("input:radio:not(:checked)").length; i++)
            {
                var item = $("input:radio:not(:checked)")[i].getAttribute('value');
                if(item)
                {
                    $("input[type=radio][value=" + item + "]").attr("disabled", "disabled");
                    $(".container").css('cursor','not-allowed');
                    $(".container").css('opacity','0.5');
                }
            }
        }
        else {
            this.divheader = "Edit Food Item";
            this.lblname = "Menu Name";
            this.smdid = this.editModData.subid;
            this.mainmodid = this.editModData.subid;
            this.brandHide = "none";
            this.priceHide = "block";
        }
        this.mdid = this.editModData.id;
        this.action = 'U';
        this.gridShow = "none";
        this.templatetype = this.editModData.templatetype;
        this.mdname = this.editModData.name;
        this.brandname = this.editModData.brandname;
        this.description = this.editModData.description;
        this.price = this.editModData.price;
        this.status = (this.editModData.status == 'Active') ? true : false;
        this.chksts = (this.editModData.status == 'Active') ? 'Y' : 'N';
        this.contentShow = "block"; this.viewcontentShow = "none"; this.coursegridShow = "none";
        this.gridShow = "none";
        if(this.templatetype == 'FM')
        {
            this.profileimagename = (!this.editModData.image) ? "" : this.editModData.image;
            this.profileimagepath = (!this.editModData.imagepath) ? "" : this.editModData.imagepath;
        }
        else if(this.templatetype == 'IM')
        {
            this.menuimagename = (!this.editModData.menuimage) ? "" : this.editModData.menuimage;
            this.menuimagepath = (!this.editModData.menuimagepath) ? "" : this.editModData.menuimagepath; 
        }
        if(this.templatetype == 'TM')
        {    
            this.htmltemplateimage = "";
        }
        if (this.editModData.htmltext != "" || this.editModData.htmltext != undefined) {
            this.tempdata = this.editModData.htmltext;
            this.edittemplate = this.changehtml(this.editModData.htmltext);
        }
        this.templateid = this.editModData.templateid;

        this.templateId = this.templateid;
        this.templatetypechange();

    }

    changests(stat) {
        this.chksts = (stat == true) ? 'Y' : 'N';
        if(this.chksts == 'Y')
        {
            this.status = true;
        } 
        else if(this.chksts == 'N')
        {
            this.status = false;
        }
    }

    // changeshowmenu(e) {
    //     this.chkshowonmenu = (e.target.checked == true) ? 'Y' : 'N';
    // }

    goBack() {
        this.gridShow = "block";
        this.contentShow = "none";
        this.viewcontentShow = "none";
        this.coursegridShow = "none";
        this.action = 'A';
        if (this.type == 'S') {
            this.viewfoods(this.dataobjforcancel, 'M');
        }
    }

    templatetypechange() {
        if(this.action == 'A' && this.templatetype != '')
        {
            var selectedoption = $("input[name='templatetype']:checked").val();
            for(var i = 0; i < $("input:radio:not(:checked)").length; i++)
            {
                var item = $("input:radio:not(:checked)")[i].getAttribute('value');
                if(item)
                {
                    $("input[type=radio][value=" + item + "]").attr("disabled", "disabled");
                    $(".container").css('cursor','not-allowed');
                    $(".container").css('opacity','0.5');
                }
            }
        }
        if (this.templatetype == "FM") {
            this.menuimagedivhide = "none";
            this.menutemplatedivhide = "none";
            this.innerHTML = "";
            this.edittemplate = "";
            this.viewtemplate = "";
            this.templateid = 0;
            this.templateId = 0;
            this.menuimagepath = ""; this.menuimagecropped = ""; this.menuimage = "";
            this.htmltemplateimage = "";
            //this.profileimagepath = ""; this.imagecropped = "";
            // this.editbrandlogoimagepath = ''; this.editbrandlogoimagepath = '';
            // this.clublogoimagepath = ''; this.editclublogoimagepath = ''; this.editClubLogoImagepath = '';
        }
        else if (this.templatetype == "IM") {
            this.menutemplatedivhide = "none";
            this.menuimagedivhide = "block";
            this.innerHTML = "";
            this.edittemplate = "";
            this.viewtemplate = "";
            this.templateid = 0;
            this.templateId = 0;  
            //this.menuimagepath = ""; this.menuimagecropped = "";
            this.profileimagepath = "";  this.imagecropped = ""; this.profileimage = "";
            this.htmltemplateimage = "";
            this.templateerrormsg = "";
            // this.editbrandlogoimagepath = ''; this.editbrandlogoimagepath = '';
            // this.clublogoimagepath = ''; this.editclublogoimagepath = ''; this.editClubLogoImagepath = '';
        }
        else if (this.templatetype == "TM") {
            if (this.action == 'A') {
                this.menuimagedivhide = "none";
                this.editTemplateDesign = "none";
                this.menutemplatedivhide = "block";
                this.innerHTML = "";
                this.menuimagecropped = "";
                this.menuimagepath = ""; this.menuimage = "";
                this.profileimagepath = "";  this.imagecropped = ""; this.profileimagename = ''; this.profileimage = "";
            }
            else if (this.action == 'U' && this.edittemplate == '') {
                this.menuimagedivhide = "none";
                this.editTemplateDesign = "none";
                this.menutemplatedivhide = "block";
                this.innerHTML = "";
                this.menuimagecropped = "";
                this.menuimagepath = ""; this.menuimage = "";
                this.profileimagepath = "";  this.imagecropped = ""; this.profileimagename = ''; this.profileimage = "";
            }
            else {
                this.menuimagedivhide = "none";
                this.menutemplatedivhide = "none";
                this.editTemplateDesign = "block";
                this.innerHTML = "";
                this.menuimagecropped = "";
                this.menuimagepath = "";
                this.profileimagepath = "";  this.imagecropped = ""; this.profileimagename = '';
            }
        }
    }

    saveData() {
        if (!this.modulesForm.valid) {
        }
        this.submitAttempt = true;
       
        if (this.modulesForm.valid) {
            if (this.templatetype == "TM" && this.showTemplateDesign == "none" && (this.templateId == undefined || this.templateId == 0)) {
                let msg = '<span style="color: red">Choose any Template Design</span>';
                this.toastMessage(msg);
            }
            else if (this.templatetype == "IM" && this.action == 'A') {
                if(this.menuimagename == "" && this.menuimagecropped == "")
                {
                    this.templateerrormsg = "Choose menu image";
                }
            }
            else if ((this.templateId != undefined && this.templatetype == "TM")) {
                this.TemplateDesign(this.templateId);
                if (this.action == "U" && this.innerHTML == '') {
                    this.innerHTML = this.tempdata;
                }
                if(this.action == "U" && this.dblclicked == true)
                {
                    if (this.templateid == 1) {
                        if (this.innerHTML.includes('subitem_')) {
                            this.templateerrormsg = "";
                        }
                        else {
                            this.templateerrormsg = "Add atleast one sub menu item. The Template cannot be empty.";
                        }
                    }
                    if (this.templateid == 2) {
                        if (this.innerHTML.includes('item_')) {
                            if(this.innerHTML.includes('submenuitem_'))
                            {
                                this.templateerrormsg = "";
                            }
                            else
                            {
                                this.templateerrormsg = "Add atleast one sub menu item for atleast one main menu item.";
                            }
                        }
                        else {
                            this.templateerrormsg = "Add atleast one main menu item. The Template cannot be empty.";
                        }
                    }
                    if (this.templateid == 3) {
                        if (this.innerHTML.includes('mainmenudiv_')) {
                            if(this.innerHTML.includes('col_'))
                            {
                                this.templateerrormsg = "";
                            }
                            else
                            {
                                this.templateerrormsg = "Add atleast one sub menu item for atleast one main menu item.";
                            }
                        }
                        else {
                            this.templateerrormsg = "Add atleast one main menu item. The Template cannot be empty.";
                        }
                    }
                }
                if ((this.templatetype == 'FM' || this.templatetype == 'IM') && (this.templateid == 0 || this.templateId == 0)) {
                    this.innerHTML = "";
                }
            }
            if ((this.templatetype == "FM") || (this.templatetype == "IM" && this.templateerrormsg == "") || (this.templatetype == "TM" && this.templateid != 0 && this.templateerrormsg == "")) {
                if(this.templatetype == "FM")
                {
                    this.menuimage = "";
                    this.htmltemplateimage = "";
                }
                else if(this.templatetype == "IM")
                {
                    this.profileimagename = "";
                    this.htmltemplateimage = "";
                }
                else if(this.templatetype == "TM")
                {
                    this.menuimage = "";
                    this.profileimagename = "";
                }
                var modulesinfo = {
                    "action": this.action, "id": this.mdid, "subid": this.smdid, "clubid": this.golfclubid, "name": this.mdname, "description": this.description, 'image': this.profileimagename, 'binaryimage': this.imagecropped, "brandname": this.brandname, "price": this.price, "updtaedid": localStorage.getItem('userId'), "status": this.chksts,
                    'menuimage': this.menuimagename, 'menubinaryimage': this.menuimagecropped, 'templatetype': this.templatetype, 'templateimage': this.htmltemplateimage, 'htmltext': this.innerHTML, 'templateid': this.templateid
                }
                //console.log(modulesinfo);
                this.spinnerService.show();
                this.api.postOH('savefoodmenutypes', modulesinfo).subscribe(
                    (response) => {
                        if(response[1] != "Food Menu Types Already Exist or Unable to process your request ")
                        {
                            this.dblclicked = false;
                            this.modulesForm.reset();
                            if (this.type == 'M') {
                                let parameters = { searchvalue: "  WHERE MT_MT_ID=0 AND MT_GCB_ID=" + this.golfclubid + " AND MT_STATUS= 'Y' " };
                                this.GetFoodtypesData(parameters);
    
                                let parameters1 = { searchvalue: " WHERE U_STATUS = 'Y' " };
                                this.getUsers(parameters1);
    
                                this.gridShow = "block"; this.viewcontentShow = "none"
                                this.contentShow = "none"; this.coursegridShow = "none";
                                this.menuimagedivhide = "none"; this.menutemplatedivhide = "none"; this.showTemplateDesign = "none";
                                this.editTemplateDesign = "none";
                                index = []; mainindex = []; deleteditem = []; count = 0; mainMenuCount = 0; divdblclickcount = 0;
                                this.arr = []; this.mainarr = []; this.submenuarr = [];
                                this.innerHTML = '';
                                this.editTmpId = 0;
                                this.brandlogoimagename = ''; this.imagecropped1 = ''; this.brandlogoimagepath = '';
                                this.clublogoimagename = ''; this.imagecropped2 = ''; this.clublogoimagepath = '';
                                this.editbrandlogoimagename = ''; this.imagecropped3 = ''; this.editbrandlogoimagepath = '';
                                this.editclublogoimagename = ''; this.imagecropped4 = ''; this.editclublogoimagepath = ''; this.editClubLogoImagepath = '';
                                this.viewtemplate = '';
                                this.htmltemplateimage = "";
    
                                let msg = (this.action == "A") ? '<span style="color: green">Food Type Added Successfully.</span>' : '<span style="color: green">Food Type Updated Successfully.</span>';
                                this.toastMessage(msg);

                                this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
                            }
                            else {
                                let parameters = { searchvalue: "  WHERE MT_MT_ID=" + this.mainmodid + " AND MT_GCB_ID=" + this.golfclubid + " " };
                                this.getfooditemsdetailstable(parameters);
                                this.viewfoods(this.dataobjforcancel, 'M');
                                this.gridShow = "none"; this.viewcontentShow = "block"
                                this.contentShow = "none"; this.coursegridShow = "block";
                                this.menuimagedivhide = "none"; this.menutemplatedivhide = "none"; this.showTemplateDesign = "none";
                                this.editTemplateDesign = "none";
                                this.innerHTML = '';
                                let msg = (this.action == "A") ? '<span style="color: green">Food Item Added Successfully.</span>' : '<span style="color: green">Food Item Updated Successfully.</span>';
                                this.toastMessage(msg);
                            }
                            this.spinnerService.hide();
                            window.scrollTo(0, 0);
                        }
                        else
                        {
                            let msg = '<span style="color: red">' + response[1] + '</span>';
                            this.toastMessage(msg);
                            this.spinnerService.hide();
                            window.scrollTo(0, 0);
                        }
                       
                    }, error => {
                        this.browsingImage = false;
                        this.spinnerService.hide();
                    });
            }
        }
    }

    OpenModaltoPreview(previewtemplate: TemplateRef<any>, tempValue) {
        this.modalRef = this.modalService.show(previewtemplate, { class: 'templatepreview' });
        this.TemplateDesign(tempValue);
        if (this.innerHTML != '') {
            this.previewtemplate = this.innerHTML;
            document.getElementById('preview').innerHTML = this.previewtemplate;
            document.getElementById('preview').style.width = "1000px";
            this.htmlView();
        }
        if (this.action == 'U' && this.dblclicked == false) {
            this.previewtemplate = this.tempdata;
            document.getElementById('preview').innerHTML = this.previewtemplate;
            document.getElementById('preview').style.width = "1000px";
            this.htmlView();
        }
    }

    confirmtemplate()
    {
        this.saveData();
        this.modalRef.hide();
    }

    closetemplate()
    {
        this.modalRef.hide();
    }

    htmlView()
    {
        html2canvas(document.querySelector("#preview"),{width:1050}).then(canvas =>
        {
            var imageData = canvas.toDataURL('image/png');
            this.htmltemplateimage = (imageData != "") ? imageData.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
        })
    }

    toastMessage(msg) {
        let options = {
            positionClass: 'toast-top-center',
        };

        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 5000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    }

    openModalfordeletefromgrid(template: TemplateRef<any>, id, subid) {
        mainiddeletefromgrid = id;
        subiddeletefromgrid = subid;
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    }

    openModalforimage(imgtemplate: TemplateRef<any>) {
        this.modalRef = this.modalService.show(imgtemplate, { class: 'modal-sm' });
    }

    imageclose() {
        this.modalRef.hide();
    }

    confirm(): void {
        this.modalRef.hide();
        var modulesinfo = {};
        if(this.action == 'V')
        {
            modulesinfo = {
                "action": 'D', "id": this.mdid, "subid": this.smdid, "clubid": this.golfclubid, "name": '', "description": '', "image": "", "binaryimage": "", "brandname": '', "price": '', "updtaedid": localStorage.getItem('userId'), "status": 'D',
                'menuimage': "", 'menubinaryimage': "", 'templatetype': "", 'templateimage':"", 'htmltext':"","templateid":0
            }
        }
        else
        {
            modulesinfo = {
                "action": 'D', "id": mainiddeletefromgrid, "subid": subiddeletefromgrid, "clubid": this.golfclubid, "name": '', "description": '', "image": "", "binaryimage": "", "brandname": '', "price": '', "updtaedid": localStorage.getItem('userId'), "status": 'D',
                'menuimage': "", 'menubinaryimage': "", 'templatetype': "", 'templateimage':"", 'htmltext':"","templateid":0
            }
        }
        
        let msg = '<span style="color: green">Food Type deleted Successfully</span>';
        this.DEapicall(modulesinfo, msg, 'M');
    }

    enablemodule(id, type): void {
        var modulesinfo = {
            "action": 'E', "id": id, "subid": this.smdid, "clubid": this.golfclubid, "name": '', "description": '', "image": "", "binaryimage": "", "brandname": '', "price": '', "updtaedid": localStorage.getItem('userId'), "status": 'Y',
            'menuimage': "", 'menubinaryimage': "", 'templatetype': ""
        }

        let msg = '<span style="color: green">Food Type enabled Successfully</span>';
        this.DEapicall(modulesinfo, msg, type);
    }

    DEapicall(modulesinfo, msg, type) {
        //console.log(modulesinfo);
        this.api.postOH('savefoodmenutypes', modulesinfo).subscribe(
            (response) => {
                mainiddeletefromgrid = 0;
                subiddeletefromgrid = 0;
                if (type == 'M') {
                    let parameters = { searchvalue: "  WHERE MT_MT_ID=0 AND MT_GCB_ID=" + this.golfclubid + " AND MT_STATUS= 'Y' " };
                    this.GetFoodtypesData(parameters);
                    this.gridShow = "block"; this.viewcontentShow = "none"
                    this.contentShow = "none"; this.coursegridShow = "none";
                    this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
                }
                else {
                    let parameters = { searchvalue: "  WHERE MT_MT_ID=" + this.mainmodid + " AND MT_GCB_ID=" + this.golfclubid + " " };
                    this.getfooditemsdetailstable(parameters);
                    this.gridShow = "none"; this.viewcontentShow = "block"
                    this.contentShow = "none"; this.coursegridShow = "block";
                }
                this.toastMessage(msg);
            }, error => {

            });
    }

    decline(): void {
        this.modalRef.hide();
    }

    fileChange(input, fimg) {
        if(this.templatetype == 'FM' && this.profileimagepath == '')
        {
            this.browsingImage = true;
        }
        else if(this.templatetype == 'IM' && this.menuimagepath == '')
        {
            this.browsingImage = true;
        }
        this.readFiles(input.files, fimg);
    }
    readFile(file, fimg, reader, callback) {
        reader.onload = () => {
            callback(reader.result);
            if (fimg == 'profimg') {
                this.profileimagepath = reader.result;
                this.imagecropped = (reader.result != "") ? reader.result.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
                this.profileimagename = file.name;
                this.browsingImage = false;
            }
            else if (fimg == 'menuimg') {
                this.menuimagepath = reader.result;
                this.menuimagecropped = (reader.result != "") ? reader.result.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
                this.menuimagename = file.name;
                this.browsingImage = false;
                this.templateerrormsg = "";
            }
            if (fimg == 'brandlogo') {
                this.brandlogoimagepath = reader.result;
                let base64str1 = reader.result;
                this.brandlogoimagename = file.name;
                this.imagecropped1 = (base64str1 != "") ? base64str1.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : ""
            }
            else if (fimg == 'clublogo') {
                this.clublogoimagepath = reader.result;
                let base64str2 = reader.result;
                this.clublogoimagename = file.name;
                this.imagecropped2 = (base64str2 != "") ? base64str2.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
            }
            else if (fimg == 'editbrandlogo') {
                this.editbrandlogoimagepath = reader.result;
                let base64str3 = reader.result;
                this.editbrandlogoimagename = file.name;
                this.imagecropped3 = (base64str3 != "") ? base64str3.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : ""
            }
            else if (fimg == 'editclublogo') {
                this.editclublogoimagepath = reader.result;
                let base64str4 = reader.result;
                this.editclublogoimagename = file.name;
                this.imagecropped4 = (base64str4 != "") ? base64str4.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
            }
            else if (fimg == 'editclublogoVal') {
                this.editClubLogoImagepath = reader.result;
                let base64str5 = reader.result;
                this.editclublogoimagename = file.name;
                this.imagecropped4 = (base64str5 != "") ? base64str5.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
            }

        }
        reader.readAsDataURL(file);
    }
    // readFiles(files, fimg, index = 0) {
    //     // Create the file reader
    //     let reader = new FileReader();
    //     // If there is a file
    //     if (index in files) {
    //         var extn = (files[index].name).split('.');
    //         if (extn[1].toLowerCase() == "jpg" || extn[1].toLowerCase() == "png" || extn[1].toLowerCase() == "gif" || extn[1].toLowerCase() == "jpeg") {
                
    //                 this._ngxPicaService.compressImage(files[index], 1.5).subscribe((res1) => {
    //                     // Start reading this file
    //                     this.readFile(res1, fimg, reader, (result) => {
    //                         // Create an img element and add the image file data to it
    //                         var img = document.createElement("img");
    //                         img.style.backgroundColor = "white";
    //                         img.src = result;
    //                         this.resize(img, 776, (res) => {
    //                             if (fimg == 'profimg') {
    //                                 this.profileimagepath = res;
    //                                 //console.log(this.profileimagepath);
    //                                 this.imagecropped = (res != "") ? res.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
    //                                 this.profileimagename = files[index].name;
    //                                 this.browsingImage = false;
    //                             }
    //                             else if (fimg == 'menuimg') {
    //                                 this.menuimagepath = res;
    //                                 //console.log(this.menuimagepath);
    //                                 this.menuimagecropped = (res != "") ? res.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
    //                                 this.menuimagename = files[index].name;
    //                                 this.browsingImage = false;
    //                             }
    //                         });
    //                     })
    //                 },
    //                 (err: NgxPicaErrorInterface) => {
    //                     this.browsingImage = false;
    //                     let msg='<span style="color:red">Unable to compress.</span>';
    //                     this.toastMessage(msg);
    //                     //console.log(err.err);
    //                 });
              
                
    //         }
    //         else {
    //             let msg = '<span style="color:red"> Browse image with extensions .jpg, .jpeg, .png, .gif only.</span>';
    //             this.toastMessage(msg);
    //         } 
    //     } else {
    //         // When all files are done This forces a change detection
    //         // this.changeDetectorRef.detectChanges();
    //     }
    // }

    readFiles(files, fimg, index = 0) {
        // Create the file reader  
        let reader = new FileReader();
        // If there is a file  
        if (index in files) {
            // Start reading this file 
            var extn = (files[index].name).split('.');
            if (extn[1].toLowerCase() == "jpg" || extn[1].toLowerCase() == "png" || extn[1].toLowerCase() == "gif" || extn[1].toLowerCase() == "jpeg") {
                this.readFile(files[index], fimg, reader, (result) => {
                    // Create an img element and add the image file data to it  
                    var img = document.createElement("img");
                    img.src = result;
                });
            }
            else {
                this.browsingImage = false;
                let msg = '<span style="color:red"> Browse image with extensions .jpg, .jpeg, .png, .gif only.</span>';
                this.toastMessage(msg);
            }

        } else {
            // When all files are done This forces a change detection  
            // this.changeDetectorRef.detectChanges();
        }
    }

    resize(img, MAX_WIDTH: number, callback) {
        // This will wait until the img is loaded before calling this function
        return img.onload = () => {
            // Get the images current width and height
            var width = img.width;
            var height = img.height;
            // Set the WxH to fit the Max values (but maintain proportions)
            if (width > MAX_WIDTH) {
                height *= MAX_WIDTH / width;
                width = MAX_WIDTH;
            } 
            // create a canvas object
            var canvas = document.createElement("canvas");
            // Set the canvas to the new calculated dimensions
            canvas.width = width;
            canvas.height = height;
            canvas.style.backgroundColor = "transparent";
            var ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0, width, height);
            // Get this encoded as a jpeg
            // IMPORTANT: 'jpeg' NOT 'jpg'
            var dataUrl = canvas.toDataURL('image/jpeg');
            // callback with the results
            callback(dataUrl, img.src.length, dataUrl.length);
        };
    }

    //for beverages

    sort(value: string) {
        this.key = value;
        this.nameasc = "sortwhite"; this.namedesc = "sortwhite"; this.roleasc = "sortwhite"; this.roledesc = "sortwhite";
        if (this.key == value) {
            this.reverse = !this.reverse;
            if (this.key == "clubcourseadmin" && this.reverse) {
                this.nameasc = "sortgreen";
            }
            else if (this.key == "clubcourseadmin" && (!this.reverse)) {
                this.namedesc = "sortgreen";
            }
            else if (this.key == "rolename" && this.reverse) {
                this.roleasc = "sortgreen";
            }
            else if (this.key == "rolename" && (!this.reverse)) {
                this.roledesc = "sortgreen";
            }
        }
    }

    getClubUsers() {
        let parameters1 = {
            searchvalue: " WHERE GCCA_GCB_ID = " + this.golfclubid + " AND GCCA_STATUS = 'Y' "
        };
        this.api.postOH('getclubcourseuserassignment', parameters1).subscribe(
            (data) => {
                if (data.length > 0) {
                    for (let k = 0; k < data.length; k++) {
                        this.clubusers.push({
                            "id": data[k].id,
                            "clubcourseid": data[k].clubcourseid,
                            "clubcoursename": data[k].clubcoursename,
                            "clubcourseuserid": data[k].clubcourseuserid,
                            "clubcourseadmin": data[k].clubcourseadmin
                        });
                    }
                }
                else if (data.length == 0) {
                    this.GridMessage = "No data found";
                }

            }, error => {

            }
        )
    }

    getUsers(parameters) {
        this.api.postOH('getusers', parameters).subscribe(
            (response) => {
                this.usersdata = [];
                for (let i = 0; i < response.length; i++) {
                    this.usersdata.push({
                        "userid": response[i].id,
                        "name": response[i].name,
                        "roleid": response[i].roleid,
                        "rolename": response[i].rolename,
                        "clubuserdata": this.clubusers
                    });
                }
            }, error => {

            }
        );
    }

    getRoles() {
        let parameters = { searchvalue: " WHERE R_STATUS = 'Y' AND R_CODE = 'CB'" };
        this.api.postOH('getuserroles', parameters).subscribe(
            (response) => {
                this.roledata = [];
                for (let i = 0; i < response.length; i++) {
                    this.roledata.push({
                        'rolesid': response[i].id,
                        'rolesname': response[i].name,
                        'rolescode': response[i].code
                    })
                }
            }, error => {

            }
        );
    }

    toggleChange(user, isBeveragerStatus) {
        this.id = 0;
        var rangerroleid = this.roledata[0].rolesid;
        if (isBeveragerStatus == true) {
            this.beveragestatus = true;
            this.beveragechkstatus = 'Y';
            this.modifiedRoleid = rangerroleid;
            this.previousRoleid = user.roleid;
            this.modifiedUid = user.userid;
        }
        else if (isBeveragerStatus == false) {
            this.beveragestatus = false;
            this.beveragechkstatus = 'N';
            for (var i = 0; i < this.beverageData.length; i++) {
                if (user.userid == this.beverageData[i].modifiedUserId && this.beverageData[i].status == 'Y' && this.beverageData[i].previousRoleId != rangerroleid) {
                    this.initialroleid.push(this.beverageData[i].previousRoleId);
                }
            }
            this.modifiedRoleid = parseInt((this.removeDuplicates(this.initialroleid)).toString());
            //this.modifiedRoleid = 2;
            this.previousRoleid = user.roleid;
            this.modifiedUid = user.userid;
        }



        var rangermodel = {
            'id': this.id, 'modifiedUserId': this.modifiedUid, 'previousRoleId': this.previousRoleid,
            'modifiedRoleId': this.modifiedRoleid, 'modifyingUserId': parseInt(this.modifyingUid),
            'status': this.beveragechkstatus
        }
        //console.log(rangermodel);
        this.api.postOH('saveRangerData', rangermodel).subscribe(
            (response) => {
                if (response[1] == 'Ranger Updated Successfully') {
                    let parameters = { searchvalue: " WHERE U_STATUS = 'Y' " };
                    this.getUsers(parameters);
                    let msg = '<span style="color: green">Beverage updated Successfully. </span>';
                    this.toastMessage(msg);
                }
            })
    }

    removeDuplicates(arr) {
        let unique_array = []
        for (let i = 0; i < arr.length; i++) {
            if (unique_array.indexOf(arr[i]) == -1) {
                unique_array.push(arr[i])
            }
        }
        return unique_array;
    }

    viewgetBeverages() {
        let parameters = {
            searchvalue: ""
        };
        this.api.postOH('getRangerView', parameters).subscribe(
            (data) => {
                this.beverageData = data;
            })
    }

    AddTemplateData(val) {
        this.templateId = '';
        this.templateId = val;
        if (val == 1) {
            this.innerHTML = '';
            this.sampledesign1 = '';
            this.menutemplatedivhide = "none";
            this.showTemplateDesign = "block";
            var style = $('#template1').html();
            if (style != '' || style != undefined) {
                this.sampledesign1 = this.changehtml(style);
            }
        }
        if (val == 2) {
            this.innerHTML = '';
            this.sampledesign2 = '';
            this.menutemplatedivhide = "none";
            this.showTemplateDesign = "block";
            var style = $('#template2').html();
            if (style != '' || style != undefined) {
                this.sampledesign2 = this.changehtml(style);
            }
        }
        if (val == 3) {
            this.innerHTML = '';
            this.sampledesign3 = '';
            this.menutemplatedivhide = "none";
            this.showTemplateDesign = "block";
            var style = $('#template3').html();
            if (style != '' || style != undefined) {
                this.sampledesign3 = this.changehtml(style);
            }
        }

    }

    changehtml(style) {
        if (this.templatetype == "TM") {
            return this.sanitizer.bypassSecurityTrustHtml(style);
        }
    }

    //for assigning html design to a string
    TemplateDesign(val) {
        if (this.action == 'A') {
            this.templateid = 0;
            if (val == 1) {
                if ($('#mainitem').val().toString() == "" || this.brandlogoimagepath == '' || this.clublogoimagepath == '' || this.arr == [] || this.arr.length == 0) {
                    this.innerHTML = '';
                    this.templateerrormsg = "Browse Brand Logo, Club Logo. Enter Main Food Item and add atleast one sub menu item. The Template cannot be empty.";
                }
                else {
                    this.templateerrormsg = '';
                    this.templateid = val;
                    var brandimage = this.brandlogoimagepath; var clublogo = this.clublogoimagepath;
                    if (brandimage == undefined) {
                        brandimage = '';
                    }
                    if (clublogo == undefined) {
                        clublogo = '';
                    }
                    var maindescription = $('#mainitem').val();

                    this.innerHTML = '';
                    this.innerHTML = this.innerHTML + "<div id='template' style='padding-top:10px; background: white;margin-right:-34px;'>";
                    this.innerHTML = this.innerHTML + "<div style='text-align: center'><img id='brandlogos' height='100px' src='" + brandimage + "'/></div>";
                    if (clublogo != '') {
                        this.innerHTML = this.innerHTML + "<div style='text-align: center; margin-top: 15px;'><img id='clublogos' style='background:#eee;' src='" + clublogo + "' height='30px';/>";
                        this.innerHTML = this.innerHTML + "<div style='border-top: 1px solid #aaa;margin-top: -15px;margin-left: 65px;margin-right: 65px; '></div></div>";
                    }
                    this.innerHTML = this.innerHTML + "<div style='text-align: center; padding:30px 0'><label id='maindesc' style='color:saddlebrown;text-transform: uppercase;font-weight:bolder;font-size:36px;'>" + maindescription + "</label></div>";
                    for (var i = 1; i <= count; i++) {
                        if (($('#submenuname_' + i).val()) != undefined && ($('#submenudesc_' + i).val()) != undefined && ($('#submenuprice_' + i).val()) != undefined) {
                            this.innerHTML = this.innerHTML + "<div id='subitem_" + i + "' style='text-align: center; padding:10px 0'>";
                            this.innerHTML = this.innerHTML + "<label id='submenulabel_" + i + "' style='font-weight:bold;text-transform: uppercase;font-size:26px;'>" + $('#submenuname_' + i).val() + "</label>";
                            this.innerHTML = this.innerHTML + "<p id='submenudescription_" + i + "' style='padding:0px 69px !important; margin-top:0px;font-size:20px;margin-bottom:0px;'>" + $('#submenudesc_' + i).val() + "</p>";
                            this.innerHTML = this.innerHTML + "<label id='submenuprices_" + i + "' style='color:saddlebrown;margin-top:0px;font-family:Trebuchet MS;font-size:26px;font-weight:bold;'>" + $('#submenuprice_' + i).val() + "</h3>";
                            this.innerHTML = this.innerHTML + "</div>";
                        }
                    }
                    this.innerHTML = this.innerHTML + "</div><br/>";
                }
            }

            if (val == 2) {
                if (this.mainarr == [] || this.submenuarr == [] || $('#footerheading').val() == '' || $('#footerdesc').val() == '' || this.mainarr.length == 0 || this.submenuarr.length == 0) {
                    this.innerHTML = '';
                    this.templateerrormsg = "Add atleast one main item and sub menu item, footer heading and footer description. The Template cannot be empty.";
                }
                else {
                    this.templateerrormsg = '';
                    this.templateid = val;
                    this.innerHTML = '';
                    this.innerHTML = this.innerHTML + "<div id='template' style='padding-top:10px; background: white;margin-right:-34px;'>";
                    this.innerHTML = this.innerHTML + "<div id='ItemTemplate'>";
                    for (var i = 0; i < this.mainarr.length; i++) {
                        if ($('#mainfooditem_' + i).val() != undefined) {
                            this.innerHTML = this.innerHTML + "<div id='item" + i + "'>";
                            this.innerHTML = this.innerHTML + "<div id='mainheadingdiv_" + i + "' style='text-align:center;margin-top: 15px;padding-top:0px;padding-bottom:10px;margin-bottom:0px;'>";
                            this.innerHTML = this.innerHTML + "<h1 id='mainfooditem_" + i + "' style='color:rgb(158, 7, 100);text-transform:capitalize;font-variant: small-caps;padding:10px 16%;'>" + $('#mainfooditem_' + i).val() + "</h1>";
                            if ($('#descline1_' + i).val() != undefined && $('#descline2_' + i).val() != undefined) {
                                this.innerHTML = this.innerHTML + "<label id='mainfooddescline1_" + i + "' style='color:rgb(158, 7, 100);text-transform:capitalize;font-variant: small-caps;font-weight:bolder;font-size:20px;'>" + $('#descline1_' + i).val() + "</label> <br/>";
                                this.innerHTML = this.innerHTML + "<label id='mainfooddescline2_" + i + "' style='color:rgb(158, 7, 100);text-transform:capitalize;font-variant: small-caps;font-weight:bolder;font-size:20px;'>" + $('#descline2_' + i).val() + "</label>";
                            }
                            this.innerHTML = this.innerHTML + "</div>";

                            for (var j = 0; j < this.submenuarr[i + 1].length; j++) {
                                if ($('#submenuname_' + i + '' + j).val() != undefined && $('#submenudesc_' + i + '' + j).val() != undefined) {
                                    this.innerHTML = this.innerHTML + "<div id='submenuitem_" + i + "" + j + "' style='padding:10px 10spx;'>";
                                    this.innerHTML = this.innerHTML + "<div id='submenuitemname_" + i + "" + j + "' style='float:left;font-weight:bold;text-transform:capitalize;font-variant: small-caps;font-size:26px;color:rgb(158, 7, 100);padding-right: 4px;'>" + $('#submenuname_' + i + '' + j).val() + "&nbsp; &#8211; </div>";
                                    this.innerHTML = this.innerHTML + "<div id='submenuitemdesc_" + i + "" + j + "' style='text-align:left;font-style: italic;font-family: -webkit-pictograph;font-size:26px;font-weight:normal !important;'>" + $('#submenudesc_' + i + '' + j).val() + "</div>";
                                    this.innerHTML = this.innerHTML + "</div>";
                                }
                            }
                            this.innerHTML = this.innerHTML + "</div>";
                        }
                    }
                    this.innerHTML = this.innerHTML + "</div>";
                    this.innerHTML = this.innerHTML + "<div style='padding-top:10px;font-size:20px;'>";
                    this.innerHTML = this.innerHTML + "<div style='text-align: center;font-style: italic;font-family: -webkit-pictograph;'>";
                    this.innerHTML = this.innerHTML + "<label id='footerHeading' style='font-weight:bold;color:rgb(158, 7, 100);'>" + $('#footerheading').val() + "</label>";
                    this.innerHTML = this.innerHTML + "<p id='footerDesc' style='padding:0px 12% !important; margin-top:0px;font-weight:bold;'>" + $('#footerdesc').val() + "</p>";
                    this.innerHTML = this.innerHTML + "</div>";
                    this.innerHTML = this.innerHTML + "</div>";
                    this.innerHTML = this.innerHTML + "</div>";
                }

            }

            if (val == 3) {
                if (this.mainarr == [] || this.submenuarr == [] || $('#footerheading').val() == '' || $('#footerdesc').val() == '' || this.mainarr.length == 0 || this.submenuarr.length == 0) {
                    this.innerHTML = '';
                    this.templateerrormsg = "Add atleast one main item and sub menu item, footer heading and footer description. The Template cannot be empty.";
                }
                else {
                    this.templateid = val;
                    this.templateerrormsg = '';
                    var clubLogo = this.clublogoimagepath;
                    this.innerHTML = '';
                    this.innerHTML = this.innerHTML + '<div id="template" style="padding-top:10px; background: white;font-family:sans-serif;margin-right:-34px;">';
                    this.innerHTML = this.innerHTML + '<div  id="Clublogoduringsave" style="text-align:center; margin-top: 15px; padding-bottom:10px;">';
                    this.innerHTML = this.innerHTML + '<img id="clublogoImage" src="' + clubLogo + '" height="100px" style="border: 1px solid #dda;margin: 0% 25%;" />';
                    this.innerHTML = this.innerHTML + '</div>';
                    this.innerHTML = this.innerHTML + "<div id='ItemTemplate'>";
                    for (var i = 0; i < this.mainarr.length; i++) {
                        if (i == 0) {
                            this.innerHTML = this.innerHTML + '<div id="mainmenudiv_' + i + '" class="col-xs-12 col-md-12" style="text-align: center;padding-top:0px;padding-bottom:10px;">';
                            this.innerHTML = this.innerHTML + '<h1 id="mainfooditem_' + i + '" style="color:#000;text-transform:uppercase;padding:10px 16%;font-weight: bolder;margin-bottom:0px;">' + $('#mainfooditem_' + i).val() + '</h1>';
                            this.innerHTML = this.innerHTML + '<label id="mainfooddescline1_' + i + '" style="text-transform:capitalize;font-weight:bolder;font-size:20px;">' + $('#descline1_' + i).val() + '</label> <br/>';
                            this.innerHTML = this.innerHTML + '<label id="mainfooddescline2_' + i + '" style="text-transform:capitalize;font-weight:normal;font-size:20px;">' + $('#descline2_' + i).val() + '</label>';
                            this.innerHTML = this.innerHTML + '</div>';
                        }
                        else {
                            if (($('#descline1_' + i).val() != '' || $('#descline1_' + i).val() != undefined) && ($('#descline2_' + i).val() != '' || $('#descline2_' + i).val() != undefined)) {
                                this.innerHTML = this.innerHTML + '<div id="mainmenudiv_' + i + '" class="col-xs-12 col-md-12" style="text-align: center; padding-top:0px;padding-bottom:10px;">';
                                this.innerHTML = this.innerHTML + '<hr style="margin-top: 20px;margin-bottom: 20px;border: 0;border-top: 1px solid rgb(42, 41, 41);width:100%;" />';
                                this.innerHTML = this.innerHTML + '<h1 id="mainfooditem_' + i + '" style="color:#000;text-transform:uppercase;padding:10px 16%;font-weight: bolder;margin-bottom:0px; ">' + $('#mainfooditem_' + i).val() + '</h1>';
                                this.innerHTML = this.innerHTML + '<label id="mainfooddescline1_' + i + '" style="text-transform:capitalize;font-weight:bolder;font-size:20px;">' + $('#descline1_' + i).val() + '</label> <br/>';
                                this.innerHTML = this.innerHTML + '<label id="mainfooddescline2_' + i + '" style="text-transform:capitalize;font-weight:normal;font-size:20px;">' + $('#descline2_' + i).val() + '</label>';
                                this.innerHTML = this.innerHTML + '<hr style="margin-top: 0px;margin-bottom: 20px;border: 0;border-top: 1px solid rgb(42, 41, 41);width:100%;" />';
                                this.innerHTML = this.innerHTML + '</div>';
                            }
                            else {
                                this.innerHTML = this.innerHTML + '<div id="mainmenudiv_' + i + '" class="col-xs-12 col-md-12" style="text-align: center; padding-top:0px;padding-bottom:10px;">';
                                this.innerHTML = this.innerHTML + '<hr style="margin-top: 20px;margin-bottom: 20px;border: 0;border-top: 1px solid rgb(42, 41, 41);width:100%;" />';
                                this.innerHTML = this.innerHTML + '<h1 id="mainfooditem_' + i + '" style="color:#000;text-transform:uppercase;padding:10px 16%;font-weight: bolder;margin-bottom:0px; ">' + $('#mainfooditem_' + i).val() + '</h1>';
                                this.innerHTML = this.innerHTML + '<hr style="margin-top: 0px;margin-bottom: 20px;border: 0;border-top: 1px solid rgb(42, 41, 41);width:100%;" />';
                                this.innerHTML = this.innerHTML + '</div>';
                            }
                        }
                        this.innerHTML = this.innerHTML + '<table class="col-xs-12 col-md-12" id="submenutable_' + i + '" style="width:100%; margin-left:10px;">';
                        for (var j = 0; j < this.submenuarr[i + 1].length; j++) {
                            this.innerHTML = this.innerHTML + '<td class="col-xs-12 col-md-6" id="col_' + i + '' + j + '" style="width:50%;padding-top:10px;float:left;padding-left:0px;">';
                            this.innerHTML = this.innerHTML + '<label id="submenuitemname_' + i + '' + j + '" style="float:left;font-weight:bold;font-size:20px;text-transform:capitalize;color:saddlebrown;text-align:left;">' + $('#submenuname_' + i + '' + j).val() + '</label><br/><br/>';
                            this.innerHTML = this.innerHTML + '<p id="submenuitemdesc_' + i + '' + j + '" style="margin-top:0px;font-family: -webkit-pictograph;font-size:20px;text-align:left;margin-right:10px;">' + $('#submenudesc_' + i + '' + j).val() + '</p>';
                            this.innerHTML = this.innerHTML + '</td>';
                        }
                        this.innerHTML = this.innerHTML + '</table>';
                    }
                    this.innerHTML = this.innerHTML + '</div>';
                    this.innerHTML = this.innerHTML + '<div style="padding-top:20px;padding-bottom:10px;">';
                    this.innerHTML = this.innerHTML + '<div style="text-align: center;">';
                    this.innerHTML = this.innerHTML + '<label id="footerHeading" style="font-weight:bold;color:black;font-size:20px;">' + $('#footerheading').val() + '</label>';
                    this.innerHTML = this.innerHTML + '<p id="footerDesc" style="padding:0px 12% !important; margin-top:4px;font-style:italic;">' + $('#footerdesc').val() + '</p>';
                    this.innerHTML = this.innerHTML + '</div>';
                    this.innerHTML = this.innerHTML + '</div>';
                    this.innerHTML = this.innerHTML + '</div>';
                }
            }
        }
        else if (this.action == 'U' && this.dblclicked == true && this.edittemplate != '') {
            this.templateid = 0;
            if (val == 1) {
                    this.templateid = val;
                    var brandimageduringedit; var clubimageduringedit;

                    if (this.editbrandlogoimagepath != '') {
                        brandimageduringedit = this.editbrandlogoimagepath;
                    }
                    else {
                        brandimageduringedit = this.brandlogoimagepath;
                    }

                    if (this.editbrandlogoimagepath == '' && this.brandlogoimagepath == '') {
                        brandimageduringedit = '';
                    }

                    if (this.editclublogoimagepath != '') {
                        clubimageduringedit = this.editclublogoimagepath;
                    }
                    else {
                        clubimageduringedit = this.clublogoimagepath;
                    }

                    if (this.editclublogoimagepath == '' && this.clublogoimagepath == '') {
                        clubimageduringedit = '';
                    }

                    this.innerHTML = '';
                    this.innerHTML = this.innerHTML + "<div id='template' style='padding-top:10px; background: white;margin-right:-34px;'>";
                    this.innerHTML = this.innerHTML + "<div style='text-align: center'><img id='brandlogos' height='100px' src='" + brandimageduringedit + "'/></div>";
                    if (clubimageduringedit != '') {
                        this.innerHTML = this.innerHTML + "<div style='text-align: center; margin-top: 15px;'><img id='clublogos' style='background:#eee;' src='" + clubimageduringedit + "' height='30px';/>";
                        this.innerHTML = this.innerHTML + "<div style='border-top: 1px solid #aaa;margin-top: -15px;margin-left: 65px;margin-right: 65px; '></div></div>";
                    }
                    this.innerHTML = this.innerHTML + "<div style='text-align:center;padding:30px 0'><label id='maindesc' style='color:saddlebrown;text-transform: uppercase;font-weight:bolder;font-size:36px;'>" + $('#mainmenudesc').val() + "</label></div>";

                    var submenucounts = []; var subitemids = []; var alldivids = [];
                    submenucounts.push($('div[id^=subitem_]'));
                    for(var d=0; d < submenucounts[0].length; d++)
                    {
                        subitemids.push(submenucounts[0][d].getAttribute('id'));
                    }
                    subitemids = this.removeDuplicates(subitemids);

                    for(var e = 0; e < subitemids.length; e++)
                    {
                        var item = subitemids[e].split('_');
                        alldivids.push(parseInt(item[1]));
                    }
                    var lastindex = Math.max(...alldivids);
                    for (var i = 1; i <= lastindex; i++) {
                        if (($('#submenulabels_' + i).val()) != undefined && ($('#submenudescriptions_' + i).val()) != undefined && ($('#submenupriceVal_' + i).val()) != undefined) {
                            this.innerHTML = this.innerHTML + "<div id='subitem_" + i + "' style='text-align: center; padding:10px 0'>";
                            this.innerHTML = this.innerHTML + "<label id='submenulabel_" + i + "' style='font-weight:bold;text-transform: uppercase;font-size:26px;'>" + $('#submenulabels_' + i).val() + "</label>";
                            this.innerHTML = this.innerHTML + "<p id='submenudescription_" + i + "' style='padding:0px 69px !important; margin-top:0px;font-size:20px;margin-bottom:0px;'>" + $('#submenudescriptions_' + i).val() + "</p>";
                            this.innerHTML = this.innerHTML + "<label id='submenuprices_" + i + "' style='color:saddlebrown;margin-top:0px;font-family:Trebuchet MS;font-weight:bold;font-size:26px;'>" + $('#submenupriceVal_' + i).val() + "</label>";
                            this.innerHTML = this.innerHTML + "</div>";
                        }
                    }
                    this.innerHTML = this.innerHTML + "</div><br/>";
            }
            if (val == 2) {
                this.templateid = val;
                this.innerHTML = '';
                this.innerHTML = this.innerHTML + "<div id='template' style='padding-top:10px; background: white;margin-right:-34px;'>";
                this.innerHTML = this.innerHTML + "<div id='ItemTemplate'>";

                var mainmenudivs = []; var ids = [];

                mainmenudivs.push($('div[id^=item]'));
                for (var k = 0; k < mainmenudivs[0].length; k++) {
                    ids.push(mainmenudivs[0][k].getAttribute('id'));

                }

                ids = this.removeDuplicates(ids);
                var lastitemid = ids[ids.length - 1];
                lastitemid = lastitemid.substring(lastitemid.indexOf('m') + 1, lastitemid[lastitemid.length]);
                for (var i = 0; i <= lastitemid; i++) {
                    if ($('#mainfooditemname_' + i).val() != undefined) {
                        this.innerHTML = this.innerHTML + "<div id='item" + i + "'>";
                        this.innerHTML = this.innerHTML + "<div id='mainheadingdiv_" + i + "' style='text-align:center;margin-top: 15px;padding-top:0px;padding-bottom:10px;margin-bottom:0px;'>";
                        this.innerHTML = this.innerHTML + "<h1 id='mainfooditem_" + i + "' style='color:rgb(158, 7, 100);text-transform:capitalize;font-variant: small-caps;padding:10px 16%;'>" + $('#mainfooditemname_' + i).val() + "</h1>";
                        if ($('#mainfooditemdescline1_' + i).val() != undefined && $('#mainfooditemdescline2_' + i).val() != undefined) {
                            this.innerHTML = this.innerHTML + "<label id='mainfooddescline1_" + i + "' style='color:rgb(158, 7, 100);text-transform:capitalize;font-variant: small-caps;font-weight:bolder;font-size:20px;'>" + $('#mainfooditemdescline1_' + i).val() + "</label> <br/>";
                            this.innerHTML = this.innerHTML + "<label id='mainfooddescline2_" + i + "' style='color:rgb(158, 7, 100);text-transform:capitalize;font-variant: small-caps;font-weight:bolder;font-size:20px;'>" + $('#mainfooditemdescline2_' + i).val() + "</label>";
                        }
                        this.innerHTML = this.innerHTML + "</div>";

                        var submenudivs = []; var subids = []; 
                        var subidVals = []; var subiditemInd = []; var lasteachIndex;
                        submenudivs.push($('div[id^=submenuitem_' + i + ']'));
                        for (var m = 0; m < submenudivs[0].length; m++) {
                            subids.push((submenudivs[0][m].getAttribute('id')));
                        }
                        subids = this.removeDuplicates(subids);
                        for(var y = 0; y < subids.length; y++)
                        {
                            subidVals.push((subids[y].split('_'))[1]);
                        }
                        for(var x=0; x<subidVals.length; x++)
                        {
                            if(subidVals[x].length == 2)
                            {
                                var itemindex = subidVals[x].split('');
                                subiditemInd.push(itemindex[1]);
                            }
                            else
                            {
                                var itemindex = subidVals[x].splice(-2);
                                subiditemInd.push(itemindex);
                            }
                        }
            
                        var lastindexes = Math.max(...subiditemInd);

                        for (var j = 0; j <= lastindexes; j++) {
                            if ($('#submenuitemnames_' + i + '' + j).val() != undefined && $('#submenuitemdescs_' + i + '' + j).val() != undefined) {
                                //alert($('#submenuitemnames_' + i + '' + j).val());
                                //alert($('#submenuitemdescs_' + i + '' + j).val());
                                this.innerHTML = this.innerHTML + "<div id='submenuitem_" + i + "" + j + "' style='padding:10px 10px;'>";
                                this.innerHTML = this.innerHTML + "<div id='submenuitemname_" + i + "" + j + "' style='float:left;font-weight:bold;text-transform:capitalize;font-variant: small-caps;font-size:26px;color:rgb(158, 7, 100);padding-right: 4px;'>" + $('#submenuitemnames_' + i + '' + j).val() + "&nbsp; &#8211; </div>";
                                this.innerHTML = this.innerHTML + "<div id='submenuitemdesc_" + i + "" + j + "' style='text-align:left;font-style: italic;font-family: -webkit-pictograph;font-size:26px;font-weight:normal !important;'>" + $('#submenuitemdescs_' + i + '' + j).val() + "</div>";
                                this.innerHTML = this.innerHTML + "</div>";
                            }
                        }
                        this.innerHTML = this.innerHTML + "</div>";
                    }
                }
                this.innerHTML = this.innerHTML + "</div>";
                this.innerHTML = this.innerHTML + "<div style='padding-top:10px;font-size:20px;'>";
                this.innerHTML = this.innerHTML + "<div style='text-align: center;font-style: italic;font-family: -webkit-pictograph;'>";
                this.innerHTML = this.innerHTML + "<label id='footerHeading' style='font-weight:bold;color:rgb(158, 7, 100);'>" + $('#fheading').val() + "</label>";
                this.innerHTML = this.innerHTML + "<p id='footerDesc' style='padding:0px 12% !important; margin-top:0px;font-weight:bold;'>" + $('#fdesc').val() + "</p>";
                this.innerHTML = this.innerHTML + "</div>";
                this.innerHTML = this.innerHTML + "</div>";
                this.innerHTML = this.innerHTML + "</div>";
            }
            if (val == 3) {
                this.templateid = val;
                var clubimageduringedit;
                if (this.editClubLogoImagepath != '') {
                    clubimageduringedit = this.editClubLogoImagepath;
                }
                else {
                    clubimageduringedit = this.clublogoimagepath;
                }
                if (this.editClubLogoImagepath == '' && this.clublogoimagepath == '') {
                    clubimageduringedit = '';
                }

                this.innerHTML = '';
                this.innerHTML = this.innerHTML + '<div id="template" style="padding-top:10px; background: white;font-family:sans-serif;margin-right:-34px;">';
                this.innerHTML = this.innerHTML + '<div  id="Clublogoduringsave" style="text-align:center; margin-top: 15px; padding-bottom:10px;">';
                this.innerHTML = this.innerHTML + '<img id="clublogoImage" src="' + clubimageduringedit + '" height="100px" style="border: 1px solid #dda;margin: 0% 25%;" />';
                this.innerHTML = this.innerHTML + '</div>';
                this.innerHTML = this.innerHTML + "<div id='ItemTemplate'>";
                var mainmenudivs = []; var mainmenudivids = []; var lastdiv; var lastdivid;
                mainmenudivs.push($('div[id^=mainmenudiv_]')); 
                for(var a = 0; a < mainmenudivs[0].length; a++)
                {
                    mainmenudivids.push((mainmenudivs[0][a]).getAttribute('id'));
                }
                mainmenudivids = this.removeDuplicates(mainmenudivids);
                lastdiv = mainmenudivids[mainmenudivids.length - 1];
                lastdivid = lastdiv.split('_');
            
                for (var i = 0; i <= lastdivid[1]; i++) {
                    if ($('#mainfooditemnameduringedit_' + i).val() != undefined) {
                        if (i == 0) {
                            this.innerHTML = this.innerHTML + '<div id="mainmenudiv_' + i + '" class="col-xs-12 col-md-12" style="text-align: center;padding-top:0px;padding-bottom:10px;">';
                            this.innerHTML = this.innerHTML + '<h1 id="mainfooditem_' + i + '" style="color:#000;text-transform:uppercase;padding:10px 16%;font-weight: bolder;margin-bottom:0px;">' + $('#mainfooditemnameduringedit_' + i).val() + '</h1>';
                            this.innerHTML = this.innerHTML + '<label id="mainfooddescline1_' + i + '" style="text-transform:capitalize;font-weight:bolder;font-size:20px;">' + $('#mainfooditemdesc1duringedit_' + i).val() + '</label> <br/>';
                            this.innerHTML = this.innerHTML + '<label id="mainfooddescline2_' + i + '" style="text-transform:capitalize;font-weight:normal;font-size:20px;">' + $('#mainfooditemdesc2duringedit_' + i).val() + '</label>';
                            this.innerHTML = this.innerHTML + '</div>';
                        }
                        else {
                            if (($('#mainfooditemdesc1duringedit_' + i).val() != '' || $('#mainfooditemdesc1duringedit_' + i).val() != undefined) && ($('#mainfooditemdesc2duringedit_' + i).val() != '' || $('#mainfooditemdesc2duringedit_' + i).val() != undefined)) {
                                this.innerHTML = this.innerHTML + '<div id="mainmenudiv_' + i + '" class="col-xs-12 col-md-12" style="text-align: center; padding-top:0px;padding-bottom:10px;">';
                                this.innerHTML = this.innerHTML + '<hr style="margin-top: 20px;margin-bottom: 20px;border: 0;border-top: 1px solid rgb(42, 41, 41);width:100%;" />';
                                this.innerHTML = this.innerHTML + '<h1 id="mainfooditem_' + i + '" style="color:#000;text-transform:uppercase;padding:10px 16%;font-weight: bolder;margin-bottom:0px; ">' + $('#mainfooditemnameduringedit_' + i).val() + '</h1>';
                                this.innerHTML = this.innerHTML + '<label id="mainfooddescline1_' + i + '" style="text-transform:capitalize;font-weight:bolder;font-size:20px;">' + $('#mainfooditemdesc1duringedit_' + i).val() + '</label> <br/>';
                                this.innerHTML = this.innerHTML + '<label id="mainfooddescline2_' + i + '" style="text-transform:capitalize;font-weight:normal;font-size:20px;">' + $('#mainfooditemdesc2duringedit_' + i).val() + '</label>';
                                this.innerHTML = this.innerHTML + '<hr style="margin-top: 0px;margin-bottom: 20px;border: 0;border-top: 1px solid rgb(42, 41, 41);width:100%;" />';
                                this.innerHTML = this.innerHTML + '</div>';
                            }
                            else {
                                this.innerHTML = this.innerHTML + '<div id="mainmenudiv_' + i + '" class="col-xs-12 col-md-12" style="text-align: center; padding-top:0px;padding-bottom:10px;">';
                                this.innerHTML = this.innerHTML + '<hr style="margin-top: 20px;margin-bottom: 20px;border: 0;border-top: 1px solid rgb(42, 41, 41);width:100%;" />';
                                this.innerHTML = this.innerHTML + '<h1 id="mainfooditem_' + i + '" style="color:#000;text-transform:uppercase;padding:10px 16%;font-weight: bolder;margin-bottom:0px; ">' + $('#mainfooditemnameduringedit_' + i).val() + '</h1>';
                                this.innerHTML = this.innerHTML + '<hr style="margin-top: 0px;margin-bottom: 20px;border: 0;border-top: 1px solid rgb(42, 41, 41);width:100%;" />';
                                this.innerHTML = this.innerHTML + '</div>';
                            }
                        }
                    }
                    this.innerHTML = this.innerHTML + '<table class="col-xs-12 col-md-12" id="submenutable_' + i + '" style="width:100%;margin-left:10px;">';

                    var subdivs = [];  var subdivids = []; var lastsubdiv; var lastsubdivid;
                    subdivs.push($('#submenutable_' + i).children('tbody').children('tr').children('td'));
                    for(var c = 0; c < subdivs[0].length; c++)
                    {
                        subdivids.push((subdivs[0][c]).getAttribute('id'));
                    }
                    subdivids = this.removeDuplicates(subdivids);
                    if(subdivids.length != 0)
                    {
                        lastsubdiv = subdivids[subdivids.length - 1];
                        lastsubdivid = lastsubdiv.split('_');
                        if(lastsubdivid[1].length == 2)
                        {
                            lastsubdivid = lastsubdivid[1].split('');
                            lastsubdivid = lastsubdivid[1];
                        }
                        else if(lastsubdivid[1].length > 2){
                            lastsubdivid = lastsubdivid[1].splice(-2);
                        }
                    }
                    for (var j = 0; j <= lastsubdivid; j++) {
                        if ($('#submenuitemnameduringedit' + i + '' + j).val() != undefined && $('#submenuitemdescduringedit' + i + '' + j).val() != undefined) {
                            this.innerHTML = this.innerHTML + '<td class="col-xs-12 col-md-6" id="col_' + i + '' + j + '" style="width:50%;padding-top:10px;float:left;padding-left:0px;">';
                            this.innerHTML = this.innerHTML + '<label id="submenuitemname_' + i + '' + j + '" style="float:left;font-weight:bold;font-size:20px;text-transform:capitalize;color:saddlebrown;text-align:left;">' + $('#submenuitemnameduringedit' + i + '' + j).val() + '</label><br/><br/>';
                            this.innerHTML = this.innerHTML + '<p id="submenuitemdesc_' + i + '' + j + '" style="margin-top:0px;font-family: -webkit-pictograph;font-size:20px;text-align:left;margin-right:10px;">' + $('#submenuitemdescduringedit' + i + '' + j).val() + '</p>';
                            this.innerHTML = this.innerHTML + '</td>';
                        }
                    }
                    this.innerHTML = this.innerHTML + '</table>';
                }
                this.innerHTML = this.innerHTML + '</div>';
                this.innerHTML = this.innerHTML + '<div style="padding-top:20px;padding-bottom:10px;">';
                this.innerHTML = this.innerHTML + '<div style="text-align: center;">';
                this.innerHTML = this.innerHTML + '<label id="footerHeading" style="font-weight:bold;color:black;font-size:20px;">' + $('#fheading').val() + '</label>';
                this.innerHTML = this.innerHTML + '<p id="footerDesc" style="padding:0px 12% !important; margin-top:4px;font-style:italic;">' + $('#fdesc').val() + '</p>';
                this.innerHTML = this.innerHTML + '</div>';
                this.innerHTML = this.innerHTML + '</div>';
                this.innerHTML = this.innerHTML + '</div>';
            }
        }
    }

    //for returning back to template design div
    closeDiv() {
        this.mainarr = [];
        this.arr = [];
        this.submenuarr = [];
        index = []; mainindex = [];
        this.showTemplateDesign = "none";
        this.menutemplatedivhide = "block";

    }

    //dynamic sub menu adding for template 1
    addsubmenulist() {
        count = count + 1;
        this.countRepeat();
    }

    //dynamic sub menu adding for template 1
    countRepeat() {
        this.arr = [];
        for (var i = 1; i <= count; i++) {
            this.arr.push(i);
        }
        this.arr = this.removeDuplicates(this.arr);
        for (var m = 0; m < index.length; m++) {
            if (index[m] > -1) {
                this.arr.splice(index[m], 1);
            }
        }
    }

    //dynamic sub menu removing for template 1
    removeItem(c) {
        index.push(this.arr.indexOf(c));
        for (var m = 0; m < index.length; m++) {
            if (index[m] > -1) {
                this.arr.splice(index[m], 1);
            }
        }
    }

    //dynamic sub menu adding for template 2 & 3
    addsubmenulist1(ind) {
        count = count + 1;
        this.countRepeat1(ind);
    }
    //dynamic sub menu removing for template 2 & 3
    removeItem1(c, mainVal) {
        c = c + 1;
        mainVal = mainVal + 1;
        var item = mainVal + "_" + c;
        deleteditem.push(this.submenuarr[mainVal].indexOf(item));
        for (var p = 0; p < deleteditem.length; p++) {
            if (deleteditem[p] > -1) {
                this.submenuarr[mainVal].splice(deleteditem[p], 1);
            }
        }
    }
    //dynamic sub menu adding for template 2 & 3
    countRepeat1(ind) {
        this.submenuarr[ind] = [];
        for (var i = 1; i <= count; i++) {
            this.submenuarr[ind].push(ind + "_" + i);
        }
        this.submenuarr[ind] = this.removeDuplicates(this.submenuarr[ind]);
        if (deleteditem.length != 0) {
            for (var p = 0; p < deleteditem.length; p++) {
                this.submenuarr[ind].splice(deleteditem[p], 1);
            }
        }
    }

    //for template 2 & 3
    addmainmenulist(val) {
        if (val == 0) {
            count = 0;
        }
        mainMenuCount = mainMenuCount + 1;
        this.mainMenuCountRepeat();
    }

    mainMenuCountRepeat() {
        this.mainarr = [];
        for (var i = 1; i <= mainMenuCount; i++) {
            this.mainarr.push(i);
        }
        this.mainarr = this.removeDuplicates(this.mainarr);
        for (var n = 0; n < mainindex.length; n++) {
            if (mainindex[n] > -1) {
                this.mainarr.splice(mainindex[n], 1);
            }
        }
    }

    removeMainItem(maincount) {
        mainindex.push(this.mainarr.indexOf(maincount));
        for (var n = 0; n < mainindex.length; n++) {
            if (mainindex[n] > -1) {
                this.mainarr.splice(mainindex[n], 1);
            }
        }
    }

    editTemplate(tmpId) {
        this.dblclicked = true;
        divdblclickcount = divdblclickcount + 1;
        if (divdblclickcount > 1) {
            $('#editTemplate').one("click", function (event) {
                event.preventDefault();
            })
        }
        else if (divdblclickcount == 1) {
            if (tmpId == 1) {
                this.editTmpId = 0;
                this.editTmpId = tmpId;
                this.templateId = tmpId;
                var submenucount = ($('#template div:last').attr('id'));
                var subcount = submenucount.split('_');
          
                if ($('#brandlogos').change()) {
                    if (($('#editbrandlogo').attr('src')) == undefined) {
                        this.brandlogoimagepath = $('#brandlogos').attr('src');
                        this.editbrandlogoimagepath = '';
                    }
                    else {
                        this.editbrandlogoimagepath = $('#editbrandlogo').attr('src');
                        this.brandlogoimagepath = '';
                    }
                }
                if ($('#clublogos').change()) {
                    if (($('#editclublogo').attr('src')) == undefined) {
                        this.clublogoimagepath = $('#clublogos').attr('src');
                        this.editclublogoimagepath = '';
                    }
                    else {
                        this.editclublogoimagepath = $('#editclublogo').attr('src');
                        this.clublogoimagepath = '';
                    }
                }
                $('#maindesc').replaceWith('<br/><input type="text" id="mainmenudesc" style="color:saddlebrown;text-transform: uppercase;font-size:22px;width:90%;" value="' + $('#maindesc').html() + '">');
                
                for (var i = 1; i <= parseInt(subcount[1]); i++) {
                        count = i;
                        $('#subitem_' + count).append('<i class="fa fa-times-circle-o" aria-hidden="true" style="float: right;font-size: 20px;margin-right: 3%; cursor: pointer;margin-top:-10%;" id="removeSubMenuItemDuringEdit_' + count + '" ></i>');
                        $('#submenulabel_' + count).replaceWith('<br/><input type="text" placeholder="Sub Menu Item Name" id="submenulabels_' + i + '" style="text-align: center;font-weight:bold;text-transform: uppercase;font-size:26px;" value="' + $('#submenulabel_' + count).html() + '">');
                        $('#submenudescription_' + count).replaceWith('<br/><br/><input type="text" placeholder="Sub Menu Item Description" id="submenudescriptions_' + i + '" style="width:90%;text-align: center;margin-top:0px;font-size:20px;" value="' + $('#submenudescription_' + count).html() + '">');
                        $('#submenuprices_' + count).replaceWith('<br/><br/><input type="text" placeholder="Sub Menu Item Price" id="submenupriceVal_' + i + '" style="text-align: center;color:saddlebrown;font-family:Trebuchet MS;" value="' + $('#submenuprices_' + count).html() + '">');
    
                        $('#removeSubMenuItemDuringEdit_' + count).click(function () {
                            for (var j = 1; j <= parseInt(subcount[1]); j++) {
                                if ($(this)[j - 1] != undefined) {
                                    var currentclickindex = $(this)[j - 1].getAttribute('id');
                                    if (currentclickindex) {
                                        var divindex = currentclickindex.split('_');
                                        $('#subitem_' + divindex[1]).remove();
                                    }
                                }
                            }
                        })
                
                }
                
                $('#template').append('<br/><div style="text-align:left;margin-top:0%;margin-left:1%;"><button class="btn btn-primary" id="dynamicFoodItemAdd">Add Food Items</button></div><br/>');

                $("#dynamicFoodItemAdd").click(function () {
                    count = count + 1;
                        $('#template').append(`<br/><div id="subitem_` + count + `" style="text-align:center;padding:10px 0;"><i class="fa fa-times-circle-o" aria-hidden="true" style="float: right;font-size: 20px;margin-right: 3%; cursor: pointer;" id="removeSubMenuItemDuringEdit_` + count + `" ></i>
                        <br/><input type="text" placeholder="Sub Menu Item Name" id="submenulabels_` + count + `" style="text-align: center;font-weight:bold;text-transform: uppercase;font-size:26px;">
                        <br/><br/><input type="text" placeholder="Sub Menu Item Description" id="submenudescriptions_` + count + `" style="width:90%;text-align: center;margin-top:0px;font-size:20px;">
                        <br/><br/><input type="text" placeholder="Sub Menu Item Price" id="submenupriceVal_` + count + `" style="text-align: center;color:saddlebrown;font-family:Trebuchet MS;"></div><br/>`);
                    $('#removeSubMenuItemDuringEdit_' + count).click(function () {
                        for (var j = 1; j <= parseInt(subcount[1]); j++) {
                            if ($(this)[j - 1] != undefined) {
                                var currentclickindex = $(this)[j - 1].getAttribute('id');
                                if (currentclickindex) {
                                    var divindex = currentclickindex.split('_');
                                    $('#subitem_' + divindex[1]).remove();
                                }
                            }
                        }
                    })
                })
            }

            if (tmpId == 2) {
                this.editTmpId = 0;
                this.editTmpId = tmpId;
                this.templateId = tmpId;

                var mainmenudivcount = []; var mainmenudivsitemid = []; var lastitemid;
                mainmenudivcount.push($('div[id^=item]'));
                for (var q = 0; q < mainmenudivcount[0].length; q++) {
                    mainmenudivsitemid.push(mainmenudivcount[0][q].getAttribute('id'));
                }
                mainmenudivsitemid = this.removeDuplicates(mainmenudivsitemid);
                lastitemid = (mainmenudivsitemid[mainmenudivsitemid.length - 1]).split('');
                lastitemid = parseInt(lastitemid[lastitemid.length - 1]);
                count = 0;
                mainMenuCount = 0;
                var submenudivcount = []; var submenudivids = []; var subids = [];
                for (var i = 0; i <= lastitemid; i++) {
                    mainMenuCount = i;
                    $('#mainfooditem_' + i).replaceWith('<input type="text" style="font-weight:bolder;text-align:center;margin-top: 15px;padding-top:0px;padding-bottom:10px;margin-bottom:0px;color:rgb(158, 7, 100);text-transform:capitalize;font-variant:small-caps;padding:10px 16%;width:90%;" id="mainfooditemname_' + i + '" value="' + $('#mainfooditem_' + i).html() + '">');
                    $('#mainfooddescline1_' + i).replaceWith('<br/><br/><input type="text" palceholder="Description 1" style="text-align:center;color:rgb(158, 7, 100);text-transform:capitalize;font-variant: small-caps;font-weight:bolder;font-size:16px;width:90%;" id="mainfooditemdescline1_' + i + '" value="' + $('#mainfooddescline1_' + i).html() + '">');
                    $('#mainfooddescline2_' + i).replaceWith('<br/><input type="text" palceholder="Description 2" style="text-align:center;color:rgb(158, 7, 100);text-transform:capitalize;font-variant: small-caps;font-weight:bolder;font-size:16px;width:90%;" id="mainfooditemdescline2_' + i + '" value="' + $('#mainfooddescline2_' + i).html() + '">');
                    $('#mainheadingdiv_' + i).append('<i class="fa fa-times-circle-o" aria-hidden="true" style="float:right;font-size:20px;cursor:pointer;position:absolute;right:3%;margin-top:-125px;" id="removeMainMenuItemDuringEdit_' + i + '" ></i>');

                    submenudivcount.push($('div[id^=submenuitem_' + i + ']'));
                    for (var q = 0; q < submenudivcount.length; q++) {
                        for (var p = 0; p <= submenudivcount[q].length; p++) {
                            if (submenudivcount[q][p]) {
                                submenudivids.push((submenudivcount[q][p].getAttribute('id')).split('_'));
                                for (var z = 0; z < submenudivids.length; z++) {
                                    subids.push(submenudivids[z][1]);

                                }

                            }

                        }

                    }

                    subids = this.removeDuplicates(subids);

                    var lastitem = subids[subids.length - 1];
                    lastitem = lastitem.split('');

                    for (var j = 0; j <= lastitem[1]; j++) {
                        count = j;
                        var subitemName;
                        if (($('#submenuitemname_' + i + '' + j).html() != undefined)) {
                            if ((($('#submenuitemname_' + i + '' + j).html()).includes('&nbsp;'))) {
                                var name = ($('#submenuitemname_' + i + '' + j).html()).split('&nbsp;');
                                subitemName = name[0];
                            }
                            else {
                                subitemName = ($('#submenuitemname_' + i + '' + j).html());
                            }
                        }

                        $('#submenuitemname_' + i + '' + j).replaceWith('<input type="text" style="text-align:left;font-style: italic;font-family: -webkit-pictograph;font-size:20px;width:30%;" id="submenuitemnames_' + i + '' + j + '" value="' + subitemName + '">');
                        $('#submenuitemdesc_' + i + '' + j).replaceWith('<label style="width:3%"/><input type="text" style="text-align:left;font-style: italic;font-family: -webkit-pictograph;font-size:20px;width:60%;" id="submenuitemdescs_' + i + '' + j + '" value="' + $('#submenuitemdesc_' + i + '' + j).html() + '">');
                        $('#submenuitem_' + i + '' + j).append('<i class="fa fa-times-circle-o" aria-hidden="true" style="float: right;font-size: 20px;margin-right: 5%; cursor: pointer;" id="removeSubMenusItemDuringEdit_' + i + '' + j + '"></i>');
                        $('#removeSubMenusItemDuringEdit_' + i + '' + j).click(function () {
                            var currentclicksubindex = $(this)[0].getAttribute('id');
                            if (currentclicksubindex) {
                                var divindex = currentclicksubindex.split('_');
                                $('#submenuitem_' + divindex[1]).remove();
                            }
                        })
                    }
                    $('#item' + i).append('<button class="btn btn-primary" id="addsubmenudivduringedit_' + i + '">Add Sub Menu Items</button><br/>');
                    $('#removeMainMenuItemDuringEdit_' + i).click(function () {
                        var currentclickmainindex = $(this)[0].getAttribute('id');
                        if (currentclickmainindex) {
                            var divindex = currentclickmainindex.split('_');
                            $('#mainheadingdiv_' + divindex[1]).remove();
                            $('#addsubmenudivduringedit_' + divindex[1]).css('display', 'none');
                        }
                        var submenulength = $('div[id^=submenuitem_' + divindex[1] + ']').length;
                        for (var k = 0; k < submenulength; k++) {
                            var submenuid = $('#submenuitem_' + divindex[1] + '' + k)[0].id;
                            $('#' + submenuid).remove();
                        }
                    })
                    
                    $('#addsubmenudivduringedit_' + i).click(function () {
                        var divid = ($(this)[0].getAttribute('id')).split('_');
                        var divlastchildcount = []; var divlastchildcountIds = []; var indexids = [];
                        divlastchildcount.push($('div[id^=submenuitem_' + divid[1] + ']'));
                        for(var p = 0; p < divlastchildcount.length; p++)
                        {
                            for (var q = 0; q < divlastchildcount[p].length; q++) {
                                var item = (divlastchildcount[p][q].getAttribute('id')).split('_');
                                if (item[1].length == 2) {
                                    var index = item[1].split('');
                                    divlastchildcountIds.push(parseInt(index[1]));
                                }
                                else {
                                    divlastchildcountIds.push(parseInt(item[1].splice(-2)));
                                }
                            }
                        }

                        for (let s = 0; s < divlastchildcountIds.length; s++) {
                            if (indexids.indexOf(divlastchildcountIds[s]) == -1) {
                                indexids.push(divlastchildcountIds[s]);
                            }
                        }
                        var lastcount = Math.max(...indexids);
                        if(lastcount == -Infinity)
                        {
                            lastcount = -1;
                        }
                        var counts = lastcount + 1;

                        $('#item' + divid[1]).append(`<div id="submenuitem_` + divid[1] + '' + counts + `" style="padding-top:1%">
                                                      <input type="text" style="text-align:left;font-style: italic;font-family: -webkit-pictograph;font-size:20px;width:30%;" placeholder="Sub Menu Item Name" id="submenuitemnames_` + divid[1] + '' + counts + `">
                                                      <label style="width:3%"/><input type="text" style="text-align:left;font-style: italic;font-family: -webkit-pictograph;font-size:20px;width:60%;" placeholder="Sub Menu Item Description" id="submenuitemdescs_` + divid[1] + '' + counts + `">
                                                      <i class="fa fa-times-circle-o" aria-hidden="true" style="float: right;font-size: 20px;margin-right: 5%; cursor: pointer;" id="removeSubMenusItemDuringEdits_` + divid[1] + '' + counts + `"></i>
                                                    </div>`);
                        $('#removeSubMenusItemDuringEdits_' + divid[1] + '' + counts).click(function () {
                            var currentclicksubindex = $(this)[0].getAttribute('id');
                            if (currentclicksubindex) {
                                var divindex = currentclicksubindex.split('_');
                                $('#submenuitem_' + divindex[1]).remove();
                            }
                        })
                    })
                }
                var mainMenuCounts = lastitemid;
                $('#ItemTemplate').append('<br/><button class="btn btn-primary" id="addmainmenuitem">Add Main Menu Items</button>');
                $('#addmainmenuitem').click(function () {
                    mainMenuCounts = mainMenuCounts + 1;
                    $('#ItemTemplate').append(`<div id="item` + mainMenuCounts + `">
                    <div id='mainheadingdiv_` + mainMenuCounts + `' style='text-align:center;margin-top: 15px;padding-top:0px;padding-bottom:10px;margin-bottom:0px;'>
                    <input type="text" placeholder="Main Menu Item Name" style="font-weight:bolder;text-align:center;margin-top: 15px;padding-top:0px;padding-bottom:10px;margin-bottom:0px;color:rgb(158, 7, 100);text-transform:capitalize;font-variant:small-caps;padding:10px 16%;width:90%;" id="mainfooditemname_` + mainMenuCounts + `">
                    <br/><br/><input type="text" placeholder="Description 1" style="text-align:center;color:rgb(158, 7, 100);text-transform:capitalize;font-variant: small-caps;font-weight:bolder;font-size:16px;width:90%;" id="mainfooditemdescline1_` + i + `">
                    <br/><br/><input type="text" placeholder="Description 2" style="text-align:center;color:rgb(158, 7, 100);text-transform:capitalize;font-variant: small-caps;font-weight:bolder;font-size:16px;width:90%;" id="mainfooditemdescline2_` + i + `">
                    <i class="fa fa-times-circle-o" aria-hidden="true" style="float:right;font-size:20px;cursor:pointer;position:absolute;right:4%;margin-top:-8%;" id="removeMainMenuItemDuringEdits_` + mainMenuCounts + `" ></i>
                    <br/><br/><button class="btn btn-primary" style="float:left;margin:0 5%;" id="submenuAdd`+ mainMenuCounts + `">Add Sub Menu Items</button><br/><br/>
                    </div>`);

                    var subdiv = 0;
                    $('#submenuAdd' + mainMenuCounts).click(function () {
                        $('#item' + mainMenuCounts).append(`<div id="submenuitem_` + mainMenuCounts + '' + subdiv + `" style="padding-top:1%">
                                <input type="text" style="text-align:left;font-style: italic;font-family: -webkit-pictograph;font-size:20px;width:30%;" placeholder="Sub Menu Item Name" id="submenuitemnames_` + mainMenuCounts + '' + subdiv + `">
                                <label style="width:3%"/><input type="text" style="text-align:left;font-style: italic;font-family: -webkit-pictograph;font-size:20px;width:60%;" placeholder="Sub Menu Item Description" id="submenuitemdescs_` + mainMenuCounts + '' + subdiv + `">
                                <i class="fa fa-times-circle-o" aria-hidden="true" style="float: right;font-size: 20px;margin-right: 5%; cursor: pointer;" id="removeSubMenusItem_` + mainMenuCounts + '' + subdiv + `"></i>
                                </div>`);

                        $('#removeSubMenusItem_' + mainMenuCounts + '' + subdiv).click(function () {
                            var currentclicksubindexVal = $(this)[0].getAttribute('id');
                            if (currentclicksubindexVal) {
                                var divindex = currentclicksubindexVal.split('_');
                                $('#submenuitem_' + divindex[1]).remove();
                            }
                        })
                        subdiv = subdiv + 1;
                    })

                    $('#removeMainMenuItemDuringEdits_' + mainMenuCounts).click(function () {
                        //alert(mainMenuCount);
                        $('#addsubmenudivduringedit_' + mainMenuCounts).css('display', 'none');
                        var currentclickmainindexVal = $(this)[0].getAttribute('id');
                        if (currentclickmainindexVal) {
                            var divindex = currentclickmainindexVal.split('_');
                            $('#mainheadingdiv_' + divindex[1]).remove();
                        }
                        var submenulength = $('div[id^=submenuitem_' + divindex[1] + ']').length;
                        if (submenulength != undefined || submenulength != 0) {
                            for (var k = 0; k < submenulength; k++) {
                                var submenuid = $('#submenuitem_' + divindex[1] + '' + k)[0].id;
                                $('#' + submenuid).remove();
                            }
                        }
                    })
                })

                $('#footerHeading').replaceWith('<input type="text" placeholder="Footer heading" id="fheading" style="font-style: italic;font-family: -webkit-pictograph;text-align:center;font-weight:bold;color:rgb(158, 7, 100);width:90%;" value="' + $('#footerHeading').html() + '">');
                $('#footerDesc').replaceWith('<br><br/><textarea placeholder="Footer description" id="fdesc" style="font-style: italic;font-family: -webkit-pictograph;font-weight:bold;width:90%;" rows="5" cols="2000">' + $('#footerDesc').html() + '</textarea>');


            }

            if (tmpId == 3) {
                this.editTmpId = 0;
                this.editTmpId = tmpId;
                this.templateId = tmpId;

                $('hr').css('display', 'none');

                if ($('#clublogoImage').change()) {
                    if (($('#editclublogoVal').attr('src')) == undefined) {
                        this.clublogoimagepath = $('#clublogoImage').attr('src');
                        this.editClubLogoImagepath = '';
                    }
                    else {
                        this.editClubLogoImagepath = $('#editclublogoVal').attr('src');
                        this.clublogoimagepath = '';
                    }
                }
                var mainmenudivscount = []; var mainmenudivsitemid = []; var lastitemid;
                mainmenudivscount.push($('div[id^=mainmenudiv_]'));

                for (var q = 0; q < mainmenudivscount[0].length; q++) {
                    mainmenudivsitemid.push(mainmenudivscount[0][q].getAttribute('id'));
                }
                mainmenudivsitemid = this.removeDuplicates(mainmenudivsitemid);
                lastitemid = (mainmenudivsitemid[mainmenudivsitemid.length - 1]).split('');
                lastitemid = parseInt(lastitemid[lastitemid.length - 1]);
                var subdivscount = []; var subdivscols;
                for (var i = 0; i <= lastitemid; i++) {
                    if ($('#mainfooditem_' + i).val() != undefined) {
                        $('#mainfooditem_' + i).replaceWith("<br/><input type='text' id='mainfooditemnameduringedit_" + i + "' style='text-align:center;width:90%;color:#000;text-transform:uppercase;font-weight: bolder;margin-bottom:0px;font-size:22px;margin-top:-12px;' placeholder='Main Food Menu Item Name' value='" + $('#mainfooditem_' + i).html() + "'>");
                        $('#mainfooddescline1_' + i).replaceWith("<br/><br/><input type='text' id='mainfooditemdesc1duringedit_" + i + "' style='text-align:center;width:90%;color:#000;font-weight: bolder;margin-bottom:0px;font-size:20px;' placeholder='Main Food Menu Item Description 1' value='" + $('#mainfooddescline1_' + i).html() + "'>");
                        $('#mainfooddescline2_' + i).replaceWith("<br/><input type='text' id='mainfooditemdesc2duringedit_" + i + "' style='text-align:center;width:90%;color:#000;font-weight: bolder;margin-bottom:18px;font-size:20px;' placeholder='Main Food Menu Item Description 2' value='" + $('#mainfooddescline2_' + i).html() + "'>");
                        $('#mainmenudiv_' + i).append('<i class="fa fa-times-circle-o" aria-hidden="true" style="float:right;font-size:20px;cursor:pointer;position:absolute;right:3%;margin-top:-125px;" id="removeMainMenuItemDuringEdit_' + i + '" ></i>');
                        var submenucounting;
                        subdivscount.push(($('#submenutable_' + i).children('tbody').children('tr').children('td')));
                        for (var m = 0; m < subdivscount.length; m++) {
                            if(subdivscount[m].length == 0)
                            {
                                
                            }
                            else {
                                subdivscols = subdivscount[m][subdivscount[m].length - 1].getAttribute('id').split('_');
                                if (subdivscols[1].length == 2) {
                                    subdivscols = subdivscols[1].split('');
                                    subdivscols = subdivscols[1];
                                }
                                else {
                                    subdivscols = subdivscols[1].splice(-2);
                                }
                            }
                        }
                        for (var j = 0; j <= subdivscols; j++) {
                            $('#submenuitemname_' + i + '' + j).replaceWith("<input type='text' placeholder='Sub Menu Name' id='submenuitemnameduringedit" + i + '' + j + "' style='width: 90%;font-weight: bold;font-size: 20px;color: saddlebrown;text-transform: capitalize;' value='" + $('#submenuitemname_' + i + '' + j).html() + "'>");
                            $('#submenuitemdesc_' + i + '' + j).replaceWith("<textarea placeholder='Sub Menu Description' id='submenuitemdescduringedit" + i + '' + j + "' style='width: 90%;font-size: 20px;text-transform: capitalize;margin-top:-12px;' rows='3' cols='100'>" + $('#submenuitemdesc_' + i + '' + j).html() + "</textarea>");

                            $('#col_' + i + '' + j).append('<i class="fa fa-times-circle-o" style="float:right;margin-top:-64px;margin-right:30px;font-size:18px;" id="removeSubMenuItemDuringEdit_' + i + '' + j + '" aria-hidden="true"></i>');

                            $('#removeSubMenuItemDuringEdit_' + i + '' + j).click(function () {
                                var currentclicksubindex = $(this)[0].getAttribute('id');
                                if (currentclicksubindex) {
                                    var divindex = currentclicksubindex.split('_');
                                    $('#col_' + divindex[1]).remove();
                                }
                            })
                        }
                        
                        if(subdivscols == undefined)
                        {
                            subdivscols = 0;
                        }
                        submenucounting = parseInt(subdivscols) + 1;
                        
                        $('#submenutable_' + i).append('<button class="btn btn-primary" id="addSubMenudivDuringEdits_' + i + '" style="margin-left:12px;">Add Sub Menu Item</button><br/>');
                        $('#addSubMenudivDuringEdits_' + i).click(function () {
                            var submenutableclicked = ($(this)[0].getAttribute('id')).split('_');
                            var tds = [];
                            tds.push($('#submenutable_' + submenutableclicked[1]).children('tbody').children('tr').children('td'));
                            var lastsubmenuitem; var lastsubmenuitemindex; var lastsubmenuitemindexVal;
                            if(tds[0][tds[0].length - 1] != undefined)
                            {
                                lastsubmenuitem = (tds[0][tds[0].length - 1]).getAttribute('id');
                                lastsubmenuitemindex = lastsubmenuitem.split('_');
                                lastsubmenuitemindexVal = lastsubmenuitemindex[1].split('');
                            }
                            else
                            {
                                $('#submenutable_' + submenutableclicked[1]).append('<tbody><tr>');
                                submenucounting = 0;
                            }
                            $('#submenutable_' + submenutableclicked[1] + ' tbody tr').append(`<td class="col-xs-12 col-md-6" id="col_` + submenutableclicked[1] + '' + submenucounting + `" 
                        style="width:50%;padding-top:10px;float:left;">
                        <input type="text" placeholder="Sub Menu Item Name" id="submenuitemnameduringedit` + submenutableclicked[1] + '' + submenucounting + `" style="width: 90%;font-weight: bold;font-size: 20px;color: saddlebrown;text-transform: capitalize;">
                        <br/><br/><textarea placeholder="Sub Menu Item Description" id="submenuitemdescduringedit` + submenutableclicked[1] + '' + submenucounting + `" style="width: 90%;font-size: 20px;text-transform: capitalize;margin-top:-12px;" rows="3" cols="100"></textarea>
                        <i class="fa fa-times-circle-o" style="float:right;margin-top:-64px;margin-right:30px;font-size:18px;" id="removeSubMenuItemDuringEdits_` + submenutableclicked[1] + '' + submenucounting + `" aria-hidden="true"></i>
                        </td>`);

                            $('#removeSubMenuItemDuringEdits_' + submenutableclicked[1] + submenucounting).click(function () {
                                var currentclicksubindex = $(this)[0].getAttribute('id');
                                if (currentclicksubindex) {
                                    var divindex = currentclicksubindex.split('_');
                                    var subdivindex; var maindivindex;
                                    if (divindex[1].length == 2) {
                                        var ind = divindex[1].split('');
                                        subdivindex = ind[1];
                                        maindivindex = ind[0];
                                    }
                                    else if (divindex[1].length == 3) {
                                        var ind = divindex[1].split('');
                                        subdivindex = ind[1] + '' + ind[2];
                                        maindivindex = ind[0];
                                    }
                                    $('#col_' + maindivindex + '' + subdivindex).remove();
                                }
                            })
                            submenucounting = submenucounting + 1;
                        })

                        $('#removeMainMenuItemDuringEdit_' + i).click(function () {
                            var currentclickmainindex = $(this)[0].getAttribute('id');
                            if (currentclickmainindex) {
                                var divindex = currentclickmainindex.split('_');
                                $('#mainmenudiv_' + divindex[1]).remove();
                                $('#addSubMenudivDuringEdits_' + divindex[1]).css('display', 'none');
                            }
                            var submenulength = $('#submenutable_' + divindex[1]).children('tbody').children('tr').children('td').length;
                            for (var k = 0; k < submenulength; k++) {
                                var submenuid = $('#col_' + divindex[1] + k).attr('id');
                                $('#' + submenuid).remove();
                            }
                        })
                    }

                }
                $('#ItemTemplate').append('<br/><button class="btn btn-primary" id="addmainmenuitem" style="margin-top:10px;">Add Main Menu Items</button>');
                $('#addmainmenuitem').click(function () {
                    var mainmenudivcount = $('div[id^=mainmenudiv_]').length;
                    //alert(mainmenudivcount);
                    mainMenuCount = 0;
                    mainMenuCount = mainmenudivcount - 1;
                    mainMenuCount = mainMenuCount + 1;
                    $('#ItemTemplate').append(`<div id="mainmenudiv_` + mainMenuCount + `" class="col-xs-12 col-md-12" style="text-align: center;padding-top:0px;padding-bottom:10px;">
                    <br><input type="text" id="mainfooditemnameduringedit_`+ mainMenuCount + `" style="text-align:center;width:90%;color:#000;text-transform:uppercase;font-weight: bolder;margin-bottom:0px;font-size:22px;margin-top:-12px;" placeholder="Main Food Menu Item Name">
                    <br><br><input type="text" id="mainfooditemdesc1duringedit_`+ mainMenuCount + `" style="text-align:center;width:90%;color:#000;font-weight: bolder;margin-bottom:0px;font-size:20px;" placeholder="Main Food Menu Item Description 1"> 
                    <br><br><input type="text" id="mainfooditemdesc2duringedit_`+ mainMenuCount + `" style="text-align:center;width:90%;color:#000;font-weight: bolder;margin-bottom:18px;font-size:20px;" placeholder="Main Food Menu Item Description 2">
                    <i class="fa fa-times-circle-o" aria-hidden="true" style="float:right;font-size:20px;cursor:pointer;position:absolute;right:3%;margin-top:-125px;" id="removeMainMenuItemDuringEdits_`+ mainMenuCount + `"></i>
                    <br/><button class="btn btn-primary" style="float:left;margin:0 5%;" id="submenuAdd`+ mainMenuCount + `">Add Sub Menu Items</button><br/><br/>
                    </div><table class="col-xs-12 col-md-12" id="submenutable_`+ mainMenuCount + `" style="width:100%"><tbody><tr>`);

                    var subdiv = 0;
                    $('#submenuAdd' + mainMenuCount).click(function () {
                        $('#submenutable_' + mainMenuCount + ' tbody tr').append(`<td class="col-xs-12 col-md-6" id="col_` + mainMenuCount + '' + subdiv + `" style="width:50%;padding-top:10px;float:left;">
                        <input type="text" placeholder="Sub Menu Item Name" id="submenuitemnameduringedit` + mainMenuCount + '' + subdiv + `" style="width: 90%;font-weight: bold;font-size: 20px;color: saddlebrown;text-transform: capitalize;">
                        <br><br><textarea placeholder="Sub Menu Item Description" id="submenuitemdescduringedit`+ mainMenuCount + '' + subdiv + `" style="width: 90%;font-size: 20px;text-transform: capitalize;margin-top:-12px;" rows="3" cols="100"></textarea>
                        <i class="fa fa-times-circle-o" style="float:right;margin-top:-64px;margin-right:30px;font-size:18px;" id="removeSubMenusItem_`+ mainMenuCount + '' + subdiv + `" aria-hidden="true"></i>
                        </td>`);
                        $('#removeSubMenusItem_' + mainMenuCount + '' + subdiv).click(function () {
                            var currentclicksubindexVal = $(this)[0].getAttribute('id');
                            if (currentclicksubindexVal) {
                                var divindex = currentclicksubindexVal.split('_');
                                $('#col_' + divindex[1]).remove();
                            }
                        })
                        subdiv = subdiv + 1;
                    })
                    $('#removeMainMenuItemDuringEdits_' + mainMenuCount).click(function () {
                        $('#addSubMenudivDuringEdits_' + mainMenuCount).css('display', 'none');
                        var currentclickmainindexVal = $(this)[0].getAttribute('id');
                        if (currentclickmainindexVal) {
                            var divindex = currentclickmainindexVal.split('_');
                            $('#mainmenudiv_' + divindex[1]).remove();
                        }
                        var submenulength = $('#submenutable_' + divindex[1]).children('tbody').children('tr').children('td').length;
                        if (submenulength != undefined || submenulength != 0) {
                            for (var k = 0; k < submenulength; k++) {
                                var submenuid = $('#col_' + divindex[1] + '' + k)[0].id;
                                $('#' + submenuid).remove();
                            }
                        }
                    })
                })
                $('#ItemTemplate').append(`</table>`);
                $('#footerHeading').replaceWith('<input type="text" placeholder="Footer heading" id="fheading" style="margin-top:15px;font-weight:bold;color:black;font-size:20px;width:90%;text-align:center;" value="' + $('#footerHeading').html() + '">');
                $('#footerDesc').replaceWith('<br/><br/><textarea id="fdesc" placeholder="Footer description" style="font-style: italic;width:90%;" rows="5" cols="2000">' + $('#footerDesc').html() + '</textarea>');
            }
        }

    }
}