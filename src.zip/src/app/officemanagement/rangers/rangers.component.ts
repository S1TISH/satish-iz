import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-rangers',
  templateUrl: './rangers.component.html',
  styleUrls: ['./rangers.component.css']
})
export class RangersComponent implements OnInit {

  usersdata: any; roledata: any; clubusers: any; rangerdata: any;
  GridMessage: string = 'Loading, Please wait ... !';
  id: any; modifiedUid: any; modifyingUid: any; previousRoleid: any; modifiedRoleid: any;
  rangerstatus: any; rangerchkstatus: any; golfclubid: any; initialroleid: any;
  modalRef: BsModalRef;
  key: string = 'clubcourseadmin';
  reverse: boolean = false;
  nameasc: any = "sortwhite"; namedesc: any = "sortgreen"; roleasc: any = "sortwhite"; roledesc: any = "sortwhite";
  constructor(private title: Title,private modalService: BsModalService, public toastr: ToastsManager, vcr: ViewContainerRef, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService,
    private authService: AuthService, private router: Router) {
    
    this.title.setTitle("IZON - Rangers");
    this.toastr.setRootViewContainerRef(vcr);
    this.usersdata = []; this.roledata = []; this.clubusers = []; this.rangerdata = []; this.initialroleid = [];
    this.golfclubid = localStorage.getItem('clubId');
    this.modifyingUid = localStorage.getItem('userId');    
  }

  ngOnInit() {
    this.getClubUsers();
    let parameters = { searchvalue: " WHERE U_STATUS = 'Y' " };
    this.getUsers(parameters);

    this.getRoles();

    this.viewgetRangers();
  }

  sort(value: string) {
    this.key = value;
    this.nameasc = "sortwhite"; this.namedesc = "sortwhite"; this.roleasc = "sortwhite"; this.roledesc = "sortwhite";
    if (this.key == value) {
      this.reverse = !this.reverse;
      if (this.key == "clubcourseadmin" && this.reverse) {
        this.nameasc = "sortgreen";
      }
      else if (this.key == "clubcourseadmin" && (!this.reverse)) {
        this.namedesc = "sortgreen";
      }
      else if (this.key == "rolename" && this.reverse) {
        this.roleasc = "sortgreen"; 
      }
      else if (this.key == "rolename" && (!this.reverse)) {
       this.roledesc = "sortgreen";
      }
    }
  }

  getClubUsers() {
    this.spinnerService.show();
    let parameters1 = {
      searchvalue: " WHERE GCCA_GCB_ID = " + this.golfclubid + " AND GCCA_STATUS = 'Y' "
    };
    this.api.postOH('getclubcourseuserassignment', parameters1).subscribe(
      (data) => {
        if (data.length > 0) {
          for (let k = 0; k < data.length; k++) {
            this.clubusers.push({
              "id": data[k].id,
              "clubcourseid": data[k].clubcourseid,
              "clubcoursename": data[k].clubcoursename,
              "clubcourseuserid": data[k].clubcourseuserid,
              "clubcourseadmin": data[k].clubcourseadmin
            });
          }
          this.spinnerService.hide();
        }
        else if (data.length == 0) {
          this.spinnerService.hide();
          this.GridMessage = "No data found";
        }
      }, error => {
        this.spinnerService.hide();
      }
    )
  }  

  getUsers(parameters) {
    this.api.postOH('getusers', parameters).subscribe(
      (response) => {
        this.usersdata = [];
        for (let i = 0; i < response.length; i++) {
          this.usersdata.push({
            "userid": response[i].id,
            "name": response[i].name,
            "roleid": response[i].roleid,
            "rolename": response[i].rolename,
            "clubuserdata": this.clubusers
          });
          //console.log(this.usersdata);
        }
      }, error => {

      }
    );
  }

  getRoles() {
    let parameters = { searchvalue: " WHERE R_STATUS = 'Y' AND R_CODE = 'CR'" };
    this.api.postOH('getuserroles', parameters).subscribe(
      (response) => {
        this.roledata = [];
        for (let i = 0; i < response.length; i++) {
          this.roledata.push({
            'rolesid': response[i].id,
            'rolesname': response[i].name,
            'rolescode': response[i].code
          })
        }
      }, error => {

      }
    );
  }

  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',
    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 5000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }

  toggleChange(user, isRangerStatus) {
    this.id = 0;
    var rangerroleid = this.roledata[0].rolesid;
    if (isRangerStatus == true) {
      this.rangerstatus = true;
      this.rangerchkstatus = 'Y';
      this.modifiedRoleid = rangerroleid;
      this.previousRoleid = user.roleid;
      this.modifiedUid = user.userid;
    }
    else if (isRangerStatus == false) {
      this.rangerstatus = false;
      this.rangerchkstatus = 'N';
      for (var i = 0; i < this.rangerdata.length; i++) {
        if (user.userid == this.rangerdata[i].modifiedUserId && this.rangerdata[i].status == 'Y' && this.rangerdata[i].previousRoleId != rangerroleid) {
          this.initialroleid.push(this.rangerdata[i].previousRoleId);
        }
      }
      this.modifiedRoleid = parseInt((this.removeDuplicates(this.initialroleid)).toString());
      //this.modifiedRoleid = 2;
      this.previousRoleid = user.roleid;
      this.modifiedUid = user.userid;
    }
    var rangermodel = {
      'id': this.id, 'modifiedUserId': this.modifiedUid, 'previousRoleId': this.previousRoleid,
      'modifiedRoleId': this.modifiedRoleid, 'modifyingUserId': parseInt(this.modifyingUid),
      'status': this.rangerchkstatus
    }
    this.spinnerService.show();
    //console.log(rangermodel);
    this.api.postOH('saveRangerData', rangermodel).subscribe(
      (response) => {
        if (response[1] == 'Ranger Updated Successfully') {
          let parameters = { searchvalue: " WHERE U_STATUS = 'Y' " };
          this.getUsers(parameters);
          let msg = '<span style="color: green">Ranger updated Successfully. </span>';
          this.toastMessage(msg);
        }else{
          let msg = '<span style="color: red">Ranger updated Failed. </span>';
          this.toastMessage(msg);
        }
        this.spinnerService.hide();
      },error=>{
        this.spinnerService.hide();
      })
  }

  removeDuplicates(arr) {
    let unique_array = []
    for (let i = 0; i < arr.length; i++) {
      if (unique_array.indexOf(arr[i]) == -1) {
        unique_array.push(arr[i])
      }
    }
    return unique_array;
  }

  viewgetRangers() {
    let parameters = {
      searchvalue: ""
    };
    this.api.postOH('getRangerView', parameters).subscribe(
      (data) => {
        this.rangerdata = data;
      })
  }

}
