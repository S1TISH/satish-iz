import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FullCalendarModule } from 'ng-fullcalendar';
//import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { ModalModule } from 'ngx-bootstrap';
import { OrderModule } from 'ngx-order-pipe';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { PopoverModule } from 'ngx-bootstrap';

import { FoodbeverageComponent } from './foodbeverage/foodbeverage.component';
import { RangersComponent } from './rangers/rangers.component';
import { ComingsoonComponent } from './comingsoon/comingsoon.component';

const routes: Routes = [  
  {
    path:'rangers',
    component:RangersComponent
  },
  {
    path:'foodbeverage',
    component:FoodbeverageComponent
  },
  {
    path:'comingsoon',
    component:ComingsoonComponent
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule, ReactiveFormsModule,
    FullCalendarModule,OrderModule,
    ToastModule.forRoot(),
    ModalModule.forRoot(),
    OwlDateTimeModule,PopoverModule.forRoot(),
    OwlNativeDateTimeModule, BsDatepickerModule.forRoot()
  ],
  declarations: [FoodbeverageComponent, RangersComponent, ComingsoonComponent],
  exports: [RouterModule]  
})
export class OfficemanagementModule { }
