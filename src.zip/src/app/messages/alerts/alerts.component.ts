import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Title } from '@angular/platform-browser';
import { Observable } from 'rxjs/Rx';
import * as moment from "moment";

declare const google: any;

@Component({
  selector: 'app-alerts',
  templateUrl: './alerts.component.html',
  styleUrls: ['./alerts.component.css']
})
export class AlertsComponent implements OnInit {
  modalRef: BsModalRef; map: any;
  alertsData: any; clubid: any;
  GridMessage: string = 'Loading, Please wait ... !';
  next: boolean = true; alertLength: number = 0; previous: boolean = false; RecordsCount: number = 0;
  countvalue: number = 0;
  golfclubid: any = localStorage.getItem('clubId');
  courseId: any = localStorage.getItem('courseId');
  courselat: any; courselong: any; //sub: any;
  currentGolfCourseDateTime: any = "";
  coursezoomlevel: any;
  //search
  ddlsearch: any;
  selectedoption: any = "Active"; randomcolor: any = "#5cb85c";
  txtsrch: string = ''; srchError: string = '0';
  ddlstatus: any; statusddl: boolean = false; txtsearch: boolean = true;

  //alertcount
  count: any;

  //sort values
  key: string = 'date';
  reverse: boolean = false;
  // reverse: boolean = true;
  cartidasc: any = "sortwhite";
  cartiddesc: any = "sortwhite";
  alerttypeasc: any = "sortwhite";
  alerttypedesc: any = "sortwhite";
  alertasc: any = "sortwhite";
  alertdesc: any = "sortwhite";
  dateasc: any = "sortgreen";
  datedesc: any = "sortwhite";

  showmapasc: any = "sortwhite";
  showmapdesc: any = "sortwhite";
  showmap:boolean=false;markers: any = [];
  selectmessages: string = '1'; searchmsg: boolean = false;CartName:any;

 Offset:any=""
 timeoffset: any = '';CoursesInfo:any; 

  constructor(private title: Title, private modalService: BsModalService, public toastr: ToastsManager, vcr: ViewContainerRef, private _router: Router, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService,
    private authService: AuthService, private router: Router) {
    this.toastr.setRootViewContainerRef(vcr);
    this.title.setTitle("IZON - Alerts");
    this.alertsData = [];
    this.clubid = localStorage.getItem('clubId');
    this.ddlsearch = "CARTNAME";
    this.ddlstatus = "0";
  }

  ngOnInit() {
    let searchexp = "";
    searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' and  GC_ID='" + this.courseId + "'"
    let params = { searchvalue: searchexp };
    this.getcourses(params);
  }

  //Gets Golf-Course Coordinates
  getcourses(params) {
    this.CoursesInfo=[];
    this.api.postOH('getgolfcourse', params).subscribe(
      response => {
        if (response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            this.CoursesInfo.push({
                "id": response[i].id
            })
        }
          this.courselat = response[0].latitude;
          this.courselong = response[0].longitude;
          this.timeoffset = response[0].timeoffset;
          this.coursezoomlevel = (response[0].zoomlevel != '') ? response[0].zoomlevel : 0;
          this.getTimeUsingLatLng(this.courselat, this.courselong, this.timeoffset);
        }
      }, error => {

      });
  }

  //Gets Golf Course Current Date & Time using coordinates
  getTimeUsingLatLng(lat, lng, offset) {
    this.currentGolfCourseDateTime = "";

        let currentDate: any = '';
        let d = new Date();
        let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
        currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
        this.currentGolfCourseDateTime = moment(currentDate).format('MM/DD/YYYY');
          let searchexp = " WHERE AR_GCB_ID=" + this.clubid + "";
          let countVal = this.countvalue;
          this.getalerts(this.clubid, searchexp, countVal, this.currentGolfCourseDateTime);
     
  }

  getalerts(clubid, searchvalue, countvalue, datetime) {
    var dateString = '';
    //var date = new Date(); 
    // dateString = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
    dateString = datetime;
    let parameters = {
      clubid: clubid,
      searchvalue: searchvalue,
      countvalue: countvalue,
      dateString: dateString,
      currentorpreviousmsgs: this.selectmessages
    };
    this.spinnerService.show();
    this.api.postOH('GetAlertslist', parameters).subscribe(
      (response) => {
        this.alertsData = [];
        if (response.length != 0) {
          this.RecordsCount = parseInt(response[0].TotalRecords);
          for (let i = 0; i < response.length; i++) {
            var status = (response[i].status == 'Y') ? "Viewed" : (response[i].status == 'N') ? "Not-Viewed" : "Deleted";
            var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
            var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
            var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
            var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
            var confirmshow = "row-icon-inactive";
            this.alertsData.push({
              "clubid": response[i].clubid,
              "cartid": response[i].cartid,
              "cartname": response[i].carname,
              "alertlat": response[i].alertlat,
              "alertlong": response[i].alertlong,
              "alerttype": response[i].AlertType,
              "alerttypefrom": response[i].alerttypefrom,
              "alerttypeid": response[i].alerttypeid,
              "alertmsg": response[i].alertmsg,
              "date": response[i].date,
              "status": status,
              "statusclass": statusclass,
              "editshow": editshow,
              "enableshow": enableshow,
              "removeshow": removeshow,
              "confirmshow": confirmshow
            });
          }
          if (this.previous == false) {
            this.alertLength = this.countvalue + this.alertsData.length;
            if ((this.RecordsCount == this.alertLength) && this.previous == false) {
              this.next = false;
            }
            else {
              this.next = true;
            }
          }
          else {
            this.next = true;
          }
        }
        else {
          this.GridMessage = "No Data Found";
          this.next = false;
          this.alertLength = 0;
          this.RecordsCount = 0;
        }
        this.spinnerService.hide();

      }, error => {
        this.spinnerService.hide();
      }
    );
  }

  sort(value: string) {
    this.key = value;
    this.cartidasc = "sortwhite"; this.cartiddesc = "sortwhite";
    this.alerttypeasc = "sortwhite"; this.alerttypedesc = "sortwhite";
    this.alertasc = "sortwhite"; this.alertdesc = "sortwhite";
    this.dateasc = "sortwhite"; this.datedesc = "sortwhite";
    this.showmapasc="sortwhite"; this.showmapdesc="sortwhite";
    if (this.key == value) {
      this.reverse = !this.reverse;
      if (this.key == "cartname" && this.reverse) {
        this.cartiddesc = "sortgreen";
        this.cartsSorting(this.alertsData);
      }
      else if (this.key == "cartname" && (!this.reverse)) {
        this.cartidasc = "sortgreen";
        this.cartsReverseSorting(this.alertsData);
      }
      else if (this.key == "alerttype" && this.reverse) {
        this.alerttypedesc = "sortgreen";
        this.alertTypeSorting(this.alertsData);
      }
      else if (this.key == "alerttype" && (!this.reverse)) {
        this.alerttypeasc = "sortgreen";
        this.alertTypeReverseSorting(this.alertsData);
      }


      else if (this.key == "showmap" && this.reverse) {
        this.showmapdesc = "sortgreen";
        this.showmapSorting(this.alertsData);
      }
      else if (this.key == "showmap" && (!this.reverse)) {
        this.showmapasc = "sortgreen";
        this.showmapReverseSorting(this.alertsData);
      }

      
      else if (this.key == "alertmsg" && this.reverse) {
        this.alertdesc = "sortgreen";
        this.alertMessageSorting(this.alertsData);
      }
      else if (this.key == "alertmsg" && (!this.reverse)) {
        this.alertasc = "sortgreen";
        this.alertMessageReverseSorting(this.alertsData);
      }
      else if (this.key == "date" && this.reverse) {
        this.datedesc = "sortgreen";
        this.alertDateReverseSorting(this.alertsData);
      }
      else if (this.key == "date" && (!this.reverse)) {
        this.dateasc = "sortgreen";
        this.alertDateReverseSorting(this.alertsData);
      }
    }
  }

  cartsSorting(carts) {
    //sorting
    carts.sort(function (a, b) {
      //  return a.CartName.length - b.CartName.length
      var reA = /[^a-zA-Z]/g;
      var reN = /[^0-9]/g;
      var AInt = parseInt(a.cartname, 10);
      var BInt = parseInt(b.cartname, 10);

      if (isNaN(AInt) && isNaN(BInt)) {
        var aA = a.cartname.replace(reA, "");
        var bA = b.cartname.replace(reA, "");
        if (aA === bA) {
          var aN = parseInt(a.cartname.replace(reN, ""), 10);
          var bN = parseInt(b.cartname.replace(reN, ""), 10);
          return aN === bN ? 0 : aN > bN ? 1 : -1;
        } else {
          return aA > bA ? 1 : -1;
        }
      } else if (isNaN(AInt)) {//A is not an Int
        return 1;//to make alphanumeric sort first return -1 here
      } else if (isNaN(BInt)) {//B is not an Int
        return -1;//to make alphanumeric sort first return 1 here
      } else {
        return AInt > BInt ? 1 : -1;
      }
    });
  }

  cartsReverseSorting(carts) {
    //sorting
    carts.sort(function (b, a) {
      //  return b.CartName.length - a.CartName.length
      var reA = /[^a-zA-Z]/g;
      var reN = /[^0-9]/g;
      var AInt = parseInt(a.cartname, 10);
      var BInt = parseInt(b.cartname, 10);

      if (isNaN(AInt) && isNaN(BInt)) {
        var aA = a.cartname.replace(reA, "");
        var bA = b.cartname.replace(reA, "");
        if (aA === bA) {
          var aN = parseInt(a.cartname.replace(reN, ""), 10);
          var bN = parseInt(b.cartname.replace(reN, ""), 10);
          return aN === bN ? 0 : aN > bN ? 1 : -1;
        } else {
          return aA > bA ? 1 : -1;
        }
      } else if (isNaN(AInt)) {//A is not an Int
        return 1;//to make alphanumeric sort first return -1 here
      } else if (isNaN(BInt)) {//B is not an Int
        return -1;//to make alphanumeric sort first return 1 here
      } else {
        return AInt > BInt ? 1 : -1;
      }
    });
  }

  alertTypeSorting(alerts) {
    // sort by alerttype
    alerts.sort(function (a, b) {
      var typeA = a.alerttypefrom.toUpperCase();
      var typeB = b.alerttypefrom.toUpperCase();
      if (typeA < typeB) {
        return -1;
      }
      if (typeA > typeB) {
        return 1;
      }
      return 0;
    });
  }

  alertTypeReverseSorting(alerts) {
    // reverse sort by alerttype
    alerts.reverse(function (a, b) {
      var typeA = a.alerttypefrom.toUpperCase();
      var typeB = b.alerttypefrom.toUpperCase();
      if (typeA < typeB) {
        return -1;
      }
      if (typeA > typeB) {
        return 1;
      }
      return 0;
    });
  }


  alertMessageSorting(alerts) {
    // sort by message
    alerts.sort(function (a, b) {
      var typeA = a.alertmsg.toUpperCase();
      var typeB = b.alertmsg.toUpperCase();
      if (typeA < typeB) {
        return -1;
      }
      if (typeA > typeB) {
        return 1;
      }
      return 0;
    });
  }

  showmapSorting(alerts) {
    // sort by alerttype
    alerts.sort(function (a, b) {
      var typeA = a.alerttypefrom.toUpperCase();
      var typeB = b.alerttypefrom.toUpperCase();
      if (typeA < typeB) {
        return -1;
      }
      if (typeA > typeB) {
        return 1;
      }
      return 0;
    });
  }

  showmapReverseSorting(alerts) {
    // reverse sort by alerttype
    alerts.reverse(function (a, b) {
      var typeA = a.alerttypefrom.toUpperCase();
      var typeB = b.alerttypefrom.toUpperCase();
      if (typeA < typeB) {
        return -1;
      }
      if (typeA > typeB) {
        return 1;
      }
      return 0;
    });
  }


  alertMessageReverseSorting(alerts) {
    // reverse sort by message
    alerts.reverse(function (a, b) {
      var typeA = a.alertmsg.toUpperCase();
      var typeB = b.alertmsg.toUpperCase();
      if (typeA < typeB) {
        return -1;
      }
      if (typeA > typeB) {
        return 1;
      }
      return 0;
    });
  }

  alertDateSorting(alerts) {
    return alerts.sort((a, b) => {
      return <any>new Date(a.date) - <any>new Date(b.date);
    });
  }

  alertDateReverseSorting(alerts) {
    return alerts.reverse((b, a) => {
      return <any>new Date(b.date) - <any>new Date(a.date);
    });
  }

  refreshpage() {
    this.searchmsg = false;
    this.alertLength = 0;
    this.countvalue = 0;
    this.selectedoption = "Active";
    this.randomcolor = "#5cb85c";
    let clubid = this.clubid;
    // let searchexp = " WHERE AR_GCB_ID=" + this.clubid + "";
    // let countVal = this.countvalue;
    // this.getalerts(clubid, searchexp, countVal);
    let searchexp = "";
    searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' and  GC_ID='" + this.courseId + "'"
    let params = { searchvalue: searchexp };
    this.getcourses(params);
    this.txtsrch = "";
    this.ddlstatus = "0";
    this.txtsearch = true; this.statusddl = false;
    this.ddlsearch = "CARTNAME";
    this.srchError = "0";
    this.cartidasc = "sortwhite";
    this.cartiddesc = "sortwhite";
    this.alerttypeasc = "sortwhite";
    this.alerttypedesc = "sortwhite";
    this.alertasc = "sortwhite";
    this.alertdesc = "sortwhite";
    this.dateasc = "sortgreen";
    this.datedesc = "sortwhite";
  }

  dropdownsearch(val) {
    if (val.value === "AR_VIEW_STATUS") {
      this.txtsearch = false;
      this.statusddl = true;
    }
    else {
      this.txtsearch = true;
      this.statusddl = false;
    }
    this.txtsrch = ''; this.countvalue = 0;
    // let searchexp = " WHERE AR_GCB_ID=" + this.clubid + "";
    // let countVal = this.countvalue;
    // this.getalerts(this.clubid, searchexp, countVal);
    let searchexp = "";
    searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' and  GC_ID='" + this.courseId + "'"
    let params = { searchvalue: searchexp };
    this.getcourses(params);
  }

  search() {
    this.searchmsg = true;
    this.alertLength = 0;
    this.countvalue = 0;
    if (this.txtsrch == '' && this.ddlsearch != "AR_VIEW_STATUS") {
      this.srchError = '1';
    }
    else if (this.txtsrch != "") {
      this.srchError = '0';
      if (this.ddlsearch === "CARTNAME") {
        let clubid = this.clubid;
        let searchexpression = " WHERE AR_GCB_ID = '" + this.clubid + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND AR_VIEW_STATUS <> 'D'";
        let countVal = 0;
        this.getalerts(clubid, searchexpression, countVal, this.currentGolfCourseDateTime);
      }
      else if (this.ddlsearch === "AlertType") {
        let clubid = this.clubid;
        let searchexpression = " WHERE AR_GCB_ID = '" + this.clubid + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND AR_VIEW_STATUS <> 'D'";
        let countVal = 0;
        this.getalerts(clubid, searchexpression, countVal, this.currentGolfCourseDateTime);
      }
    }
    else if (this.ddlsearch === "AR_VIEW_STATUS") {
      this.srchError = '0';
      let searchexp = "";
      if (this.ddlstatus === "viewed") {
        searchexp = " WHERE AR_GCB_ID = '" + this.clubid + "' AND AR_VIEW_STATUS = 'Y'"

      }
      else if (this.ddlstatus === "notviewed") {
        searchexp = " WHERE AR_GCB_ID = '" + this.clubid + "' AND AR_VIEW_STATUS = 'N'"
      }
      else {
        searchexp = " WHERE AR_GCB_ID = '" + this.clubid + "' AND AR_VIEW_STATUS <> 'D'"
      }
      let clubid = this.clubid;
      let searchexpression = searchexp;
      let countVal = 0;
      this.getalerts(clubid, searchexpression, countVal, this.currentGolfCourseDateTime);
    }

  }

  srchKeyUp(event: any) {
    if (this.txtsrch != '') {
      this.srchError = '0';
    }
  }

  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',

    };
    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 5000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }

  getAlertCount(clubId) {
    let parameters = {
      clubid: this.clubid,
      searchvalue: " WHERE AR_GCB_ID=" + clubId + " AND AR_VIEW_STATUS = 'N'",
      countvalue: 0
    };
    this.api.postOH('getalertcount', parameters).subscribe(
      (response) => {
        this.authService.getCall();
        this.count = (response.getalertcountResult > 99) ? '99+' : response.getalertcountResult;
        localStorage.setItem('AlertCount', this.count);
      });
  }

  updateStatus(alertRecord) {
    if (alertRecord.alerttype == "GC ") {
      var alertinfo = {
        "clubid": alertRecord.clubid,
        "cartid": alertRecord.cartid,
        "alerttypeid": alertRecord.alerttypeid,
        "date": alertRecord.date
      }
      this.api.postOH('UpdateAlertStatusfromHeader', alertinfo).subscribe(
        (response) => {
          if (response.UpdateAlertStatusfromHeaderResult == "Success") {
            let clubid = this.clubid;
            let searchexp = " WHERE AR_GCB_ID=" + this.clubid + "";
            let countVal = 0;
            this.getalerts(clubid, searchexp, countVal, this.currentGolfCourseDateTime);
            this.getAlertCount(this.clubid);
            let msg = '<span style="color: green">Alert Status from Golf Course updated Successfully. </span>';
            this.toastMessage(msg);
          }
          else {
            let msg = '<span style="color: red">Problem while updating Alert Status. </span>';
            this.toastMessage(msg);
          }
        }, error => {
          let msg = '<span style="color: red">Problem while updating Alert Status.</span>';
          this.toastMessage(msg);
        }
      );
    }
    else if (alertRecord.alerttype == "MSG") {
      var alertinfo = {
        "clubid": alertRecord.clubid,
        "cartid": alertRecord.cartid,
        "alerttypeid": alertRecord.alerttypeid,
        "date": alertRecord.date
      }
      this.api.postOH('UpdateAlertStatusfromHeader', alertinfo).subscribe(
        (response) => {
          if (response.UpdateAlertStatusfromHeaderResult == "Success") {
            let clubid = this.clubid;
            let searchexp = " WHERE AR_GCB_ID=" + this.clubid + "";
            let countVal = 0;
            this.getalerts(clubid, searchexp, countVal, this.currentGolfCourseDateTime);
            this.getAlertCount(this.clubid);
            let msg = '<span style="color: green">Alert Status from Club Contact updated Successfully .</span>';
            this.toastMessage(msg);
          }
          else {
            let msg = '<span style="color: red">Problem while updating Alert Status.</span>';
            this.toastMessage(msg);
          }
        }, error => {
          let msg = '<span style="color: red">Problem while updating Alert Status.</span>';
          this.toastMessage(msg);
        }
      );
    }
  }

  nextAlerts() {
    this.countvalue += 20; this.previous = false;
    if (this.txtsrch == "" && this.ddlstatus == "0") {
      let clubid = this.clubid;
      let countVal = this.countvalue;
      let searchexp = " WHERE AR_GCB_ID=" + this.clubid + "";
      this.getalerts(clubid, searchexp, countVal, this.currentGolfCourseDateTime);
    }
    else {
      if (this.txtsrch != "") {
        this.srchError = '0';
        if (this.ddlsearch === "CARTNAME") {
          let clubid = this.clubid;
          let searchexpression = " WHERE AR_GCB_ID = '" + this.clubid + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND AR_VIEW_STATUS <> 'D'";
          let countVal = this.countvalue;
          this.getalerts(clubid, searchexpression, countVal, this.currentGolfCourseDateTime);
        }
        else if (this.ddlsearch === "AlertType") {
          let clubid = this.clubid;
          let searchexpression = " WHERE AR_GCB_ID = '" + this.clubid + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND AR_VIEW_STATUS <> 'D'";
          let countVal = this.countvalue;
          this.getalerts(clubid, searchexpression, countVal, this.currentGolfCourseDateTime);
        }
      }
      else if (this.ddlsearch === "AR_VIEW_STATUS") {
        this.srchError = '0';
        let searchexp = "";
        if (this.ddlstatus === "viewed") {
          searchexp = " WHERE AR_GCB_ID = '" + this.clubid + "' AND AR_VIEW_STATUS = 'Y'"

        }
        else if (this.ddlstatus === "notviewed") {
          searchexp = " WHERE AR_GCB_ID = '" + this.clubid + "' AND AR_VIEW_STATUS = 'N'"
        }
        else {
          searchexp = " WHERE AR_GCB_ID = '" + this.clubid + "' AND AR_VIEW_STATUS <> 'D'"
        }
        let clubid = this.clubid;
        let searchexpression = searchexp;
        let countVal = this.countvalue;
        this.getalerts(clubid, searchexpression, countVal, this.currentGolfCourseDateTime);
      }
    }
  }

  previousAlerts() {
    this.countvalue = this.countvalue - 20; this.previous = false;
    //this.alertLength = this.alertLength - this.alertsData.length;
    if (this.txtsrch == "" && this.ddlstatus == "0") {
      let clubid = this.clubid;
      let countVal = this.countvalue;
      let searchexp = " WHERE AR_GCB_ID=" + this.clubid + "";
      this.getalerts(clubid, searchexp, countVal, this.currentGolfCourseDateTime);
    }
    else {
      if (this.txtsrch != "") {
        this.srchError = '0';
        if (this.ddlsearch === "CARTNAME") {
          let clubid = this.clubid;
          let searchexpression = " WHERE AR_GCB_ID = '" + this.clubid + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND AR_VIEW_STATUS <> 'D'";
          let countVal = this.countvalue;
          this.getalerts(clubid, searchexpression, countVal, this.currentGolfCourseDateTime);
        }
        else if (this.ddlsearch === "AlertType") {
          let clubid = this.clubid;
          let searchexpression = " WHERE AR_GCB_ID = '" + this.clubid + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND AR_VIEW_STATUS <> 'D'";
          let countVal = this.countvalue;
          this.getalerts(clubid, searchexpression, countVal, this.currentGolfCourseDateTime);
        }
      }
      else if (this.ddlsearch === "AR_VIEW_STATUS") {
        this.srchError = '0';
        let searchexp = "";
        if (this.ddlstatus === "viewed") {
          searchexp = " WHERE AR_GCB_ID = '" + this.clubid + "' AND AR_VIEW_STATUS = 'Y'"

        }
        else if (this.ddlstatus === "notviewed") {
          searchexp = " WHERE AR_GCB_ID = '" + this.clubid + "' AND AR_VIEW_STATUS = 'N'"
        }
        else {
          searchexp = " WHERE AR_GCB_ID = '" + this.clubid + "' AND AR_VIEW_STATUS <> 'D'"
        }
        let clubid = this.clubid;
        let searchexpression = searchexp;
        let countVal = this.countvalue;
        this.getalerts(clubid, searchexpression, countVal, this.currentGolfCourseDateTime);
      }
    }
  }

  selectmessagestype(typeid) {
    this.countvalue = 0; let previousDate: any = '';
    this.selectmessages = typeid;
    this.alertLength = 0;
    this.countvalue = 0;
    this.selectedoption = "Active";
    this.randomcolor = "#5cb85c";
    let clubid = this.clubid;
    this.txtsrch = "";
    this.ddlstatus = "0";
    this.txtsearch = true; this.statusddl = false;
    this.ddlsearch = "CARTNAME";
    this.srchError = "0";
    let countVals = this.countvalue;
    let searchexp = " WHERE AR_GCB_ID=" + this.clubid + "";
    let countVal = this.countvalue;
    this.getalerts(this.clubid, searchexp, countVals, this.currentGolfCourseDateTime);
  }
  openModal(alertmodel, template: TemplateRef<any>) {
    this.CartName=alertmodel.cartname;
    let latlng2 = { lat: parseFloat(alertmodel.alertlat), lng: parseFloat(alertmodel.alertlong) };
    this.modalRef = this.modalService.show(template, { class: 'modal-md modal-lg modal-sm' });
    this.showmap=(this.courselat!='' && this.courselat!=undefined && this.courselat!=null)?true:false;
    this.maploading(latlng2, alertmodel.alerttype, alertmodel.date);
  }

  // hazardonmap(alertlat,alertlong){
  //   this.maploading();
  // }
  maploading(latlng2, type, date) {
    this.map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: parseFloat(this.courselat), lng: parseFloat(this.courselong) },
        zoom: 20,
        
        //disableDefaultUI: true,
        mapTypeId: 'satellite',
        tilt: 0,
        rotateControl: true
    });
    this.setoverlayimage(latlng2, type, date);
    //this.getpolylinedetails();
}
setoverlayimage(latlng2, type, date) {
  let me = this;
  for (let i = 0; i < this.CoursesInfo.length; i++) {
      var imageMapType = new google.maps.ImageMapType({
          getTileUrl: function (coord, zoom) {
              //console.log('http://iadmin.azaz.com/tiles/' + me.golfclubid+ '/' +me.CoursesInfo[i].id+ '/' + zoom + '/' + coord.x + '/' + coord.y + '.png');
              // let clbid=''; let cursid='';
              // if(me.golfclubid=='1002'){clbid='1445'}else{clbid=me.golfclubid};
              // if(me.CoursesInfo[i].id==2){cursid='539'}else if(me.CoursesInfo[i].id==3){cursid='540'}else if(me.CoursesInfo[i].id==4){cursid='541'}else{cursid=me.CoursesInfo[i].id};
              // return ['http://cp.izongolf.com/tiles/' + clbid + '/' + cursid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
              return ['http://cp.izongolf.com/tiles/' + me.golfclubid + '/' + me.CoursesInfo[i].id + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
          },
          tileSize: new google.maps.Size(256, 256)
      });
      me.map.overlayMapTypes.push(imageMapType);
      this.addMarker(latlng2, type, date);
  }
}

addMarker(location, types, date) {
  let me = this;
  let i=1;
  types=types.replace(' ','');
  let type = types === 'HZ' ? "HZ" : "OB";
  var infowindow = new google.maps.InfoWindow();
  var marker = new google.maps.Marker({
    position: location,
    label: {
      text: type,
      color: 'white'
    },
    draggable: false,
    map: this.map
  });
  this.markers.push(marker);
  this.map.setCenter(new google.maps.LatLng(location));
  google.maps.event.addListener(marker, 'mouseover', (function (marker, i) {
    return function () {
      var content = "";
      content += '<div style="color:green;font-weight:bold;padding-bottom:10px;">Cart Position At:</div>'
      content += date + "\n";
      infowindow.setContent(content);
      infowindow.open(me.map, marker);
    }
  })(marker, 0));

  google.maps.event.addListener(marker, 'mouseout', function () {
    infowindow.close();
  });
}
declinetemplate(): void {
  this.modalRef.hide();
}

}



