import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Title } from '@angular/platform-browser';
import { Observable } from 'rxjs/Rx';
import * as moment from "moment";
@Component({
  selector: 'app-messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.css']
})
export class MessagesComponent implements OnInit {
  modalRef: BsModalRef;
  messagesData: any; clubid: any;
  GridMessage: string = 'Loading, Please wait ... !';
  next: boolean = true; messageLength: number = 0; previous: boolean = false; RecordsCount: number = 0;
  countvalue: number = 0;currentGolfClubDateTime:any;

  //search
  ddlsearch: any;
  selectedoption: any = "Active"; randomcolor: any = "#5cb85c";
  txtsrch: string = ''; srchError: string = '0';
  ddlstatus: any; statusddl: boolean = false; txtsearch: boolean = true;

  //sort values
  key: string = 'date';
  reverse: boolean = true;
  updatedbyasc: any = "sortwhite";
  updatedbydesc: any = "sortwhite";
  userroleasc: any = "sortwhite";
  userroledesc: any = "sortwhite";
  fromcartnameasc: any = "sortwhite";
  fromcartnamedesc: any = "sortwhite";
  tocartnameasc: any = "sortwhite";
  tocartnamedesc: any = "sortwhite";
  messageasc: any = "sortwhite";
  messagedesc: any = "sortwhite";
  dateasc: any = "sortgreen";
  datedesc: any = "sortwhite";
  courseid: any;

  //messagecount
  count: any;
  selectmessages: string = '1';
  courselat: any; courselong: any;
  searchmsg:boolean=false;
  timeoffset: any = '';


  constructor(private title: Title, private modalService: BsModalService, public toastr: ToastsManager, vcr: ViewContainerRef, private _router: Router, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService,
    private authService: AuthService, private router: Router) {
    this.toastr.setRootViewContainerRef(vcr);
    this.title.setTitle("IZON - Messages");
    this.messagesData = []; this.messageLength = 0;
    this.clubid = localStorage.getItem('clubId');
    this.courseid = localStorage.getItem('courseId');
    this.ddlsearch = "U_FIRST_NAME";
    this.ddlstatus = "0";
  }

  ngOnInit() {
   // let searchexp = "";
    // let searchexp1 = "";
    // searchexp1 = " WHERE GC_GCB_ID='" + this.clubid + "' and GC_STATUS='Y' and  GC_ID='" + this.courseid + "'"
    // let params = { searchvalue: searchexp1 };
    // this.getcourses(params);
    // if (this.selectmessages == "1") {
    //   searchexp = " WHERE M_GC_ID=" + this.courseid + " AND M_GCB_ID=" + this.clubid + " AND convert(date,M_TS)='" + dateString + "'";
    // }
    // else {
    //   searchexp = " WHERE M_GC_ID=" + this.courseid + " AND M_GCB_ID=" + this.clubid + " AND convert(date,M_TS)<'" + dateString + "'";
    // }
     let searchexp = " WHERE M_GC_ID=" + this.courseid + " AND M_GCB_ID=" + this.clubid + "";
    let countVal = this.countvalue;
    this.getmessages(this.clubid, searchexp, countVal);
  }

  getmessages(clubid, searchvalue, countvalue) {
    this.currentGolfClubDateTime = "";
    var searchexp = " WHERE GC_GCB_ID='" + this.clubid  + "' and GC_STATUS='Y' "
    let parameters1 = { searchvalue: searchexp };
    this.api.postOH('getgolfcourse', parameters1).subscribe(
        response => {
            if (response.length !== 0) {
                this.courselat = response[0].latitude;
                this.courselong = response[0].longitude;
                this.timeoffset = response[0].timeoffset;
              
                let currentDate: any = '';
                let d = new Date();
                let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
                currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
                this.currentGolfClubDateTime = moment(currentDate).format('YYYY-MM-DD');
                      let parameters = {
                        clubid: clubid,
                        searchvalue: searchvalue,
                        countvalue: countvalue,
                        dateString: this.currentGolfClubDateTime,
                        currentorpreviousmsgs:this.selectmessages
                      };
                      this.spinnerService.show();
                      this.api.postOH('getMessages', parameters).subscribe(
                        (response) => {
                  
                          this.messagesData = [];
                          if (response.length != 0) {
                            this.RecordsCount = parseInt(response[0].TotalRecords);
                            for (let i = 0; i < response.length; i++) {
                              var status = (response[i].readstatus == 'Y') ? "Read" : (response[i].readstatus == 'N') ? "Unread" : "Deleted";
                              var statusclass = (response[i].readstatus == 'Y') ? "active-status" : (response[i].readstatus == 'N') ? "inactive-status" : "deleted-status";
                              var editshow = (response[i].readstatus != 'D') ? "row-icon-active" : "row-icon-inactive";
                              var enableshow = (response[i].readstatus == 'D') ? "row-icon-active" : "row-icon-inactive";
                              var removeshow = (response[i].readstatus != 'D') ? "row-icon-active" : "row-icon-inactive";
                              var confirmshow = "row-icon-inactive";
                  
                              this.messagesData.push({
                                "id": response[i].id,
                                "clubid": response[i].clubid,
                                "clubname": response[i].clubname,
                                "tocartid": response[i].tocartid,
                                "tocartname": response[i].tocartname,
                                "fromcartid": response[i].fromcartid,
                                "fromcartname": response[i].fromcartname,
                                "message": response[i].message,
                                "type": response[i].type,
                                "userid": response[i].userid,
                                "updatedby": response[i].updatedby,
                                "userrole": response[i].userrole,
                                "date": new Date(response[i].date),
                                "status": status,
                                "statusclass": statusclass,
                                "editshow": editshow,
                                "enableshow": enableshow,
                                "removeshow": removeshow,
                                "confirmshow": confirmshow
                              });
                            }
                            if (this.previous == false) {
                              this.messageLength = this.countvalue + this.messagesData.length;
                              if ((this.RecordsCount == this.messageLength) && this.previous == false) {
                                this.next = false;
                              }
                              else {
                                this.next = true;
                              }
                            }
                            else {
                              this.next = true;
                            }
                          }
                          else {
                            this.GridMessage = "No Data Found";
                            this.next = false;
                            this.messageLength = 0;
                            this.RecordsCount = 0;
                          }
                          this.spinnerService.hide();
                  
                        }, error => {
                          this.spinnerService.hide();
                        }
                      );
                }
        }, error => {
            this.spinnerService.hide();
        })

  }

  sort(value: string) {
    this.key = value;
    this.updatedbyasc = "sortwhite"; this.updatedbydesc = "sortwhite";
    this.userroleasc = "sortwhite"; this.userroledesc = "sortwhite";
    this.fromcartnameasc = "sortwhite"; this.fromcartnamedesc = "sortwhite";
    this.tocartnameasc = "sortwhite"; this.tocartnamedesc = "sortwhite";
    this.messageasc = "sortwhite"; this.messagedesc = "sortwhite";
    this.dateasc = "sortwhite"; this.datedesc = "sortwhite";
    if (this.key == value) {
      this.reverse = !this.reverse;
      if (this.key == "updatedby" && this.reverse) {
        this.updatedbydesc = "sortgreen";
      }
      else if (this.key == "updatedby" && (!this.reverse)) {
        this.updatedbyasc = "sortgreen";
      }
      if (this.key == "userrole" && this.reverse) {
        this.userroledesc = "sortgreen";
      }
      else if (this.key == "userrole" && (!this.reverse)) {
        this.userroleasc = "sortgreen";
      }
      if (this.key == "fromcartname" && this.reverse) {
        this.fromcartnamedesc = "sortgreen";
      }
      else if (this.key == "fromcartname" && (!this.reverse)) {
        this.fromcartnameasc = "sortgreen";
      }
      else if (this.key == "tocartname" && this.reverse) {
        this.tocartnamedesc = "sortgreen";
      }
      else if (this.key == "tocartname" && (!this.reverse)) {
        this.tocartnameasc = "sortgreen";
      }
      else if (this.key == "message" && this.reverse) {
        this.messagedesc = "sortgreen";
      }
      else if (this.key == "message" && (!this.reverse)) {
        this.messageasc = "sortgreen";
      }
      else if (this.key == "date" && this.reverse) {
        this.datedesc = "sortgreen";
      }
      else if (this.key == "date" && (!this.reverse)) {
        this.dateasc = "sortgreen";
      }
    }
  }

  refreshpage() {
    this.searchmsg=false;
    this.messageLength = 0;
    this.countvalue = 0;
    this.selectedoption = "Active";
    this.randomcolor = "#5cb85c";
    let clubid = this.clubid;
    let searchexp = " WHERE  M_GC_ID=" + this.courseid + " AND M_GCB_ID=" + this.clubid + "";
    let countVal = this.countvalue;
    this.getmessages(clubid, searchexp, countVal);
    this.txtsrch = "";
    this.ddlstatus = "0";
    this.txtsearch = true; this.statusddl = false;
    this.ddlsearch = "U_FIRST_NAME";
    this.srchError = "0";

  }

  dropdownsearch(val) {
    if (val.value === "M_READ_STATUS") {
      this.txtsearch = false;
      this.statusddl = true;
    }
    else {
      this.txtsearch = true;
      this.statusddl = false;
    }
    this.txtsrch = '';this.countvalue = 0;
    let searchexp = " WHERE  M_GC_ID=" + this.courseid + " AND M_GCB_ID=" + this.clubid + "";
    let countVal = this.countvalue;
    this.getmessages(this.clubid, searchexp, countVal);
  }

  search() {
    this.searchmsg=true;
    this.messageLength = 0;
    this.countvalue = 0;
    if (this.txtsrch == '' && this.ddlsearch != "M_READ_STATUS") {
      this.srchError = '1';
    }
    else if (this.txtsrch != "") {
      this.srchError = '0';
      if (this.ddlsearch === "FROMCARTNAME") {
        let clubid = this.clubid;
        let searchexpression = " WHERE  M_GC_ID=" + this.courseid + " AND M_GCB_ID='" + this.clubid + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND M_READ_STATUS <> 'D'";
        let countVal = 0;
        this.getmessages(clubid, searchexpression, countVal);

      }
      else if(this.ddlsearch == "U_FIRST_NAME"){
        let clubid = this.clubid;
        let searchexpression = " WHERE M_GC_ID=" + this.courseid + " AND M_GCB_ID='" + this.clubid + "' AND UPDATEDBY LIKE '%" + this.txtsrch + "%' AND M_READ_STATUS <> 'D'";
        let countVal = 0;
        this.getmessages(clubid, searchexpression, countVal);
      }
      else if (this.ddlsearch === "TOCARTNAME") {

        let clubid = this.clubid;
        let searchexpression = " WHERE M_GC_ID=" + this.courseid + " AND M_GCB_ID='" + this.clubid + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND M_READ_STATUS <> 'D'";
        let countVal = 0;
        this.getmessages(clubid, searchexpression, countVal);

      }
      else if (this.ddlsearch === "M_MESSAGE") {
        let clubid = this.clubid;
        let searchexpression = " WHERE M_GC_ID=" + this.courseid + " AND M_GCB_ID='" + this.clubid + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND M_READ_STATUS <> 'D'";
        let countVal = 0;
        this.getmessages(clubid, searchexpression, countVal);

      }
    }
    else if (this.ddlsearch === "M_READ_STATUS") {
      this.srchError = '0';
      let searchexp = "";
      if (this.ddlstatus === "read") {
        searchexp = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID = '" + this.clubid + "' AND M_READ_STATUS = 'Y'"
      }
      else if (this.ddlstatus === "notread") {
        searchexp = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID = '" + this.clubid + "' AND M_READ_STATUS = 'N'"
      }
      else {
        searchexp = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID = '" + this.clubid + "' AND M_READ_STATUS <> 'D'"
      }
      let clubid = this.clubid;
      let searchexpression = searchexp;
      let countVal = 0;
     
      this.getmessages(clubid, searchexpression, countVal);
    }
   
  }

  srchKeyUp(event: any) {
    if (this.txtsrch != '') {
      this.srchError = '0';
    }
  }

  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',

    };
    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 5000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }

  updateStatus(msg) {
    var msginfo = {
      "clubid": msg.clubid,
      "messageid": msg.id
    }
    this.api.postOH('UpdateMessageStatusfromHeader', msginfo).subscribe(
      (response) => {
        if (response.UpdateMessageStatusfromHeaderResult == "Success") {
          this.txtsrch = "";
          this.ddlstatus = "0";
          this.txtsearch = true; this.statusddl = false;
          this.ddlsearch = "U_FIRST_NAME";
          this.srchError = "0";
          this.messageLength = 0;
          let clubid = this.clubid;
          let searchexp = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID=" + this.clubid + "";
          let countVal = 0;
          this.getmessages(clubid, searchexp, countVal);
          let msg = '<span style="color: green">Message Status updated Successfully. </span>';
          this.toastMessage(msg);
          this.getMessageCount(this.clubid);

        }
        else {
          let msg = '<span style="color: red">Problem while updating Message Status. </span>';
          this.toastMessage(msg);
        }
      }, error => {
        let msg = '<span style="color: red">Problem while updating Message Status. </span>';
        this.toastMessage(msg);
      }
    );
  }

  getMessageCount(clubId) {
    let parameters = {
      clubid: this.clubid,
      searchvalue: " WHERE M_GC_ID=" + this.courseid + " AND M_GCB_ID=" + clubId + " AND M_READ_STATUS = 'N'",
      countvalue: 0
    };
    this.api.postOH('getmessagecount', parameters).subscribe(
      (response) => {
        //console.log(response);
        this.authService.getCall();
        this.count = (response.getmessagecountResult > 99) ? '99+' : response.getmessagecountResult;
        localStorage.setItem('MessageCount', this.count);
      });
  }

  nextMessages() {
    this.countvalue += 20; this.previous = false;
    if (this.txtsrch == "" && this.ddlstatus == "0") {
      let clubid = this.clubid;
      let countVal = this.countvalue;
      let searchexp = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID=" + this.clubid + "";
      this.getmessages(clubid, searchexp, countVal);
    }
    else {
      if (this.txtsrch != "") {
        this.srchError = '0';
        if (this.ddlsearch === "FROMCARTNAME") {
          let clubid = this.clubid;
          let searchexpression = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID='" + this.clubid + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND M_READ_STATUS <> 'D'";
          let countVal = this.countvalue;
          this.getmessages(clubid, searchexpression, countVal);
        }
        else if(this.ddlsearch == "U_FIRST_NAME"){
          let clubid = this.clubid;
          let searchexpression = " WHERE M_GC_ID=" + this.courseid + " AND M_GCB_ID='" + this.clubid + "' AND UPDATEDBY LIKE '%" + this.txtsrch + "%' AND M_READ_STATUS <> 'D'";
          let countVal = this.countvalue;
          this.getmessages(clubid, searchexpression, countVal);
        }
        else if (this.ddlsearch === "TOCARTNAME") {

          let clubid = this.clubid;
          let searchexpression = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID='" + this.clubid + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND M_READ_STATUS <> 'D'";
          let countVal = this.countvalue;
          this.getmessages(clubid, searchexpression, countVal);
        }
        else if (this.ddlsearch === "M_MESSAGE") {
          let clubid = this.clubid;
          let searchexpression = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID='" + this.clubid + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND M_READ_STATUS <> 'D'";
          let countVal = this.countvalue;
          this.getmessages(clubid, searchexpression, countVal);

        }
      }
      else if (this.ddlsearch === "M_READ_STATUS") {
        this.srchError = '0';
        let searchexp = "";
        if (this.ddlstatus === "read") {
          searchexp = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID = '" + this.clubid + "' AND M_READ_STATUS = 'Y'"
        }
        else if (this.ddlstatus === "notread") {
          searchexp = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID = '" + this.clubid + "' AND M_READ_STATUS = 'N'"
        }
        else {
          searchexp = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID = '" + this.clubid + "' AND M_READ_STATUS <> 'D'"
        }
        let clubid = this.clubid;
        let searchexpression = searchexp;
        let countVal = this.countvalue;
        this.getmessages(clubid, searchexpression, countVal);
      }
    }
  }

  previousMessages() {
    this.countvalue = this.countvalue - 20; this.previous = false;
    //this.messageLength = this.messageLength - this.messagesData.length;
    if (this.txtsrch == "" && this.ddlstatus == "0") {
      let clubid = this.clubid;
      let searchexp = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID=" + this.clubid + "";
      let countVal = this.countvalue;
      this.getmessages(clubid, searchexp, countVal);
    }
    else {
      if (this.txtsrch != "") {
        this.srchError = '0';
        if (this.ddlsearch === "FROMCARTNAME") {
          let clubid = this.clubid;
          let searchexpression = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID='" + this.clubid + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND M_READ_STATUS <> 'D'";
          let countVal = this.countvalue;
          this.getmessages(clubid, searchexpression, countVal);
        }
        else if(this.ddlsearch == "U_FIRST_NAME"){
          let clubid = this.clubid;
          let searchexpression = " WHERE M_GC_ID=" + this.courseid + " AND M_GCB_ID='" + this.clubid + "' AND UPDATEDBY LIKE '%" + this.txtsrch + "%' AND M_READ_STATUS <> 'D'";
          let countVal = this.countvalue;
          this.getmessages(clubid, searchexpression, countVal);
        }
        else if (this.ddlsearch === "TOCARTNAME") {

          let clubid = this.clubid;
          let searchexpression = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID='" + this.clubid + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND M_READ_STATUS <> 'D'";
          let countVal = this.countvalue;
          this.getmessages(clubid, searchexpression, countVal);

        }
        else if (this.ddlsearch === "M_MESSAGE") {
          let clubid = this.clubid;
          let searchexpression = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID='" + this.clubid + "' AND " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND M_READ_STATUS <> 'D'";
          let countVal = this.countvalue;
          this.getmessages(clubid, searchexpression, countVal);
        }
      }
      else if (this.ddlsearch === "M_READ_STATUS") {
        this.srchError = '0';
        let searchexp = "";
        if (this.ddlstatus === "read") {
          searchexp = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID = '" + this.clubid + "' AND M_READ_STATUS = 'Y'"
        }
        else if (this.ddlstatus === "notread") {
          searchexp = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID = '" + this.clubid + "' AND M_READ_STATUS = 'N'"
        }
        else {
          searchexp = " WHERE M_GC_ID=" + this.courseid + " AND  M_GCB_ID = '" + this.clubid + "' AND M_READ_STATUS <> 'D'"
        }
        let clubid = this.clubid;
        let searchexpression = searchexp;
        let countVal = this.countvalue;
        this.getmessages(clubid, searchexpression, countVal);
      }
    }
  }
  selectmessagestype(typeid) {
    this.countvalue = 0;
    this.selectmessages = typeid;
    this.selectedoption = "Active";
    this.randomcolor = "#5cb85c";
    let clubid = this.clubid;
    this.txtsrch = "";
    this.ddlstatus = "0";
    this.txtsearch = true; this.statusddl = false;
    this.ddlsearch = "U_FIRST_NAME";
    this.srchError = "0";
    let searchexp = "";
    searchexp = " WHERE M_GC_ID=" + this.courseid + " AND M_GCB_ID=" + this.clubid + "";
    let countVal = this.countvalue;
    this.getmessages(this.clubid, searchexp, countVal);
  }
}


