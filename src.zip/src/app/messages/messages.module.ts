import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FullCalendarModule } from 'ng-fullcalendar';
//import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { ModalModule } from 'ngx-bootstrap';
import { OrderModule } from 'ngx-order-pipe';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { PopoverModule } from 'ngx-bootstrap';

import { MessagesComponent } from './messages/messages.component';
import { AlertsComponent } from './alerts/alerts.component';

const routes: Routes = [
    {
        path:'messages',
        component:MessagesComponent
    },
    {        
        path:'alerts',
        component:AlertsComponent
    }
];

@NgModule({
    imports: [
      CommonModule,
      RouterModule.forChild(routes),
      FormsModule, ReactiveFormsModule,
      FullCalendarModule,OrderModule,
      ToastModule.forRoot(),
      ModalModule.forRoot(),
      OwlDateTimeModule,PopoverModule.forRoot(),
      OwlNativeDateTimeModule, BsDatepickerModule.forRoot()
    ],  
    declarations: [MessagesComponent, AlertsComponent],
    exports: [RouterModule]  
  })
  export class MessagesModule { }
  