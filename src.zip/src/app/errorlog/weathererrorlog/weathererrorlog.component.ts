import { Component, OnInit } from '@angular/core';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { Observable } from 'rxjs/Rx';


@Component({
  selector: 'app-weathererrorlog',
  templateUrl: './weathererrorlog.component.html',
  styleUrls: ['./weathererrorlog.component.css']
})
export class WeathererrorlogComponent implements OnInit {

  clubid: any;  WeathererrorlogList: any; GridMessage: any = "No data found"; 
  sub: any; 

  constructor(private title: Title, private router: Router, private spinnerService: Ng4LoadingSpinnerService,
    private api: ApiService) {
      this.title.setTitle("IZON - Weather Error Log");
      this.clubid = localStorage.getItem('clubId');
      this.WeathererrorlogList = [];
     }

  ngOnInit() {
    this.getWeatherErrorLog();
    this.sub = Observable.interval(1000 * 60 * 30).subscribe(x => {
    });
  }

    getWeatherErrorLog()
    {
      let params = { clubid: this.clubid };
      this.api.postOH('getWeatherErrorLog', params).subscribe(
        (response) =>
        {
          if(response.length > 0)
          {
            this.WeathererrorlogList = response;
          }
          else if(response.length == 0){
            this.WeathererrorlogList.length = 0;
            this.GridMessage = "No data found";
          }
        })
    }

}
