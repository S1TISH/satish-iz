import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WeathererrorlogComponent } from './weathererrorlog.component';

describe('WeathererrorlogComponent', () => {
  let component: WeathererrorlogComponent;
  let fixture: ComponentFixture<WeathererrorlogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WeathererrorlogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WeathererrorlogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
