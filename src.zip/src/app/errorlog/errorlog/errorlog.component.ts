import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-errorlog',
  templateUrl: './errorlog.component.html',
  styleUrls: ['./errorlog.component.css']
})
export class ErrorlogComponent implements OnInit {
  clubId: any = ""; courseId: any = ""; countvalue: number = 0; errorLogList: any = []; GridMessage: string = 'Loading... !';
  next:boolean = true; errorLogLength:number = 0; previous:boolean = false;RecordsCount:number=0;
  constructor(private title: Title, private router: Router, private spinnerService: Ng4LoadingSpinnerService,
    private api: ApiService) {
    this.title.setTitle("IZON - Error Log");
    this.clubId = JSON.parse(localStorage.getItem('clubId'));
    this.courseId = JSON.parse(localStorage.getItem('courseId'));
  }

  ngOnInit() {
    this.getErrorLog(this.clubId, this.courseId, this.countvalue);
  }

  getErrorLog(clubId, courseId, countvalue) {
    this.errorLogList = [];
    this.spinnerService.show();
    let parameters = {
      clubid: clubId,
      courseid: courseId,
      countvalue: countvalue
    };
    this.api.postOH('GetErrorLog', parameters).subscribe(
      response => {
        if (response.length > 0) {
          if (response[0].ResponseCode == 'Empty') {
            this.errorLogList = [];
            this.errorLogLength = 0;
            this.GridMessage = response[0].ResponseText;
            this.next = false;
          }
          else {
            this.errorLogList = response;
            this.RecordsCount = (parseInt(response[0].TotalRecords));
            if (this.previous == false) {
              this.errorLogLength = this.errorLogLength + this.errorLogList.length;
              if ((parseInt(response[0].TotalRecords) === this.errorLogLength) && this.previous == false) {
                this.next = false;
              }
              else {
                this.next = true;
              }
            }
            else {
              this.next = true;
            }
          }
        }
        this.spinnerService.hide();
      },
      err => {
        this.spinnerService.hide();
      }
    );
  }

  nextErrorLog() {
    this.countvalue += 20;this.previous=false;
    this.getErrorLog(this.clubId, this.courseId, this.countvalue);
  }

  previousErrorLog() {
    this.countvalue += -20;this.previous = true;
    this.errorLogLength = this.errorLogLength - this.errorLogList.length;
    this.getErrorLog(this.clubId, this.courseId, this.countvalue);
  }

}
