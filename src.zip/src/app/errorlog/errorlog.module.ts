import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ErrorlogComponent } from './errorlog/errorlog.component';
import { WeathererrorlogComponent } from './weathererrorlog/weathererrorlog.component';

const routes: Routes = [
  {
      path: 'errorlog',
      component: ErrorlogComponent
  },
  {
    path: 'weathererrorlog',
    component: WeathererrorlogComponent
  }
  
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  declarations: [ErrorlogComponent, WeathererrorlogComponent],
  exports: [RouterModule]  
})
export class ErrorlogModule { }
