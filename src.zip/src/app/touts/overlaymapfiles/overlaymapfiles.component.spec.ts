import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OverlaymapfilesComponent } from './overlaymapfiles.component';

describe('OverlaymapfilesComponent', () => {
  let component: OverlaymapfilesComponent;
  let fixture: ComponentFixture<OverlaymapfilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OverlaymapfilesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OverlaymapfilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
