import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form'
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { AuthService } from '../../services/auth.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Title } from '@angular/platform-browser';
import * as moment from "moment";

@Component({
  selector: 'app-syncoverlayimages',
  templateUrl: './syncoverlayimages.component.html',
  styleUrls: ['./syncoverlayimages.component.css']
})
export class SyncoverlayimagesComponent implements OnInit {

  modalRef: BsModalRef;
  cartsList: any = [];IsAllCheckedIsAllChecked: boolean;selectedCartIds:string;IsAllChecked: boolean;cartsAppVersionList: any = []
  clubId:any;courseid:any;userId:any;errorMessage: any = "none";subBtn: any;
  key: string = 'name';reverse: boolean = false;
  cartnameasc: any = "sortgreen"; cartnamedesc: any = "sortwhite";
  appvasc: any = "sortwhite"; appvdesc: any = "sortwhite";
  sendasc: any = "sortwhite"; senddesc: any = "sortwhite";
  recdasc: any = "sortwhite"; recddesc: any = "sortwhite"; 

  findallchecked:any=0; ddlsearch:any; txtsearch: boolean = true; ddlappversiondiv: boolean = false;
  reqstatusdiv: boolean = false; syncstatusdiv:boolean = false;

  txtsrch:any='';ddlappversion:any="0";reqstatus:any="0";syncstatus:any="0";
  srchError:any=0;timeoffset:any;

  constructor(private title: Title, public toastr: ToastsManager, vcr: ViewContainerRef,
    private router: Router, public formBuilder: FormBuilder,
    private spinnerService: Ng4LoadingSpinnerService,
    private api: ApiService, private authService: AuthService,
    private modalService: BsModalService) {
      this.title.setTitle("IZON - Sync Overlays");
      this.clubId = localStorage.getItem('clubId');
      this.courseid = localStorage.getItem('courseId');
      this.userId = localStorage.getItem('userId');
      this.toastr.setRootViewContainerRef(vcr);
     }

     ngOnInit() {
      this.ddlsearch="cartname";
      this.getCourses();
      this.selectedCartIds="";
    
   
    }
    getCourses() {
      let parameters = { searchvalue: " WHERE GC_GCB_ID='" + this.clubId + "' AND GC_ID='" + this.courseid + "'" };
      this.api.postOH('getgolfcourse', parameters).subscribe(
        response => {
          if (response.length !== 0) {
             this.timeoffset = response[0].timeoffset;
          }
          let currentDate: any = '';
          let d = new Date();
          let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
          currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
          var senddate=moment(currentDate).format('MM/DD/YYYY hh:mm A');
          let parameters = {
            clubid: this.clubId,
            cartname: '',
            appversion: '',
            reqstatus: '',
            syncstatus: '',
            flag:'M',
            senddate:senddate
          };
          this.GetCartsList(parameters);
          this.GetCartAppVersions();
         
        });
    }
  
    GetCartsList(parameters) {
      this.spinnerService.show();
      this.selectedCartIds="";
      this.cartsList = [];
      this.findallchecked=0;
      this.IsAllChecked=false;
      this.api.postOH('GetToutNotifications', parameters).subscribe(
        (response) => {
          if (response.GetToutNotificationsResult.length > 0) {
            for (let i = 0; i < response.GetToutNotificationsResult.length; i++) {
              this.cartsList.push({
                "id": response.GetToutNotificationsResult[i].cartid,
                "name": response.GetToutNotificationsResult[i].cartname,
                "appversion": response.GetToutNotificationsResult[i].appversion,
                "Selected": (response.GetToutNotificationsResult[i].sendstatus == 'Y') ? false : true,
                "sendstatus": response.GetToutNotificationsResult[i].sendstatus,
                "receivedstatus": response.GetToutNotificationsResult[i].receivedstatus,
                "sendsts": response.GetToutNotificationsResult[i].sendsts,
                "receivedts": response.GetToutNotificationsResult[i].receivedts,
                "sendcount": response.GetToutNotificationsResult[i].sendcount,
                "flag": response.GetToutNotificationsResult[i].flag
              });

              if (response.GetToutNotificationsResult[i].sendstatus != 'Y') {
                if (this.selectedCartIds == "") {
                  this.selectedCartIds = response.GetToutNotificationsResult[i].cartid
                } else {
                  this.selectedCartIds = this.selectedCartIds + ', ' + response.GetToutNotificationsResult[i].cartid
                }
              } else {
                this.findallchecked++;
              }
            }
            if (this.findallchecked == 0) {
              this.IsAllChecked = true;
            }
          }
          this.spinnerService.hide();
        }, error => {
          this.spinnerService.hide();
        }
      );
    }
  
    GetCartAppVersions(){
      let parameters = {
        clubid: this.clubId
      };    
      this.cartsAppVersionList = [];    
      this.api.postOH('GetCartAppVersions', parameters).subscribe(
        (response) => {
          for (let i = 0; i < response.GetCartAppVersionsResult.length; i++) {
            this.cartsAppVersionList.push({
              "appversion": response.GetCartAppVersionsResult[i].appversion            
            });
          }
        }, error => {        
        }
      );
    }
  
    sort(value: string) {
      this.key = value;
      this.cartnameasc = "sortwhite"; this.cartnamedesc = "sortwhite"; this.appvasc = "sortwhite"; this.appvdesc = "sortwhite";
      this.sendasc = "sortwhite"; this.senddesc = "sortwhite"; this.recdasc = "sortwhite"; this.recddesc = "sortwhite";
      if (this.key == value) {
        this.reverse = !this.reverse;
        if (this.key == "name" && this.reverse) {
          this.cartnamedesc = "sortgreen";
        }
        else if (this.key == "name" && (!this.reverse)) {
          this.cartnameasc = "sortgreen";
        }
        else if (this.key == "appversion" && this.reverse) {
          this.appvdesc = "sortgreen";
        }
        else if (this.key == "appversion" && (!this.reverse)) {
          this.appvasc = "sortgreen";
        }
        else if (this.key == "sendstatus" && this.reverse) {
          this.senddesc = "sortgreen";
        }
        else if (this.key == "sendstatus" && (!this.reverse)) {
          this.sendasc = "sortgreen";
        }      
        else if (this.key == "receivedstatus" && this.reverse) {
          this.recddesc = "sortgreen";
        }
        else if (this.key == "receivedstatus" && (!this.reverse)) {
          this.recdasc = "sortgreen";
        }
      }
    }
  
    refreshpage(){
      let currentDate: any = '';
      let d = new Date();
      let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
      currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
      var senddate=moment(currentDate).format('MM/DD/YYYY hh:mm A');
      let parameters = {
        clubid: this.clubId,
        cartname: '',
        appversion: '',
        reqstatus: '',
        syncstatus: '',
        flag: 'M',
        senddate:senddate
      };
      this.GetCartsList(parameters);
    }
  
    CheckUncheckAll(){    
      this.selectedCartIds = '';
      for (var i = 0; i < this.cartsList.length; i++) {
        this.cartsList[i].Selected = this.IsAllChecked;
      }
      for (var i = 0; i < this.cartsList.length; i++) {
        if (this.cartsList[i].Selected == true) {
          if(this.selectedCartIds==""){
            this.selectedCartIds=this.cartsList[i].id
          }else{
            this.selectedCartIds=this.selectedCartIds+', '+this.cartsList[i].id
          }
        }
      }
    }
  
    CheckUncheckHeader(){
      this.selectedCartIds = '';
      this.IsAllChecked = false;
      for (var i = 0; i < this.cartsList.length; i++) {
        if (!this.cartsList[i].Selected) {
          this.IsAllChecked = false;
          this.errorMessage = "none";
          break;
        }
        else {
          this.IsAllChecked = true;
        }
      };
      for (var i = 0; i < this.cartsList.length; i++) {
        if (this.cartsList[i].Selected == true) {
          if(this.selectedCartIds==""){
            this.selectedCartIds=this.cartsList[i].id
          }else{
            this.selectedCartIds=this.selectedCartIds+', '+this.cartsList[i].id
          }
        }
      }
    }
  
    openModal(template: TemplateRef<any>) {
      this.modalRef = this.modalService.show(template, { class: 'modal-sm' });  
    }
  
    decline(): void {
      this.modalRef.hide();
    }
  
    confirm(): void {
      this.modalRef.hide();
      this.saveSyncSelectedCarts();
    }
  
    saveSyncSelectedCarts(){
      this.subBtn = true;
      let currentDate: any = '';
      let d = new Date();
      let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
      currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
      var senddate=moment(currentDate).format('MM/DD/YYYY hh:mm A');

      if (this.selectedCartIds != '') {      
        var toutsyncinfo={"toutsynccarts": this.selectedCartIds, "clubid": this.clubId, "courseid":this.courseid, "sendstatus": 'Y', "senddate":senddate, "userid": this.userId, "flag":'M' };
        this.spinnerService.show();
        this.errorMessage = "none";
        this.api.postOH('SaveSyncToutsCarts', toutsyncinfo).subscribe(
          response => {
            if (response == "Success") {
              let msg = '<span style="color: green">Selected Carts Maps Synchronize Successfully</span>';
              this.toastMessage(msg);
              window.scrollTo(0, 0);
              let currentDate: any = '';
              let d = new Date();
              let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
              currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
              var senddate=moment(currentDate).format('MM/DD/YYYY hh:mm A');
              let parameters = {
                clubid: this.clubId,
                cartname: '',
                appversion: '',
                reqstatus: '',
                syncstatus: '',
                flag: 'M',
                senddate: senddate
              };
              this.GetCartsList(parameters);
            }else{
              let msg = '<span style="color: red">Selected Carts Maps Synchronize Failed</span>';
              this.toastMessage(msg);
            }
            this.spinnerService.hide();
            this.subBtn = false;
          },
          err => {
            this.spinnerService.hide();
            this.subBtn = false;
          }
        );
      }
      else {
        this.errorMessage = "block"; this.subBtn = false;
      }
    }
  
    vidwsyncdatafiles(cid){
      localStorage.setItem('toutcartid', cid);
      this.router.navigate(['/data/syncmapsdatastatus']);
    }
  
    ddlsearchevent(){
      this.txtsrch='';this.ddlappversion="0";this.reqstatus="0";this.syncstatus="0";
      this.txtsearch=false;this.ddlappversiondiv=false;this.reqstatusdiv=false;this.syncstatusdiv=false;
      this.srchError=0;
      if(this.ddlsearch == "cartname"){
        this.txtsearch=true;
      }else if(this.ddlsearch == "appversion"){
        this.ddlappversiondiv=true;      
      }else if(this.ddlsearch == "reqstatus"){
        this.reqstatusdiv=true;
      }else if(this.ddlsearch == "syncstatus"){
        this.syncstatusdiv=true;
      }    
    }
  
    search(){
      this.srchError=0;
      let currentDate: any = '';
      let d = new Date();
      let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
      currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
      var senddate=moment(currentDate).format('MM/DD/YYYY hh:mm A');
      if(this.ddlsearch == "cartname" && this.txtsrch!=''){
        let parameters = {
          clubid: this.clubId,
          cartname: this.txtsrch,
          appversion: '',
          reqstatus: '',
          syncstatus: '',
          flag: 'M',
          senddate: senddate
        };
        this.GetCartsList(parameters);
        this.txtsrch='';
      }else if(this.ddlsearch == "cartname" && this.txtsrch==''){      
        this.srchError=1;
      }else if(this.ddlsearch == "appversion"){
        let parameters = {
          clubid: this.clubId,
          cartname: '',
          appversion: (this.ddlappversion=='0')?'':this.ddlappversion,
          reqstatus: '',
          syncstatus: '',
          flag: 'M',
          senddate: senddate
        };
        this.GetCartsList(parameters);
      }else if(this.ddlsearch == "reqstatus"){
        let parameters = {
          clubid: this.clubId,
          cartname: '',
          appversion: '',
          reqstatus: (this.reqstatus=='0')?'':this.reqstatus,
          syncstatus: '',
          flag: 'M',
          senddate: senddate
        };
        this.GetCartsList(parameters);
      }else if(this.ddlsearch == "syncstatus"){
        let parameters = {
          clubid: this.clubId,
          cartname: '',
          appversion: '',
          reqstatus: '',
          syncstatus: (this.syncstatus=='0')?'':this.syncstatus,
          flag: 'M',
          senddate: senddate
        };
        this.GetCartsList(parameters);
      }
    }
  
    toastMessage(msg) {
      let options = {
        positionClass: 'toast-top-center',
      };
  
      this.toastr.custom(msg, null, {
        enableHTML: true, toastLife: 3000,
        showCloseButton: true, 'positionClass': 'toast-bottom-right'
      });
    }

}
