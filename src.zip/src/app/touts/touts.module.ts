import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { ModalModule } from 'ngx-bootstrap';
import { OrderModule } from 'ngx-order-pipe';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { PopoverModule } from 'ngx-bootstrap';

import { SynctoutsComponent } from './synctouts/synctouts.component';
import { ToutfilesComponent } from './toutfiles/toutfiles.component';
import { SyncoverlayimagesComponent } from './syncoverlayimages/syncoverlayimages.component';
import { OverlaymapfilesComponent } from './overlaymapfiles/overlaymapfiles.component';

const routes: Routes = [  
  {
    path:'syncdata',
    component:SynctoutsComponent
  },
  {
    path:'syncdatastatus',
    component:ToutfilesComponent
  },
  {
    path:'syncoverlaymaps',
    component:SyncoverlayimagesComponent
  },
  {
    path:'syncmapsdatastatus',
    component:OverlaymapfilesComponent
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule, ReactiveFormsModule,
    OrderModule, ToastModule.forRoot(),
    ModalModule.forRoot(),
    OwlDateTimeModule,PopoverModule.forRoot(),
    OwlNativeDateTimeModule, BsDatepickerModule.forRoot()
  ],
  declarations: [SynctoutsComponent, ToutfilesComponent, SyncoverlayimagesComponent, OverlaymapfilesComponent],
  exports: [RouterModule]
})
export class ToutsModule { }
