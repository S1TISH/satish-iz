import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ToutfilesComponent } from './toutfiles.component';

describe('ToutfilesComponent', () => {
  let component: ToutfilesComponent;
  let fixture: ComponentFixture<ToutfilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ToutfilesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ToutfilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
