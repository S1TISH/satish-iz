import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Observable } from 'rxjs/Rx';
import * as moment from "moment";
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-toutfiles',
  templateUrl: './toutfiles.component.html',
  styleUrls: ['./toutfiles.component.css']
})
export class ToutfilesComponent implements OnInit {
  toutFilesList: any = []; cartDetails: any = []; carts: any = '0';
  toutFileDate = new Date();
  GridMessage: string = 'Loading...!';
  clubId: any; cartId: any;

  key: string = 'fileDate';
  reverse: boolean = false;
  filestatusasc: any = "sortwhite";
  filestatusdsc: any = "sortwhite";
  filenameasc: any = "sortgreen";
  filenamedesc: any = "sortwhite";
  dateasc: any = "sortwhite";
  datedesc: any = "sortwhite";  
  timeoffset:any;

  constructor(private title: Title, public toastr: ToastsManager, vcr: ViewContainerRef,
    public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService,
    public api: ApiService, private authService: AuthService, private router: Router) {
    this.title.setTitle("IZON - Sync Data Files");
    this.clubId = localStorage.getItem('clubId');    
    this.toastr.setRootViewContainerRef(vcr);
  }

  ngOnInit() {
    this.getCourses(); 
  }
  getCourses() {
    let parameters = { searchvalue: " WHERE GC_GCB_ID='" + this.clubId + "' AND GC_ID='" + localStorage.getItem('courseId') + "'" };
    this.api.postOH('getgolfcourse', parameters).subscribe(
      response => {
        if (response.length !== 0) {
           this.timeoffset = response[0].timeoffset;
        }
        let currentDate: any = '';
        let d = new Date();
        let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
        currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
        this.toutFileDate=new Date(moment(currentDate).format('MMMM DD, YYYY'));
        this.getCartDetails(currentDate); 
      });
  }

  getCartDetails(currentDate) {
    this.cartDetails = [];
    let parameters = {
      searchvalue: " WHERE CD_GCB_ID='" + this.clubId + "' AND CD_DEVICE_TYPE='T' AND (CD_DEVICE_TOKEN!='' or CD_DEVICE_TOKEN !=null) AND CD_STATUS = 'Y'"
    };
    this.api.postOH('getcartdetails', parameters).subscribe(
      (response) => {
        if (response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            this.cartDetails.push({
              value: response[i].id,
              name: response[i].name
            });
          }
          if(localStorage.getItem('toutcartid')==null || localStorage.getItem('toutcartid')==undefined || localStorage.getItem('toutcartid')==''){
            this.carts = this.cartDetails[0].value;
          }else{
            this.carts=localStorage.getItem('toutcartid');
            localStorage.removeItem('toutcartid');
          }
          let parameters = {
            clubId: this.clubId,
            cartId: this.carts,            
            date: moment(currentDate).format('MM/DD/YYYY'),
            flag: 'A'
          };
          this.getToutFiles(parameters);
        } else {
          this.toutFilesList = [];
          this.GridMessage = "No Records Found";
        }
      });
  }

  getToutFiles(parameters) {
    this.toutFilesList = [];    
    this.spinnerService.show();
    this.api.postOH('GetToutFiles', parameters).subscribe(
      response => {
        if (response.length > 0) {
          if (response[0].ResponseCode == 'Empty') {
            this.toutFilesList = [];
            this.GridMessage = response[0].ResponseText;            
          }
          else {
            for (let i = 0; i < response.length; i++) {
              this.toutFilesList.push({
                "Id": response[i].Id,
                "cartName": response[i].cartName,
                "fileName": response[i].fileName,
                "fileStatus": response[i].fileStatus == 'Y' ? 'Success' : 'Failure',
                "count": response[i].count,
                "fileDate": response[i].fileDate,
                "createdDate": response[i].createdDate,
                "flag": response[i].flag
              });
            }
          }
          this.spinnerService.hide();
        } else {
          this.toutFilesList = []; 
          this.GridMessage = "No Records Found";
          this.spinnerService.hide();
        }
      },
      err => {
        this.toutFilesList = []; 
        this.GridMessage = "No Records Found";
        this.spinnerService.hide();
      }
    );
  }

  sort(value: string) {
    this.key = value;
    this.filestatusasc = "sortwhite";
    this.filestatusdsc = "sortwhite";
    this.filenameasc = "sortwhite";
    this.filenamedesc = "sortwhite";
    this.dateasc = "sortwhite";
    this.datedesc = "sortwhite";

    if (this.key == value) {
      this.reverse = !this.reverse;
      if (this.key == "fileStatus" && this.reverse) {
        this.filestatusdsc = "sortgreen";
      }
      else if (this.key == "fileStatus" && (!this.reverse)) {
        this.filestatusasc = "sortgreen";
      }
      else if (this.key == "filename" && this.reverse) {
        this.filenamedesc = "sortgreen";
      }
      else if (this.key == "filename" && (!this.reverse)) {
        this.filenameasc = "sortgreen";
      }
      else if (this.key == "fileDate" && this.reverse) {
        this.datedesc = "sortgreen";
      }
      else if (this.key == "fileDate" && (!this.reverse)) {
        this.dateasc = "sortgreen";
      }
    }
  }

  search() {
    let parameters ={};
    parameters = {
        clubId: this.clubId,
        cartId: this.carts,        
        date: moment(this.toutFileDate).format('MM/DD/YYYY'),
        flag: 'A'
      }; 
    this.getToutFiles(parameters);     
  }

  refreshpage() {    
    let parameters ={};
    parameters = {
        clubId: this.clubId,
        cartId: this.carts,        
        date: moment(this.toutFileDate).format('MM/DD/YYYY'),
        flag: 'A'
      }; 
    this.getToutFiles(parameters);  
  }

  goBack(){
    this.router.navigate(['/data/syncdata']);
  }

  
}
