import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-clubuserassignment',
  templateUrl: './clubuserassignment.component.html',
  styleUrls: ['./clubuserassignment.component.css']
})
export class ClubuserassignmentComponent implements OnInit {
  modalRef: BsModalRef;
  public clubuserForm: FormGroup; submitAttempt: boolean = false; divheader: string = "Add Club Employee";
  searchtxt: boolean = true; searchddl: boolean = false;
  usersdata: any; golfclubsdata: any; clubuserassignmentdata: any;
  contentShow: string = "none"; gridShow: string = "none"; searchgolfclub: string = "block";
  txtShow: string = "none"; lblShow: string = "none";
  action: string = 'A'; clubuserid: string = "0";
  clubname: string; username: string; chkstatus: any; assignmentstatus: any; viewcontentShow: string = "none";
  txtsrch: string = ''; ddlclubs: any; ddlusers: any; txtstatus: string = 'fa fa-check-circle-o'; clubuserchkstatus: boolean = true;
  GridMessage: string = 'Loading, Please wait ... !'; viewstatustitle: any; viewstatusclass: any;
  key: string = 'clubcoursename';
  reverse: boolean = false;ddlsearch:any;
  srchError: string = '0';
  nameasc:any="sortgreen"; namedesc:any="sortwhite"; adminasc:any="sortwhite"; admindesc:any="sortwhite";
  selectedoption:any="Active";randomcolor:any="#5cb85c";
  constructor(private title: Title,private modalService: BsModalService, public toastr: ToastsManager, vcr: ViewContainerRef, private _router: Router, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService, private authService: AuthService) {
    
    this.title.setTitle("IZON - Employee Assignment");
    this.ddlsearch="GCB_NAME";
    this.toastr.setRootViewContainerRef(vcr);
    this.contentShow = "none"; this.gridShow = "none";
    this.ddlclubs = "0";
    this.ddlusers = "0";
    this.golfclubsdata = []; this.usersdata = []; this.clubuserassignmentdata = [];
  }

  ngOnInit() {
    this.clubuserForm = this.formBuilder.group({
      clubino: ['0', Validators.compose([Validators.required])],
      userinfo: ['0', Validators.compose([Validators.required])],
      clubuserchkstatus: ['']
    });
    let parameters = {
      searchvalue: " WHERE  GCB_STATUS = 'Y'"
    };
    this.getgolfclubs(parameters);
    parameters = { searchvalue: " WHERE U_STATUS = 'Y' " };
    this.getUsers(parameters);
    parameters = {
      searchvalue: " WHERE  GCCA_STATUS= 'Y' "
    };
    this.getclubuserassignmenttable(parameters);

    this.gridShow = "block";
    this.contentShow = "none";
  }
  bindselectedoption(selectedoption) {
    if (this.selectedoption == 'Active') {
        this.randomcolor = "#5cb85c";
        this.srchSts('Y');
    }
    else if (this.selectedoption == 'In-Active') {
        this.randomcolor = "#337ab7";
        this.srchSts('N');
    }
    else if (this.selectedoption == 'Deleted') {
        this.randomcolor = "#d9534f";
        this.srchSts('D');
    }
  }
  getclubuserassignmenttable(parameters) {
    this.spinnerService.show();
    this.api.postOH('getclubcourseuserassignment', parameters).subscribe(
      (response) => {
        //console.log(response);
        this.clubuserassignmentdata = [];
        for (let i = 0; i < response.length; i++) {
          var status = (response[i].status == 'Y') ? "fa fa-check-circle-o" : (response[i].status == 'N') ? "fa fa-ban" : "fa fa-times-circle-o";
          var statustitle = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
          var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
          var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
          var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var confirmshow = "row-icon-inactive";

          this.clubuserassignmentdata.push({
            "id": response[i].id,
            "clubcourseid": response[i].clubcourseid,
            "clubcoursename": response[i].clubcoursename,
            "clubcourseuserid": response[i].clubcourseuserid,
            "clubcourseadmin": response[i].clubcourseadmin,
            "courseid": response[i].courseid,
            "createddate": response[i].createddate,
            "updatedby": response[i].updatedby,
            "status": status,
            "statustitle": statustitle,
            "statusclass": statusclass,
            "editshow": editshow,
            "enableshow": enableshow,
            "removeshow": removeshow,
            "confirmshow": confirmshow
          });
        }
        if (this.action === "U") {
          this.ddlclubs = (!this.clubuserassignmentdata[0].clubcourseid) ? "" : this.clubuserassignmentdata[0].clubcourseid;
          this.ddlusers = (!this.clubuserassignmentdata[0].clubcourseuserid) ? "" : this.clubuserassignmentdata[0].clubcourseuserid;
          this.clubuserchkstatus = (this.clubuserassignmentdata[0].statustitle == "Active") ? true : false;
          this.assignmentstatus = (this.clubuserassignmentdata[0].statustitle == "Active") ? 'Y' : 'N';
        }
        {
          this.GridMessage = "No Data Found";
        }
        this.spinnerService.hide();

      }, error => {
        this.spinnerService.hide();
      }
    );

  }
  refreshpage() {
    this.txtsrch = "";
    this.srchError="0";
    
    let parameters = {
      searchvalue: " WHERE  GCCA_STATUS= 'Y' "
    };
    this.getclubuserassignmenttable(parameters);
    this.ddlsearch="GCB_NAME";
    this.selectedoption="Active";this.randomcolor="#5cb85c";
  }

  search() {
    if(this.txtsrch == '')
    {
      this.srchError = '1';
    }
    else if(this.txtsrch != ''){
    let searchexp="";
    if(this.ddlsearch==="GCB_NAME"){
      searchexp= " WHERE GCB_NAME LIKE '%" + this.txtsrch + "%' and GCCA_STATUS<>'D'"
    }
    else if(this.ddlsearch==="IZ_U_FIRST_NAME"){
      searchexp= " WHERE (U_FIRST_NAME LIKE '%" + this.txtsrch + "%' OR U_LAST_NAME LIKE '%" + this.txtsrch + "%') AND GCCA_STATUS<>'D' "
    }

    let parameters = {
      searchvalue: searchexp
    };
    this.getclubuserassignmenttable(parameters);
  }
  }


  getgolfclubs(parameters) {
    this.api.postOH('getgolfclubaddressddl', parameters).subscribe(
      (response) => {
        this.golfclubsdata = [];
        for (let i = 0; i < response.length; i++) {
          this.golfclubsdata.push({
            "id": response[i].id,
            "name": response[i].name,
            "clubcode": response[i].clubcode
          });
        }

      }, error => {

      }
    );
  }
  getUsers(parameters) {
    this.api.postOH('getusers', parameters).subscribe(
      (response) => {
        this.usersdata = [];
        for (let i = 0; i < response.length; i++) {
          this.usersdata.push({
            "id": response[i].id,
            "name": response[i].name,
          });
        }

      }, error => {

      }
    );
  }

  checkBoxChange(status) {
    this.chkstatus = status;
    if (this.chkstatus == true) {
      this.assignmentstatus = 'Y';
      //this.assignmentstatus = true;
      this.txtstatus = 'fa fa-check-circle-o';
    }
    else {
      this.assignmentstatus = 'N';
      //this.assignmentstatus = false;
      this.txtstatus = 'fa fa-ban';
    }
  }
  viewclubuser(clubassignments) {
    window.scrollTo(0, 0);
    this.action = 'V';
    this.gridShow = "none";
    this.viewcontentShow = "block";
    this.contentShow = "none";
    this.clubuserid = clubassignments.id;
    this.clubname = (!clubassignments.clubcoursename) ? "" : clubassignments.clubcoursename;
    this.username = (!clubassignments.clubcourseadmin) ? "" : clubassignments.clubcourseadmin;
    //this.cartstatus = cartdetaildata.status;
    if (clubassignments.status == 'fa fa-check-circle-o') {
      this.assignmentstatus = 'Y';
      this.viewstatustitle = "Active";
      this.viewstatusclass = "active-status";
    }
    else if (clubassignments.status == 'fa fa-ban') {
      this.assignmentstatus = 'N';
      this.viewstatustitle = "In-Active";
      this.viewstatusclass = "inactive-status";
    }
    else {
      this.viewstatustitle = "Deleted";
      this.viewstatusclass = "deleted-status";
    }
    this.clubuserchkstatus = (this.assignmentstatus == 'Y') ? true : false;
    this.txtstatus = (this.assignmentstatus == 'Y') ? 'fa fa-check-circle-o' : (this.assignmentstatus == 'N') ? 'fa fa-ban' : 'fa fa-times-circle-o';
    if (clubassignments.status == 'fa fa-times-circle-o') {
      this.assignmentstatus = 'D';
      this.txtstatus = 'fa fa-times-circle-o';
    }
  }

  addclubuser() {
    //this.clubuserForm.reset();
    this.action = 'A';
    this.clubuserid = "0";
    this.gridShow = "none";
    this.contentShow = "block";
    this.txtShow = "block"; this.lblShow = "none";
    this.submitAttempt = false;
    this.clearform();
  }
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }
  decline(): void {
    this.modalRef.hide();
  }
  confirm(): void {
    this.modalRef.hide();
    this.action = "D";
    var golfclubuserassignmentmodel = {
      "flag": "CB",
      "action": "D",
      "id": this.clubuserid,
      "clubcourseid": this.ddlclubs,
      "clubcourseuserid": this.ddlusers,
      "courseid": "0",
      "updatedid": localStorage.getItem('userId'),
      "status": this.assignmentstatus
    }
    this.saveclubassignment(golfclubuserassignmentmodel);
  }
  srchSts(type) {
    let parameters = {
      searchvalue: " WHERE  GCCA_STATUS= '" + type + "' "
    };
    this.getclubuserassignmenttable(parameters);
  }
  enableclubuser(clubassignments) {
    this.action = "E";
    var golfclubuserassignmentmodel = {
      "flag": "CB",
      "action": "E",
      "id": clubassignments.id,
      "clubcourseid": this.ddlclubs,
      "clubcourseuserid": this.ddlusers,
      "courseid": "0",
      "updatedid": localStorage.getItem('userId'),
      "status": 'Y'
    }
    this.saveclubassignment(golfclubuserassignmentmodel);
  }
  editclubuser() {
    this.divheader = "Edit Club Employee";
    this.action = 'U';
    this.gridShow = "none";
    this.contentShow = "block";
    this.viewcontentShow = "none";
    this.txtShow = "block"; this.lblShow = "none";
    let parameters = {
      searchvalue: ' WHERE GCCA_ID=' + this.clubuserid + ''
    };
    this.spinnerService.show();
    this.getclubuserassignmenttable(parameters);
    this.spinnerService.hide();
  }
  gotogrid() {
    let parameters = {
      searchvalue: " WHERE  GCCA_STATUS= 'Y' "
    };
    this.getclubuserassignmenttable(parameters);
    this.selectedoption="Active";this.randomcolor="#5cb85c";
    this.gridShow = "block";
    this.contentShow = "none";
    this.viewcontentShow = "none";
    this.action = 'A';
  }
  goBack() {
    this.gridShow = "block";
    this.contentShow = "none";
    this.viewcontentShow = "none";
    this.action = 'A';
  }
  clearform() {
    this.ddlclubs = "0";
    this.ddlusers = "0";
    this.action = "A";
    this.clubuserid = "0";
    this.assignmentstatus = "Y"
  }
  saveData() {
    if (!this.clubuserForm.valid) {
      //alert('f');
    }
    this.submitAttempt = true;
    if (this.ddlclubs != '0' && this.ddlusers != '0') {
      if (this.clubuserForm.valid) {        
        var golfclubuserassignmentmodel = {
          "flag": "CB",
          "action": this.action,
          "id": this.clubuserid,
          "clubcourseid": this.ddlclubs,
          "clubcourseuserid": this.ddlusers,
          "courseid": 0,
          "updatedid": localStorage.getItem('userId'),
          "status": this.assignmentstatus
        }
        this.saveclubassignment(golfclubuserassignmentmodel);
      }
    }
  }
  saveclubassignment(golfclubuserassignmentmodel) {
    this.spinnerService.show();
    this.api.postOH('saveclubusers', golfclubuserassignmentmodel).subscribe(
      (response) => {
        let parameters = {
          searchvalue: " WHERE  GCCA_STATUS= 'Y' "
        };
        this.getclubuserassignmenttable(parameters);
        this.selectedoption="Active";this.randomcolor="#5cb85c";
        this.gridShow = "block";
        this.contentShow = "none";
        this.viewcontentShow = "none";
        let msg = (this.action == "A") ? '<span style="color: green">Club Employee added Successfully .</span>' : (this.action == "U") ? '<span style="color: green">Club Employee updated Successfully</span>' : (this.action == "D") ? '<span style="color: green">Club Employee deleted Successfully</span>' : (this.action == "E") ? '<span style="color: green">Club Employee enabled Successfully</span>' : "";
        this.toastMessage(msg);
        this.spinnerService.hide();
        window.scrollTo(0, 0);
      },error=>{
        this.spinnerService.hide();
      });
  }
  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',

    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 3000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }
  sort(value : string)
  {
    this.key = value;
    this.nameasc="sortwhite"; this.namedesc="sortwhite"; this.adminasc="sortwhite"; this.admindesc="sortwhite";
      if(this.key == value)
      {
          this.reverse = !this.reverse;
      }
      if(this.key=="clubcoursename" && this.reverse){
        this.namedesc="sortgreen";
      }
      else if(this.key=="clubcoursename" && (!this.reverse)){
        this.nameasc="sortgreen";
      }
      else if(this.key=="clubcourseadmin" && (this.reverse)){
        this.admindesc="sortgreen";
      }
      else if(this.key=="clubcourseadmin" && (!this.reverse)){
        this.adminasc="sortgreen";
      }
     
  }
}
