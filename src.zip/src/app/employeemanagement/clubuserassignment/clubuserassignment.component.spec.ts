import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClubuserassignmentComponent } from './clubuserassignment.component';

describe('ClubuserassignmentComponent', () => {
  let component: ClubuserassignmentComponent;
  let fixture: ComponentFixture<ClubuserassignmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClubuserassignmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClubuserassignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
