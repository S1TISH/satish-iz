import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { ModalModule } from 'ngx-bootstrap';
import { OrderModule } from 'ngx-order-pipe';
//import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';

import { UsersComponent } from './users/users.component';
import { ModulesComponent } from './modules/modules.component';
import { RolesComponent } from './roles/roles.component';
import { ClubuserassignmentComponent } from './clubuserassignment/clubuserassignment.component';
import { SidemenumodulesComponent } from './sidemenumodules/sidemenumodules.component';

const routes: Routes = [
  {
    path:'users',
    component:UsersComponent
  },
  {
    path:'modules',
    component:ModulesComponent
  },
  {
    path:'roles',
    component:RolesComponent
  },
  {
    path:'clubuserassignment',
    component:ClubuserassignmentComponent
  },
  {
    path:'sidemenumodules',
    component:SidemenumodulesComponent
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule, ReactiveFormsModule,OrderModule,
    ToastModule.forRoot(),
    ModalModule.forRoot()
  ],
  declarations: [UsersComponent, ModulesComponent, RolesComponent, ClubuserassignmentComponent, SidemenumodulesComponent],
  exports: [RouterModule]
})
export class EmployeemanagementModule { }
