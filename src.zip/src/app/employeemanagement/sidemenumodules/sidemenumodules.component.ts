import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Title } from '@angular/platform-browser';

@Component({
    selector: 'app-sidemenumodules',
    templateUrl: './sidemenumodules.component.html',
    styleUrls: ['./sidemenumodules.component.css']
})
export class SidemenumodulesComponent implements OnInit {
    modalRef: BsModalRef;
    public sidemenumodulesForm: FormGroup; submitAttempt: boolean = false; divheader: string = "Add Module";
    searchtxt: boolean = true; searchddl: boolean = false;
    sidemenumodulesdata: any; sidemenusubmodulesdata: any;
    contentShow: string = "none"; gridShow: string = "none";
    viewcontentShow: string = "none"; coursegridShow: string = "none";

    action: string = 'A'; smid: string = "0"; smsubid: string = "0"; mainmodid: string = "0"; 
    searchvalue: string = '  WHERE SM_M_ID=0 ';
    txtmname: string; txtpname: string; txticon: string; txtseq: string;
    lblmdname: string; lblpagename: string; lblglyphicon: string; lblsequence: string;
    clubtxtsts: string = 'Active'; txtsrch: string = '';
    GridMessage: string = 'Loading, Please wait ... !';
    srchError: string = '0'; status: boolean = false; chksts: string = 'Y';chkshowonmenu: any=false;
    editModData: any = []; type: string = 'M'; lblname: string = "Module Name";

    cancelmainmoduledata:any;iconname:any;

    key: string = 'name';
    reverse: boolean = false;ddlsearch:any; 
    nameasc:any="sortgreen"; namedesc:any="sortwhite"; seqasc:any="sortwhite"; seqdesc:any="sortwhite"; 
    selectedoption:any="Active";randomcolor:any="#5cb85c";

    txtShow:any='block';

    constructor(private title: Title,private modalService: BsModalService, public toastr: ToastsManager, vcr: ViewContainerRef, private _router: Router, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService, private authService: AuthService) {
        this.toastr.setRootViewContainerRef(vcr);
        this.title.setTitle("IZON - Side Menu Modules");
        this.ddlsearch="SM_M_NAME";
        this.contentShow = "none"; this.gridShow = "none";
        this.sidemenumodulesdata = []; this.sidemenusubmodulesdata = [];
    }

    ngOnInit() {
      this.sidemenumodulesForm = this.formBuilder.group({
            fmdname: ['', Validators.compose([Validators.required])],
            fpagename: ['',Validators.compose([Validators.required])],
            fglyphicon: [''],
            fsequence: ['', Validators.compose([Validators.required])],
            fchkshowonmenu: [''],
            status:['']
        });
        this.searchvalue = " WHERE SM_M_ID= 0 AND SM_STATUS= 'Y'";
        let parameters = { searchvalue: this.searchvalue };
        this.GetSideMenuData(parameters);

        this.gridShow = "block";
        this.contentShow = "none";
    }

    refreshpage() {
        this.selectedoption="Active";this.randomcolor="#5cb85c";
        this.srchError="0";
        let parameters = { searchvalue: "  WHERE SM_M_ID=0 AND SM_STATUS= 'Y' " };
        this.GetSideMenuData(parameters);
        this.ddlsearch="SM_M_NAME";
    }
    srchKeyUp(event: any) {
        if (this.txtsrch != '') {
            this.srchError = '0';
        }
    }
    bindselectedoption(selectedoption) {
        if (this.selectedoption == 'Active') {
            this.randomcolor = "#5cb85c";
            this.srchSts('Y');
        }
        else if (this.selectedoption == 'In-Active') {
            this.randomcolor = "#337ab7";
            this.srchSts('N');
        }
        else if (this.selectedoption == 'Deleted') {
            this.randomcolor = "#d9534f";
            this.srchSts('D');
        }
    }
    search() {
        if (this.txtsrch == '') {
            this.srchError = '1';
        }
        else if (this.txtsrch != '') {
            let parameters = {
                searchvalue: " WHERE MOD_M_ID=0 AND "+this.ddlsearch+" LIKE '%" + this.txtsrch + "%' AND MOD_STATUS<>'D' "
            };
            this.GetSideMenuData(parameters);
            this.txtsrch = "";
        }
    }
    sort(value : string)
    {
        this.key = value;
        this.nameasc="sortwhite"; this.namedesc="sortwhite"; this.seqasc="sortwhite"; this.seqdesc="sortwhite";
        if(this.key == value)
        {
            this.reverse = !this.reverse;
            if(this.key=="modulename" && this.reverse){
                this.namedesc="sortgreen";
              }
              else  if(this.key=="modulename" && (!this.reverse)){
                this.nameasc="sortgreen";
              }
              else if(this.key=="sequence" && this.reverse){
                this.seqdesc="sortgreen";
              }
              else  if(this.key=="sequence" && (!this.reverse)){
                this.seqasc="sortgreen";
              }
        }
    }
    srchSts(type) {
        let parameters = {
            searchvalue: " WHERE SM_M_ID=0 AND SM_STATUS='" + type + "'"
        };
        this.GetSideMenuData(parameters);
    }
    GetSideMenuData(parameters) {
        this.spinnerService.show();
        this.api.postOH('getsidemenumodules', parameters).subscribe(
            (response) => {
                this.sidemenumodulesdata = [];
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                    var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var confirmshow = "row-icon-inactive";

                    this.sidemenumodulesdata.push({
                        "id": response[i].id,
                        "moduleid": response[i].moduleid,
                        "modulename": response[i].modulename,
                        "pagename": response[i].pagename,
                        "moduleicon": response[i].moduleicon,
                        "sequence": response[i].sequence,
                        "createdby": response[i].updatedby,
                        "createddate": response[i].createddate,
                        "status": status,
                        "statusclass": statusclass,
                        "editshow": editshow,
                        "enableshow": enableshow,
                        "removeshow": removeshow,
                        "confirmshow": confirmshow
                    });
                }
                {
                    this.GridMessage = "No Data Found";
                }
               this.spinnerService.hide();

            }, error => {
                this.spinnerService.hide();
            }
        );
    }

    //get sub modules table
    getsubmodulesdetailstable(parameters) {
        this.sidemenusubmodulesdata = [];
        this.spinnerService.show();
        this.api.postOH('getsidemenumodules', parameters).subscribe(
            (response) => {
                
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                    var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var confirmshow = "row-icon-inactive";

                    this.sidemenusubmodulesdata.push({
                      "id": response[i].id,
                      "moduleid": response[i].moduleid,
                      "modulename": response[i].modulename,
                      "pagename": response[i].pagename,
                      "moduleicon": response[i].moduleicon,
                      "sequence": response[i].sequence,
                      "createdby": response[i].updatedby,
                      "createddate": response[i].createddate,
                      "status": status,
                      "statusclass": statusclass,
                      "editshow": editshow,
                      "enableshow": enableshow,
                      "removeshow": removeshow,
                      "confirmshow": confirmshow
                    });
                }
                {
                    this.GridMessage = "No Data Found";
                }
                this.spinnerService.hide();

            }, error => {
                this.spinnerService.hide();
            }
        );
    }

    viewsidemenumodule(moduledata, type) {
        //console.log(moduledata);
        window.scrollTo(0, 0);
        this.type = type;
        this.editModData = moduledata;
        this.mainmodid=moduledata.id;
        this.action = 'V';
        this.viewcontentShow = "block"; this.contentShow = "none";
        this.gridShow = "none"; this.coursegridShow = "block";

        this.smid = moduledata.id;
        this.lblmdname = (!moduledata.modulename) ? "" : moduledata.modulename;
        this.lblpagename = (!moduledata.pagename) ? "" : moduledata.pagename;
        this.lblglyphicon = (!moduledata.moduleicon) ? "" : moduledata.moduleicon;
        this.lblsequence = (!moduledata.sequence) ? "" : moduledata.sequence;
        this.clubtxtsts = moduledata.status;
        if (type == 'M') {
            this.cancelmainmoduledata=moduledata;
            let parameters = { searchvalue: "  WHERE SM_M_ID="+moduledata.id+" and SM_STATUS<>'D' " };
            this.getsubmodulesdetailstable(parameters);
        }
        else {
            this.viewcontentShow = "block"; this.contentShow = "none";
            this.gridShow = "none"; this.coursegridShow = "none";
        }

    }

    cancel() {
        if (this.type == 'M' && this.action=='A') {
            this.gridShow = "block";
            this.contentShow = "none";
            this.viewcontentShow = "none";
            this.coursegridShow = "none";
           
        }
        else if (this.type == 'M' && this.action == 'U') {
            this.gridShow = "none";
            this.contentShow = "none";
            this.viewcontentShow = "block";
            this.coursegridShow = "block";
        }

        else{
            this.gridShow = "none";
            this.contentShow = "none";
            this.viewcontentShow = "block";
            this.coursegridShow = "block";
            this.viewsidemenumodule(this.cancelmainmoduledata, 'M');
         }
       

    }

    addsidemenumodules(type) {
        this.type = type;
        this.sidemenumodulesForm.reset();
        this.gridShow = "none"; this.viewcontentShow = "none";
        this.contentShow = "block"; this.coursegridShow = "none";
        this.divheader = (type == 'M') ? "Edit Side Menu Module" : "Edit Side Menu Submodule";
        this.action = 'A';
        if (type == 'M') {
            this.divheader = "Add Side Menu Module";
            this.smid = "0"; this.smsubid = "0";
            this.lblname = "Side Menu Module Name";
            this.iconname="GlyphIcon";
        }
        else {
            this.divheader = "Add Side Menu Submodule";
            this.smid = "0";this.smsubid=this.mainmodid;
            this.lblname = "Side Menu Submodule Name";
            this.iconname="Icon Image Name";
        }
        this.submitAttempt = false;
        this.txtmname = "";
        this.txtpname = "";
        this.txticon = "";
        this.txtseq = "";
        this.chkshowonmenu=false;

    }
    allowNumbers(event) {
        if (event.keyCode < 48 || event.keyCode > 57) {
            event.preventDefault();
        }
    }

    //edit record
    editsidemenumodules() {
        //console.log(this.editModData);       
        if (this.type == 'M') {
            this.divheader = "Edit Side Menu Module";
            this.lblname = "Side Menu Module Name";
            this.iconname="GlyphIcon";
        }
        else {
            this.divheader = "Edit Side Menu Submodule";
            this.lblname = "Side Menu Submodule Name";
            this.smsubid = this.editModData.moduleid;
            this.mainmodid=this.editModData.moduleid;
            this.iconname="Icon Image Name";
        }
        this.smid = this.editModData.id;
        this.action = 'U';
        this.gridShow = "none";       
        this.txtmname = this.editModData.modulename;
        this.txtpname = this.editModData.pagename;
        this.txticon = this.editModData.moduleicon;
        this.txtseq = this.editModData.sequence;
        this.status = (this.editModData.status == 'Active') ? true : false;       
        this.contentShow = "block"; this.viewcontentShow = "none"; this.coursegridShow = "none";
        this.gridShow = "none";
    }

    changests(e) {
        this.chksts = (e.target.checked == true) ? 'Y' : 'N';
    }

    goBack() {
        this.gridShow = "block";
        this.contentShow = "none";
        this.viewcontentShow = "none";
        this.coursegridShow = "none";
        this.action = 'A';
        if(this.type=='S'){
            this.viewsidemenumodule(this.cancelmainmoduledata, 'M');
        }
    }

    saveData() {
        if (!this.sidemenumodulesForm.valid) {
           
        }

        this.submitAttempt = true;
        if (this.sidemenumodulesForm.valid) {
            var modulesinfo = {
                "action": this.action, 
                "id": this.smid, 
                "moduleid": this.smsubid, 
                "modulename": this.txtmname,  
                "pagename": this.txtpname, 
                "moduleicon": this.txticon,
                "sequence": this.txtseq, 
                "updtaedid": localStorage.getItem('userId'),
                "status": this.chksts
            }
            this.spinnerService.show();
            //console.log(modulesinfo);
            this.api.postOH('savesidemenumodules', modulesinfo).subscribe(
                (response) => {                   
                    if (this.type == 'M') {
                        let parameters = { searchvalue: "  WHERE SM_M_ID=0 AND SM_STATUS= 'Y' " };
                        this.GetSideMenuData(parameters);
                        this.selectedoption="Active";this.randomcolor="#5cb85c";
                        this.gridShow = "block"; this.viewcontentShow = "none"
                        this.contentShow = "none"; this.coursegridShow = "none";
                        let msg = (this.action == "A") ? '<span style="color: green">Sidemenu Module added Successfully .</span>' : '<span style="color: green">Sidemenu Module updated Successfully .</span>';
                        this.toastMessage(msg);
                    }
                    else {
                        // let parameters = { searchvalue: "  WHERE SM_M_ID=" + this.mainmodid + " " };
                        // this.getsubmodulesdetailstable(parameters);
                        this.viewsidemenumodule(this.cancelmainmoduledata, 'M');
                        this.gridShow = "none"; this.viewcontentShow="block"
                        this.contentShow = "none"; this.coursegridShow = "block";
                        let msg = (this.action == "A") ? '<span style="color: green">Sidemenu Submodule added Successfully .</span>' : '<span style="color: green">Sidemenu Submodule updated Successfully .</span>';
                        this.toastMessage(msg);
                    }                  
                    this.spinnerService.hide();
                    window.scrollTo(0, 0);
                }, error => {
                    console.log(error);
                });
        }
    }

    toastMessage(msg) {
        let options = {
            positionClass: 'toast-top-center',

        };

        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 5000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    }

    confirm(): void {
        this.modalRef.hide();
        var modulesinfo = {
          "action": 'D', "id": this.smid, "moduleid": this.smsubid, "modulename": '', "pagename": '', "moduleicon": '', "sequence": 0, "updtaedid": localStorage.getItem('userId'),"status": 'D'
        }
        let msg = '<span style="color: green">Sidemenu Module deleted Successfully</span>';
        this.DEapicall(modulesinfo, msg);
    }

    enablesidemenumodule(id,type): void {
        var modulesinfo = {
          "action": 'E', "id": id, "moduleid": this.smsubid, "modulename": '', "pagename": '', "moduleicon": '', "sequence": 0, "updtaedid": localStorage.getItem('userId'), "status": 'Y'
        }
        let msg = '<span style="color: green">Sidemenu Module enabled Successfully</span>';
        this.DEapicall(modulesinfo, msg);
    }

    DEapicall(modulesinfo, msg) {
        
        this.api.postOH('savesidemenumodules', modulesinfo).subscribe(
            (response) => {
                let parameters = { searchvalue: "  WHERE SM_M_ID=0 AND SM_STATUS= 'Y' " };
                this.GetSideMenuData(parameters);
                this.selectedoption="Active";this.randomcolor="#5cb85c";
                this.contentShow = "none"; this.gridShow= "block";
                this.viewcontentShow ="none"; this.coursegridShow= "none";
                this.toastMessage(msg);
            }, error => {
                console.log(error);
            });
    }

    decline(): void {
        this.modalRef.hide();
    }
}

