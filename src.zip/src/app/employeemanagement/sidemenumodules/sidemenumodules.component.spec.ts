import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SidemenumodulesComponent } from './sidemenumodules.component';

describe('SidemenumodulesComponent', () => {
  let component: SidemenumodulesComponent;
  let fixture: ComponentFixture<SidemenumodulesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SidemenumodulesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SidemenumodulesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
