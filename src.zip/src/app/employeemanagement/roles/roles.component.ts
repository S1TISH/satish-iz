import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
//import { ModalService } from 'ng-bootstrap-modal';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormArray, FormControl } from '@angular/forms/src/model';
import { Observable } from 'rxjs/Observable';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.css']
})

export class RolesComponent implements OnInit {
  modalRef: BsModalRef;
  public rolesForm: FormGroup; submitAttempt: boolean = false; divheader: string = "Add Role";
  searchtxt: boolean = true; searchddl: boolean = false;
  contentShow: string = "none"; gridShow: string = "none";
  viewcontentShow: string = "none"; buttonShow: string = "none";
  rolesdata: any; mainmoduleslist: any; submoduleslist: any;
  txtShow: string = "none"; lblShow: string = "none"; action: string = 'A';
  txtname: any; txtcode: any;
  txtsrch: string = '';
  roleid: any;
  GridMessage: string = 'Loading, Please wait ... !';
  rolestatus: any; rolechkstatus: boolean = true;
  stat: any;
  selectedModules = []; selectedsubModules = []; submenumodulesdata = []; submenumainmoddata = []; selectedsubmenu = []; selectedsubmenumainmod = [];
  userloginid: any; srchError: string = '0';
  //select_mod: string;
  roletxtstatus: string = 'Active';
  readonlyProp: boolean = false;
  key: string = 'name';
  reverse: boolean = false; ddlsearch: any;
  nameasc: any = "sortgreen"; namedesc: any = "sortwhite"; codeasc: any = "sortwhite"; codedesc: any = "sortwhite";
  editRoleInfo: any;
  selectedoption: any = "Active"; randomcolor: any = "#5cb85c";


  constructor(private title: Title, private modalService: BsModalService, public toastr: ToastsManager, vcr: ViewContainerRef, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService,
    private authService: AuthService, private router: Router) {

    this.title.setTitle("IZON - Roles");
    this.ddlsearch = "R_NAME";
    this.toastr.setRootViewContainerRef(vcr);

    this.contentShow = "none"; this.gridShow = "none"; this.viewcontentShow = "none";
    this.rolesdata = [];
    this.userloginid = localStorage.getItem('userId');
    this.selectedModules = []; this.selectedsubModules = []; this.submenumodulesdata = []; this.submenumainmoddata = []; this.selectedsubmenu = []; this.selectedsubmenumainmod = [];
  }

  ngOnInit() {
    this.rolesForm = this.formBuilder.group({
      txtname: ['', Validators.compose([Validators.required])],
      txtcode: ['', Validators.compose([Validators.required])],
      fmodules: [this.selectedModules.length == 0 && this.selectedsubModules.length == 0, Validators.compose([Validators.required])],
      fsubmenu: [this.selectedsubmenumainmod.length == 0 && this.selectedsubmenu.length == 0, Validators.compose([Validators.required])],
      rolestatus: ['']
    });
    this.bindModules();
    this.GetSubMenuModulesData();
    let parameters = {
      searchvalue: " WHERE R_STATUS = 'Y'"
    };
    this.GetRoleData(parameters);

    this.gridShow = "block";
    this.contentShow = "none";
  }

  GetSubMenuModulesData() {
    let parameters = {
      searchvalue: " WHERE SM_STATUS = 'Y'"
    };
    this.api.postOH('getsidemenumodules', parameters).subscribe(
      (response) => {
        this.submenumodulesdata = response;
        this.submenumainmoddata = response;
      }
    );
  }

  sort(value: string) {
    this.key = value;
    this.nameasc = "sortwhite"; this.namedesc = "sortwhite"; this.codeasc = "sortwhite"; this.codedesc = "sortwhite";
    if (this.key == value) {
      this.reverse = !this.reverse;
      if (this.key == "name" && this.reverse) {
        this.namedesc = "sortgreen";
      }
      else if (this.key == "name" && (!this.reverse)) {
        this.nameasc = "sortgreen";
      }
      else if (this.key == "code" && this.reverse) {
        this.codedesc = "sortgreen";
      }
      else if (this.key == "code" && (!this.reverse)) {
        this.codeasc = "sortgreen";
      }
    }

  }

  refreshpage() {
    let parameters = {
      searchvalue: " WHERE R_STATUS = 'Y'"
    };
    this.GetRoleData(parameters);
    this.selectedoption = "Active";
    this.randomcolor = "#5cb85c";
    this.txtsrch = "";
    this.ddlsearch = "R_NAME";
    this.srchError = "0";
  }

  search() {
    if (this.txtsrch == '') {
      this.srchError = '1';
    }
    else if (this.txtsrch != "") {
      this.srchError = '0';
      let parameters = {
        searchvalue: " WHERE " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND R_STATUS<>'D' "
      };
      this.GetRoleData(parameters);
      this.txtsrch = "";
    }
  }

  srchKeyUp(event: any) {
    if (this.txtsrch != '') {
      this.srchError = '0';
    }
  }

  srchSts(type) {
    let parameters = {
      searchvalue: " WHERE R_STATUS= '" + type + "' "
    };
    this.GetRoleData(parameters);
  }

  bindselectedoption(selectedoption) {
    this.srchError = '0';
    if (this.selectedoption == 'Active') {
      this.randomcolor = "#5cb85c";
      this.srchSts('Y');
    }
    else if (this.selectedoption == 'In-Active') {
      this.randomcolor = "#337ab7";
      this.srchSts('N');
    }
    else if (this.selectedoption == 'Deleted') {
      this.randomcolor = "#d9534f";
      this.srchSts('D');
    }
  }
  addRole() {
    this.submitAttempt = false;
    this.readonlyProp = false;
    this.clear();
    this.bindModules();
    this.divheader = "Add Role";
    this.action = 'A';
    this.gridShow = "none";
    this.contentShow = "block";
    this.viewcontentShow = "none";
    this.txtShow = "block"; this.lblShow = "none";
    this.txtname = ''; this.txtcode = '';
    this.rolestatus = 'Y';
    this.selectedsubModules = [];
    this.selectedModules = [];
  }

  GetRoleData(parameters) {
    this.spinnerService.show();
    this.api.postOH('getuserroles', parameters).subscribe(
      (response) => {
        this.rolesdata = [];
        for (let i = 0; i < response.length; i++) {
          var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
          var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
          var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
          var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var confirmshow = "row-icon-inactive";

          this.rolesdata.push({
            "id": response[i].id,
            "name": response[i].name,
            "code": response[i].code,
            "createdby": response[i].updatedby,
            "createddate": response[i].createddate,
            "status": status,
            "statusclass": statusclass,
            "editshow": editshow,
            "enableshow": enableshow,
            "removeshow": removeshow,
            "confirmshow": confirmshow
          });
        }
        {
          this.GridMessage = "No Data Found";
        }
        this.spinnerService.hide();

      }, error => {
        this.spinnerService.hide();
      }
    );
  }

  bindModules() {
    let parameters = {
      searchvalue: " WHERE MOD_STATUS = 'Y'"
    };
    this.api.postOH('getmodules', parameters).subscribe(
      (response) => {
        this.mainmoduleslist = response;
        this.submoduleslist = response;
      })
  }

  clear() {
    for (var k = 0; k < this.mainmoduleslist.length; k++) {
      this.mainmoduleslist[k].moduleselected = false;
    }

    for (var s = 0; s < this.submoduleslist.length; s++) {
      this.submoduleslist[s].submodselected = false;
    }

    for (var s = 0; s < this.submenumodulesdata.length; s++) {
      this.submenumodulesdata[s].smmodselected = false;
    }

    for (var s = 0; s < this.submenumainmoddata.length; s++) {
      this.submenumainmoddata[s].smmainmod = false;
    }
  }

  cancel() {
    if (this.action == 'A') {
      this.rolesForm.reset();
      this.clear();
      this.gridShow = "block";
      this.contentShow = "none";
      this.viewcontentShow = "none";
      this.action = 'A';
    }
    else {
      this.gridShow = "none";
      this.contentShow = "none";
      this.viewcontentShow = "block";
      this.viewrole(this.editRoleInfo);
    }

  }

  checkBoxChange(status) {
    this.stat = status;
    if (this.stat == true) {
      this.rolestatus = 'Y';
      this.roletxtstatus = 'Active';
    }
    else {
      this.rolestatus = 'N';
      this.roletxtstatus = 'In-Active';
    }
  }

  viewrole(roledata) {
    window.scrollTo(0, 0);
    this.editRoleInfo = roledata;
    this.action = 'V';
    this.viewcontentShow = "block";
    this.gridShow = "none";
    this.roleid = roledata.id;
    this.txtname = (!roledata.name) ? "" : roledata.name;
    this.txtcode = (!roledata.code) ? "" : roledata.code;
    // if (roledata.status == 'Active') {
    //   this.rolestatus = 'Y';
    // }
    // else if (roledata.status == 'In-Active') {
    //   this.rolestatus = 'N';
    // }
    // this.rolechkstatus = (this.rolestatus == 'Y') ? true : false;
    // this.roletxtstatus = (this.rolestatus == 'Y') ? 'Active' : 'In-Active';
    // if (roledata.status == 'Deleted') {
    //   this.rolestatus = 'D';
    //   this.roletxtstatus = 'Deleted';
    // }

    this.roletxtstatus = roledata.status
    if (roledata.status == 'Deleted') {
      this.roletxtstatus = 'Deleted';
    }
  }

  goBack() {
    this.rolesForm.reset();
    this.gridShow = "block";
    this.contentShow = "none";
    this.viewcontentShow = "none";
  }

  editRole() {
    this.clear();
    this.selectedsubModules = [];
    this.selectedModules = [];
    this.bindModules();
    this.divheader = "Edit Role";
    this.action = 'U';
    this.gridShow = "none";
    this.contentShow = "block"; this.viewcontentShow = "none";
    this.txtShow = "block"; this.lblShow = "none";
    let parameters = {
      searchvalue: ' WHERE R_ID=' + this.roleid + ''
    };
    //this.spinnerService.show();
    let roledata = [];
    this.api.postOH('getuserroles', parameters).subscribe(
      (response) => {
        for (let i = 0; i < response.length; i++) {
          var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
          var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
          var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
          var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var confirmshow = "row-icon-inactive";

          roledata.push({
            "id": response[i].id,
            "name": response[i].name,
            "code": response[i].code,
            "createdby": response[i].updatedby,
            "createddate": response[i].createddate,
            "status": status,
            "statusclass": statusclass,
            "editshow": editshow,
            "enableshow": enableshow,
            "removeshow": removeshow,
            "confirmshow": confirmshow
          });
        }
        this.txtname = (!roledata[0].name) ? "" : roledata[0].name;
        this.txtcode = (!roledata[0].code) ? "" : roledata[0].code;
        if (roledata[0].status == 'Active') {
          this.rolestatus = true;
        } else {
          this.rolestatus = false;
        }

        if (this.txtcode == 'SA') {
          this.readonlyProp = true;
        }
        else {
          this.readonlyProp = false;
        }
        let parameters = {
          searchvalue: " WHERE P_STATUS = 'Y' AND P_R_ID = " + this.roleid
        };
        this.api.postOH('getrolesmodules', parameters).subscribe(
          (response) => {
            //console.log(response);
            for (var i = 0; i < response.length; i++) {
              var moduleid = response[i].mod_id;
              var submoduleid = response[i].sub_mod_id;
              for (var j = 0; j < this.mainmoduleslist.length; j++) {
                if (this.mainmoduleslist[j].id == moduleid && this.mainmoduleslist[j].subid == 0) {
                  this.mainmoduleslist[j].moduleselected = true;
                  if (this.action == 'U' || this.action == 'A') {
                    this.checkBoxChange1(this.mainmoduleslist[j].id, this.mainmoduleslist[j].subid, this.mainmoduleslist[j].moduleselected);
                  }
                }

              }
              for (var j = 0; j < this.submoduleslist.length; j++) {
                if (this.submoduleslist[j].id == submoduleid && this.submoduleslist[j].subid == moduleid) {
                  this.submoduleslist[j].submodselected = true;
                  if (this.action == 'U' || this.action == 'A') {
                    this.checkBoxChange2(this.submoduleslist[j].id, this.submoduleslist[j].subid, this.submoduleslist[j].submodselected);
                  }
                }
              }
            }
          });
        let parameters1 = {
          searchvalue: " WHERE RSP_STATUS = 'Y' AND RSP_UR_ID = " + this.roleid
        };
        this.api.postOH('getrolesidemenupreviliges', parameters1).subscribe(
          (response) => {
            //console.log(response);
            for (var i = 0; i < response.length; i++) {
              var sidemenumoduleid = response[i].RSP_SM_MAIN_ID;
              var sidemenusubmoduleid = response[i].RSP_SM_ID;
              for (var j = 0; j < this.submenumainmoddata.length; j++) {
                if (this.submenumainmoddata[j].id == sidemenumoduleid && this.submenumainmoddata[j].moduleid == 0) {
                  this.submenumainmoddata[j].smmainmod = true;
                  if (this.action == 'U' || this.action == 'A') {
                    this.checkBoxChange4(this.submenumainmoddata[j].id, this.submenumainmoddata[j].moduleid, this.submenumainmoddata[j].smmainmod);
                  }
                }

              }
              for (var j = 0; j < this.submenumodulesdata.length; j++) {
                if (this.submenumodulesdata[j].id == sidemenusubmoduleid && this.submenumodulesdata[j].moduleid == sidemenumoduleid) {
                  this.submenumodulesdata[j].smmodselected = true;
                  if (this.action == 'U' || this.action == 'A') {
                    this.checkBoxChange3(this.submenumodulesdata[j].id, this.submenumodulesdata[j].moduleid, this.submenumodulesdata[j].smmodselected);
                  }
                }
              }
            }
          });

        //this.spinnerService.hide();

      }, error => {
        this.spinnerService.hide();
      }
    );

  }

  filter_array(test_array) {
    var index = -1,
      arr_length = test_array ? test_array.length : 0,
      resIndex = -1,
      result = [];

    while (++index < arr_length) {
      var value = test_array[index];

      if (value) {
        result[++resIndex] = value;
      }
    }

    return result;
  }

  checkBoxChange1(val1, val2, status) {
    this.selectedModules.push(val1 + "_" + val2);
    for (var i = 0; i <= this.selectedModules.length; i++) {
      if (status == false) {
        var unchkitem = val1 + "_" + val2;
        var position = this.selectedModules.indexOf(unchkitem);
        if (~position) {
          this.selectedModules.splice(position, 1);
          this.selectedModules = this.filter_array(this.selectedModules);
        }
        for (var s = 0; s < this.mainmoduleslist.length; s++) {
          if (val1 == this.mainmoduleslist[s].id) {
            this.mainmoduleslist[s].moduleselected = false;
          }
        }
      }
    }
    let arr = [];
    for (var k = 0; k <= this.selectedModules.length; k++) {
      if (arr.indexOf(this.selectedModules[k]) == -1) {
        arr.push(this.selectedModules[k]);
      }
    }
    if (arr[0] == undefined && arr.length == 1) {
      arr = []; this.selectedModules = [];
    }
    this.selectedModules = arr;
  }

  checkBoxChange2(val1, val2, status) {
    this.selectedsubModules.push(val1 + "_" + val2);
    for (var i = 0; i <= this.selectedsubModules.length; i++) {
      if (status == false) {
        var unchkitem = val1 + "_" + val2;
        var position = this.selectedsubModules.indexOf(unchkitem);
        if (~position) { this.selectedsubModules.splice(position, 1); }


        for (var s = 0; s < this.submoduleslist.length; s++) {
          if (val1 == this.submoduleslist[s].id) {
            this.submoduleslist[s].submodselected = false;
          }
        }
      }
    }
    if (this.selectedsubModules.length != 0) {
      for (var i = 0; i < this.mainmoduleslist.length; i++) {
        if (parseInt(this.mainmoduleslist[i].id) == parseInt(val2)) {
          this.selectedModules.push(val2 + "_" + 0);
          this.selectedModules = this.removeDuplicates(this.selectedModules);
          this.mainmoduleslist[i].moduleselected = true;
        }
      }
    }
  }

  checkBoxChange3(val1, val2, status) {
    this.selectedsubmenu.push(val1 + "_" + val2);
    for (var i = 0; i <= this.selectedsubmenu.length; i++) {
      if (status == false) {
        var unchkitem = val1 + "_" + val2;
        var position = this.selectedsubmenu.indexOf(unchkitem);
        if (~position) { this.selectedsubmenu.splice(position, 1); }

        for (var s = 0; s < this.submenumodulesdata.length; s++) {
          if (val1 == this.submenumodulesdata[s].id) {
            this.submenumodulesdata[s].smmodselected = false;
          }
        }
      }
    }
    if (this.selectedsubmenu.length != 0) {
      for (var i = 0; i < this.submenumainmoddata.length; i++) {
        if (parseInt(this.submenumainmoddata[i].id) == parseInt(val2)) {
          this.selectedsubmenumainmod.push(val2 + "_" + 0);
          this.selectedsubmenumainmod = this.removeDuplicates(this.selectedsubmenumainmod);
          this.submenumainmoddata[i].smmainmod = true;
        }
      }
    }
  }

  checkBoxChange4(val1, val2, status) {
    this.selectedsubmenumainmod.push(val1 + "_" + val2);
    for (var i = 0; i <= this.selectedsubmenumainmod.length; i++) {
      if (status == false) {
        var unchkitem = val1 + "_" + val2;
        var position = this.selectedsubmenumainmod.indexOf(unchkitem);
        if (~position) { this.selectedsubmenumainmod.splice(position, 1); }

        for (var s = 0; s < this.submenumainmoddata.length; s++) {
          if (val1 == this.submenumainmoddata[s].id) {
            this.submenumainmoddata[s].smmainmod = false;
          }
        }
      }
    }
    let arr1 = [];
    for (var k = 0; k <= this.selectedsubmenumainmod.length; k++) {
      if (arr1.indexOf(this.selectedsubmenumainmod[k]) == -1) {
        arr1.push(this.selectedsubmenumainmod[k]);
      }
    }
    if (arr1[0] == undefined && arr1.length == 1) {
      arr1 = []; this.selectedsubmenumainmod = [];
    }
    this.selectedsubmenumainmod = arr1;
  }

  removeDuplicates(arr) {
    let unique_array = []
    for (let i = 0; i < arr.length; i++) {
      if (unique_array.indexOf(arr[i]) == -1) {
        unique_array.push(arr[i])
      }
    }
    return unique_array;
  }

  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',

    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 5000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }

  saveData() {
    if (!this.rolesForm.valid) {
    }
    this.submitAttempt = true;
    if (this.rolesForm.valid) {
      var select_mod = ""; var selectsubmenumod = "";
      if (this.action == 'A' || this.action == 'U') {
        select_mod = (this.selectedModules + "," + this.selectedsubModules).toString();
        if (select_mod.charAt(0) == ",") {
          select_mod = select_mod.substr(1);
        }
        if (select_mod.includes(',,')) {
          select_mod = select_mod.replace(",,", ",");
        }

        selectsubmenumod = (this.selectedsubmenumainmod + "," + this.selectedsubmenu).toString();
        if (selectsubmenumod.charAt(0) == ",") {
          selectsubmenumod = selectsubmenumod.substr(1);
        }
        if (selectsubmenumod.includes(',,')) {
          selectsubmenumod = selectsubmenumod.replace(",,", ",");
        }

        var lstatus = (this.rolestatus == true) ? 'Y' : 'N';
        if(this.selectedModules.length != 0 && this.selectedsubModules.length != 0 && this.selectedsubmenumainmod.length != 0 && this.selectedsubmenu.length != 0)
        {
          var rolemodelinfo = {
            rolemodel: {
              'action': this.action,
              'id': this.roleid, 'name': this.txtname, 'code': this.txtcode,
              'updtaedid': this.userloginid, 'status': lstatus,
              'Previliges': select_mod, 'SideMenuPreviliges': selectsubmenumod
            }
          }
  
          this.spinnerService.show();
          this.api.postOH('saveroles', rolemodelinfo).subscribe(
            (data) => {
              if (this.action == 'A' || this.action == 'U') {
                if (data[1] != 'Role Already Exist or Unable to process your request ') {
                  let parameters = {
                    searchvalue: " WHERE R_STATUS = 'Y'"
                  };
                  this.GetRoleData(parameters);
                  this.gridShow = "block";
                  this.selectedoption = "Active";
                  this.randomcolor = "#5cb85c";
                  this.contentShow = "none";
                  this.viewcontentShow = "none";
                  this.submitAttempt = false;
                  this.selectedsubModules = [];
                  this.selectedModules = [];
                  this.clear();
                  let msg = (this.action == "A") ? '<span style="color: green">Role added Successfully .</span>' : '<span style="color: green">Role updated Successfully .</span>';
                  this.toastMessage(msg);
                  //this.displayMsg = data[1];
                }
                else {
                  //this.displayMsg = data[1];
                  let msg = "<span style='color: red'>" + data[1] + "</span>";
                  this.toastMessage(msg);
                }
                this.spinnerService.hide();
                window.scrollTo(0, 0);
              }
              this.spinnerService.hide();
            })
        }
      }
    }
  }



  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }

  confirm(): void {
    this.modalRef.hide();
    this.rolestatus = 'D';
    this.action = 'D';
    var rolemodelinfo = {
      rolemodel: {
        'action': this.action,
        'id': parseInt(this.roleid), 'name': this.txtname, 'code': this.txtcode,
        'updtaedid': parseInt(this.userloginid), 'status': this.rolestatus,
        'Previliges': ''
      }
    }
    let msg = '<span style="color: green">Role deleted Successfully</span>';
    this.DEapicall(rolemodelinfo, msg);
  }

  enableRole(id): void {
    this.rolestatus = 'Y';
    this.action = 'E';
    var rolemodelinfo = {
      rolemodel: {
        'action': this.action,
        'id': parseInt(id), 'name': '', 'code': '',
        'updtaedid': parseInt(this.userloginid), 'status': this.rolestatus,
        'Previliges': ''
      }
    }
    let msg = '<span style="color: green">Role enabled Successfully</span>';
    this.DEapicall(rolemodelinfo, msg);
  }

  DEapicall(rolemodelinfo, msg) {
    //console.log(rolemodelinfo);
    this.api.postOH('saveroles', rolemodelinfo).subscribe(
      (response) => {
        let parameters = {
          searchvalue: " WHERE R_STATUS = 'Y'"
        };
        this.GetRoleData(parameters);
        this.selectedoption = "Active";
        this.randomcolor = "#5cb85c";
        this.gridShow = "block";
        this.contentShow = "none";
        this.viewcontentShow = "none";
        this.toastMessage(msg);
      }, error => {
        console.log(error);
      });
  }

  decline(): void {
    this.modalRef.hide();
  }


}
