import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
//import { ModalService } from 'ng-bootstrap-modal';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Title } from '@angular/platform-browser';

var select_mod = ""; var mod = ""; var mainmod = ""; 
var selectsubmenumod = "";

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})

export class UsersComponent implements OnInit {
  modalRef: BsModalRef;
  public usersForm: FormGroup; submitAttempt: boolean = false; divheader: string = "Add Employee";
  searchtxt: boolean = true; searchddl: boolean = false;
  contentShow: string = "none"; gridShow: string = "none";
  viewcontentShow: string = "none"; buttonShow: string = "none";
  usersdata: any; userroles: any; mainmoduleslist: any; submoduleslist: any;
  txtShow: string = "none"; lblShow: string = "none"; action: string = 'A';
  ddlsearchuserrole:any;ddluserrolediv:boolean=false;searchtextdiv:boolean=true;
  
  txtfname: any; txtlname: any; ddluserroles: any = "0"; txtuname: any; txtemail: any; txtpswd: any; txtprofile: any; profileimage: any = ''; profileimagepath: any = ''; profilebinaryimage: any = '';
  imagecropped:any;
  txtsrch: string = '';
  userid: any;
  GridMessage: string = 'Loading, Please wait ... !';
  fullname: string;
  userstatus: any; userchkstatus: boolean = true;
  stat: any; rolename: any;
  profileimagename: string; path = ''; selectedModules = []; selectedsubModules = []; modules = [];
  userloginid: any; srchError: string = '0';

  submenumodulesdata: any; submenumainmoddata: any; selectedsubmenu: any; selectedsubmenumainmod: any;
  
  userrole:any;

  userroleselected: boolean = false;

  key: string = 'name';
  reverse: boolean = false; ddlsearch: any;
  selectedoption:any="Active";randomcolor:any="#5cb85c";

  usertxtstatus: string = 'Active';
  public file_srcs: string[] = [];
  public debug_size_before: string[] = [];
  public debug_size_after: string[] = [];
  nameasc: any = "sortgreen"; namedesc: any = "sortwhite"; roleasc: any = "sortwhite"; roledesc: any = "sortwhite"; emailasc: any = "sortwhite"; emaildesc: any = "sortwhite";usernameasc: any = "sortwhite"; usernamedesc: any = "sortwhite";

  isDisabled: any = false;
  
  editUserInfo: any;

  constructor(private title: Title,private modalService: BsModalService, public toastr: ToastsManager, vcr: ViewContainerRef, private _router: Router, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService,
    private authService: AuthService) {
    
    this.title.setTitle("IZON - Employees");
    this.ddlsearch = "U_FIRST_NAME";
    this.toastr.setRootViewContainerRef(vcr);
    this.contentShow = "none"; this.gridShow = "none";
    this.userroles = []; this.usersdata = []; 
    this.selectedsubModules = []; this.selectedModules = []; this.submenumodulesdata = []; this.submenumainmoddata = []; this.selectedsubmenu = []; this.selectedsubmenumainmod = [];

    this.userloginid = localStorage.getItem('userId');
    this.txtuname='';this.ddlsearchuserrole="0";

    this.ddluserrolediv=false;
    this.searchtextdiv=true;
  }

  ngOnInit() {
    this.usersForm = this.formBuilder.group({
      txtfname: ['', Validators.compose([Validators.required])],
      txtlname: ['', Validators.compose([Validators.required])],
      froles: ['0', Validators.compose([Validators.required])],
      txtuname: ['', Validators.compose([Validators.required])],
      txtemail: [''],
      txtpswd: ['', Validators.compose([Validators.required])],
      fmodules: [this.selectedsubModules.length == 0, Validators.compose([Validators.required])],
      fsubmenu: [this.selectedsubmenu.length == 0, Validators.compose([Validators.required])],
      fcstatus: ['']
    });
    this.getRoles();
    this.bindModules();
    this.GetSubMenuModulesData();
    let parameters = {
      searchvalue: " WHERE U_STATUS = 'Y'"
    };
    this.GetUsersData(parameters);

    this.gridShow = "block";
    this.contentShow = "none";
  }

  GetSubMenuModulesData() {
    let parameters = {
      searchvalue: " WHERE SM_STATUS = 'Y'"
    };
    this.api.postOH('getsidemenumodules', parameters).subscribe(
        (response) => {
          this.submenumodulesdata = response;
          this.submenumainmoddata = response;
        }
    );
  }

  refreshpage() {
    this.selectedoption="Active";
    this.randomcolor="#5cb85c";
    let parameters = {
      searchvalue: " WHERE U_STATUS = 'Y'"
    };
    this.GetUsersData(parameters);
    this.txtsrch = "";
    this.ddlsearch = "U_FIRST_NAME";
    this.ddlsearchuserrole="0";
    this.srchError="0";
    this.ddluserrolediv=false;
    this.searchtextdiv=true;
  }
  sort(value: string) {
    this.key = value;
    this.nameasc = "sortwhite"; this.namedesc = "sortwhite"; this.usernameasc="sortwhite"; this.usernamedesc="sortwhite"; this.roleasc = "sortwhite"; this.roledesc = "sortwhite"; this.emailasc = "sortwhite"; this.emaildesc = "sortwhite";
    if (this.key == value) {
      this.reverse = !this.reverse;
      if (this.key == "name" && this.reverse) {
        this.namedesc = "sortgreen";
      }
      else if (this.key == "name" && (!this.reverse)) {
        this.nameasc = "sortgreen";
      }
      else if (this.key == "username" && this.reverse) {
        this.usernamedesc = "sortgreen";
      }
      else if (this.key == "username" && (!this.reverse)) {
        this.usernameasc = "sortgreen";
      }
      else if (this.key == "email" && this.reverse) {
        this.emaildesc = "sortgreen";
      }
      else if (this.key == "email" && (!this.reverse)) {
        this.emailasc = "sortgreen";
      }
      else if (this.key == "role" && this.reverse) {
        this.roledesc = "sortgreen";
      }
      else if (this.key == "role" && (!this.reverse)) {
        this.roleasc = "sortgreen";
      }
    }
  }

  ddlsearchchange(){
    this.srchError = '0';this.txtsrch='';this.ddlsearchuserrole="0";
    this.ddluserrolediv=false;this.searchtextdiv=false;
    if(this.ddlsearch=="U_FIRST_NAME" || this.ddlsearch=="U_EMAIL_ID" || this.ddlsearch=="U_USER_ID"){
      this.ddluserrolediv=false;
      this.searchtextdiv=true;
    }else if(this.ddlsearch=="R_NAME"){
      this.ddluserrolediv=true;
      this.searchtextdiv=false;
      this.ddlsearchuserrolechange();
    }
  }

  search() {
    if (this.txtsrch == '') {
      this.srchError = '1';
    }
    else if (this.txtsrch != "") {
      this.srchError = '0';
      var status;
      if(this.selectedoption == "Active")
      {
        status = 'Y';
      }
      else if(this.selectedoption == "In-Active")
      {
        status = 'N';
      }
      if (this.ddlsearch == "U_FIRST_NAME") {
        let parameters = {
          searchvalue: " WHERE U_FIRST_NAME + ' ' + U_LAST_NAME LIKE '%" + this.txtsrch + "%' and U_STATUS<>'D' AND U_STATUS = '" + status + "' "
        };
        this.GetUsersData(parameters);
        this.txtsrch = "";
      }
      else {
        let parameters = {
          searchvalue: " WHERE " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' and U_STATUS<>'D' AND U_STATUS = '" + status + "'"
        };
        this.GetUsersData(parameters);
        this.txtsrch = "";
      }
    }
  }

  ddlsearchuserrolechange(){
    let parameters={};
    var status;
      if(this.selectedoption == "Active")
      {
        status = 'Y';
      }
      else if(this.selectedoption == "In-Active")
      {
        status = 'N';
      }
    if(this.ddlsearchuserrole=="0"){
      parameters = {
        searchvalue: " WHERE U_STATUS<>'D' AND U_STATUS = '" + status + "' "
      };
    }else{
      parameters = {
        searchvalue: " WHERE U_TYPE=" + this.ddlsearchuserrole + " AND U_STATUS<>'D' AND U_STATUS = '" + status + "'  "
      };
    }    
    this.GetUsersData(parameters);
  }
  
  srchKeyUp(event: any) {
    if (this.txtsrch != '') {
        this.srchError = '0';
    }
  }

  srchSts(type) {
    this.srchError = '0';this.txtsrch='';this.ddlsearchuserrole="0";this.ddlsearch="U_FIRST_NAME";
    this.ddluserrolediv=false;this.searchtextdiv=true;

    let parameters = {
      searchvalue: " WHERE U_STATUS= '" + type + "' "
    };
    this.GetUsersData(parameters);
  }

  addUser() {
    window.scrollTo(0,0);
    this.profileimage = "";
    this.profileimagepath = "";
    this.profilebinaryimage = "";
    this.profileimagename = "";
    this.clear();
    this.bindModules();
    this.GetSubMenuModulesData();
    this.isDisabled = false;
    this.usersForm.controls['txtlname'].reset();
    this.usersForm.controls['txtfname'].reset();
    this.usersForm.controls['txtuname'].reset();
    this.usersForm.controls['txtemail'].reset();
    this.usersForm.controls['txtpswd'].reset();
    this.divheader = "Add Employee";
    this.action = 'A';
    this.gridShow = "none";
    this.contentShow = "block";
    this.viewcontentShow = "none";
    this.txtShow = "block"; this.lblShow = "none";
    this.txtfname = ''; this.txtlname = ''; this.txtuname = ''; this.txtemail = ''; this.txtpswd = ''; this.ddluserroles = '0';
    this.userid = "0";
    this.userstatus = 'Y';
    this.ddluserroles = "0";
    this.selectedsubModules = [];
    this.selectedModules = [];
    this.selectedsubmenu = [];
    this.submitAttempt = false;
  }

  getRoles() {
    let parameters = {
      searchvalue: " WHERE R_STATUS = 'Y'"
    };
    this.api.postOH('getuserroles', parameters).subscribe(
      (response) => {
        this.userroles = [];
        for (let i = 0; i < response.length; i++) {
          this.userroles.push({
            value: response[i].id,
            name: response[i].name
          });
        }
      })
  }

  bindModules() {
    let parameters = {
      searchvalue: " WHERE MOD_STATUS = 'Y'"
    };
    this.api.postOH('getmodules', parameters).subscribe(
      (response) => {
        this.mainmoduleslist = response;
        this.submoduleslist = response;
        //console.log(this.submoduleslist);
      })
  }

  clear() {
    for (var k = 0; k < this.mainmoduleslist.length; k++) {
      this.mainmoduleslist[k].moduleselected = false;
    }

    for (var s = 0; s < this.submoduleslist.length; s++) {
      this.submoduleslist[s].submodselected = false;
    }

    for(var j=0; j < this.submenumodulesdata.length; j++)
    {
      this.submenumodulesdata[j].smmodselected = false;
    }

    for(var i=0; i < this.submenumainmoddata.length; i++)
    {
      this.submenumainmoddata[i].smmainmod = false;
    }
  }

  bindAssignedModules(userrole) {
    if (userrole != "0") {
      this.userroleselected = true;
      this.selectedModules = []; this.selectedsubModules = []; this.selectedsubmenumainmod = []; this.selectedsubmenu = [];
      this.clear();
      let parameters = {
        searchvalue: " WHERE P_STATUS = 'Y' AND P_R_ID = " + this.ddluserroles
      };
      this.api.postOH('getrolesmodules', parameters).subscribe(
        (response) => {
          //console.log(response);
          for (var i = 0; i < response.length; i++) {
            var moduleid = response[i].mod_id;
            var submoduleid = response[i].sub_mod_id;
            for (var j = 0; j < this.mainmoduleslist.length; j++) {
              if (this.mainmoduleslist[j].id == moduleid && this.mainmoduleslist[j].subid == 0) {
                this.mainmoduleslist[j].moduleselected = true;
                if (this.action == 'U' || this.action == 'A') {
                  this.checkBoxChange1(this.mainmoduleslist[j].id, this.mainmoduleslist[j].subid, this.mainmoduleslist[j].moduleselected);
                }
              }
            }
            for (var j = 0; j < this.submoduleslist.length; j++) {
              if (this.submoduleslist[j].id == submoduleid && this.submoduleslist[j].subid == moduleid) {
                this.submoduleslist[j].submodselected = true;
                if (this.action == 'U' || this.action == 'A') {
                  this.checkBoxChange2(this.submoduleslist[j].id, this.submoduleslist[j].subid, this.submoduleslist[j].submodselected);
                }
              }
            }
          }
        })

      let parameters1 = {
        searchvalue: " WHERE RSP_STATUS = 'Y' AND RSP_UR_ID = " + this.ddluserroles
      };
      this.api.postOH('getrolesidemenupreviliges', parameters1).subscribe(
        (response) => {
          //console.log(response);
          for (var i = 0; i < response.length; i++) {
            var sidemenumoduleid = response[i].RSP_SM_MAIN_ID;
            var sidemenusubmoduleid = response[i].RSP_SM_ID;
            for (var j = 0; j < this.submenumainmoddata.length; j++) {
              if (this.submenumainmoddata[j].id == sidemenumoduleid && this.submenumainmoddata[j].moduleid == 0) {
                this.submenumainmoddata[j].smmainmod = true;
                if (this.action == 'U' || this.action == 'A') {
                  this.checkBoxChange4(this.submenumainmoddata[j].id, this.submenumainmoddata[j].moduleid, this.submenumainmoddata[j].smmainmod);
                }
              }

            }
            for (var j = 0; j < this.submenumodulesdata.length; j++) {
              if (this.submenumodulesdata[j].id == sidemenusubmoduleid && this.submenumodulesdata[j].moduleid == sidemenumoduleid) {
                this.submenumodulesdata[j].smmodselected = true;
                if (this.action == 'U' || this.action == 'A') {
                  this.checkBoxChange3(this.submenumodulesdata[j].id, this.submenumodulesdata[j].moduleid, this.submenumodulesdata[j].smmodselected);
                }
              }
            }
          }
        })
    }
  }

  usermodules(userid) {
    let me=this;
    let modules = this.mainmoduleslist;
    let submodules = this.submoduleslist;    
    let parameters = { searchvalue: " WHERE UP_STATUS = 'Y' AND UP_UL_ID = " + userid };
    this.api.postOH('getusermodules', parameters).subscribe(function (response) {
      for (var i = 0; i < response.length; i++) {
        var moduleid = response[i].up_m_id;
        var submoduleid = response[i].up_sm_id;
        this.mainmoduleslist = modules;
        this.submoduleslist = submodules;
        for (var k = 0; k < this.mainmoduleslist.length; k++) {
          if (this.mainmoduleslist[k].id == moduleid && this.mainmoduleslist[k].subid == 0) {
            this.mainmoduleslist[k].moduleselected = true;
          }
        }
        for (var k = 0; k < this.submoduleslist.length; k++) {
          if (this.submoduleslist[k].id == submoduleid && this.submoduleslist[k].subid == moduleid) {
            this.submoduleslist[k].submodselected = true;
          }
        }
      }
      me.usersubmenumodules(userid);
    });
  }

  usersubmenumodules(userid) {
    let submenu = this.submenumodulesdata;
    let submenumainmodules = this.submenumainmoddata;
    let me=this;
    let parameters = { searchvalue: " WHERE USP_STATUS = 'Y' AND USP_UL_ID = " + userid };
    this.api.postOH('getsidemenuuserpreviliges', parameters).subscribe(function (response) {
      for (var i = 0; i < response.length; i++) {
        var submenmodid = response[i].usp_sm_id;
        var submenumainmodid = response[i].usp_sm_main_id;
        this.submenumodulesdata = submenu;
        this.submenumainmoddata = submenumainmodules;
        for (var k = 0; k < this.submenumodulesdata.length; k++) {
          if (this.submenumodulesdata[k].id == submenmodid && this.submenumainmoddata[k].moduleid == submenumainmodid) {
            this.submenumodulesdata[k].smmodselected = true;
          }
        }
        for (var k = 0; k < this.submenumainmoddata.length; k++) {
          if (this.submenumainmoddata[k].id == submenumainmodid && this.submenumainmoddata[k].moduleid == 0) {
            this.submenumainmoddata[k].smmainmod = true;
          }
        }        
      }
      select_mod = ""; mod = ""; mainmod = ""; 
      selectsubmenumod = "";
      if (me.action == 'U') {
        for (var s = 0; s < me.mainmoduleslist.length; s++) { 
          
          if (me.mainmoduleslist[s].moduleselected == true) {
            me.selectedModules.push(me.mainmoduleslist[s].id + "_" + me.mainmoduleslist[s].subid);
            //mainmod += this.mainmoduleslist[s].id + "_" + this.mainmoduleslist[s].subid + ",";
          }
        }
        for (var s = 0; s < me.submoduleslist.length; s++) {
          if (me.submoduleslist[s].submodselected == true) {
            me.selectedsubModules.push(me.submoduleslist[s].id + "_" + me.submoduleslist[s].subid);
            //mod += this.submoduleslist[s].id + "_" + this.submoduleslist[s].subid + ",";
          }
        }
        for(var s=0; s< me.submenumodulesdata.length; s++)
        {
          if(me.submenumodulesdata[s].smmodselected == true)
          {
            me.selectedsubmenu.push(me.submenumodulesdata[s].id + "_" + me.submenumodulesdata[s].moduleid);
          }
        }
        for(var s=0; s< me.submenumodulesdata.length; s++)
        {
          if(me.submenumainmoddata[s].smmainmod == true)
          {
            me.selectedsubmenumainmod.push(me.submenumainmoddata[s].id + "_" + me.submenumainmoddata[s].moduleid);
          }
        }
        //mod = mod + this.selectedsubModules;
        //mainmod = mainmod + this.selectedModules;
        me.selectedsubModules = me.removeDuplicates(me.selectedsubModules);
        me.selectedModules = me.removeDuplicates(me.selectedModules);
        mod = me.selectedsubModules.toString();
        mainmod = me.selectedModules.toString();
        select_mod = mainmod + "," + mod;
        if (select_mod.includes(",,")) {
          select_mod = select_mod.replace(",,", ",");
        }
        me.selectedsubmenu = me.removeDuplicates(me.selectedsubmenu);
        me.selectedsubmenumainmod = me.removeDuplicates(me.selectedsubmenumainmod);
        selectsubmenumod = me.selectedsubmenumainmod.toString() + "," + me.selectedsubmenu.toString();
        if (selectsubmenumod.includes(",,")) {
          selectsubmenumod = selectsubmenumod.replace(",,", ",");
        }
      }      
    });
  }

  cancel() {
    window.scrollTo(0,0);
    if (this.action == 'A') {
      //this.usersForm.reset();
      this.clear();
      this.gridShow = "block";
      this.contentShow = "none";
      this.viewcontentShow = "none";
    }
    else {
      this.gridShow = "none";
      this.contentShow = "none";
      this.viewcontentShow = "block";
      //this.bindModules();
      //this.GetSubMenuModulesData();
	  this.viewuser(this.editUserInfo);
      this.clear();
    }

  }

  checkBoxChange(status) {
    this.stat = status;
    if (this.stat == true) {
      this.userstatus = 'Y';
      this.usertxtstatus = 'Active';
    }
    else {
      this.userstatus = 'N';
      this.usertxtstatus = 'In-Active';
    }
  }

  GetUsersData(parameters) {
    this.spinnerService.show();
    this.api.postOH('getusers', parameters).subscribe(
      (response) => {
        this.usersdata = [];
        for (let i = 0; i < response.length; i++) {
          var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
          var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
          var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
          var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var confirmshow = "row-icon-inactive";

          this.usersdata.push({
            "id": response[i].id,
            "name": response[i].name,
            "fname": response[i].fname,
            "lname": response[i].lname,
            "roleid": response[i].roleid,
            "role": response[i].rolename,
            "email": response[i].emailid,
            "username": response[i].userid,
            "password": response[i].password,
            "image": response[i].image,
            "imagepath": response[i].imagepath,
            "binaryimage": response[i].binaryimage,
            "createdby": response[i].updatedby,
            "createddate": response[i].createddate,
            "status": status,
            "statusclass": statusclass,
            "editshow": editshow,
            "enableshow": enableshow,
            "removeshow": removeshow,
            "confirmshow": confirmshow
          });
        }
        {
          this.GridMessage = "No Data Found";
        }
        this.spinnerService.hide();

      }, error => {
        this.spinnerService.hide();
      }
    );
  }

  viewuser(userdata) {
	this.editUserInfo = userdata;  
    window.scrollTo(0,0);
    this.action = 'V';
    this.viewcontentShow = "block";
    this.gridShow = "none";
    this.userid = userdata.id;
    this.fullname = (!userdata.name) ? "" : userdata.name;
    this.txtfname = (!userdata.fname) ? "" : userdata.fname;
    this.txtlname = (!userdata.lname) ? "" : userdata.lname;
    this.ddluserroles = (!userdata.roleid) ? "0" : userdata.roleid;
    this.rolename = (!userdata.role) ? "" : userdata.role;
    this.txtuname = (!userdata.username) ? "" : userdata.username;
    this.txtemail = (!userdata.email) ? "" : userdata.email;
    this.txtemail = (!userdata.email) ? "" : userdata.email;
    this.profileimagename = (!userdata.image) ? "" : userdata.image;
    this.profileimagepath = (!userdata.imagepath) ? "" : userdata.imagepath;
    if (userdata.status == 'Active') {
      this.userstatus = 'Y';
    }
    else if (userdata.status == 'In-Active') {
      this.userstatus = 'N';
    }
    this.userchkstatus = (this.userstatus == 'Y') ? true : false;
    this.usertxtstatus = (this.userstatus == 'Y') ? 'Active' : 'In-Active';
    if (userdata.status == 'Deleted') {
      this.userstatus = 'D';
      this.usertxtstatus = 'Deleted';
    }
  }

  goBack() {
    //this.usersForm.reset();
    this.gridShow = "block";
    this.contentShow = "none";
    this.viewcontentShow = "none";
  }

  editUser() {
    //this.bindModules();  
    //this.GetSubMenuModulesData();  
    window.scrollTo(0,0);
    this.clear();
    this.submitAttempt = false;
    this.imagecropped="";
    this.selectedsubmenumainmod = [];
    this.selectedsubmenu = [];
    this.selectedsubModules = [];
    this.selectedModules = [];
    this.divheader = "Edit Employee";
    this.action = 'U';
    this.gridShow = "none";
    this.contentShow = "block"; this.viewcontentShow = "none";
    this.txtShow = "block"; this.lblShow = "none";
    let parameters = {
      searchvalue: ' WHERE U_ID=' + this.userid + ''
    };
    this.spinnerService.show();
    let userdata = [];
    this.api.postOH('getusers', parameters).subscribe(
      (response) => {
        for (let i = 0; i < response.length; i++) {
          var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
          var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
          var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
          var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var confirmshow = "row-icon-inactive";

          userdata.push({
            "id": response[i].id,
            "name": response[i].name,
            "fname": response[i].fname,
            "lname": response[i].lname,
            "roleid": response[i].roleid,
            "role": response[i].rolename,
            "email": response[i].emailid,
            "username": response[i].userid,
            "password": response[i].password,
            "image": response[i].image,
            "imagepath": response[i].imagepath,
            "binaryimage": response[i].binaryimage,
            "createdby": response[i].updatedby,
            "createddate": response[i].createddate,
            "status": status,
            "statusclass": statusclass,
            "editshow": editshow,
            "enableshow": enableshow,
            "removeshow": removeshow,
            "confirmshow": confirmshow
          });
        }
        this.fullname = (!userdata[0].name) ? "" : userdata[0].name;
        this.txtfname = (!userdata[0].fname) ? "" : userdata[0].fname;
        this.txtlname = (!userdata[0].lname) ? "" : userdata[0].lname;
        this.ddluserroles = (!userdata[0].roleid) ? "0" : userdata[0].roleid;
        this.rolename = (!userdata[0].role) ? "" : userdata[0].role;
        this.txtuname = (!userdata[0].username) ? "" : userdata[0].username;
        this.txtemail = (!userdata[0].email) ? "" : userdata[0].email;
        this.txtpswd = (!userdata[0].password) ? "" : userdata[0].password;
        this.profileimagename = (!userdata[0].image) ? "" : userdata[0].image;
        this.profileimagepath = (!userdata[0].imagepath) ? "" : userdata[0].imagepath;
        this.usermodules(this.userid);
        //this.usersubmenumodules(this.userid);
        this.spinnerService.hide();
      },
    ); error => {
      this.spinnerService.hide();
    }

  }

  fileChange(input, fimg) {
    this.readFiles(input.files, fimg);
  }
  readFile(file, fimg, reader, callback) {
    reader.onload = () => {
      callback(reader.result);
      if (fimg == 'profimg') {
        this.profileimagepath = reader.result;
        this.imagecropped = (reader.result != "") ? reader.result.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
        this.profileimagename = file.name;
      }
    }
    reader.readAsDataURL(file);
  }
  readFiles(files, fimg, index = 0) {
    // Create the file reader  
    let reader = new FileReader();
    // If there is a file  
    if (index in files) {
      // Start reading this file  
      this.readFile(files[index], fimg, reader, (result) => {
        // Create an img element and add the image file data to it  
        var img = document.createElement("img");
        img.src = result;
        // Send this img to the resize function (and wait for callback)  
        //this.resize(img, 250, 250, (resized_jpeg, before, after) => {
        //    // For debugging (size in bytes before and after)  
        //    this.debug_size_before.push(before);
        //    this.debug_size_after.push(after);
        //    // Add the resized jpeg img source to a list for preview  
        //    // This is also the file you want to upload. (either as a  
        //    // base64 string or img.src = resized_jpeg if you prefer a file).  
        //    this.file_srcs.push(resized_jpeg);
        //    // Read the next file;  
        //    this.readFiles(files, index + 1);
        //});
      });
    } else {
      // When all files are done This forces a change detection  
      // this.changeDetectorRef.detectChanges();
    }
  }
  resize(img, MAX_WIDTH: number, MAX_HEIGHT: number, callback) {
    // This will wait until the img is loaded before calling this function  
    return img.onload = () => {
      // Get the images current width and height  
      var width = img.width;
      var height = img.height;
      // Set the WxH to fit the Max values (but maintain proportions)  
      if (width > height) {
        if (width > MAX_WIDTH) {
          height *= MAX_WIDTH / width;
          width = MAX_WIDTH;
        }
      } else {
        if (height > MAX_HEIGHT) {
          width *= MAX_HEIGHT / height;
          height = MAX_HEIGHT;
        }
      }
      // create a canvas object  
      var canvas = document.createElement("canvas");
      // Set the canvas to the new calculated dimensions  
      canvas.width = width;
      canvas.height = height;
      var ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, width, height);
      // Get this encoded as a jpeg  
      // IMPORTANT: 'jpeg' NOT 'jpg'  
      var dataUrl = canvas.toDataURL('image/jpeg');
      // callback with the results  
      callback(dataUrl, img.src.length, dataUrl.length);
    };
  }

  mainmoduleclicked(val1, val2, event)
  {
    if(this.ddluserroles == "0")
    {
      event.target.checked = false;
      let msg = "<span style='color:red'>Select User Role to check Main Module</span>";
      this.toastMessage(msg);
    }
    if(this.ddluserroles != "0")
    {
      this.checkBoxChange1(val1, val2, event.target.checked);
    }
  }

  submoduleclicked(val1, val2, event)
  {
    if(this.ddluserroles == "0")
    {
      event.target.checked = false;
      let msg = "<span style='color:red'>Select User Role to check Sub Module</span>";
      this.toastMessage(msg);
    }
    if(this.ddluserroles != "0")
    {
      this.checkBoxChange2(val1, val2, event.target.checked);
    }
  }

  sidemenumainmoduleclicked(val1, val2, event)
  {
    if(this.ddluserroles == "0")
    {
      event.target.checked = false;
      let msg = "<span style='color:red'>Select User Role to check Side Menu Main Module</span>";
      this.toastMessage(msg);
    }
    if(this.ddluserroles != "0")
    {
      this.checkBoxChange4(val1, val2, event.target.checked);
    }
  }

  sidemenusubmoduleclicked(val1, val2, event)
  {
    if(this.ddluserroles == "0")
    {
      event.target.checked = false;
      let msg = "<span style='color:red'>Select User Role to check Side Menu Sub Module</span>";
      this.toastMessage(msg);
    }
    if(this.ddluserroles != "0")
    {
      this.checkBoxChange3(val1, val2, event.target.checked);
    }
  }

  filter_array(test_array) {
    var index = -1,
        arr_length = test_array ? test_array.length : 0,
        resIndex = -1,
        result = [];

    while (++index < arr_length) {
        var value = test_array[index];

        if (value) {
            result[++resIndex] = value;
        }
    }

    return result;
  }

  checkBoxChange1(val1, val2, status) {
    this.selectedModules = [];
    this.selectedModules.push(val1 + "_" + val2);
    this.selectedModules = this.removeDuplicates(this.selectedModules);
    for (var i = 0; i <= this.selectedModules.length; i++) {
      if (status == false) {
        var unchkitem = val1 + "_" + val2;
        var position = this.selectedModules.indexOf(unchkitem);
        if (~position) 
        {
          this.selectedModules.splice(position, 1);
          this.selectedModules = this.filter_array(this.selectedModules);
        }

        for (var s = 0; s <= this.mainmoduleslist.length; s++) {
          if (val1 == this.mainmoduleslist[s].id) {
            this.mainmoduleslist[s].moduleselected = false;
          }
        }
      }
    }
    let arr = [];
    for (var k = 0; k <= this.selectedModules.length; k++) {
      if (arr.indexOf(this.selectedModules[k]) == -1) {
        arr.push(this.selectedModules[k]);
      }
    }
    this.selectedModules = arr;
  }

  checkBoxChange2(val1, val2, status) {
    //this.selectedsubModules = [];
    this.selectedsubModules.push(val1 + "_" + val2);
    for (var i = 0; i <= this.selectedsubModules.length; i++) {
      if (status == false) {
        var unchkitem = val1 + "_" + val2;
        var position = this.selectedsubModules.indexOf(unchkitem);
        if (~position) { this.selectedsubModules.splice(position, 1); }


        for (var s = 0; s < this.submoduleslist.length; s++) {
          if (val1 == this.submoduleslist[s].id) {
            this.submoduleslist[s].submodselected = false;
          }
        }
      }
    }
    if(this.selectedsubModules.length != 0)
    {
      for (var i = 0; i < this.mainmoduleslist.length; i++) {
        if(parseInt(this.mainmoduleslist[i].id) == parseInt(val2))
        {
          this.selectedModules.push(val2 + "_" + 0);
          this.selectedModules = this.removeDuplicates(this.selectedModules);
          this.mainmoduleslist[i].moduleselected = true;
        }
      }
    }
  }

  checkBoxChange3(val1, val2, status) {
    //this.selectedsubmenu = [];
    this.selectedsubmenu.push(val1 + "_" + val2);
    this.selectedsubmenu = this.removeDuplicates(this.selectedsubmenu);
    for (var i = 0; i <= this.selectedsubmenu.length; i++) {
      if (status == false) {
        var unchkitem = val1 + "_" + val2;
        var position = this.selectedsubmenu.indexOf(unchkitem);
        if (~position) { this.selectedsubmenu.splice(position, 1); }

        for (var s = 0; s < this.submenumodulesdata.length; s++) {
          if (val1 == this.submenumodulesdata[s].id) {
            this.submenumodulesdata[s].smmodselected = false;
          }
        }
      }
    }
    if(this.selectedsubmenu.length != 0)
    {
      for (var i = 0; i < this.submenumainmoddata.length; i++) {
        if(parseInt(this.submenumainmoddata[i].id) == parseInt(val2))
        {
          this.selectedsubmenumainmod.push(val2 + "_" + 0);
          this.selectedsubmenumainmod = this.removeDuplicates(this.selectedsubmenumainmod);
          this.submenumainmoddata[i].smmainmod = true;
        }
      }
    }
  }

  checkBoxChange4(val1, val2, status) {
    //this.selectedsubmenumainmod = [];
    this.selectedsubmenumainmod.push(val1 + "_" + val2);
    this.selectedsubmenumainmod = this.removeDuplicates(this.selectedsubmenumainmod);
    for (var i = 0; i <= this.selectedsubmenumainmod.length; i++) {
      if (status == false) {
        var unchkitem = val1 + "_" + val2;
        var position = this.selectedsubmenumainmod.indexOf(unchkitem);
        if (~position) { 
          this.selectedsubmenumainmod.splice(position, 1); 
          this.selectedsubmenumainmod = this.filter_array(this.selectedsubmenumainmod);
        }
        for (var s = 0; s < this.submenumainmoddata.length; s++) {
          if (val1 == this.submenumainmoddata[s].id) {
            this.submenumainmoddata[s].smmainmod = false;
          }
        }
      }
    }
    let arr1 = [];
    for (var k = 0; k <= this.selectedsubmenumainmod.length; k++) {
      if (arr1.indexOf(this.selectedsubmenumainmod[k]) == -1) {
        arr1.push(this.selectedsubmenumainmod[k]);
      }
    }
    this.selectedsubmenumainmod = arr1;
  }

  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',
    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 5000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right',
    });
  }

  removeDuplicates(arr){
    let unique_array = []
    for(let i = 0;i < arr.length; i++){
        if(unique_array.indexOf(arr[i]) == -1){
            unique_array.push(arr[i])
        }
    }
    return unique_array
  }

  saveData() {
    if (!this.usersForm.valid) {
    }
    this.submitAttempt = true;
    if(this.usersForm.controls.froles.value == "0") { this.usersForm.controls['froles'].setErrors({'incorrect': true});}
    if (this.usersForm.valid) {    
      select_mod = ""; mod = ""; mainmod = ""; 
      selectsubmenumod = "";
      if (this.action == 'U') {
        for (var s = 0; s < this.mainmoduleslist.length; s++) { 
          
          if (this.mainmoduleslist[s].moduleselected == true) {
            this.selectedModules.push(this.mainmoduleslist[s].id + "_" + this.mainmoduleslist[s].subid);
            //mainmod += this.mainmoduleslist[s].id + "_" + this.mainmoduleslist[s].subid + ",";
          }
        }
        for (var s = 0; s < this.submoduleslist.length; s++) {
          if (this.submoduleslist[s].submodselected == true) {
            this.selectedsubModules.push(this.submoduleslist[s].id + "_" + this.submoduleslist[s].subid);
            //mod += this.submoduleslist[s].id + "_" + this.submoduleslist[s].subid + ",";
          }
        }
        for(var s=0; s< this.submenumodulesdata.length; s++)
        {
          if(this.submenumodulesdata[s].smmodselected == true)
          {
            this.selectedsubmenu.push(this.submenumodulesdata[s].id + "_" + this.submenumodulesdata[s].moduleid);
          }
        }
        for(var s=0; s< this.submenumodulesdata.length; s++)
        {
          if(this.submenumainmoddata[s].smmainmod == true)
          {
            this.selectedsubmenumainmod.push(this.submenumainmoddata[s].id + "_" + this.submenumainmoddata[s].moduleid);
          }
        }
        //mod = mod + this.selectedsubModules;
        //mainmod = mainmod + this.selectedModules;
        this.selectedsubModules = this.removeDuplicates(this.selectedsubModules);
        this.selectedModules = this.removeDuplicates(this.selectedModules);
        mod = this.selectedsubModules.toString();
        mainmod = this.selectedModules.toString();
        select_mod = mainmod + "," + mod;
        if (select_mod.includes(",,")) {
          select_mod = select_mod.replace(",,", ",");
        }
        this.selectedsubmenu = this.removeDuplicates(this.selectedsubmenu);
        this.selectedsubmenumainmod = this.removeDuplicates(this.selectedsubmenumainmod);
        selectsubmenumod = this.selectedsubmenumainmod.toString() + "," + this.selectedsubmenu.toString();
        if (selectsubmenumod.includes(",,")) {
          selectsubmenumod = selectsubmenumod.replace(",,", ",");
        }
      }  
      
      if ((this.action == 'A' && this.selectedsubModules.length != 0 && this.selectedsubmenu.length != 0) || 
          (this.action == 'U' && this.selectedsubModules.length != 0 && this.selectedsubmenu.length != 0)) {
        this.isDisabled = true;
        if (this.action == 'A') {
          select_mod = (this.selectedModules + "," + this.selectedsubModules).toString();
          if (select_mod.includes(",,")) {
            select_mod = select_mod.replace(",,", ",");
          }
          selectsubmenumod = (this.selectedsubmenumainmod + "," + this.selectedsubmenu).toString();
          if (selectsubmenumod.includes(",,")) {
            selectsubmenumod = selectsubmenumod.replace(",,", ",");
          }
        }
        var usermodelinfo = {
          'action': this.action,
          'id': this.userid, 'roleid': this.ddluserroles, 'fname': this.txtfname,
          'lname': this.txtlname, 'image': this.profileimagename, 'binaryimage': this.imagecropped,
          'emailid': this.txtemail, 'userid': this.txtuname, 'password': this.txtpswd,
          'facebookid': '', 'googleid': '', 'updtaedid': this.userloginid, 'status': this.userstatus,
          'Previliges': select_mod, 'SideMenuPreviliges': selectsubmenumod
        }
        //console.log(usermodelinfo);
        this.spinnerService.show();
        this.api.postOH('saveusers', usermodelinfo).subscribe(
          (data) => {
            if (this.action == 'A' || this.action == 'U') {
              if (data[1] != 'User Already Exist or Unable to process your request ') {
                this.isDisabled = false;
                let parameters = {
                  searchvalue: " WHERE U_STATUS = 'Y'"
                };
                this.GetUsersData(parameters);
                this.selectedoption="Active";
                this.randomcolor="#5cb85c";
                this.gridShow = "block";
                this.contentShow = "none";
                this.viewcontentShow = "none";
                this.submitAttempt = false;
                this.selectedsubModules = [];
                this.selectedModules = [];
                this.selectedsubmenu = [];
                this.clear();
                this.bindModules();
                this.GetSubMenuModulesData();
                let msg = (this.action == "A") ? '<span style="color: green">User added Successfully.</span>' : '<span style="color: green">User updated Successfully.</span>';
                this.toastMessage(msg);
                //this.displayMsg = data[1];
              }
              else {
                //this.displayMsg = data[1];
                this.isDisabled = false;
                let msg = "<span style='color: red'>" + data[1] + "</span>";
                this.toastMessage(msg);
              }
              this.spinnerService.hide();
            }
            this.spinnerService.hide();
            window.scrollTo(0, 0);
          },error=>{
            this.spinnerService.hide();
        })
      }
    }
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }

  confirm(): void {
    this.modalRef.hide();
    this.userstatus = 'D';
    this.action = 'D';
    var usermodelinfo = {
      'action': this.action,
      'id': parseInt(this.userid), 'roleid': this.ddluserroles, 'fname': this.txtfname,
      'lname': this.txtlname, 'image': '', 'binaryimage': '',
      'emailid': this.txtemail, 'userid': this.txtuname, 'password': '',
      'facebookid': '', 'googleid': '', 'updtaedid': parseInt(this.userloginid), 'status': this.userstatus,
      'Previliges': '', 'SideMenuPreviliges': ''
    }
    let msg = '<span style="color: green">User deleted Successfully</span>';
    this.DEapicall(usermodelinfo, msg);
  }

  enableUser(id): void {
    this.userstatus = 'Y';
    this.action = 'E';
    var usermodelinfo = {
      'action': this.action,
      'id': parseInt(id), 'roleid': this.ddluserroles, 'fname': '',
      'lname': '', 'image': '', 'binaryimage': '',
      'emailid': '', 'userid': '', 'password': '',
      'facebookid': '', 'googleid': '', 'updtaedid': parseInt(this.userloginid), 'status': this.userstatus,
      'Previliges': '', 'SideMenuPreviliges': ''
    }
    let msg = '<span style="color: green">User enabled Successfully</span>';
    this.DEapicall(usermodelinfo, msg);
  }

  DEapicall(usermodelinfo, msg) {
    //console.log(usermodelinfo);
    this.api.postOH('saveusers', usermodelinfo).subscribe(
      (response) => {
        let parameters = {
          searchvalue: " WHERE U_STATUS = 'Y'"
        };
        this.GetUsersData(parameters);
        this.selectedoption="Active";
        this.randomcolor="#5cb85c";
        this.gridShow = "block";
        this.contentShow = "none";
        this.viewcontentShow = "none";
        this.toastMessage(msg);
      }, error => {
        //console.log(error);
      });
  }

  decline(): void {
    this.modalRef.hide();
  }
  bindselectedoption(selectedoption) {
    if (this.selectedoption == 'Active') {
        this.randomcolor = "#5cb85c";
        this.srchSts('Y');
    }
    else if (this.selectedoption == 'In-Active') {
        this.randomcolor = "#337ab7";
        this.srchSts('N');
    }
    else if (this.selectedoption == 'Deleted') {
        this.randomcolor = "#d9534f";
        this.srchSts('D');
    }
  }

  allowalpphanumeric(e){
    if (!(e.which > 47 && e.which < 58) && // numeric (0-9)
        !(e.which > 64 && e.which < 91) && // upper alpha (A-Z)
        !(e.which > 96 && e.which < 123)) { // lower alpha (a-z)
      return false;
    }
  }

}
