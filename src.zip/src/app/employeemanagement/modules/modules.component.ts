import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Title } from '@angular/platform-browser';

@Component({
    selector: 'app-modules',
    templateUrl: './modules.component.html',
    styleUrls: ['./modules.component.css']
})
export class ModulesComponent implements OnInit {
    modalRef: BsModalRef;
    public modulesForm: FormGroup; submitAttempt: boolean = false; divheader: string = "Add Module";
    searchtxt: boolean = true; searchddl: boolean = false;
    modulesdata: any; submodulesdata: any;
    contentShow: string = "none"; gridShow: string = "none";
    viewcontentShow: string = "none"; coursegridShow: string = "none";

    action: string = 'A'; mdid: string = "0"; smdid: string = "0";mainmodid: string = "0"; searchvalue: string = '  WHERE MOD_M_ID=0 ';
    mdname: string; pagename: string; glyphicon: string; sequence: string;
    lblmdname: string; lblpagename: string; lblglyphicon: string; lblsequence: string;
    clubtxtsts: string = 'Active'; txtsrch: string = '';
    GridMessage: string = 'Loading, Please wait ... !';
    srchError: string = '0'; status: boolean = false; chksts: string = 'Y';chkshowonmenu: any=false;
    editModData: any = []; type: string = 'M'; lblname: string = "Module Name";

    cancelmainmodules:any;

    key: string = 'name';
    reverse: boolean = false;ddlsearch:any; 
    nameasc:any="sortgreen"; namedesc:any="sortwhite"; seqasc:any="sortwhite"; seqdesc:any="sortwhite"; 
    selectedoption:any="Active";randomcolor:any="#5cb85c";
    constructor(private title: Title,private modalService: BsModalService, public toastr: ToastsManager, vcr: ViewContainerRef, private _router: Router, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService, private authService: AuthService) {
        this.toastr.setRootViewContainerRef(vcr);
        this.title.setTitle("IZON - Modules");
        this.ddlsearch="MOD_NAME";
        this.contentShow = "none"; this.gridShow = "none";
        this.modulesdata = []; this.submodulesdata = [];
    }

    ngOnInit() {
        this.modulesForm = this.formBuilder.group({
            fmdname: ['', Validators.compose([Validators.required])],
            fpagename: ['', Validators.compose([Validators.required])],
            fglyphicon: [''],
            fsequence: ['', Validators.compose([Validators.required])],
            fchkshowonmenu: [''],
            status:['']
        });
        this.searchvalue = " WHERE MOD_M_ID= 0 AND MOD_STATUS= 'Y'";
        let parameters = { searchvalue: this.searchvalue };
        this.GetModulesData(parameters);

        this.gridShow = "block";
        this.contentShow = "none";
    }

    refreshpage() {
        this.selectedoption="Active";this.randomcolor="#5cb85c";
        this.srchError="0";
        let parameters = { searchvalue: "  WHERE MOD_M_ID=0 AND MOD_STATUS= 'Y' " };
        this.GetModulesData(parameters);
        this.ddlsearch="MOD_NAME";
    }
    srchKeyUp(event: any) {
        if (this.txtsrch != '') {
            this.srchError = '0';
        }
    }
    bindselectedoption(selectedoption) {
        if (this.selectedoption == 'Active') {
            this.randomcolor = "#5cb85c";
            this.srchSts('Y');
        }
        else if (this.selectedoption == 'In-Active') {
            this.randomcolor = "#337ab7";
            this.srchSts('N');
        }
        else if (this.selectedoption == 'Deleted') {
            this.randomcolor = "#d9534f";
            this.srchSts('D');
        }
    }
    search() {
        if (this.txtsrch == '') {
            this.srchError = '1';
        }
        else if (this.txtsrch != '') {
            let parameters = {
                searchvalue: " WHERE MOD_M_ID=0 AND "+this.ddlsearch+" LIKE '%" + this.txtsrch + "%' AND MOD_STATUS<>'D' "
            };
            this.GetModulesData(parameters);
            this.txtsrch = "";
        }
    }
    sort(value : string)
    {
        this.key = value;
        this.nameasc="sortwhite"; this.namedesc="sortwhite"; this.seqasc="sortwhite"; this.seqdesc="sortwhite";
        if(this.key == value)
        {
            this.reverse = !this.reverse;
            if(this.key=="name" && this.reverse){
                this.namedesc="sortgreen";
              }
              else  if(this.key=="name" && (!this.reverse)){
                this.nameasc="sortgreen";
              }
              else if(this.key=="sequence" && this.reverse){
                this.seqdesc="sortgreen";
              }
              else  if(this.key=="sequence" && (!this.reverse)){
                this.seqasc="sortgreen";
              }
        }
    }
    srchSts(type) {
        let parameters = {
            searchvalue: " WHERE MOD_M_ID=0 AND MOD_STATUS='" + type + "'"
        };
        this.GetModulesData(parameters);
    }
    GetModulesData(parameters) {
        this.spinnerService.show();
        this.api.postOH('getmodules', parameters).subscribe(
            (response) => {
                this.modulesdata = [];
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                    var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var confirmshow = "row-icon-inactive";

                    this.modulesdata.push({
                        "id": response[i].id,
                        "subid": response[i].subid,
                        "name": response[i].name,
                        "pagename": response[i].pagename,
                        "glypicon": response[i].glypicon,
                        "sequence": response[i].seq,
                        "createdby": response[i].updatedby,
                        "createddate": response[i].createddate,
                        "status": status,
                        "showonmenu":response[i].showonmenu,
                        "statusclass": statusclass,
                        "editshow": editshow,
                        "enableshow": enableshow,
                        "removeshow": removeshow,
                        "confirmshow": confirmshow
                    });
                }
                {
                    this.GridMessage = "No Data Found";
                }
               this.spinnerService.hide();

            }, error => {
                this.spinnerService.hide();
            }
        );
    }

    //get golf Course table
    getsubmodulesdetailstable(parameters) {
        this.submodulesdata = [];
        this.spinnerService.show();
        this.api.postOH('getmodules', parameters).subscribe(
            (response) => {
                
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                    var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var confirmshow = "row-icon-inactive";

                    this.submodulesdata.push({
                        "id": response[i].id,
                        "subid": response[i].subid,
                        "name": response[i].name,
                        "pagename": response[i].pagename,
                        "glypicon": response[i].glypicon,
                        "sequence": response[i].seq,
                        "createdby": response[i].updatedby,
                        "createddate": response[i].createddate,
                        "status": status,
                        "showonmenu":response[i].showonmenu,
                        "statusclass": statusclass,
                        "editshow": editshow,
                        "enableshow": enableshow,
                        "removeshow": removeshow,
                        "confirmshow": confirmshow
                    });
                }
                {
                    this.GridMessage = "No Data Found";
                }
                this.spinnerService.hide();

            }, error => {
                this.spinnerService.hide();
            }
        );
    }

    viewmodule(moduledata, type) {
        //console.log(moduledata);
        window.scrollTo(0, 0);
        this.type = type;
        this.editModData = moduledata;
        this.mainmodid=moduledata.id;
        this.action = 'V';
        this.viewcontentShow = "block"; this.contentShow = "none";
        this.gridShow = "none"; this.coursegridShow = "block";

        this.mdid = moduledata.id;
        this.lblmdname = (!moduledata.name) ? "" : moduledata.name;
        this.lblpagename = (!moduledata.pagename) ? "" : moduledata.pagename;
        this.lblglyphicon = (!moduledata.glyphicon) ? "" : moduledata.glyphicon;
        this.lblsequence = (!moduledata.sequence) ? "" : moduledata.sequence;
        this.clubtxtsts = moduledata.status;
        if (type == 'M') {
            this.cancelmainmodules=moduledata;
            let parameters = { searchvalue: "  WHERE MOD_M_ID="+moduledata.id+" and MOD_STATUS<>'D' " };
            this.getsubmodulesdetailstable(parameters);
        }
        else {
            this.viewcontentShow = "block"; this.contentShow = "none";
            this.gridShow = "none"; this.coursegridShow = "none";
        }

    }

    cancel() {
        if (this.type == 'M' && this.action=='A') {
            this.gridShow = "block";
            this.contentShow = "none";
            this.viewcontentShow = "none";
            this.coursegridShow = "none";
           
        }
        else if (this.type == 'M' && this.action == 'U') {
            this.gridShow = "none";
            this.contentShow = "none";
            this.viewcontentShow = "block";
            this.coursegridShow = "block";

        }
        else {
            this.gridShow = "none";
            this.contentShow = "none";
            this.viewcontentShow = "block";
            this.coursegridShow = "block";
            this.viewmodule(this.cancelmainmodules, 'M');
         }
       

    }

    addmodules(type) {
        this.type = type;
        this.modulesForm.reset();
        this.gridShow = "none"; this.viewcontentShow = "none";
        this.contentShow = "block"; this.coursegridShow = "none";
        this.divheader = (type == 'M') ? "Edit Module" : "Edit Submodule";
        this.action = 'A';
        if (type == 'M') {
            this.divheader = "Add Module";
            this.mdid = "0"; this.smdid = "0";
            this.lblname = "Module Name";
        }
        else {
            this.divheader = "Add Submodule";
            this.smdid = "0";this.mdid=this.mainmodid;
            this.lblname = "Submodule Name";
        }
        this.submitAttempt = false;
        this.mdname = "";
        this.pagename = "";
        this.glyphicon = "";
        this.sequence = "";
        this.chkshowonmenu=false;

    }
    allowNumbers(event) {
        if (event.keyCode < 48 || event.keyCode > 57) {
            event.preventDefault();
        }
    }

    //edit record
    editmodules() {
        //console.log(this.editModData);       
        if (this.type == 'M') {
            this.divheader = "Edit Module";
            this.lblname = "Module Name";           
        }
        else {
            this.divheader = "Edit Submodule";
            this.lblname = "Submodule Name";
            this.smdid = this.editModData.subid;
            this.mainmodid=this.editModData.subid;
        }
        this.mdid = this.editModData.id;
        this.action = 'U';
        this.gridShow = "none";       
        this.mdname = this.editModData.name;
        this.pagename = this.editModData.pagename;
        this.glyphicon = this.editModData.glyphicon;
        this.sequence = this.editModData.sequence;
        this.status = (this.editModData.status == 'Active') ? true : false;
        this.chkshowonmenu = (this.editModData.showonmenu == 'Y') ? true : false;        
        this.contentShow = "block"; this.viewcontentShow = "none"; this.coursegridShow = "none";
        this.gridShow = "none";
    }

    changests(e) {
        this.chksts = (e.target.checked == true) ? 'Y' : 'N';
    }

    goBack() {
        this.gridShow = "block";
        this.contentShow = "none";
        this.viewcontentShow = "none";
        this.coursegridShow = "none";
        this.action = 'A';
        if(this.type=='S'){
            this.viewmodule(this.cancelmainmodules, 'M');
        }
    }

    saveData() {
        if (!this.modulesForm.valid) {
           
        }

        this.submitAttempt = true;
        if (this.modulesForm.valid) {
            let lshowonmenu=(this.chkshowonmenu==true)?'Y':'N';
            var modulesinfo = {
                "action": this.action, "id": this.mdid, "subid": this.smdid, "name": this.mdname, "glypicon": '', "pagename": this.pagename, "seq": this.sequence, "updtaedid": localStorage.getItem('userId'),"showonmenu":lshowonmenu, "status": this.chksts
            }
            this.spinnerService.show();
            //console.log(modulesinfo);
            this.api.postOH('savemodules', modulesinfo).subscribe(
                (response) => {                   
                    if (this.type == 'M') {
                        let parameters = { searchvalue: "  WHERE MOD_M_ID=0 AND MOD_STATUS= 'Y' " };
                        this.GetModulesData(parameters);
                        this.selectedoption="Active";this.randomcolor="#5cb85c";
                        this.gridShow = "block"; this.viewcontentShow = "none"
                        this.contentShow = "none"; this.coursegridShow = "none";
                        let msg = (this.action == "A") ? '<span style="color: green">Module added Successfully .</span>' : '<span style="color: green">Module updated Successfully .</span>';
                        this.toastMessage(msg);
                    }
                    else {
                        // let parameters = { searchvalue: "  WHERE MOD_M_ID=" + this.mainmodid + " " };
                        // this.getsubmodulesdetailstable(parameters);
                        this.viewmodule(this.cancelmainmodules, 'M');
                        this.gridShow = "none"; this.viewcontentShow="block"
                        this.contentShow = "none"; this.coursegridShow = "block";
                        let msg = (this.action == "A") ? '<span style="color: green">Submodule added Successfully .</span>' : '<span style="color: green">Submodule updated Successfully .</span>';
                        this.toastMessage(msg);
                    }                  
                    this.spinnerService.hide();
                    window.scrollTo(0, 0);
                }, error => {
                    console.log(error);
                });
        }
    }

    toastMessage(msg) {
        let options = {
            positionClass: 'toast-top-center',

        };

        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 5000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    }

    confirm(): void {
        this.modalRef.hide();
        var modulesinfo = {
            "action": 'D', "id": this.mdid, "subid": this.smdid, "name": '', "glypicon": '', "pagename": '', "seq": 0, "updtaedid": localStorage.getItem('userId'),"showonmenu":'Y', "status": 'D'
        }
        let msg = '<span style="color: red">Module deleted Successfully</span>';
        this.DEapicall(modulesinfo, msg);
    }

    enablemodule(id,type): void {
        var modulesinfo = {
            "action": 'E', "id": id, "subid": this.smdid, "name": '', "glypicon": '', "pagename": '', "seq": 0, "updtaedid": localStorage.getItem('userId'),"showonmenu":'Y', "status": 'Y'
        }
        let msg = '<span style="color: green">Module enabled Successfully</span>';
        this.DEapicall(modulesinfo, msg);
    }

    DEapicall(modulesinfo, msg) {
        
        this.api.postOH('savemodules', modulesinfo).subscribe(
            (response) => {
                let parameters = { searchvalue: "  WHERE MOD_M_ID=0 AND MOD_STATUS= 'Y' " };
                this.GetModulesData(parameters);
                this.selectedoption="Active";this.randomcolor="#5cb85c";
                this.contentShow = "none"; this.gridShow= "block";
                this.viewcontentShow ="none"; this.coursegridShow= "none";
                this.toastMessage(msg);
            }, error => {
                console.log(error);
            });
    }

    decline(): void {
        this.modalRef.hide();
    }
}

