import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { Title } from '@angular/platform-browser';

@Component({
    selector: 'app-teeboxdetails',
    templateUrl: './teeboxdetails.component.html',
    styleUrls: ['./teeboxdetails.component.css']
})
export class TeeboxdetailsComponent implements OnInit {
    modalRef: BsModalRef;
    public TeeboxForm: FormGroup; submitAttempt: boolean = false; divheader: string = "Add TeeBox Configuration";
    searchtxt: boolean = true;
    tboxdetailsdata: any; id: any = 0;
    golfclbid: any; userid: any;
    contentShow: string = "none"; viewcontentShow: string = "none"; gridShow: string = "none"; txtShow: string = "none"; lblShow: string = "none";
    action: string = 'A'; gcid: string = "0";
    tboxname: string; chkactive: boolean = true; clubsts: string; clubchksts: boolean = true; cartstatus: any; cartchkstatus: boolean = true; carttxtstatus: string = 'Active';
    stat: any; headername: string; viewheadername: string;
    clubtxtsts: string = 'Active'; txtsrch: string = ''; srchError: string = '0';
    GridMessage: string = 'Loading, Please wait ... !';
    key: string = 'tboxname';
    reverse: boolean = false;
    nameasc: any = "sortgreen"; namedesc: any = "sortwhite";
    selectedoption:any = 'Active' ;randomcolor:any = "#5cb85c";

    constructor(private title: Title,public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService, public toastr: ToastsManager, vcr: ViewContainerRef, public modalService: BsModalService,
        private authService: AuthService, private router: Router) {
        
            this.title.setTitle("IZON - Tee Box Configuration");
        //localStorage.removeItem('courseId');
        this.headername = localStorage.getItem('clubname') + " >> Tee Box Configuration";
        this.toastr.setRootViewContainerRef(vcr);
        this.contentShow = "none"; this.gridShow = "none";
        this.tboxdetailsdata = [];
        this.userid = localStorage.getItem('userId');
        this.golfclbid = localStorage.getItem('clubId');
    }

    ngOnInit() {
        this.TeeboxForm = this.formBuilder.group({
            fteeboxname: ['', Validators.compose([Validators.required])],
            cartchkstatus: ['']
        });
        let parameters = {
            searchvalue: " WHERE TB_GCB_ID='" + this.golfclbid + "' AND TB_STATUS='Y'"
        };
        this.getTeeBoxDetailsData(parameters);

        this.gridShow = "block";
        this.contentShow = "none";
    }

    sort(value: string) {
        this.key = value;
        this.nameasc = "sortwhite"; this.namedesc = "sortwhite";
        if (this.key == value) {
            this.reverse = !this.reverse;
            if (this.key == "tboxname" && this.reverse) {
                this.namedesc = "sortgreen";
            }
            else if (this.key == "tboxname" && (!this.reverse)) {
                this.nameasc = "sortgreen";
            }
        }
    }
    refreshpage() {
        this.selectedoption = 'Active' ;this.randomcolor = "#5cb85c";
        this.txtsrch = "";
        this.srchError = '0';
        let parameters = {
            searchvalue: " WHERE TB_GCB_ID='" + this.golfclbid + "' AND TB_STATUS='Y'"
        };
        this.getTeeBoxDetailsData(parameters);
    }

    search() {
        if (this.txtsrch == '') {
            this.srchError = '1';
        }
        else if (this.txtsrch != '') {
            this.srchError = '0';
            let parameters = {
                searchvalue: " WHERE TB_GCB_ID='" + this.golfclbid + "' and TB_NAME LIKE '%" + this.txtsrch + "%' AND TB_STATUS<>'D'"
            };
            this.getTeeBoxDetailsData(parameters);
            this.txtsrch = "";
        }
    }

    goBackClub() {
        //localStorage.removeItem('clubId');
        //localStorage.removeItem('clubname');
        this.authService.getCall();
        this.router.navigate(['/clubmanagement/golfclub']);
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    }
    decline(): void {
        this.modalRef.hide();
    }


    //get teebox table details 
    getTeeBoxDetailsData(parameters) {
        this.spinnerService.show();
        this.api.postOH('gettboxdetails', parameters).subscribe(
            (response) => {
                //console.log(response);
                this.tboxdetailsdata = [];
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                    var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var confirmshow = "row-icon-inactive";

                    this.tboxdetailsdata.push({
                        "id": response[i].id,
                        "tboxname": response[i].tboxname,
                        "golfclubid": response[i].golfclubid,
                        "golfclubname": response[i].golfclubname,
                        "updatedby": response[i].updatedby,
                        "createddate": response[i].createddate,
                        "status": status,
                        "statusclass": statusclass,
                        "editshow": editshow,
                        "enableshow": enableshow,
                        "removeshow": removeshow,
                        "confirmshow": confirmshow
                    });
                }
                {
                    this.GridMessage = "No Data Found";
                }
                this.spinnerService.hide();

            }, error => {
                this.spinnerService.hide();
            }
        );
    }

    addTeeBoxConfig() {
        this.id = 0;
        this.action = 'A';
        this.cartstatus = 'Y';
        this.gridShow = "none";
        this.contentShow = "block";
        this.txtShow = "block"; this.lblShow = "none";
        this.tboxname = '';
        this.submitAttempt = false;
        this.TeeboxForm.reset();
        this.divheader = "Add Tee Box Configuration";
    }
    gotogrid() {
        this.gridShow = "block";
        this.contentShow = "none";
        this.action = 'A';
    }
    //edit record
    edit() {
        this.divheader = "Edit Tee Box Configuration";
        this.action = 'U';
        this.gcid = this.golfclbid;
        this.gridShow = "none";
        this.contentShow = "block";
        this.txtShow = "block"; this.lblShow = "none"; this.viewcontentShow = "none";
        let parameters = {
            searchvalue: ' WHERE TB_ID=' + this.id + ''
        };
        //this.spinnerService.show();
        let teeBoxData = [];
        this.api.postOH('gettboxdetails', parameters).subscribe(
            (response) => {
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                    var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var confirmshow = "row-icon-inactive";

                    teeBoxData.push({
                        "id": response[i].id,
                        "tboxname": response[i].tboxname,
                        "golfclubid": response[i].golfclubid,
                        "golfclubname": response[i].golfclubname,
                        "updatedby": response[i].updatedby,
                        "createddate": response[i].createddate,
                        "status": status,
                        "statusclass": statusclass,
                        "editshow": editshow,
                        "enableshow": enableshow,
                        "removeshow": removeshow,
                        "confirmshow": confirmshow
                    });
                }
                //console.log(teeBoxData);
                this.tboxname = (!teeBoxData[0].tboxname) ? "" : teeBoxData[0].tboxname;
                // this.id= teeBoxData[0].id;
                this.spinnerService.hide();

            }, error => {
                this.spinnerService.hide();
            }
        );

    }

    goBack() {
        this.gridShow = "block";
        this.contentShow = "none";
        this.viewcontentShow = "none";
    }


    viewtbox(teeBoxData) {
        window.scrollTo(0, 0);
        this.viewheadername = "Tee Box Info";
        this.action = 'V';
        this.viewcontentShow = "block";
        this.gridShow = "none";
        this.id = teeBoxData.id;
        this.tboxname = (!teeBoxData.tboxname) ? "" : teeBoxData.tboxname;
        this.clubtxtsts = teeBoxData.status;
        if (teeBoxData.status == 'Active') {
            this.cartstatus = 'Y';
        }
        else if (teeBoxData.status == 'In-Active') {
            this.cartstatus = 'N';
        }
        this.cartchkstatus = (this.cartstatus == 'Y') ? true : false;
        this.carttxtstatus = (this.cartstatus == 'Y') ? 'Active' : 'In-Active';
        if (teeBoxData.status == 'Deleted') {
            this.cartstatus = 'D';
            this.carttxtstatus = 'Deleted';
        }
    }
    checkBoxChange(status) {
        this.stat = status;
        if (this.stat == true) {
            this.cartstatus = 'Y';
            this.carttxtstatus = 'Active';
        }
        else {
            this.cartstatus = 'N';
            this.carttxtstatus = 'In-Active';
        }
    }
    savedata() {
        if (!this.TeeboxForm.valid) {
            // alert('f');
        }
        this.submitAttempt = true;
        if (this.TeeboxForm.valid) {
            var teeboxinfo = {
                "action": this.action, "id": this.id, "golfclubid": this.golfclbid, "tboxname": this.tboxname, "updtaedid": localStorage.getItem('userId'), "status": this.cartstatus
            }
            this.saveteebox(teeboxinfo);
        }
    }
    confirm(): void {
        this.modalRef.hide();
        this.action = "D";
        var teeboxinfo = {
            "action": this.action, "id": this.id, "golfclubid": this.golfclbid, "tboxname": this.tboxname, "updtaedid": localStorage.getItem('userId'), "status": this.cartstatus
        }
        this.saveteebox(teeboxinfo);
    }

    saveteebox(teeboxmodel) {
        this.spinnerService.show();
        this.api.postOH('savetboxdetails', teeboxmodel).subscribe(
            (response) => {
                let msg = "";
                if (this.action == "A") {
                    msg = '<span style="color: green">Tee Box Details added Successfully .</span>';
                } else if (this.action == "U") {
                    msg = '<span style="color: green">Tee Box Details updated Successfully .</span>';
                } else if (this.action == "D") {
                    msg = '<span style="color: green">Tee Box Deleted Successfully.</span>';
                }
                this.toastMessage(msg);
                let parameters = {
                    searchvalue: " WHERE TB_GCB_ID='" + this.golfclbid + "' AND TB_STATUS='Y'"
                };
                this.getTeeBoxDetailsData(parameters);
                this.gridShow = "block";
                this.contentShow = "none"; this.viewcontentShow = "none";
                this.spinnerService.hide();
                window.scrollTo(0, 0);
            },error=>{
                this.spinnerService.hide();
            });
    }
    toastMessage(msg) {
        let options = {
            positionClass: 'toast-top-center',
        };

        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 5000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }

    enableTeeBox(id): void {
        //console.log(id);
        var tboxinfo = {
            "action": 'E', "id": id, "tboxname": "",
            "updtaedid": localStorage.getItem('userId'), "status": 'Y'
        }
        let msg = '<span style="color: green">Teebox enabled Successfully</span>';
        this.DEapicall(tboxinfo, msg);
    }
    DEapicall(tboxinfo, msg) {
        //console.log(tboxinfo);
        this.api.postOH('savetboxdetails', tboxinfo).subscribe(
            (response) => {
                let parameters = {
                    searchvalue: " WHERE TB_GCB_ID='" + this.golfclbid + "' AND TB_STATUS='Y'"
                };
                this.getTeeBoxDetailsData(parameters);
                this.gridShow = "block";
                this.contentShow = "none";

                this.toastMessage(msg);
            }, error => {
                console.log(error);
            });
    }

    
    bindselectedoption(selectedoption) {
        if (this.selectedoption == 'Active') {
            this.randomcolor = "#5cb85c";
            this.srchSts('Y');
        }
        else if (this.selectedoption == 'In-Active') {
            this.randomcolor = "#337ab7";
            this.srchSts('N');
        }
        else if (this.selectedoption == 'Deleted') {
            this.randomcolor = "#d9534f";
            this.srchSts('D');
        }
    }
    srchSts(type) {
        let parameters = {
            searchvalue: " WHERE TB_GCB_ID='" + this.golfclbid + "' and TB_STATUS= '" + type + "' "
        };
        this.getTeeBoxDetailsData(parameters);
    }
    srchKeyUp(event: any) {
        if (this.txtsrch != '') {
            this.srchError = '0';
        }
    }
}



