import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TeeboxdetailsComponent } from './teeboxdetails.component';

describe('TeeboxdetailsComponent', () => {
  let component: TeeboxdetailsComponent;
  let fixture: ComponentFixture<TeeboxdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TeeboxdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TeeboxdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
