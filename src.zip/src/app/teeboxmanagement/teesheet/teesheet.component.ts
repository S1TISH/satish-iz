import { Component, OnInit, ViewContainerRef, } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Title } from '@angular/platform-browser';

declare const google: any;

@Component({
  selector: 'app-teesheet',
  templateUrl: './teesheet.component.html',
  styleUrls: ['./teesheet.component.css']
})
export class TeesheetComponent implements OnInit {

  public teeboxholeForm: FormGroup; submitAttempt: boolean = false;
    btnName: any = "SAVE";HolesInfo:any=[];
    golfclubid: any; golfcourseid: any; holeid: any; userid: any; chkactive: any;
    clat: any; clong: any; czoomlevel: any; crotate: any; 
    map: any; latlngarry: any; labelname: any; image: any; markers: any = [];
    teeboxdata: any; 
    action: string = 'A';
    teebox: any = "0"; lat: any; long: any; tboxholeid: any = 0;ddlhole:any;
    tboxholechkstatus: boolean = true; tboxholestatus: any;
    tboxholetxtstatus: string = 'Active'; txtsrch: string = '';
    editTeeBoxHoleInfo: any = [];
    cancelEditTeeBox: any = [];
    stat: any; srchError: string = '0'; teeboxheader: string; viewteeboxheader: string; btnSave: any;

    constructor(private title: Title,public toastr: ToastsManager, private _router: Router, vcr: ViewContainerRef, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService, private authService: AuthService) {
        this.title.setTitle("IZON - Tee Boxes");
        this.golfclubid = localStorage.getItem('clubId');
        this.golfcourseid = localStorage.getItem('courseId');        
        this.userid = localStorage.getItem('userId');
        this.toastr.setRootViewContainerRef(vcr);
        this.teeboxdata = [];
    }

    ngOnInit() {
        this.teeboxholeForm = this.formBuilder.group({
            fddlhole: ['0', Validators.compose([Validators.required])], 
            fteebox: ['0', Validators.compose([Validators.required])],
            flat: ['', Validators.compose([Validators.required])],
            flong: ['', Validators.compose([Validators.required])],
            fchkactive: ['']
        })
        this.getHoles();
        this.getTeeBoxes();
        this.getCourses();        
    }

    getHoles() {
      let parameters = { searchvalue: " WHERE HD_GCB_ID=" + this.golfclubid + " AND HD_GC_ID = " + this.golfcourseid + " and HD_STATUS='Y' " };
      this.spinnerService.show();
      this.api.postOH('getholes', parameters).subscribe(
          response => {              
              this.HolesInfo = [];            
              if (response.length !== 0) {                
                  for (let i = 0; i < response.length; i++) {
                      this.HolesInfo.push({
                          "id": response[i].id,
                          "holename": response[i].holename
                      });
                  }
              }
              this.ddlhole='0';
              this.spinnerService.hide();
          },
          err => {
            this.spinnerService.hide();
          }
      );
    }

    getTeeBoxes() {
      let parameters = {
          searchvalue: " WHERE TB_GCB_ID=" + this.golfclubid + " AND TB_STATUS='Y' "
      };
      this.api.postOH('gettboxdetails', parameters).subscribe(
          (response) => {
              for (var i = 0; i < response.length; i++) {
                  this.teeboxdata.push({
                      value: response[i].id,
                      name: response[i].tboxname
                  })
              }
          }
      )
    }

    getCourses() {
      let parameters = { searchvalue: " WHERE GC_GCB_ID='" + this.golfclubid + "' AND GC_ID='" + this.golfcourseid + "'" };
      this.api.postOH('getgolfcourse', parameters).subscribe(
        response => {
          if (response.length !== 0) {
            this.clat = response[0].latitude;
            this.clong = response[0].longitude;
            this.czoomlevel=(response[0].zoomlevel!='')?response[0].zoomlevel:'0';
            this.crotate=(response[0].rotate!='')?response[0].rotate:'0';
          }
          this.maploading();          
        })
    }

    maploading() {
      this.map = new google.maps.Map(document.getElementById('map'), {
          center: { lat: parseFloat(this.clat), lng: parseFloat(this.clong) },
          zoom: parseInt(this.czoomlevel),
          disableDefaultUI: false,
          mapTypeId: 'satellite',
          heading: parseInt(this.crotate),
          tilt: 0,
          rotateControl: true
      });
      this.setoverlayimage();        

      var me = this;
      this.map.addListener('click', function (event) {
          me.deletemarker();
          this.latlngarry = JSON.parse(JSON.stringify(event));           
          if (me.teebox > 0) {
              me.lat = this.latlngarry.latLng.lat;
              me.long = this.latlngarry.latLng.lng;
              me.addMarker(event.latLng);
          }            
          else {
              let msg = '<span style="color: red">Please select tee box to set positions</span>';
              me.toastMessage(msg);
          }
      });

      this.spinnerService.hide();
    }

    setoverlayimage(){
      let me=this;    
      var imageMapType = new google.maps.ImageMapType({
        getTileUrl: function(coord, zoom) {
          //console.log('http://iadmin.azaz.com/tiles/' + me.golfclubid+ '/' +me.courseid+ '/' + zoom + '/' + coord.x + '/' + coord.y + '.png');
          return ['http://cp.izongolf.com/tiles/' + me.golfclubid+ '/' +me.golfcourseid+ '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
        //   let clbid=''; let cursid='';
        //   if(me.golfclubid=='1002'){clbid='1445'}else{clbid=me.golfclubid};
        //   if(me.golfcourseid=='2'){cursid='539'}else if(me.golfcourseid=='3'){cursid='540'}else if(me.golfcourseid=='4'){cursid='541'}else{cursid=me.golfcourseid};
        //   return ['http://cp.izongolf.com/tiles/' + clbid + '/' + cursid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
        },
        tileSize: new google.maps.Size(256, 256)
      });
      this.map.overlayMapTypes.push(imageMapType);
    }

    addMarker(location) {
      var marker = new google.maps.Marker({
          position: location,
          map: this.map,
          label: this.labelname,
          draggable: true
      });
      this.markers.push(marker);
      var me = this;
      google.maps.event.addListener(marker, "dragend", function (e) {
          me.lat = marker.getPosition().lat();
          me.long = marker.getPosition().lng();
      })
    }

    //hole change event
    holechangeevent() {
      this.clearMarkers();
      this.teebox="0";
      this.lat="";
      this.long="";this.action = "A"; this.btnName = "SAVE";  
      if (this.ddlhole > 0){
        let parameters = {
          searchvalue: " WHERE  HD_GCB_ID='" + this.golfclubid + "' AND HD_GC_ID='" + this.golfcourseid + "' and HD_ID='" + this.ddlhole + "' "
        };
        this.GetHoleLatLongDetails(parameters);        
      } else {        
        this.getCourses();        
      }
    }

    GetHoleLatLongDetails(parameters) {
      this.api.postOH('getholes', parameters).subscribe(
          (response) => {
            this.clat = response[0].clatitude;
            this.clong = response[0].clongitude;
            this.czoomlevel = (response[0].zoomlevel!='')?response[0].zoomlevel:0;
            this.crotate = (response[0].rotate=='')?0:response[0].rotate;
            this.map.setCenter(new google.maps.LatLng(parseFloat(this.clat), parseFloat(this.clong)));
            this.map.setZoom(parseInt(this.czoomlevel));
            this.map.setHeading(parseInt(this.crotate));
          }, error => {
          }
      );
    }

    //tee box change event
    setPositons(val) {
      if (val.target.value == "0") {
          this.clearMarkers(); this.tboxholeid="0"; this.lat = ""; this.teebox = 0; this.long = ""; this.action = "A"; this.btnName = "SAVE";          
      }
      else {
        if(this.ddlhole>0){
          let parameters = {
              searchvalue: ' WHERE TBHD_GCB_ID=' + this.golfclubid + ' AND TBHD_GC_ID=' + this.golfcourseid + ' AND TBHD_HD_ID=' + this.ddlhole + ' AND TBHD_TB_ID=' + val.target.value + ''
          };
          this.clearMarkers();
          let locstr=val.target.options[val.target.selectedIndex].text;
          this.labelname={ text:(locstr.substring(0,1)).toUpperCase(), color: "white" };
          this.getPositions(parameters);          
        }else{
          let msg = "<span style='color: red'>Please Select Hole</span>";
          this.toastMessage(msg);
        }
      }
    }

    getPositions(parameters) {
      let latlng = {};
      this.spinnerService.show();
      let teeboxholedata = [];
      this.api.postOH('getTeeBoxHoleDetails', parameters).subscribe(
          (response) => {
              if (response.length > 0) {
                  teeboxholedata = response;
                  this.action = 'U'; this.btnName = "UPDATE";
                  this.teebox = (!teeboxholedata[0].teeboxid) ? "0" : teeboxholedata[0].teeboxid.toString();
                  this.tboxholeid = (!teeboxholedata[0].id) ? "0" : teeboxholedata[0].id.toString()
                  this.lat = (!teeboxholedata[0].latitude) ? "" : teeboxholedata[0].latitude;
                  this.long = (!teeboxholedata[0].longitude) ? "" : teeboxholedata[0].longitude;
                  this.chkactive = (teeboxholedata[0].status == 'Y') ? true : false;
                  latlng = { lat: parseFloat(this.lat), lng: parseFloat(this.long) };                    
                  this.addMarker(latlng);
                  this.spinnerService.hide();
              }
              else if (response.length == 0) {
                  this.lat = ""; this.long = "";this.tboxholeid="0";
                  this.clearMarkers(); this.action = "A"; this.btnName = "SAVE";
              }
              this.spinnerService.hide();
          }, error => {
              this.spinnerService.hide();
          }
      );
    }

    deletemarker() {
        for (var i = 0; i < this.markers.length; i++) {
            this.markers[i].setMap(null);
        }
    }

    setMapOnAll(map) {
        for (var i = 0; i < this.markers.length; i++) {
            this.markers[i].setMap(map);
        }
    }

    clearMarkers() {
        this.setMapOnAll(null);
        this.markers = [];
    }    

    //save or update teesheet positions
    saveData() {
        if (this.teebox > 0) {
            let latlng = {};            
            this.submitAttempt = true;
            if (this.teeboxholeForm.valid) {
                this.btnSave = true;
                var teeboxholesmodel = {
                    "action": this.action,
                    "id": this.tboxholeid,
                    "golfclubid": this.golfclubid,
                    "golfcourseid": this.golfcourseid,
                    "holeid": this.ddlhole,
                    "teeboxid": this.teebox,
                    "latitude": this.lat,
                    "longitude": this.long,
                    "updtaedid": this.userid,
                    "status": (this.chkactive == true) ? "Y" : 'N'
                }
                this.spinnerService.show();
                this.api.postOH('saveteeboxholes', teeboxholesmodel).subscribe(
                    (response) => {
                        if (response[1] != 'Tee Box Hole Assignment Already Exist or Unable to process your request ') {
                            let parameters = {
                                searchvalue: " WHERE TBHD_GCB_ID = " + this.golfclubid + " AND TBHD_GC_ID = " + this.golfcourseid + " AND TBHD_HD_ID = " + this.ddlhole + " AND TBHD_STATUS = 'Y'"
                            };
                            let msg = (this.action == 'A') ? '<span style="color: green">Tee Box Hole Positions Created Successfully.</span>' : '<span style="color: green">Tee Box Hole Positions Updated Successfully .</span>';
                            this.toastMessage(msg);
                            if (this.action == 'A') {
                                this.action = "U"; this.btnName = 'UPDATE'; this.tboxholeid = response[0]; this.chkactive = true;
                                latlng = { lat: parseFloat(this.lat), lng: parseFloat(this.long) };
                                this.image = '';
                                this.addMarker(latlng);
                            }
                        } else {
                            let msg = "<span style='color: red'>" + response[1] + "</span>";
                            this.toastMessage(msg);
                        }
                        this.btnSave = false;
                        this.spinnerService.hide();
                    }, error => {
                        this.btnSave = false;
                        this.spinnerService.hide();
                    });
            }
        } else {
            this.submitAttempt = true;
        }
    }

    allowNumbersAndDecimals(e) {
        if (e.which != 46 && e.which != 45 && e.which != 46 &&
            !(e.which >= 48 && e.which <= 57)) {
            return false;
        }
    }

    toastMessage(msg) {
      let options = {
          positionClass: 'toast-top-center',
      };
      this.toastr.custom(msg, null, {
          enableHTML: true, toastLife: 5000,
          showCloseButton: true, 'positionClass': 'toast-bottom-right'
      });
    }

}
