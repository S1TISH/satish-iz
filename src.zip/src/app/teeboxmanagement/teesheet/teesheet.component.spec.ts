import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TeesheetComponent } from './teesheet.component';

describe('TeesheetComponent', () => {
  let component: TeesheetComponent;
  let fixture: ComponentFixture<TeesheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TeesheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TeesheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
