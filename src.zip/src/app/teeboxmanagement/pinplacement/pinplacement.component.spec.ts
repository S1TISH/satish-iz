import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PinplacementComponent } from './pinplacement.component';

describe('PinplacementComponent', () => {
  let component: PinplacementComponent;
  let fixture: ComponentFixture<PinplacementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PinplacementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PinplacementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
