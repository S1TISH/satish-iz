import { Component, OnInit, ViewContainerRef, TemplateRef, ViewChild, ElementRef } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Console } from '@angular/core/src/console';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { error } from 'util';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import * as moment from "moment";
import { Title } from '@angular/platform-browser';

declare const google: any;
@Component({
  selector: 'app-pinplacement',
  templateUrl: './pinplacement.component.html',
  styleUrls: ['./pinplacement.component.css']
})
export class PinplacementComponent implements OnInit {
    modalRef: BsModalRef;
    HolesInfo: any = []; HolesEditInfo: any = []; pinAdjustment: any = [];
    public holeflagForm: FormGroup; submitAttempt: boolean = false;
    public adjholeflagForm: FormGroup; submitAttempt1: boolean = false;
    
    holelat: any; holelong: any; holezoomlevel: any; holerotate: any;
    golfclubid: any; courseid: any; holeid: any;
    poly: any; map: any; flagpositionheader: string; action: any = 'A';
    holepolylinecoordinates: any = []; latlngarry: any; flightPath: any; line: any = [];
    btnname: any; adjbtnname: any; radiobtn: any; ddlholeflaglist: any = []; todayactiveflag: any;
    ddlflag: any; activecontrol: any; lbltodaydayflag: any; id: any = 0; btnsavedisable: any; dayposition: any;
    txtsequence: any; txtfrontlat: any; txtfrontlong: any; txtmiddlelat: any; txtmiddlelong: any; tempmiddlelat: any; tempmiddlelong: any; txtbacklat: any; txtbacklong: any; chkactive: any; mchktemp: any;
    ddlactflag: any; btnflagupdatedisb: any; markers: any = []; image: any; labelname: any;

    invmarkers: any = {};

    selectPlacementId: string = '3'; selectHoleId: string = '1'; mapClicked: boolean = false;
    fromdate: any; todate: any; day: string; month: any; txtHide: boolean = false; datearry: any = []; dates: any = [];
    adjMarker: any; datesinfo: any = []; selectedFlag: string = '0'; flagPosId: any;
    flagScheduleInfo: any = []; ddlflagpos: any = []; holeflagdetails: any = []; flagScheduleArr: any = [];
    fhid: string = '0'; fhname: string = '0'; seletedFlagChange: string = '0'; todayActiveFlag: string = '1';
    NoMaploading: boolean = false; typeValue: string = '0'; pageChecked: boolean = false; lblmaptext: string = '';
    adjPinShow: boolean = true; adjColor: string = ''; is_edit: boolean = false; delFlag: string = ''; showDelBtn: boolean = false;
    adjSeq: string = ''; pinExist: boolean = false; pinNumber: string = ''; prevAdjpin: boolean = false;
    timeoffset:any;

    @ViewChild('template') template: TemplateRef<any>;
    @ViewChild('template1') template1: TemplateRef<any>;

    constructor(private title: Title,public api: ApiService, public toastr: ToastsManager, public formBuilder: FormBuilder, vcr: ViewContainerRef, private spinnerService: Ng4LoadingSpinnerService, private modalService: BsModalService) {
        
        this.title.setTitle("IZON - Pin Placement");
        this.toastr.setRootViewContainerRef(vcr);
        this.adjMarker = 'assets/imgs/adjmarker.png';
        this.btnname = "Save"; this.adjbtnname = "Save";

        this.golfclubid = localStorage.getItem('clubId');
        this.courseid = localStorage.getItem('courseId');
       
        this.ddlflag = "0";
        this.txtsequence = "1";
        this.txtfrontlat = "";
        this.txtfrontlong = "";
        this.txtbacklat = "";
        this.txtbacklong = "";
        this.activecontrol = "none";

        this.ddlflagpos = [
            { "id": '1', "name": 'Position 1' },
            { "id": '2', "name": 'Position 2' },
            { "id": '3', "name": 'Position 3' },
            { "id": '4', "name": 'Position 4' },
            { "id": '5', "name": 'Position 5' },
            { "id": '6', "name": 'Position 6' },
            { "id": 'GF', "name": 'Green Front' },
            { "id": 'GM', "name": 'Green Middle' },
            { "id": 'GB', "name": 'Green Back' }
        ];
    }

    ngOnInit() {
        this.holeflagForm = this.formBuilder.group({
            txtsequence: [''],
            ddlpos: ['0', Validators.compose([Validators.required]),],
            txtmiddlelat: ['', Validators.compose([Validators.required]),],
            txtmiddlelong: ['', Validators.compose([Validators.required]),],
            chktemp: ['']
        })  

        this.adjholeflagForm = this.formBuilder.group({
            txtsequence: [''],
            ddlpos: ['0', Validators.compose([Validators.required]),],
            tempmiddlelat: ['', Validators.compose([Validators.required]),],
            tempmiddlelong: ['', Validators.compose([Validators.required]),],
            fromdate: [''],
            todate: [''],
            chkactive: ['']
        }) 
        this.getCourses(); 
       
    }
    getCourses() {
        let parameters = { searchvalue: " WHERE GC_GCB_ID='" + this.golfclubid + "' AND GC_ID='" + this.courseid + "'" };
        this.api.postOH('getgolfcourse', parameters).subscribe(
          response => {
            if (response.length !== 0) {
               this.timeoffset = response[0].timeoffset;
            }
            this.pinSchedule();
          });
      }
   
    allowNumbersAndDecimals(e) {
        if (e.which != 46 && e.which != 45 && e.which != 46 &&
            !(e.which >= 48 && e.which <= 57)) {
            return false;
        }
    }

    getholeperimetersdata(parameters) {
        this.spinnerService.show();
        this.api.postOH('GetHolePerimeters', parameters).subscribe(
            (response) => {
                this.holepolylinecoordinates = [];
                if (response.length > 0) {
                    for (var i = 0; i < response.length; i++) {
                        this.holepolylinecoordinates.push({
                            lat: parseFloat(response[i].Latitude),
                            lng: parseFloat(response[i].Longitude)
                        });
                    }
                    let parameters = {
                        searchvalue: " WHERE  HD_GCB_ID='" + this.golfclubid + "' AND HD_GC_ID='" + this.courseid + "' and HD_ID='" + this.holeid + "' "
                    };
                    this.GetHoleLatLongDetails(parameters);
                } else {
                    let parameters = {
                        searchvalue: " WHERE  HD_GCB_ID='" + this.golfclubid + "' AND HD_GC_ID='" + this.courseid + "' and HD_ID='" + this.holeid + "' "
                    };
                    this.GetHoleLatLongDetails(parameters);
                }
            }, error => {
                this.spinnerService.hide();
            }
        );
    }

    GetHoleLatLongDetails(parameters) {
        this.HolesEditInfo = [];
        this.api.postOH('getholes', parameters).subscribe(
            (response) => {
                this.HolesEditInfo = response; 
                this.holelat = (response[0].gmlatitude != '') ? response[0].gmlatitude : (response[0].clatitude == '') ? 0.0 : response[0].clatitude;
                this.holelong = (response[0].gmlongitude != '') ? response[0].gmlongitude : (response[0].clongitude == '') ? -0.0 : response[0].clongitude;
                this.holezoomlevel = (response[0].gmlatitude != '') ? 20 : (response[0].zoomlevel == '') ? 15 : response[0].zoomlevel;
                this.holerotate = (response[0].rotate == '') ? 0 : response[0].rotate;
                if (!this.NoMaploading) { this.maploading(); } 
                this.getholeflagpositions();
                if (response[0].gmlatitude != '') {
                    let latlng1 = { lat: parseFloat(response[0].gmlatitude), lng: parseFloat(response[0].gmlongitude) };
                    this.labelname = { text: '.', textseq: 'M', color: '#5EBA47', id: '' + response[0].id + '' };
                    this.image = 'assets/imgs/markers/gm.png'
                    if (this.selectPlacementId != '3') { this.addMarker(latlng1); } 

                }

                if (response[0].gflatitude != '') {
                    let latlng2 = { lat: parseFloat(response[0].gflatitude), lng: parseFloat(response[0].gflongitude) };
                    this.labelname = { text: '.', textseq: 'F', color: '#5EBA47', id: '' + response[0].id + '' };
                    this.image = 'assets/imgs/markers/gf.png'
                    if (this.selectPlacementId != '3') { this.addMarker(latlng2); } 

                }

                if (response[0].gblatitude != '') {
                    let latlng3 = { lat: parseFloat(response[0].gblatitude), lng: parseFloat(response[0].gblongitude) };
                    this.labelname = { text: '.', textseq: 'B', color: '#5EBA47', id: '' + response[0].id + '' };
                    this.image = 'assets/imgs/markers/gb.png'
                    if (this.selectPlacementId != '3') { this.addMarker(latlng3); } 
                  }
                  this.spinnerService.hide();
               }, error => {
                this.spinnerService.hide();
            }
        );
    }

    maploading() {
        this.map = new google.maps.Map(document.getElementById('map'), {
            center: { lat: parseFloat(this.holelat), lng: parseFloat(this.holelong) },
            zoom: parseInt(this.holezoomlevel),
            disableDefaultUI: false,
            mapTypeId: 'satellite',
            heading: parseInt(this.holerotate),
            tilt: 0,
            rotateControl: true
        });
        this.setoverlayimage();
        this.holeperimetersdrawpolyline();
        var me = this;
        //if (this.selectPlacementId != '2') {
        this.map.addListener('click', function (event) {
                me.enableToggle(); me.enableDDL();
                me.mapClicked = true; me.mchktemp = false;
                // me.clearMarkers();
                this.latlngarry = JSON.parse(JSON.stringify(event));
                me.txtmiddlelat = this.latlngarry.latLng.lat;
                me.txtmiddlelong = this.latlngarry.latLng.lng;
                me.image = 'assets/imgs/markers/empty.png';
                me.labelname = '';
                me.addMarker(event.latLng);
                me.ddlflag = '0'; me.action = 'A'; me.btnname = 'Save'; me.id = 0;
                me.txtHide = false; me.mchktemp = false;
            });
        //}
        this.spinnerService.hide();
    }

    setoverlayimage() {
        let me = this;
        var imageMapType = new google.maps.ImageMapType({
            getTileUrl: function (coord, zoom) {
                return ['http://cp.izongolf.com/tiles/' + me.golfclubid + '/' + me.courseid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
                // let clbid=''; let cursid='';
                // if(me.golfclubid=='1002'){clbid='1445'}else{clbid=me.golfclubid};
                // if(me.courseid==2){cursid='539'}else if(me.courseid==3){cursid='540'}else if(me.courseid==4){cursid='541'}else{cursid=me.courseid};
                // return ['http://cp.izongolf.com/tiles/' + clbid + '/' + cursid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
            },
            tileSize: new google.maps.Size(256, 256)
        });
        this.map.overlayMapTypes.push(imageMapType);
    }

    // Adds a marker to the map.
    addMarker(location) {
        // Add the marker at the clicked location, and add the next-available label
        // from the array of alphabetical characters.
        this.deletemarker();
        var marker = new google.maps.Marker({
            position: location,
            map: this.map,
            label: this.labelname,
            icon: this.image,
            draggable: true,
            
        });
        this.markers.push(marker);
        var me = this;
        //Attach click event to the marker.
        (function (marker, location) {
            google.maps.event.addListener(marker, "click", function (event) {
                me.deletemarker(); me.disableDDL(); me.pinExist = false;
                me.mapClicked = true; //me.mchktemp = false;
                me.latlngarry = JSON.parse(JSON.stringify(marker.getPosition()));
                if (marker.label.textseq != undefined) {
                    if (marker.label.textseq != me.ddlflag) {
                        me.mchktemp = false; me.txtHide = false;
                        me.tempmiddlelat = '';
                        me.tempmiddlelong = '';
                    }
                    if (marker.label.textseq == me.ddlflag && marker.label.atype == undefined) {
                       // me.mchktemp = false;
                        me.txtHide = false;
                        me.tempmiddlelat = '';
                        me.tempmiddlelong = '';
                    }
                    if (marker.label.textseq == me.ddlflag && marker.label.atype == undefined && me.mchktemp == false) {
                        me.mchktemp = false; me.txtHide = false;
                        me.tempmiddlelat = '';
                        me.tempmiddlelong = '';
                    }
                   
                    if (me.selectPlacementId == '1') { me.action = 'U'; } else { me.action = 'A';}
                    me.btnname = 'Update'; me.id = marker.label.id; me.dayposition = marker.label.pos;
                    me.flagPosId = marker.label.fpid;  me.chkactive = (marker.label.status == 'Y') ? true : false;
                    me.ddlflag = (marker.label.textseq == 'F') ? 'GF' : (marker.label.textseq == 'M') ? 'GM' : (marker.label.textseq == 'B') ? 'GB' : marker.label.textseq;
                    //let imgPath = 'assets/imgs/markers/';
                    //let imgMarkerPath = (marker.label.textseq == '1') ? imgPath + 'r1.png' : (marker.label.textseq == '2') ? imgPath + 'r2.png' : (marker.label.textseq == '3') ? imgPath + 'r3.png' :
                    //    (marker.label.textseq == '4') ? imgPath + 'r4.png' : (marker.label.textseq == '5') ? imgPath + 'r5.png' : (marker.label.textseq == '6') ? imgPath + 'r6.png':
                    //     (marker.label.textseq == 'F') ? imgPath + 'gf.png' : (marker.label.textseq == 'M') ? imgPath + 'gm.png' : imgPath + 'gb.png'

                    //marker.setIcon(imgMarkerPath);
                    me.fromdate = marker.label.fdate;
                    me.todate = marker.label.tdate;
                    //if (me.selectPlacementId == '2') {
                    //    if (marker.label.atype == 'J') { me.adjPinShow = true; } else { me.adjPinShow = false; }
                    //} 
                    
                    if (marker.label.atype == 'J') {
                        me.disableToggle();
                        me.selectPlacementId = '2';
                        me.mchktemp = true; me.txtHide = true;
                        me.tempmiddlelat = me.latlngarry.lat;
                        me.tempmiddlelong = me.latlngarry.lng;
                        me.showDelBtn = true;
                        me.prevAdjpin = true;
                    }
                    else if (me.mchktemp == true && marker.label.atype == undefined) {
                        me.enableToggle();
                        me.selectPlacementId = '2';
                        me.mchktemp = true; me.txtHide = true;
                        me.tempmiddlelat = me.latlngarry.lat;
                        me.tempmiddlelong = me.latlngarry.lng;
                    }
                    else {
                        me.enableToggle();
                        me.selectPlacementId = '1';
                        me.mchktemp = false; me.txtHide = false;
                        me.txtmiddlelat = me.latlngarry.lat;
                        me.txtmiddlelong = me.latlngarry.lng;
                        let sval = marker.label.textseq;
                        if (me.adjSeq.indexOf(sval) > -1) { me.pinExist = true; me.pinNumber = sval; }
                        else { me.pinExist = false; me.pinNumber = ''; }
                    }
                    if (me.prevAdjpin && marker.label.textseq == me.ddlflag && marker.label.atype == undefined) {
                        me.prevAdjpin = false;
                        me.enableToggle();
                        me.selectPlacementId = '1';
                        me.mchktemp = false; me.txtHide = false;
                        me.txtmiddlelat = me.latlngarry.lat;
                        me.txtmiddlelong = me.latlngarry.lng;
                        let sval = marker.label.textseq;
                        if (me.adjSeq.indexOf(sval) > -1) { me.pinExist = true; me.pinNumber = sval; }
                        else { me.pinExist = false; me.pinNumber = ''; }
                    }
                    
                }
                else {
                    me.txtmiddlelat = me.latlngarry.lat;
                    me.txtmiddlelong = me.latlngarry.lng;
                    me.ddlflag = '0'; me.action = 'A'; me.btnname = 'Save'; me.id = 0; me.dayposition = 'N'; me.flagPosId = '0';
                }
            });
        })(marker, location);
        //Add a listener for the click event
        var me = this;
        google.maps.event.addListener(marker, "dragend", function (e) {
            if(me.action!='A'){
            me.deletemarker();
            me.disableDDL();
            }
            me.pinExist = false;
            me.mapClicked = true; //me.mchktemp = false;
            me.latlngarry = JSON.parse(JSON.stringify(marker.getPosition()));
            if (marker.label.textseq != undefined) {
                //if (marker.label.textseq != me.ddlflag) {
                //    me.mchktemp = false; me.txtHide = false;
                //    me.tempmiddlelat = '';
                //    me.tempmiddlelong = '';
                //}
                //else if (marker.label.textseq == me.ddlflag && marker.label.atype == undefined && me.mchktemp == false) {
                //    me.mchktemp = false; me.txtHide = false;
                //    me.tempmiddlelat = '';
                //    me.tempmiddlelong = '';
                //}

                if (marker.label.textseq != me.ddlflag) {
                    me.mchktemp = false; me.txtHide = false;
                    me.tempmiddlelat = '';
                    me.tempmiddlelong = '';
                }
                if (marker.label.textseq == me.ddlflag && marker.label.atype == undefined) {
                    // me.mchktemp = false;
                    me.txtHide = false;
                    me.tempmiddlelat = '';
                    me.tempmiddlelong = '';
                }
                if (marker.label.textseq == me.ddlflag && marker.label.atype == undefined && me.mchktemp == false) {
                    me.mchktemp = false; me.txtHide = false;
                    me.tempmiddlelat = '';
                    me.tempmiddlelong = '';
                }

                if (me.selectPlacementId == '1') { me.action = 'U'; } else { me.action = 'A'; }
                 me.btnname = 'Update'; me.id = marker.label.id; me.dayposition = marker.label.pos;
                me.flagPosId = marker.label.fpid; me.fromdate = marker.label.fdate; me.todate = marker.label.tdate; me.chkactive = (marker.label.status == 'Y') ? true : false;
                me.ddlflag = (marker.label.textseq == 'F') ? 'GF' : (marker.label.textseq == 'M') ? 'GM' : (marker.label.textseq == 'B') ? 'GB' : marker.label.textseq;
                //let imgPath = 'assets/imgs/markers/';
                //let imgMarkerPath = (marker.label.textseq == '1') ? imgPath + 'r1.png' : (marker.label.textseq == '2') ? imgPath + 'r2.png' : (marker.label.textseq == '3') ? imgPath + 'r3.png' :
                //    (marker.label.textseq == '4') ? imgPath + 'r4.png' : (marker.label.textseq == '5') ? imgPath + 'r5.png' : (marker.label.textseq == '6') ? imgPath + 'r6.png' :
                //        (marker.label.textseq == 'F') ? imgPath + 'gf.png' : (marker.label.textseq == 'M') ? imgPath + 'gm.png' : imgPath + 'gb.png'

                //marker.setIcon(imgMarkerPath);
                if (marker.label.atype == 'J') {
                    me.disableToggle();
                    me.selectPlacementId = '2';
                    me.mchktemp = true; me.txtHide = true;
                    me.tempmiddlelat = me.latlngarry.lat;
                    me.tempmiddlelong = me.latlngarry.lng;
                    me.showDelBtn = true;
                    me.prevAdjpin = true;
                }
                else if (me.mchktemp == true && marker.label.atype == undefined) {
                    me.enableToggle();
                    me.selectPlacementId = '2';
                    me.mchktemp = true; me.txtHide = true;
                    me.tempmiddlelat = me.latlngarry.lat;
                    me.tempmiddlelong = me.latlngarry.lng;
                }
                else {
                    me.enableToggle();
                    me.selectPlacementId = '1';
                    me.mchktemp = false; me.txtHide = false;
                    me.txtmiddlelat = me.latlngarry.lat;
                    me.txtmiddlelong = me.latlngarry.lng;
                    let sval = marker.label.textseq;
                    if (me.adjSeq.indexOf(sval) > -1) { me.pinExist = true; me.pinNumber = sval; }
                    else { me.pinExist = false; me.pinNumber = ''; }
                }

                if (me.prevAdjpin && marker.label.textseq == me.ddlflag && marker.label.atype == undefined) {
                    me.prevAdjpin = false;
                    me.enableToggle();
                    me.selectPlacementId = '1';
                    me.mchktemp = false; me.txtHide = false;
                    me.txtmiddlelat = me.latlngarry.lat;
                    me.txtmiddlelong = me.latlngarry.lng;
                    let sval = marker.label.textseq;
                    if (me.adjSeq.indexOf(sval) > -1) { me.pinExist = true; me.pinNumber = sval; }
                    else { me.pinExist = false; me.pinNumber = ''; }
                }
                
                //if (me.selectPlacementId == '2') {
                //    if (marker.label.atype == 'J') { me.adjPinShow = true; } else { me.adjPinShow = false; }
                //} 
            }
            else {
                me.txtmiddlelat = me.latlngarry.lat;
                me.txtmiddlelong = me.latlngarry.lng;
                me.ddlflag = '0'; me.action = 'A'; me.btnname = 'Save'; me.id = 0; me.dayposition = 'N'; me.flagPosId = '0';
            }
        })

    }

    deletemarker() {
        for (var i = 0; i < this.markers.length; i++) {
            if (this.markers[i].label == '') {
                this.markers[i].setMap(null);
            }
            //else {
            //    let lblval = (this.markers[i].label.textseq == undefined) ? 'M' : '';
            //    if (lblval == this.radiobtn) {
            //        this.markers[i].setMap(null);
            //    }
            //}
        }
    }

    // Sets the map on all markers in the array.
    setMapOnAll(map) {
        for (var i = 0; i < this.markers.length; i++) {
            this.markers[i].setMap(map);
        }
    }

    // Removes the markers from the map, but keeps them in the array.
    clearMarkers() {
        this.setMapOnAll(null);
        this.markers = [];
    }

    holeperimetersdrawpolyline() {
        this.flightPath = new google.maps.Polyline({
            path: this.holepolylinecoordinates,
            //editable:true,
            geodesic: true,
            strokeColor: '#FF0000',
            strokeOpacity: 1.0,
            strokeWeight: 2
        });
        this.line.push(this.flightPath);
        this.flightPath.setMap(this.map);
    }

    getholeflagpositions() {
        this.spinnerService.show();
        this.submitAttempt = false;
        this.clearMarkers()
        let latlng = {};
        let parameters = {
            //searchvalue: " WHERE  FP_GCB_ID='" + this.golfclubid + "' AND FP_GC_ID='" + this.courseid + "' AND FP_HD_ID='" + this.holeid + "' AND FP_SEQUENCE='" + this.ddlflag + "' "
            searchvalue: " WHERE  FP_GCB_ID='" + this.golfclubid + "' AND FP_GC_ID='" + this.courseid + "' AND FP_HD_ID='" + this.holeid + "' AND FP_STATUS='Y'"

        };
        this.api.postOH('getholeflagdetails', parameters).subscribe(
            (response) => {
                this.holeflagdetails = []; this.ddlflagpos = [];
                if (response.length > 0) {
                    this.clearallvales();
                    this.holeflagdetails = response;
                    for (var i = 0; i < response.length; i++) {
                        this.action = 'U';
                        this.id = response[i].id;
                        this.txtsequence = response[i].sequence;
                        this.txtfrontlat = response[i].frontlatitude;
                        this.txtfrontlong = response[i].frontlongitude;

                         //latlng={lat:parseFloat(this.txtfrontlat),lng:parseFloat(this.txtfrontlong)};
                         //this.labelname={textseq:'F',color:'white'};
                         //this.image='';
                         //this.addMarker(latlng);

                        this.txtmiddlelat = response[i].middlelatitude;
                        this.txtmiddlelong = response[i].middlelongitude;
                        this.txtbacklat = response[i].backlatitude;
                        this.txtbacklong = response[i].backlongitude;

                        //latlng={lat:parseFloat(this.txtbacklat),lng:parseFloat(this.txtbacklong)};
                        //this.labelname={textseq:'B',color:'white'};
                        //this.image='';
                        //this.addMarker(latlng);

                        this.chkactive = (response[i].status == 'Y') ? true : false;
                        this.dayposition = response[i].dayposition;
                        this.activecontrol = "block";
                        this.btnname = "Update";
                        //this.radiobtn='M';
                        let currentDate: any = '';
                        let d = new Date();
                        let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
                        currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
                        latlng = { lat: parseFloat(this.txtmiddlelat), lng: parseFloat(this.txtmiddlelong) };
                        this.labelname = {
                            text: ".",
                            textseq: '' + this.txtsequence + '',
                            color: '222222',//'#EB2125',
                            id: '' + this.id + '',
                            pos: '' + this.dayposition + '',
                            fpid: '' + this.id + '',
                            fdate: '' + moment(new Date(currentDate)).format('MM.DD.YYYY') + '', //this.convertDate2(new Date(Date.now()))
                            tdate: '' + moment(new Date(currentDate)).format('MM.DD.YYYY') + '', //this.convertDate2(new Date(Date.now()))
                            status: 'Y'
                            
                        };
                        //this.image = '';
                        let imgPath = 'assets/imgs/markers/';
                        this.image = (this.txtsequence == '1') ? imgPath + 'b1.png' : (this.txtsequence == '2') ? imgPath + 'b2.png' : (this.txtsequence == '3') ? imgPath + 'b3.png' :
                            (this.txtsequence == '4') ? imgPath + 'b4.png' : (this.txtsequence == '5') ? imgPath + 'b5.png' : imgPath + 'b6.png';
                        this.addMarker(latlng);
                    }
                    //if (this.selectPlacementId != '2') {
                    //    if (this.holeflagdetails.length > 0) {
                    //        for (let i = 0; i < this.holeflagdetails.length; i++) {
                    //            this.ddlflagpos.push({
                    //                "id": this.holeflagdetails[i].sequence,
                    //                "name": "position " + this.holeflagdetails[i].sequence,
                    //            });
                    //        }
                    //    }

                    //    this.getPinAdjustment();
                    //}
                    //else if (this.selectPlacementId == '1') {
                    //    this.ddlflagpos = [
                    //        { "id": '1', "name": 'Position 1' },
                    //        { "id": '2', "name": 'Position 2' },
                    //        { "id": '3', "name": 'Position 3' },
                    //        { "id": '4', "name": 'Position 4' },
                    //        { "id": '5', "name": 'Position 5' },
                    //        { "id": '6', "name": 'Position 6' },
                    //        { "id": 'GF', "name": 'Green Front' },
                    //        { "id": 'GM', "name": 'Green Middle' },
                    //        { "id": 'GB', "name": 'Green Back' }
                    //    ];
                    //}
                    this.getPinAdjustment();
                    this.ddlflagpos = [
                            { "id": '1', "name": 'Position 1' },
                            { "id": '2', "name": 'Position 2' },
                            { "id": '3', "name": 'Position 3' },
                            { "id": '4', "name": 'Position 4' },
                            { "id": '5', "name": 'Position 5' },
                            { "id": '6', "name": 'Position 6' },
                            { "id": 'GF', "name": 'Green Front' },
                            { "id": 'GM', "name": 'Green Middle' },
                            { "id": 'GB', "name": 'Green Back' }
                        ];
                }
                else {
                    this.clearallvales();
                    if (this.selectPlacementId != '3') {
                        let msg = '<span style="color:red">No Assigned Pin for #Hole-' + this.selectHoleId + '</span>';
                        this.toastMessage(msg);
                    //}
                    //else if (this.selectPlacementId == '1') {
                        this.ddlflagpos = [
                            { "id": '1', "name": 'Position 1' },
                            { "id": '2', "name": 'Position 2' },
                            { "id": '3', "name": 'Position 3' },
                            { "id": '4', "name": 'Position 4' },
                            { "id": '5', "name": 'Position 5' },
                            { "id": '6', "name": 'Position 6' },
                            { "id": 'GF', "name": 'Green Front' },
                            { "id": 'GM', "name": 'Green Middle' },
                            { "id": 'GB', "name": 'Green Back' }
                        ];
                    }
                }
                this.spinnerService.hide();
            }, error => {
                this.spinnerService.hide();
            });
    }

   

    clearallvales() {
        this.action = 'A';
        this.id = 0;
        this.txtfrontlat = "";
        this.txtfrontlong = "";
        this.txtmiddlelat = "";
        this.txtmiddlelong = "";
        this.txtbacklat = "";
        this.txtbacklong = "";
        this.chkactive = false;
        this.activecontrol = "none";
        this.btnname = "Save";
        this.radiobtn = '';
        this.btnsavedisable = false;
    }

    savePinAdjustment() {
        let active = 'Y';
        if (this.adjholeflagForm.valid) {
       
            if (this.action == 'D') {
                this.action = 'D'; active = 'D';
            }
            else if (this.action == 'U') {
                this.action = 'A'; active = 'Y';
            }
            else {
                this.action = 'A'; active = 'Y'; this.id = 0;
            }
            //else {
            //    if (this.chkactive == true) { this.action = 'A'; }
            //    else { this.action = 'U'; }
            //}

            //else if (this.ddlflag != 'GM' && this.ddlflag != 'GB' && this.ddlflag != 'GF' && this.txtHide == true) {
                let fdate = moment(this.fromdate).format('MM/DD/YYYY');//this.dateformats(this.fromdate);
                let todate = moment(this.todate).format('MM/DD/YYYY'); //this.dateformats(this.todate);
                //if (active == 'N' && this.action != 'D') { this.action = 'U'; }
                var flagpositionadjustmentmodel = {
                    "action": this.action,
                    "id": this.id,
                    "holeid": this.HolesEditInfo[0].id,
                    "flagPositionid": this.flagPosId,
                    "lat": this.tempmiddlelat,
                    "lng": this.tempmiddlelong,
                    "fromdate": fdate, //fdate+" 00:00:00 am",
                    "todate": todate, //todate + " 00:00:00 am",
                    "status": active,
                    "createdid": localStorage.getItem('userId')

                }
                this.apiCall('flagpositionadjustment', flagpositionadjustmentmodel);
               
              // }
        }
    }

    savedata() {
        if (!this.holeflagForm.valid) {
        }
        this.submitAttempt = true;
        if (this.ddlflag != '0') {
            if (this.holeflagForm.valid) {
                this.spinnerService.show();
                //this.btnsavedisable = true;
                //if (this.selectPlacementId == '2') {
                //    if (this.action == 'D') {
                //        this.action = 'D'; active = 'N';
                //    }
                //    else {
                //        if (this.chkactive == true) { this.action = 'A'; }
                //        else { this.action = 'U'; }
                //    }
                //}
               
                var active = '';
                if (this.action == 'A') {
                    active = 'Y';
                    this.dayposition = 'N';
                    this.txtsequence = this.ddlflag;
                }
                else if (this.action == 'D') {
                    this.action = 'D'; active = 'D';
                }
                else {
                    active = (this.chkactive == true) ? 'Y' : 'N';
                }
                if (this.ddlflag != 'GM' && this.ddlflag != 'GB' && this.ddlflag != 'GF' && this.txtHide == false) {
                    var holeflagdetailsmodel = {
                        "action": this.action, "id": this.id, "golfclubid": this.golfclubid, "golfcourseid": this.courseid, "holeid": this.holeid, "sequence": this.ddlflag,
                        "frontlatitude": this.txtfrontlat, "frontlongitude": this.txtfrontlong, "middlelatitude": this.txtmiddlelat, "middlelongitude": this.txtmiddlelong,
                        "backlatitude": this.txtbacklat, "backlongitude": this.txtbacklong, "dayposition": this.dayposition, "updtaedid": localStorage.getItem('userId'), "status": active
                    }
                   this.apiCall('saveholeflagdetails', holeflagdetailsmodel);
                    
                }
                //else if (this.ddlflag != 'GM' && this.ddlflag != 'GB' && this.ddlflag != 'GF' && this.txtHide == true) {
                //    let fdate = moment(this.fromdate).format('MM/DD/YYYY');//this.dateformats(this.fromdate);
                //    let todate = moment(this.todate).format('MM/DD/YYYY'); //this.dateformats(this.todate);
                //    if (active == 'N' && this.action != 'D') { this.action = 'U'; }
                //    var flagpositionadjustmentmodel = {
                //        "action": this.action,
                //        "id": this.id,
                //        "holeid": this.HolesEditInfo[0].id,
                //        "flagPositionid": this.flagPosId,
                //        "lat": this.tempmiddlelat,
                //        "lng": this.tempmiddlelong,
                //        "fromdate": fdate, //fdate+" 00:00:00 am",
                //        "todate": todate, //todate + " 00:00:00 am",
                //        "status": active,
                //        "createdid": localStorage.getItem('userId')

                //    }
                //    //this.apiCall('flagpositionadjustment', flagpositionadjustmentmodel);
                //    console.log(flagpositionadjustmentmodel);
                //}
                else {
                    let gmlat = '', gmlong = '', gflat = '', gflong = '', gblat = '', gblong = '';
                    if (this.ddlflag == 'GM') {
                        gmlat = this.txtmiddlelat;
                        gmlong = this.txtmiddlelong;
                        gflat = this.HolesEditInfo[0].gflatitude;
                        gflong = this.HolesEditInfo[0].gflongitude;
                        gblat = this.HolesEditInfo[0].gblatitude;
                        gblong = this.HolesEditInfo[0].gblongitude;
                    }
                    else if (this.ddlflag == 'GF') {
                        gflat = this.txtmiddlelat;
                        gflong = this.txtmiddlelong;
                        gmlat = this.HolesEditInfo[0].gmlatitude;
                        gmlong = this.HolesEditInfo[0].gmlongitude;
                        gblat = this.HolesEditInfo[0].gblatitude;
                        gblong = this.HolesEditInfo[0].gblongitude;
                    }
                    else if (this.ddlflag == 'GB') {
                        gblat = this.txtmiddlelat;
                        gblong = this.txtmiddlelong;
                        gflat = this.HolesEditInfo[0].gflatitude;
                        gflong = this.HolesEditInfo[0].gflongitude;
                        gmlat = this.HolesEditInfo[0].gmlatitude;
                        gmlong = this.HolesEditInfo[0].gmlongitude;
                    }
                    var holesmodel = {
                        "action": 'U', "id": this.HolesEditInfo[0].id, "golfclubid": this.HolesEditInfo[0].golfclubid, "golfcourseid": this.HolesEditInfo[0].golfcourseid, "holename": this.HolesEditInfo[0].holename,
                        "parval": this.HolesEditInfo[0].parval, "menhandicap": this.HolesEditInfo[0].menhandicap, "womenhandicap": this.HolesEditInfo[0].womenhandicap, "clatitude": this.HolesEditInfo[0].clatitude, "clongitude": this.HolesEditInfo[0].clongitude,
                        "gflatitude": gflat, "gflongitude": gflong, "gmlatitude": gmlat, "gmlongitude": gmlong,
                        "gblatitude": gblat, "gblongitude": gblong, "gzoomlevel": this.HolesEditInfo[0].gzoomlevel,
                        "zoomlevel": this.HolesEditInfo[0].zoomlevel, "rotate": (this.HolesEditInfo[0].rotate == '') ? '0' : this.HolesEditInfo[0].rotate, "sequence": this.HolesEditInfo[0].sequence, "paceofplay":this.HolesEditInfo[0].paceofplay,
                        "overlineimage": this.HolesEditInfo[0].overlineimage, "overlinebinaryimage": "", "updtaedid": localStorage.getItem('userId'), "status": 'Y', "contentbox": this.HolesEditInfo[0].contentbox,

                        "mholeclatitude": this.HolesEditInfo[0].mholeclatitude, "mholeclongitude": this.HolesEditInfo[0].mholeclongitude, "mholezoomlevel": this.HolesEditInfo[0].mholezoomlevel,
                        "mholesecondclatitude": this.HolesEditInfo[0].mholesecondclatitude, "mholesecondclongitude": this.HolesEditInfo[0].mholesecondclongitude, "mholesecondzoomlevel": this.HolesEditInfo[0].mholesecondzoomlevel,
                        "mholethirdclatitude": this.HolesEditInfo[0].mholethirdclatitude, "mholethirdclongitude": this.HolesEditInfo[0].mholethirdclongitude, "mholethirdzoomlevel": this.HolesEditInfo[0].mholethirdzoomlevel
                    }
                    this.apiCall('saveholes', holesmodel);
                    
                }
               
                this.spinnerService.hide();
            }
        }
       
    }

    deleteflagpositon(type) {
        this.action = 'D';
        if (type == 'A') { this.savedata(); }
        else if (type == 'J') { this.savePinAdjustment(); }
    }

    apiCall(methodname, modal) {
        this.api.postOH(methodname, modal).subscribe(
            (response) => {
                if (response[0] > 0) {
                    if (this.action == 'A') {
                        let msg = '<span style="color: green">Pin Placement Added Successfully</span>';
                        this.toastMessage(msg);
                    }
                    else if(this.action == 'U') {
                        let msg = '<span style="color: green">Pin Placement Updated Successfully</span>';
                        this.toastMessage(msg);
                    }
                    else if(this.action == 'D') {
                        let msg = '<span style="color: green">Pin Placement Deleted Successfully</span>';
                        this.toastMessage(msg);
                    }
                    //this.btnsavedisable = false;
                    //this.getholeflagpositions();
                    //this.getholeflags();
                    let parameters = {
                        searchvalue: " WHERE  HD_GCB_ID='" + this.golfclubid + "' AND HD_GC_ID='" + this.courseid + "' and HD_ID='" + this.holeid + "' "
                    };
                    this.GetHoleLatLongDetails(parameters);
                    this.mapClicked = false;
                } else {
                    if(response[0]==0){
                        let msg = '<span style="color: red">Unable to process your request!</span>';
                        this.toastMessage(msg);
                    }else if(response[0]==-2){
                        let msg = '<span style="color: red">Pin Placement Already Exist or Unable to process your request!</span>';
                        this.toastMessage(msg);
                    }                    
                   // this.btnsavedisable = false;
                }
                this.spinnerService.hide();
            },
            error => {
                //this.btnsavedisable = false;
                this.spinnerService.hide();
            }
        );
    }

    //from naveen

   Coursemaploading() {
        let courseLat = localStorage.getItem('courseLat');
        let courseLong = localStorage.getItem('courseLong');
        let courseZoomlevel = localStorage.getItem('courseZoomlevel');
        
        this.map = new google.maps.Map(document.getElementById('map'), {
            center: { lat: parseFloat(courseLat), lng: parseFloat(courseLong) },
            zoom: parseInt(courseZoomlevel),
            //disableDefaultUI: true,
            mapTypeId: 'satellite',
            tilt: 0,
            rotateControl: true
        });
        this.setoverlayimage();
        
    }

    getHoles() {
        let parameters = { searchvalue: " WHERE HD_GCB_ID=" + this.golfclubid + " AND HD_GC_ID = " + this.courseid + " AND HD_STATUS='Y'" };
        this.spinnerService.show();
        this.api.postOH('getholes', parameters).subscribe(
            response => {
               this.spinnerService.hide();
                if (response.length !== 0) {
                    this.HolesInfo = [];
                    for (let i = 0; i < response.length; i++) {
                        this.HolesInfo.push({
                            "id": response[i].id,
                            "holename": response[i].holename,
                            "flagpostion": response[i].flagpostion,
                            "clatitude": response[0].clatitude,
                            "clongitude": response[0].clongitude,
                            "gflatitude": response[0].gflatitude,
                            "gflongitude": response[0].gflongitude,
                            "gmlatitude": response[0].gmlatitude,
                            "gmlongitude": response[0].gmlongitude,
                            "gblatitude": response[0].gblatitude,
                            "gblongitude": response[0].gblongitude,
                           });
                    }
                    if (this.fhid == '0') {
                        this.holeid = this.HolesInfo[0].id;
                        this.selectHoleId = this.HolesInfo[0].holename;
                        this.fhid = this.HolesInfo[0].id;
                        this.fhname = this.HolesInfo[0].holename;
                    }
                    else {
                        this.holeid = this.fhid;
                        this.selectHoleId = this.fhname;
                    }
                    
                    let parameters = {
                        expression: " WHERE  HP_GC_ID='" + this.courseid + "' and HP_HD_ID='" + this.holeid + "' "
                    }
                    this.getholeperimetersdata(parameters);

                } else {
                    this.Coursemaploading();
                }
            },
            err => {

            }
        );
    }

    viewHoles(hole) {
        this.mapClicked = false;
        this.selectHoleId = hole.holename;
        this.holeid = hole.id;
        this.fhid = hole.id;
        this.fhname = hole.holename;
        let parameters = {
            expression: " WHERE  HP_GC_ID='" + this.courseid + "' and HP_HD_ID='" + this.holeid + "' "
        }
        this.getholeperimetersdata(parameters);
        
    }

    selectPlacementType(pId) {
        this.mapClicked = false;
        this.NoMaploading = false;
        if (this.seletedFlagChange == '1') {
            this.openModal(pId);
        }
        else {
            this.seletedFlagChange = '0';
            if (pId == '1' || pId == '2' ) {
                this.adjPinShow = true;
                this.lblmaptext = "Click on Map to assign new pin position. Drag or Click on existing pin to update pin position or create temporary pin.";
                //this.selectPlacementId = pId;
                //this.txtHide = false;
                //this.getHoles();

            //}
            //else if (pId == '2') {
                //this.adjPinShow = false;
                //this.lblmaptext = " Drag or Click on existing pin for pin adjusment.";
                this.getHoles();
                this.selectPlacementId = pId;
                //this.txtHide = true;
                let currentDate: any = '';
                let d = new Date();
                let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
                currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));

                this.fromdate = moment(new Date(currentDate)).format('MM.DD.YYYY');//this.convertDate2(new Date(Date.now()));
                this.todate = moment(new Date(currentDate)).format('MM.DD.YYYY');//this.convertDate2(new Date(Date.now()));
            }
            else {
                this.selectPlacementId = pId;
                this.pinSchedule();
             }
        }
        
    }

    closeFlag() {
        this.mapClicked = false;
        //this.NoMaploading = true;
        this.getHoles();
    }

    getPinAdjustment() {
        let parameters = { searchvalue: " WHERE FPA_H_ID =" + this.holeid + " and FPA_STATUS='Y'" };
        this.spinnerService.show();
        this.api.postOH('getlflagpositionAdjustment', parameters).subscribe(
            response => {
                this.spinnerService.hide();
                this.pinAdjustment = [];
                if (response.length !== 0) {
                   for (let i = 0; i < response.length; i++) {
                        this.pinAdjustment.push({
                            "id": response[i].id,
                            "holeid": response[i].holeid,
                            "flagPositionid": response[i].flagPositionid,
                            "flagsequenceid": response[i].flagsequenceid,
                            "lat": response[i].lat,
                            "lng": response[i].lng,
                            "fromdate": this.splitDate(response[i].fromdate), //"05/12/2018", 
                            "todate": this.splitDate(response[i].todate),//"05/15/2018"
                            "status": response[i].status
                        });
                    }
                   this.getPinAdjustmentonMaps();

                } else {

                }
            },
            err => {
                this.spinnerService.hide();
            }
        );
    }

    getPinAdjustmentonMaps() {
        let arrAdjPin = []; 
        let currentDate: any = '';
        let d = new Date();
        let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
        currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
        for (var i = 0; i < this.pinAdjustment.length; i++) {
            let daysCount = this.dateDiff(this.pinAdjustment[i].fromdate, this.pinAdjustment[i].todate);
            if (this.pinAdjustment[i].fromdate == this.convertDate(currentDate) || daysCount > 0) {
                arrAdjPin.push(this.pinAdjustment[i].flagsequenceid);
                let latlng = { lat: parseFloat(this.pinAdjustment[i].lat), lng: parseFloat(this.pinAdjustment[i].lng) };
                this.labelname = {
                    text:'.',
                    textseq: '' + this.pinAdjustment[i].flagsequenceid + '',
                    color: '#2185EB',
                    id: '' + this.pinAdjustment[i].id + '',
                    fpid: '' + this.pinAdjustment[i].flagPositionid + '',
                    fdate: '' + moment(this.pinAdjustment[i].fromdate).format('MM.DD.YYYY') + '',//this.dateformats2(this.pinAdjustment[i].fromdate)
                    tdate: '' + moment(this.pinAdjustment[i].todate).format('MM.DD.YYYY') + '',//this.dateformats2(this.pinAdjustment[i].todate)
                    status: '' + this.pinAdjustment[i].status + '',
                    atype: 'J'
                };

                let imgPath = 'assets/imgs/markers/';
                this.image = (this.pinAdjustment[i].flagsequenceid == '1') ? imgPath + 'bl1.png' : (this.pinAdjustment[i].flagsequenceid == '2') ? imgPath + 'bl2.png' : (this.pinAdjustment[i].flagsequenceid == '3') ? imgPath + 'bl3.png' :
                    (this.pinAdjustment[i].flagsequenceid == '4') ? imgPath + 'bl4.png' : (this.pinAdjustment[i].flagsequenceid == '5') ? imgPath + 'bl5.png' : imgPath + 'bl6.png';
                this.addMarker(latlng);
            }
        }
        if (arrAdjPin.length > 0) {
            this.adjSeq = arrAdjPin.join(",");
        }
        else { this.adjSeq = ''; }
    }

    pinSchedule() {
        let currentDate: any = '';
        let dt = new Date();
        let utc = dt.getTime() + (dt.getTimezoneOffset() * 60000);
        currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
         var start = new Date(currentDate),
            end = this.addDays(start, 30),
            year = start.getFullYear(),
            month = start.getMonth(),
            day = start.getDate(),
            dates = [start];
        var dd = [];
        this.datesinfo = [];
        for (let i = 1; i < 7; i++) {
            this.datesinfo.push({
                id: i, fselected: false, date: this.convertDate(start)
            });
        }
        dd.push({
            date: this.convertDate(start),
            finfo: this.datesinfo,
            rid: '0',
            rcount: 0,
            btntext: 'Save',
            selectedFlag: 1,
            bgcolor: '#1ab394',
            title: 'Save',
            action: 'A'
        });
        while (dates[dates.length - 1] < end) {
            var d = new Date(year, month, ++day);
            // d.getDate();
            dates.push(d);
            this.datesinfo = [];
            for (let i = 1; i < 7; i++) {
                this.datesinfo.push({
                    id: i, fselected: false, date: this.convertDate(d)
                });
            }
            dd.push({
                date: this.convertDate(d),
                finfo: this.datesinfo,
                rid: '0',
                rcount: 0,
                btntext: 'Save',
                selectedFlag: 1,
                bgcolor: '#1ab394',
                title: 'Save',
                action:'A'
            });
        }
        this.dates = dd;
        this. bindPinScheduleinfo();
    }

    bindPinScheduleinfo() {
        this.spinnerService.show();
        let currentDate: any = '';
        let dt = new Date();
        let utc = dt.getTime() + (dt.getTimezoneOffset() * 60000);
        currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
        let parameters = { searchvalue: ' WHERE FPS_GCB_ID =' + this.golfclubid + ' AND FPS_GC_ID=' + this.courseid + '' };
        this.api.postOH('getlflagpositionschedul', parameters).subscribe(
            response => {
                 if (response.length !== 0) {
                    this.flagScheduleInfo = [];
                    for (let i = 0; i < response.length; i++) {
                        this.flagScheduleInfo.push({
                            "rid": response[i].id,
                            "date": this.splitDate(response[i].date),
                            "selectedFlag": response[i].flagposition,
                            "rcount":1
                        });
                    }
                    if (this.flagScheduleInfo.length > 0) {
                        for (let j = 0; j < this.dates.length; j++) {
                            for (let k = 0; k < this.flagScheduleInfo.length; k++) {
                                if (this.dates[j].date == this.flagScheduleInfo[k].date) {
                                  if (this.convertDate(currentDate) == this.flagScheduleInfo[k].date) { this.todayActiveFlag = this.flagScheduleInfo[k].selectedFlag; }
                                    this.dates[j].rid = this.flagScheduleInfo[k].rid;
                                    this.dates[j].rcount = 1;
                                    this.dates[j].btntext = 'Update';
                                    this.dates[j].selectedFlag = this.flagScheduleInfo[k].selectedFlag;
                                    this.dates[j].bgcolor = "#2c8013";
                                    this.dates[j].title = 'Update';
                                    this.dates[j].action = 'U';
                                    let c = this.flagScheduleInfo[k].selectedFlag;
                                    if (c > 0) {
                                        this.dates[j].finfo[this.flagScheduleInfo[k].selectedFlag - 1].fselected = true;
                                    }
                                  
                                }
                            }
                        }
                    }
                  
                  this.spinnerService.hide();
                 }
                 else {
                    this.spinnerService.hide();
                }
                 if (!this.pageChecked) {
                     this.saveFlag();
                 }
                
            },
            err => {
                this.spinnerService.hide();
            });
          
     }
    
    onSelectionChange(fpos, index) {
        this.seletedFlagChange = '1';
        this.dates[index].rcount = '1';
        this.dates[index].selectedFlag = fpos;
        if (this.dates[index].action == 'U') { this.dates[index].bgcolor = "#337ab7"; }
    }

    saveFlag() {
            this.seletedFlagChange = '0';
            this.flagScheduleArr = [];
            if (this.dates.length > 0) {
                for (let i = 0; i < this.dates.length; i++) {
                    this.flagScheduleArr.push({
                        "FPS_ACTION_T": this.dates[i].action,
                        "FPS_ID_T": this.dates[i].rid,
                        "FPS_GCB_ID_T": this.golfclubid,
                        "FPS_GC_ID_T": this.courseid,
                        "FPS_FP_SEQ_T": this.dates[i].selectedFlag,
                        "FPS_DATE_T": this.dateformats3(this.dates[i].date) + " 00:00:00 am",
                        "FPS_STATUS_T": 'Y'
                    });
                }
            }

            var flagpositionschedulemodel = { "flagposition": this.flagScheduleArr };
            this.api.postOH("saveflagpositionschedule1", flagpositionschedulemodel).subscribe(
                (response) => {
                    if (response.saveflagpositionschedule1Result[0] == 1) {
                        let msg = '<span style="color: green">Pin Placement Schedule Saved Successfully</span>';
                        if (!this.pageChecked) {
                            this.pageChecked = true;
                         }
                        else { this.toastMessage(msg); }
                        this.bindPinScheduleinfo();
                     } else {
                        let msg = '<span style="color: red">Couldn\'t process your request,Please try again!</span>';
                        if (!this.pageChecked) {
                            this.pageChecked = true;
                        }
                        else { this.toastMessage(msg); }
                    }
                    this.spinnerService.hide();
                },
                error => {
                    let msg = '<span style="color: red">Couldn\'t process your request,Please try again!</span>';
                    if (!this.pageChecked) {
                        this.pageChecked = true;
                    }
                    else { this.toastMessage(msg); }
                     this.spinnerService.hide();
                }
            );
    }

   

    splitDate(dateTime) {
        var dateTime = dateTime.split(" ");
        var date = dateTime[0];
        return date;
    }

    dateformats(val) {
        this.datearry = val.split("-");
        var strdate = this.datearry[2] + "/" + this.datearry[1] + "/" + this.datearry[0].substring(2);
        return strdate;
    }

    dateformats2(val) {
        this.datearry = val.split("/");
        var strdate = this.datearry[2] + "-" + this.datearry[0] + "-" + this.datearry[1];
        return strdate;
    }

    dateformats3(val) {
        this.datearry = val.split("/");
        var strdate = this.datearry[1] + "/" + this.datearry[0] + "/" + this.datearry[2].substring(2);
        return strdate
    }

    convertDate2(d) {
        var  month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;

        return [year,month, day].join('-');
    }

    convertDate(d) {
        var month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;

        return [month, day, year].join('/');
    }

    addDays(startDate, numberOfDays) {
        var returnDate = new Date(
								    startDate.getFullYear(),
								    startDate.getMonth(),
								    startDate.getDate() + numberOfDays,
								    startDate.getHours(),
								    startDate.getMinutes(),
            startDate.getSeconds());

        var d = new Date(returnDate.toDateString());
        return d;
    }

    dateDiff(fromdate,todate) {
        var date1 = new Date(fromdate);
        var date2 = new Date(todate);
        var timeDiff = Math.abs(date2.getTime() - date1.getTime());
        var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
        return diffDays;
    }

    toastMessage(msg) {
        let options = {
            positionClass: 'toast-top-center',
        };

        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 3000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }

    openModal(pid) {
        this.typeValue = pid;
        if (pid != '3') {
            this.modalRef = this.modalService.show(this.template, { class: 'modal-sm' });
        }
     }

    decline(typeValue) {
        this.seletedFlagChange = '0';
        this.modalRef.hide();
        this.selectPlacementId = typeValue;
        this.selectPlacementType(this.selectPlacementId);
    }

    confirm(typeValue) {
        this.modalRef.hide();
        this.saveFlag();
        this.seletedFlagChange = '0';
        this.selectPlacementId = typeValue;
        this.selectPlacementType(this.selectPlacementId);
    }

    flagDeleteModal(type) {
       this.delFlag = type;
       this.modalRef = this.modalService.show(this.template1, { class: 'modal-sm' });
    }


    declineDelete() {
        this.modalRef.hide();
    }

    confirmDelete() {
        this.modalRef.hide();
        this.deleteflagpositon(this.delFlag);
      }

    changests(e) {
        let chksts = (e.target.checked == true) ? "Y" : "N";
        if (chksts == "Y") {
            this.txtHide = true; this.selectPlacementId = '1';
            this.tempmiddlelat = this.txtmiddlelat;
            this.tempmiddlelong = this.txtmiddlelong;
            this.showDelBtn = false;
        }
        else {
            this.txtHide = false; this.selectPlacementId = '2';
            this.showDelBtn = true;
            //this.tempmiddlelat = '';
            //this.tempmiddlelong ='';
        }
    }

    disableDDL() {
        this.holeflagForm.controls['ddlpos'].disable();
    }

    enableDDL() {
        this.holeflagForm.controls['ddlpos'].enable();
    }

    disableToggle() {
         this.holeflagForm.controls['chktemp'].disable();
    }

    enableToggle() {
        this.holeflagForm.controls['chktemp'].enable();
    }

}
