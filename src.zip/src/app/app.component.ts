import { Component, OnInit, Input, Injectable, ViewContainerRef, TemplateRef } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from './services/auth.service';
import { JwtService } from './services/jwt.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})

export class AppComponent {
  headdiv: boolean = true;pagepermission:any="";
  submenuinfo: boolean = true;modules: any = []; submodules: any = []; pagename: string; innermodules: any = []; innerpagename: string; mainsubmoduleslist: any = [];
  constructor(private _activatedRoute: ActivatedRoute, public toastr: ToastsManager, vcr: ViewContainerRef,
    private router: Router, private authService: AuthService, private jwt: JwtService, private spinnerService: Ng4LoadingSpinnerService) {
      this.toastr.setRootViewContainerRef(vcr);
      this.getinnerpageslist();

    this.authService.getUserName.subscribe(
      (name: string) => {
        if (name === undefined || name === '' || name === null) {
          this.headdiv = false;
          this.submenuinfo = false;
        } else {
          this.headdiv = true;
          this.submenuinfo = true;
        }

      }
    );
    this.jwt.getUserId.subscribe(
      (name: string) => {
        if (name === undefined || name === '' || name === null) {
          this.headdiv = false;
          this.submenuinfo = false;
        } else {
          this.headdiv = true;
          this.submenuinfo = true;
        }
      }
    );    
  }

  ngOnInit() {
    let uid=localStorage.getItem('userId');
    if (uid != '' && uid != undefined && uid != null) { 
      this.enabledpages();     
    }else{
      this.router.navigate(['/login']);
    }
  }

  getinnerpageslist() {
    this.innermodules = [];
    this.innermodules = [{
      "modulename": "cartdetails",
      "innerpages": [{
        "pagename": "carttrackdetails"
      }]
    }, {
      "modulename": "cartsview",
      "innerpages": [{
        "pagename": "cartplaytrack"
      }]
    }, {
      "modulename": "tournament",
      "innerpages": [{
        "pagename": "leaderboard"
      }]
    }, {
      "modulename": "dashboard",
      "innerpages": [{
        "pagename": "paceofplayhistory"
      }, {
        "pagename": "cartplaytrack"
      }
      ]
    },{
      "modulename": "syncdata",
      "innerpages": [{
        "pagename": "syncdatastatus"
      }
      ]
    },{
      "modulename": "syncoverlaymaps",
      "innerpages": [{
        "pagename": "syncmapsdatastatus"
      }
      ]
    }, {
      "modulename": "geofenceview",
      "innerpages": [{
        "pagename": "geofenceadd"
      }, {
        "pagename": "hazardtype"
      }
      ]
    }, {
      "modulename": "golfcourse",
      "innerpages": [{
        "pagename": "holedetails"
      }, {
        "pagename": "holeperimeters"
      }, {
        "pagename": "courseperimeters"
      }, {
        "pagename": "addgeofencepaceofplay"
      }, {
        "pagename": "geofencepaceofplay"
      }
      ]
    }
  ]
  }
  enabledpages() {
    this.spinnerService.show();
    this.modules = [];
    this.submodules = [];
    this.mainsubmoduleslist = [];
    let modulename = "";
    var windowurl = window.location.href.split('/');
    if (windowurl.length > 4) {
      this.pagename = windowurl[3] + '/' + windowurl[4];
      this.innerpagename = windowurl[4];
    }
    else {
      this.pagename = windowurl[3];
      this.innerpagename = windowurl[3];
    }
    this.modules = JSON.parse(localStorage["assigendmodules"]);
    this.submodules = JSON.parse(localStorage["assigendsubmodules"]);
    for (var i = 0; i < this.modules.length; i++) {
      var innermodulenamelist = this.modules[i].pagename.split('/');
      var innermodulename ="";
      if(innermodulenamelist.length>1){
        innermodulename = innermodulenamelist[1];
      }
      else{
        innermodulename = innermodulenamelist[0];
      }
      
      this.mainsubmoduleslist.push({
        "innermodulename": innermodulename,
        "pagename": this.modules[i].pagename,
        "ModuleName": this.modules[i].ModuleName
      })
    }
    for (var i = 0; i < this.submodules.length; i++) {
      var innermodulenamelist = this.submodules[i].pagename.split('/');
      var innermodulename ="";
      if(innermodulenamelist.length>1){
        innermodulename = innermodulenamelist[1];
      }
      else{
        innermodulename = innermodulenamelist[0];
      }
      this.mainsubmoduleslist.push({
        "innermodulename": innermodulename,
        "pagename": this.submodules[i].pagename,
        "ModuleName": this.submodules[i].ModuleName
      })
    }
    let j = 0;
    this.pagepermission="";
    if(localStorage.getItem('roleCode')==='SA'|| localStorage.getItem('roleCode')==='CA' || localStorage.getItem('roleCode')==='CR'){
      if (this.pagename == 'messages/messages'|| this.pagename == 'messages/alerts'|| this.pagename == 'clubmanagement/livefleet'|| this.pagename == 'clubmanagement/livefleettrack'|| this.pagename == 'clubmanagement/dashboardnew' || this.pagename == 'cartmanagement/fleetdashboard'|| this.pagename == 'clubmanagement/carttrack') {
        j = 1;
        this.pagepermission="success";
      }
    }

    if (this.pagename == 'check' || this.pagename == 'errorlogs/errorlog' || this.pagename == 'errorlogs/weathererrorlog'  ||  this.pagename == 'versions' || this.pagename == 'cartmanagement/clearcartsdayend'|| this.pagename == 'operations/systemvscourseadmin' ) {
      j = 1;
      this.pagepermission="success";
    }
    for (var i = 0; i < this.mainsubmoduleslist.length; i++) {
      if (this.mainsubmoduleslist[i].pagename === this.pagename) {
        j = 1;
        this.pagepermission="success";
      }
      else if(j==0){
        this.pagepermission="fail";
      }
    }
    for (var k = 0; k < this.innermodules.length; k++) {
      for (var l = 0; l < this.innermodules[k].innerpages.length; l++) {
        var innerpagename = this.innermodules[k].innerpages[l].pagename;
        if (innerpagename === this.innerpagename) {
          var mainmodule = this.innermodules[k].modulename;
          for (var i = 0; i < this.mainsubmoduleslist.length; i++) {
            if (this.mainsubmoduleslist[i].innermodulename === mainmodule) {
              j = 1;this.pagepermission="success";
            }
            else if(j==0){
              this.pagepermission="fail";
            }
          }

        }

      }
      if(k===this.innermodules.length-1 && j == 0){
        if((this.pagename !="cartmanagement/dashboard") && (this.pagename !="")){
        this.router.navigate(['/cartmanagement/dashboard']);
        this.toastMessage('<span style="color: red">You don\'t have permission to access this page</span>');   
        }
      }
    }
    this.spinnerService.hide();
    }
   
    // if (j == 0) {
    //   this.router.navigate(['/cartmanagement/dashboard']);
    //   this.toastMessage('<span style="color: red">You don\'t have permission to access this page</span>');
    // }
    // this.spinnerService.hide();
  
  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',
    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 3000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }
}
