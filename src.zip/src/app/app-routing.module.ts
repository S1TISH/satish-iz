import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path:'login',
    loadChildren:'app/login/login.module#LoginModule'
  },
  {
    path:'cartmanagement',
    loadChildren:'app/cartmanagement/cartmanagement.module#CartmanagementModule'
  },
  {
    path:'clubmanagement',
    loadChildren:'app/clubmanagement/clubmanagement.module#ClubmanagementModule'
  },
  {
    path:'operations',
    loadChildren:'app/officemanagement/officemanagement.module#OfficemanagementModule'
  },
  {
    path:'perimeters',
    loadChildren:'app/perimetersmanagement/perimetersmanagement.module#PerimetersmanagementModule'
  },
  {
    path:'placements',
    loadChildren:'app/teeboxmanagement/teeboxmanagement.module#TeeboxmanagementModule'
  },
  {
    path:'golfers',
    loadChildren:'app/izongolfers/izongolfers.module#IzongolfersModule'
  },
  {
    path:'employees',
    loadChildren:'app/employeemanagement/employeemanagement.module#EmployeemanagementModule'
  },
  {
    path:'versions',
    loadChildren:'app/versions/versions.module#VersionsModule'
  },
  {
    path:'personnel',
    loadChildren:'app/personnel/personnel.module#PersonnelModule'
  },
  {
    path:'privacypolicy',
    loadChildren:'app/privacypolicy/privacypolicy.module#PrivacypolicyModule'
  },
  {
    path:'check',
    loadChildren:'app/clubcourseinfo/clubcourseinfo.module#ClubcourseinfoModule'
  },
  {
    path:'messages',
    loadChildren:'app/messages/messages.module#MessagesModule'
  },
  {
    path:'errorlogs',
    loadChildren:'app/errorlog/errorlog.module#ErrorlogModule'
  },
  {
    path:'data',
    loadChildren:'app/touts/touts.module#ToutsModule'
  },
  {
    path:'tournaments',
    loadChildren:'app/tournament/tournament.module#TournamentModule'
  },
  {
    path:'reach',
    loadChildren:'app/reach/reach.module#ReachModule'
  },
  {
    path:'',
    redirectTo:'login',
    pathMatch:'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
