import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { ModalModule } from 'ngx-bootstrap';
import { OrderModule } from 'ngx-order-pipe';
//import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';

import { PersonnelComponent } from './personnel/personnel.component';

const routes: Routes = [
  {
    path:'',
    component:PersonnelComponent
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule, ReactiveFormsModule,
    ToastModule.forRoot(),
    ModalModule.forRoot(),OrderModule
  ],
  declarations: [PersonnelComponent],
  exports: [RouterModule]
})
export class PersonnelModule { }
