
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import { JwtService } from './jwt.service';
import { environment } from '../../environments/environment';

@Injectable()
export class ApiService {
    constructor(
        private http: Http,
        private jwt: JwtService,
    ) { }
    baseURL: string = "http://adminapi.azaz.com/IZONAdmin.svc";
    private setHeader(): Headers {
        const headersConfig = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };
        if (this.jwt.getToken()) {
            headersConfig['TokenValue'] = `${this.jwt.getToken()}`;
        }
        return new Headers(headersConfig);
    }
    get(path: string): Observable<any> {
        return this.http.get(`${environment.api_url}${path}`, {})
            .map((res: Response) => res.json());
    }
    getD(path: string, body: Object = {}): Observable<any> {
        return this.http.get(`${environment.api_url}${path}`, {body})
            .map((res: Response) => res.json());
    }

    post(path: string, body: Object = {}): Observable<any> {
        return this.http.post(`${environment.api_url}${path}`, {}, { headers: this.setHeader() })
            .map((res: Response) => {
               //  console.log(res.json());
                return res.json();
            });
    }
    postD(path: string, body: Object = {}): Observable<any> {
        return this.http.post(`${path}`, JSON.stringify(body), { headers: this.setHeader() })
            .map((res: Response) => {
                // console.log(res.json());
                return res.json();
            });
    }
    postOH(path: string, body: Object = {}): Observable<any> {
        return this.http.post(`${environment.api_url}${path}`, body, {})
            .map((res: Response) => {
               // console.log(res.json());
                return res.json();
            });
    }
   
    postWithDataHeaders(method, headers, data) {
        return this.http.post(`${environment.api_url}${method}`, JSON.stringify(data), headers)
          .map(data =>
            data.json())
          .catch(this.handleError);
      }
    postWithDataWithoutHeaders(method, data) {
        return this.http.post(`${environment.api_url}${method}`, JSON.stringify(data))
          .map(data =>
            data.json())
          .catch(this.handleError);
      }
      //this method differnt api url
      postOH1(path: string, body: Object = {}): Observable<any> {
        return this.http.post(`${environment.api_url1}${path}`, body, {})
            .map((res: Response) => {
               // console.log(res.json());
                return res.json();
            });
    }
      handleError(error: Response) {
        return Observable.throw(error);
      }

      //Get IP Adress
    getIpAddress() {
        return this.http
            .get('http://freegeoip.net/json/?callback')
            .map(response => response.json())
            .catch(this.handleError);
    }
      //Get Wether report
      getWeather(clublat,clublong,methodname) {
        return this.http
            .get('https://api.weather.gov/points/' +  clublat + ',' + clublong + '/' + methodname)
            .map(response => response.json())
            .catch(this.handleError);
    }

    getWeatherStation(weatherstation, methodname) {
        return this.http
            .get('https://api.weather.gov/stations/' + weatherstation + '/' + methodname)
            .map(response => response.json())
            .catch(this.handleError);
    }
      //Get Club Date & Time
      getDateTime(lat,lng,times_Stamp) {
        return this.http
            .get('https://maps.googleapis.com/maps/api/timezone/json?location=' + lat + ',' + lng + '&timestamp=' + times_Stamp + '&key=AIzaSyApLNScsJqtdcYr5KX9DD5_cYaUgwkdc0M')
            .map(response => response.json())
            .catch(this.handleError);
    }
    postWithDataHeadersreach(method, headers, data) {
        return this.http.post(`${environment.api_url_reach}${method}`, JSON.stringify(data), headers)
          .map(data =>
            data.json())
          .catch(this.handleError);
      }


}
