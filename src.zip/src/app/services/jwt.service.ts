import { Injectable, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { ReplaySubject } from 'rxjs/ReplaySubject';
// import { User } from '../Models/user';

@Injectable()
export class JwtService {

  @Output() getUserName: EventEmitter<any> = new EventEmitter();
  @Output() getUserId: EventEmitter<any> = new EventEmitter();
  @Output() getclubid: EventEmitter<any> = new EventEmitter();  
  constructor(
  ) { }
  getToken(): string {
      return localStorage.getItem('userId');
  }
  setUserDetails(userDetails) {
     //   localStorage.setItem('userToken', userDetails[0].loginid);
      localStorage.setItem('userName', userDetails[0].loginusername);
      localStorage.setItem('userId', userDetails[0].loginid);
      localStorage.setItem('userImage', userDetails[0].loginuserimage);
      localStorage.setItem('roleCode',userDetails[0].RoleCode);
      //localStorage.setItem('roleName',userDetails[0].RoleName);
  }
  destroyToken() {
    localStorage.removeItem('clubId');
    localStorage.removeItem('clubname');
    localStorage.removeItem('courseId');
    localStorage.removeItem('holeId');
    localStorage.removeItem('cartId');
    localStorage.removeItem('userName');
    localStorage.removeItem('userId');
    localStorage.removeItem('userImage');
    localStorage.removeItem('mainmoduleid');
    localStorage.removeItem('roleCode');
    localStorage.removeItem('currentroot');
    localStorage.removeItem("Reachpermission");
    localStorage.removeItem('ReachuserId');
    localStorage.removeItem("nineholecourse");
    localStorage.clear();
    this.getUserName.emit(localStorage.getItem('userId'));
    this.getUserId.emit(localStorage.getItem('userId'));
    this.getclubid.emit(localStorage.getItem('clubId'));

  }

}
