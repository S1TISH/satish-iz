import { Injectable, Output, EventEmitter } from '@angular/core';
import { Http } from '@angular/http';
import { Router } from '@angular/router';

@Injectable()
export class AuthService {
  constructor(
    private http: Http,
    private router: Router
  ) { }
  @Output() getUserName: EventEmitter<any> = new EventEmitter();
  @Output() getClubIdForHeader: EventEmitter<any> = new EventEmitter();
  @Output() getCourseIdForHeader: EventEmitter<any> = new EventEmitter();
  @Output() getAlertCount: EventEmitter<any> = new EventEmitter();
  @Output() getMessageCount: EventEmitter<any> = new EventEmitter();

  getCall() {
    this.getUserName.emit(localStorage.getItem('userId'));
  }
  getClubIdforheader() {
    this.getClubIdForHeader.emit(localStorage.getItem('clubId'));
  }
  getCourseIdforheader() {
    this.getCourseIdForHeader.emit(localStorage.getItem('courseId'));
  }
  getalertCount()
  {
    this.getAlertCount.emit(localStorage.getItem('AlertCount'));
  }
  getmessageCount()
  {
    this.getMessageCount.emit(localStorage.getItem('MessageCount'));
  }
  
}
