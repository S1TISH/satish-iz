import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { ApiService } from './api.service';
import { JwtService } from './jwt.service';

@Injectable()
export class AuthGaurdService {
  constructor(
    private http: Http,
    private router: Router,
    private api: ApiService,
    private jwt: JwtService
  ) { }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (this.jwt.getToken()) {
      if (localStorage.getItem('userId') != "") {
        localStorage.setItem('currentroot', next.pathFromRoot[1].routeConfig.path);
        localStorage.setItem('currentroot',"golfclub");
        return true;
      }
      else {
        this.router.navigate(['/login']); return false;
      }
      //  this.api.post('ValidateToken/', {})
      //         .subscribe((res) => {
      //             if (res.length > 0) {
      //                 if (res[0].tokenStatus === 'Valid') {
      //                      return true;
      //                      } else { this.router.navigate( ['/Login']); return false; }
      //             } else {
      //                 this.router.navigate(['/Login']);
      //                 return false;
      //             }
      //         });
      //     return true;
      // } else {
      //     this.router.navigate(['/Login']);
      //     return false;
    }

  }

}
