import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-downloadfiles',
  templateUrl: './downloadfiles.component.html',
  styleUrls: ['./downloadfiles.component.css']
})
export class DownloadfilesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
