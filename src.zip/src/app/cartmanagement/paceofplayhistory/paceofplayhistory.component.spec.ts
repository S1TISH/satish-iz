import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaceofplayhistoryComponent } from './paceofplayhistory.component';

describe('PaceofplayhistoryComponent', () => {
  let component: PaceofplayhistoryComponent;
  let fixture: ComponentFixture<PaceofplayhistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaceofplayhistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaceofplayhistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
