import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Title } from '@angular/platform-browser';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import * as moment from "moment";
var m_names = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
@Component({
  selector: 'app-paceofplayhistory',
  templateUrl: './paceofplayhistory.component.html',
  styleUrls: ['./paceofplayhistory.component.css']
})
export class PaceofplayhistoryComponent implements OnInit {
  paceofplayList: any = []; cartdetails: any = []; playerdetails: any = [];
  clubid: any; courseid: any; GridMessage: string = 'Loading... !'; refreshBtn: any;
  dateasc: any = "sortgreen"; datedesc: any = "sortwhite";
  paceofplayasc: any = "sortwhite"; paceofplaydesc: any = "sortwhite";
  totalroundsasc: any = "sortwhite"; totalroundsdesc: any = "sortwhite";
  key: string = 'selectdate';
  reverse: boolean = false;
  startdate: Date; enddate: any; monthfirstdate: any;
  modalRef: BsModalRef;
  templatemessages: BsModalRef; errorDate: any = ""; selecteddates: any;timeoffset: any = "";today:any;

  constructor(private modalService: BsModalService, private title: Title, public api: ApiService, private spinnerService: Ng4LoadingSpinnerService) {
    this.spinnerService.hide();
    this.title.setTitle("IZON - Pace Of Play History");
    this.clubid = localStorage.getItem('clubId');
    this.courseid = localStorage.getItem('courseId');
  }

  ngOnInit() {
    this.getcourses();
  }
  getcourses() {
    let searchexp = "";
    if (localStorage.getItem('courseId') === undefined || localStorage.getItem('courseId') === '' || localStorage.getItem('courseId') === null) {
        searchexp = " WHERE GC_GCB_ID='" + this.clubid + "' and GC_STATUS='Y' "
    }
    else {
        searchexp = " WHERE GC_GCB_ID='" + this.clubid + "' and GC_STATUS='Y' and  GC_ID='" + localStorage.getItem('courseId') + "'"
    }
    let parameters1 = { searchvalue: searchexp };
    this.api.postOH('getgolfcourse', parameters1).subscribe(
        response => {
            this.spinnerService.hide();
            if (response.length !== 0) {
                this.timeoffset = response[0].timeoffset;
                this.setdates();
            }
        }, error => {
            this.spinnerService.hide();
        })
}

  setdates() {
    let currentDate: any = '';  this.enddate = '';
    let d = new Date();
    let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
    currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
    var dd = (currentDate.getDate()).toString();
    var mm = m_names[currentDate.getMonth()];
    var yyyy = currentDate.getFullYear();
    if (dd.length == 1) { dd = '0' + dd };
    this.monthfirstdate = mm + ' ' + '01' + ', ' + yyyy;
    this.startdate = this.monthfirstdate;
    this.enddate = moment(currentDate).format('MMMM DD, YYYY');
    this.today=currentDate;
    let fromdate = moment(this.startdate).format('MM/DD/YYYY');
    let todate = moment(this.enddate).format('MM/DD/YYYY');
    let parameters = { "clubid": this.clubid, "courseid": this.courseid, "fromdate": fromdate, "todate": todate }
    this.getPaceofplayhistory(parameters);
  }

  getPaceofplayhistory(parameters) {
    this.paceofplayList = [];
    this.refreshBtn = true;
    this.spinnerService.show();
    this.errorDate = "";

    this.api.postOH('getpaceofplayhistory', parameters).subscribe(
      (response) => {
        if (response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            this.paceofplayList.push({
              "paceofplaydate": response[i].paceofplaydate,
              "totalrounds": response[i].totalrounds,
              "paceofplay": response[i].paceofplay
            })
          }
          this.refreshBtn = false;
          this.spinnerService.hide();
        }
        else {
          this.paceofplayList = []; this.refreshBtn = false;
          this.spinnerService.hide();
          this.GridMessage = "No Records Found";
        }
      },
      err => {
        this.spinnerService.hide(); this.paceofplayList = [];
        this.GridMessage = "No Records Found";
      }
    );
  }
  searchpaceofplay() {
    this.errorDate = '';
    if (this.startdate != null && this.enddate != null) {
      let fromdate = moment(this.startdate).format('MM/DD/YYYY');
      let todate = moment(this.enddate).format('MM/DD/YYYY');
      var datediff = (this.datediff(this.parseDate(fromdate), this.parseDate(todate)));
      if (datediff >= 0) {
        if (datediff <= 90) {
          this.errorDate = "";
          let parameters = { "clubid": this.clubid, "courseid": this.courseid, "fromdate": fromdate, "todate": todate }
          this.getPaceofplayhistory(parameters);
        }
        else {
          this.errorDate = "Date difference should be less than or equal to 90 days";
        }
      }
      else {
        this.errorDate = "End date and time should be greater than Start date and time";
      }
    }
    else {
      this.errorDate = "Please select From and To dates";
    }
  }
  parseDate(str) {
    var mdy = str.split('/');
    return new Date(mdy[2], mdy[0] - 1, mdy[1]);
  }

  datediff(first, second) {
    // Take the difference between the dates and divide by milliseconds per day.
    // Round to nearest whole number to deal with DST.
    return Math.round((second - first) / (1000 * 60 * 60 * 24));
  }

  refreshpage() {
    this.setdates();
    this.dateasc = "sortgreen"; this.datedesc = "sortwhite";
    this.paceofplayasc = "sortwhite"; this.paceofplaydesc = "sortwhite";
    this.totalroundsasc = "sortwhite"; this.totalroundsdesc = "sortwhite";
    // let fromdate = moment(this.startdate).format('MM/DD/YYYY');
    // let todate = moment(this.enddate).format('MM/DD/YYYY');
    // let parameters = { "clubid": this.clubid, "courseid": this.courseid, "fromdate": fromdate, "todate": todate }
    // this.getPaceofplayhistory(parameters);
  }
  viewGolfersDetails(selecteddate, template2: TemplateRef<any>) {
    this.cartdetails = [];
    this.selecteddates = selecteddate;
    let parameters = { "clubid": this.clubid, "courseid": this.courseid, "selectddate": selecteddate }
    this.api.postOH('getpaceofplayhistorycartdetails', parameters).subscribe(
      (response) => {
        if (response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            this.cartdetails.push({
              "cartid": response[i].cartid,
              "cartname": response[i].cartname,
              "playersinfo": response[i].playersinfo
            })
          }
          this.spinnerService.hide();
        }
        else {
          this.paceofplayList = []; this.refreshBtn = false;
          this.spinnerService.hide();
          this.GridMessage = "No Records Found";
        }
      },
      err => {
        this.spinnerService.hide(); this.paceofplayList = [];
        this.GridMessage = "No Records Found";
      }
    );

    this.templatemessages = this.modalService.show(template2, { class: 'modal-lg modal-sm' });
  }

  declinepopup(): void {
    this.templatemessages.hide();
  }

  sort(value: string) {
    this.key = value;
    this.dateasc = "sortwhite"; this.datedesc = "sortwhite";
    this.paceofplayasc = "sortwhite"; this.paceofplaydesc = "sortwhite";
    this.totalroundsasc = "sortwhite"; this.totalroundsdesc = "sortwhite";
    if (this.key == value) {
      this.reverse = !this.reverse;
      if (this.key == "selectdate" && this.reverse) {
        this.datedesc = "sortgreen";
        this.dateSorting(this.paceofplayList);
      }
      else if (this.key == "selectdate" && (!this.reverse)) {
        this.dateasc = "sortgreen";
        this.dateReverseSorting(this.paceofplayList);
      }
      if (this.key == "paceofplay" && this.reverse) {
        this.paceofplaydesc = "sortgreen";
        this.popSorting(this.paceofplayList);
      }
      else if (this.key == "paceofplay" && (!this.reverse)) {
        this.paceofplayasc = "sortgreen";
        this.popReverseSorting(this.paceofplayList);
      }
      if (this.key == "totalrounds" && this.reverse) {
        this.totalroundsdesc = "sortgreen";
        this.roundsSorting(this.paceofplayList);
      }
      else if (this.key == "totalrounds" && (!this.reverse)) {
        this.totalroundsasc = "sortgreen";
        this.roundsReverseSorting(this.paceofplayList);
      }
    }
  }

  dateSorting(paceofplayList) {
    paceofplayList.sort(function (a, b) {
      if (a.paceofplaydate < b.paceofplaydate) return -1;
      if (a.paceofplaydate > b.paceofplaydate) return 1;
      return 0;
    });
  }

  dateReverseSorting(paceofplayList) {
    paceofplayList.reverse(function (a, b) {
      if (a.paceofplaydate < b.paceofplaydate) return -1;
      if (a.paceofplaydate > b.paceofplaydate) return 1;
      return 0;
    });
  }

  popSorting(paceofplayList) {
    paceofplayList.sort(function (a, b) {
      if (a.paceofplay < b.paceofplay) return -1;
      if (a.paceofplay > b.paceofplay) return 1;
      return 0;
    });
  }

  popReverseSorting(paceofplayList) {
    paceofplayList.reverse(function (b, a) {
      if (a.paceofplay < b.paceofplay) return -1;
      if (a.paceofplay > b.paceofplay) return 1;
      return 0;
    });
  }

  roundsSorting(paceofplayList) {
    paceofplayList.sort(function (a, b) {
      var reA = /[^a-zA-Z]/g;
      var reN = /[^0-9]/g;
      var AInt = parseInt(a.totalrounds, 10);
      var BInt = parseInt(b.totalrounds, 10);

      if (isNaN(AInt) && isNaN(BInt)) {
        var aA = a.totalrounds.replace(reA, "");
        var bA = b.totalrounds.replace(reA, "");
        if (aA === bA) {
          var aN = parseInt(a.totalrounds.replace(reN, ""), 10);
          var bN = parseInt(b.totalrounds.replace(reN, ""), 10);
          return aN === bN ? 0 : aN > bN ? 1 : -1;
        } else {
          return aA > bA ? 1 : -1;
        }
      } else if (isNaN(AInt)) {
        return 1;
      } else if (isNaN(BInt)) {
        return -1;
      } else {
        return AInt > BInt ? 1 : -1;
      }
    });
  }

  roundsReverseSorting(paceofplayList) {
    paceofplayList.reverse(function (b, a) {
      var reA = /[^a-zA-Z]/g;
      var reN = /[^0-9]/g;
      var AInt = parseInt(a.totalrounds, 10);
      var BInt = parseInt(b.totalrounds, 10);

      if (isNaN(AInt) && isNaN(BInt)) {
        var aA = a.totalrounds.replace(reA, "");
        var bA = b.totalrounds.replace(reA, "");
        if (aA === bA) {
          var aN = parseInt(a.totalrounds.replace(reN, ""), 10);
          var bN = parseInt(b.totalrounds.replace(reN, ""), 10);
          return aN === bN ? 0 : aN > bN ? 1 : -1;
        } else {
          return aA > bA ? 1 : -1;
        }
      } else if (isNaN(AInt)) {
        return 1;
      } else if (isNaN(BInt)) {
        return -1;
      } else {
        return AInt > BInt ? 1 : -1;
      }
    });
  }
}
