import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CartplaytrackComponent } from './cartplaytrack.component';

describe('CartplaytrackComponent', () => {
  let component: CartplaytrackComponent;
  let fixture: ComponentFixture<CartplaytrackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CartplaytrackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CartplaytrackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
