import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Observable } from 'rxjs/Rx';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Title } from '@angular/platform-browser';
import * as moment from "moment";
import * as $ from 'jquery';

declare const google: any;
var currentZoom; var minZoom; var maxZoom;

@Component({
    selector: 'app-cartsview',
    templateUrl: './cartsview.component.html',
    styleUrls: ['./cartsview.component.css']
})
export class CartsviewComponent implements OnInit {
    modalRef: BsModalRef;
    courselat: any;
    courselong: any;
    coursezoomlevel: any;
    courserotate: any = 0;
    public messageForm: FormGroup; submitAttempt: boolean = false; iconnameonmap: any;
    cartsarry: any = []; bluecircleimage: any; readycount: any; inplaycount: any; rangerCount: any; beverageCount: any; bagDropCount: any; stagingCount: any;
    ddCartsList: any = []; ddlcarts: string; cartsviewheadername: string; map: any; pagename: any;
    inplay: any = []; ready: any = []; ranger: any = []; beverage: any[]; bagDrop: any = []; CoursesInfo: any = []; sub: any; markers: any = [];
    golfclubid: any = localStorage.getItem('clubId'); inplayDetails: any = []; stagingCarts: any = [];
    fromdate: any; todate: any; datearry: any; cartlabelname: any; cartId: any = 0; userId: any;
    startinghole: any; starttime: any; startdate: any; lastOpenedInfoWindow: any = ""; inplayBtn: any; pop: any = "none"; message: any = "Loading..";
    lastupdateddate: any; day: string; month: any; hh: any; mm: any; ss: any; gameStatus: any = ""; messageBtn: any;
    todaydate: any; todaytime: any; cartMessage: any; ranbavname: any = ""; ranbavId: any; fleetRoleId: any;
    messagepopup: boolean = false; soursefrom: boolean = false; android: string; apple: string;
    inplaycartsarray = [];
    cartsarray = []; allcarts: any; inplaycarts: any; yellowcarts: any; redcarts: any; activeall: any; activeinplay: any; activeyellow: any; activered: any;

    showpopover: boolean = true; clubcartmessages: any = []; allclubcartmessages: any = []; fleetCartColor: any; fleetDeviceType: any;
    inplaycartname: any; inplaycartcolor: any; sendmessage: boolean = false; showmsgs: boolean = false; templatemessages: BsModalRef; viewall: boolean = false; invalidcls: any = 0;

    showbroadcastmsg: boolean = false; desclength: any; coursemsgid: any = 0; courseerrmsg: boolean = false; coursemsgtext: boolean = false; selectbar: any;
    inplayselected: string; readyselected: string; rangerselected: string; bevarageselected: string; bagdropselected: string;
    IsrangerAllChecked: boolean; IsbevarageAllChecked: boolean; IsbagdropAllChecked: boolean; IsreadyAllChecked: boolean;
    chevroncls: any = "chevrn pull-right fa fa-chevron-down";
    showcustommsgs: boolean = false; contactMessages: any = [];
    cartsList: any = []; selectedCartIds: string; IsinplayAllChecked: boolean; errorMessage: any = "none";
    companionAppInplayCartsList: any = []; companionAppCartsCount: any = 0;
    editCMessage: any = ""; showtextArea_: any = []; rowval: any; indexval: any; displayWalkerName: any; currentGolfClubDateTime: any = ""; timeoffset: any = '';
    showready: boolean = false; showinplay: boolean = true; readycartslist: any; 
    public broadmessageForm: FormGroup; broadcartMessage: any; broadcastsubmitAttempt: boolean = false;
    constructor(private title: Title, public toastr: ToastsManager, public api: ApiService, private authService: AuthService,
        private router: Router, private spinnerService: Ng4LoadingSpinnerService, vcr: ViewContainerRef,
        private modalService: BsModalService, public formBuilder: FormBuilder) {

        this.title.setTitle("IZON - Live Fleet");
        this.cartsviewheadername = localStorage.getItem('clubname');
        this.gameStatus = localStorage.getItem('gameStatus');
        localStorage.removeItem('gameStatus');

        this.pagename = "Live Fleet"; this.toastr.setRootViewContainerRef(vcr);
        this.userId = JSON.parse(localStorage.getItem('userId'));

        this.desclength = 180;

    }

    ngOnInit() {
        this.allcarts = "cart-icon.png";
        this.inplaycarts = "cart-icon-orange.png";
        this.yellowcarts = "cart-icon-red.png";
        this.redcarts = "maintenance.PNG";
        this.activeall = "activecss";
        this.activeinplay = "";
        this.activeyellow = "";
        this.activered = "";
        //message sending
        this.messageForm = this.formBuilder.group({
            fmessage: ['', Validators.compose([Validators.required])],
        });

        this.broadmessageForm = this.formBuilder.group({
            fbcmessage: ['', Validators.compose([Validators.required])],
            feditCMessage: ['', Validators.compose([Validators.required])]
        });
        let searchexp = "";
        if (localStorage.getItem('courseId') === undefined || localStorage.getItem('courseId') === '' || localStorage.getItem('courseId') === null) {
            searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' "
        }
        else {
            searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' and  GC_ID='" + localStorage.getItem('courseId') + "'"
        }
        let parameters = { searchvalue: searchexp };
        this.lastupdateddate = '';
        this.getcourses(parameters);
        this.getreadyCartDetails(this.golfclubid);
        this.getRangerBeverageBagDropCartDetails(this.golfclubid);
        this.getinplayCartDetails(this.golfclubid);
        this.getStagingCartDetails(this.golfclubid);
        // this.getlastupdateddatetime();

        let parameters1 = { searchvalue: " where CCM_STATUS='Y'  and CCM_GC_ID='" + localStorage.getItem('courseId') + "'  and CCM_GCB_ID='" + this.golfclubid + "' " };
        this.getCourseCustomMessages(parameters1);

        this.sub = Observable.interval(1000 * 60).subscribe(x => {
            this.soursefrom = true;
            this.getreadyCartDetails(this.golfclubid);
            this.getRangerBeverageBagDropCartDetails(this.golfclubid);
            this.getinplayCartDetails(this.golfclubid);
            this.getStagingCartDetails(this.golfclubid);
            this.getCartsList();
            //this.getCartMap();
            this.getlastupdateddatetime();
            this.activeall = "activecss";
            this.activeinplay = "";
            this.activeyellow = "";
            this.readycartslist = "";
            this.showready = false;
            this.showinplay = true;
        });

        if (this.gameStatus == "C") {
            let msg = '<span style="color: green">Cart Cleared Successfully</span>';
            this.toastMessage(msg);
            localStorage.removeItem('gameStatus');
            this.gameStatus = "";
        }
        if (this.gameStatus == "S") {
            let msg = '<span style="color: green">Cart Signed out Successfully</span>';
            this.toastMessage(msg);
            localStorage.removeItem('gameStatus');
            this.gameStatus = "";
        }
        if (this.gameStatus == "CM") {
            let msg = '<span style="color: green">Round Completed</span>';
            this.toastMessage(msg);
            localStorage.removeItem('gameStatus');
            this.gameStatus = "";
        }
    }

    ngOnDestroy() {
        this.sub.unsubscribe();
        localStorage.removeItem('gameStatus');
        this.gameStatus = "";
    }

    toastMessage(msg) {
        let options = {
            positionClass: 'toast-top-center',
        };

        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 3000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }

    getcourses(parameters) {
        this.spinnerService.show();
        this.CoursesInfo = [];
        this.api.postOH('getgolfcourse', parameters).subscribe(
            response => {
                if (response.length !== 0) {
                    for (let i = 0; i < response.length; i++) {
                        this.CoursesInfo.push({
                            "id": response[i].id
                        })
                    }
                    this.courselat = response[0].latitude;
                    this.courselong = response[0].longitude;
                    this.timeoffset = response[0].timeoffset;
                    this.coursezoomlevel = (response[0].zoomlevel != '') ? response[0].zoomlevel : 0;
                    this.courserotate = (response[0].rotate != '') ? response[0].rotate : 0;
                    this.getCartsList();
                    this.getlastupdateddatetime();
                }
                this.spinnerService.hide();
            }, error => {
                this.spinnerService.hide();
            })
    }

    getreadyCartDetails(id: any) {
        this.spinnerService.show();
        this.readyselected = "";
        let parameters = {
            clubid: parseInt(id)
        };
        this.api.postOH('getreadycartdetails', parameters).subscribe(
            (response) => {
                this.readycount = response.length;
                this.ready = [];
                if (response.length != 0) {
                    for (let i = 0; i < response.length; i++) {
                        if (response[i].deviceStatus == 'T') {
                            this.ready.push({
                                value: response[i].id,
                                name: response[i].name,
                                cssclass: "circle-green",
                                roleId: response[i].cartroletype,
                                deviceid: response[i].deviceid,
                                cartcolor: "green.png",
                                Selected: true,
                                deviceStatus: response[i].deviceStatus
                            });
                        }
                        if (this.readyselected == "") {
                            this.readyselected = response[i].id + ', '
                        } else {
                            this.readyselected = this.readyselected + response[i].id + ', '
                        }
                    }
                }
                this.spinnerService.hide();
            }, error => {
                this.spinnerService.hide();
            });
    }

    getStagingCartDetails(id: any) {
        this.stagingCarts = []; this.stagingCount = '';
        let parameters = {
            clubid: parseInt(id)
        };
        this.spinnerService.show();
        this.api.postOH('getstagingcartdetails', parameters).subscribe(
            (response) => {
                this.stagingCount = response.length;
                this.stagingCarts = [];
                if (response.length > 0) {
                    for (let i = 0; i < response.length; i++) {
                        if (response[i].deviceStatus == 'T') {
                            this.stagingCarts.push({
                                value: response[i].id,
                                name: response[i].name,
                                cssclass: "circle-green",
                                roleId: response[i].cartroletype,
                                deviceid: response[i].deviceid,
                                cartcolor: "green.png",
                                deviceStatus: response[i].deviceStatus
                            });
                        }
                    }
                }
                this.spinnerService.hide();
            }, error => {
                this.spinnerService.hide();
            });
    }

    getRangerBeverageBagDropCartDetails(id: any) {
        this.rangerselected = "";
        this.bevarageselected = "";
        this.bagdropselected = "";
        this.spinnerService.show();
        let parameters = {
            clubid: parseInt(id)
        };
        this.api.postOH('getrangersbeveragebagdropcartdetails', parameters).subscribe(
            (response) => {
                var rangercnt = 0; var beveragecnt = 0; var bagdropcnt = 0;
                this.rangerCount = rangercnt;
                this.ranger = [];
                this.beverageCount = beveragecnt;
                this.beverage = [];
                this.bagDropCount = bagdropcnt;
                this.bagDrop = [];
                if (response.length != 0) {
                    for (let i = 0; i < response.length; i++) {
                        if (response[i].cartroletype == "3") {
                            this.ranger.push({
                                value: response[i].id,
                                name: response[i].name,
                                cssclass: "circle-blue",
                                roleId: response[i].cartroletype,
                                deviceid: response[i].deviceid,
                                cartcolor: "star.png",
                                Selected: true,
                                deviceStatus: response[i].deviceStatus
                            });
                            if (this.rangerselected == "") {
                                this.rangerselected = response[i].id + ', '
                            } else {
                                this.rangerselected = this.rangerselected + response[i].id + ', '
                            }
                        } else if (response[i].cartroletype == "4") {
                            this.beverage.push({
                                value: response[i].id,
                                name: response[i].name,
                                cssclass: "circle-blue",
                                roleId: response[i].cartroletype,
                                deviceid: response[i].deviceid,
                                cartcolor: "beverage.png",
                                Selected: true,
                                deviceStatus: response[i].deviceStatus
                            });
                            if (this.bevarageselected == "") {
                                this.bevarageselected = response[i].id + ', '
                            } else {
                                this.bevarageselected = this.bevarageselected + response[i].id + ', '
                            }
                        } else if (response[i].cartroletype == "7") {
                            this.bagDrop.push({
                                value: response[i].id,
                                name: response[i].name,
                                cssclass: "circle-blue",
                                roleId: response[i].cartroletype,
                                deviceid: response[i].deviceid,
                                cartcolor: "star.png",
                                Selected: true,
                                deviceStatus: response[i].deviceStatus
                            });
                            if (this.bagdropselected == "") {
                                this.bagdropselected = response[i].id + ', '
                            } else {
                                this.bagdropselected = this.bagdropselected + response[i].id + ', '
                            }
                        }
                    }
                    this.rangerCount = this.ranger.length;
                    this.beverageCount = this.beverage.length;
                    this.bagDropCount = this.bagDrop.length;
                }
                this.spinnerService.hide();
            }, error => {
                this.spinnerService.hide();
            });
    }

    getinplayCartDetails(id: any) {
        this.spinnerService.show();
        let parameters = {
            clubid: parseInt(id),
            courseid: localStorage.getItem('courseId'),
            cartid: 0
        };
        this.api.postOH('getinplaycartdetailsv2', parameters).subscribe(
            (response) => {
                this.cartsarry = [];
                this.inplay = []; this.companionAppInplayCartsList = [];
                if (response.length > 0) {
                    for (let i = 0; i < response.length; i++) {
                        var cartcolor = "";
                        var cartcolorname = "";
                        if (response[i].cartcolor === 'tournament') {
                            cartcolorname = 'blue_circle.png';
                        }
                        else {
                            cartcolorname = response[i].cartcolor;
                        }

                        if (response[i].deviceStatus == 'T') {
                            this.inplay.push({
                                value: response[i].id,
                                name: response[i].name,
                                cssclass: cartcolor,
                                roleId: response[i].cartroletype,
                                deviceid: response[i].deviceid,
                                cartcolor: cartcolorname,
                                Selected: true,
                                deviceStatus: response[i].deviceStatus
                            });
                        }

                        if (response[i].deviceStatus == 'C') {
                            this.companionAppInplayCartsList.push({
                                value: response[i].id,
                                name: response[i].name,
                                cssclass: cartcolor,
                                roleId: response[i].cartroletype,
                                deviceid: response[i].deviceid,
                                cartcolor: cartcolorname,
                                Selected: true,
                                deviceStatus: response[i].deviceStatus
                            });
                        }

                        if (response[i].latitude != '') {
                            this.cartsarry.push([
                                response[i].name,
                                response[i].latitude,
                                response[i].longitude,
                                response[i].id,
                                response[i].cartroletype,
                                cartcolorname,
                                response[i].deviceStatus
                            ]);
                        }
                    }
                    if (this.inplay.length > 0) {
                        this.inplaycount = this.inplay.length;
                    }
                    else {
                        this.inplaycount = 0;
                    }
                    if (this.companionAppInplayCartsList.length > 0) {
                        this.companionAppCartsCount = this.companionAppInplayCartsList.length;
                    }
                    else {
                        this.companionAppCartsCount = 0;
                    }
                    //this.inplaycartsarray = this.inplay;
                }
                else {
                    this.inplaycount = 0; this.companionAppCartsCount = 0;
                }
                this.inplaycartsarray = this.inplay;
                let parameters1 = {
                    clubid: parseInt(id)
                };
                this.api.postOH('getrangersbeveragebagdropcartdetails', parameters1).subscribe(
                    (response1) => {
                        if (response1.length > 0) {
                            for (let j = 0; j < response1.length; j++) {
                                if (response1[j].latitude != '') {
                                    var rcartcolor = "";
                                    rcartcolor = response1[j].cartroletype == "3" ? "star.png" : response1[j].cartroletype == "4" ? "beverage.png" : response1[j].cartroletype == "7" ? "star.png" : "";
                                    this.cartsarry.push([
                                        response1[j].name,
                                        response1[j].latitude,
                                        response1[j].longitude,
                                        response1[j].id,
                                        response1[j].cartroletype,
                                        rcartcolor,
                                        response1[j].deviceStatus
                                    ]);
                                }
                            }
                        }
                        if (this.ddlcarts == '0') {
                            this.setMarkers(this.map);
                        }
                        this.spinnerService.hide();
                    }, error => {
                        this.spinnerService.hide();
                    });

                // staging carts
                let parameters2 = {
                    clubid: parseInt(id)
                };
                this.api.postOH('getstagingcartdetails', parameters2).subscribe(
                    (response2) => {
                        if (response2.length > 0) {
                            for (let j = 0; j < response2.length; j++) {
                                if (response2[j].latitude != '') {
                                    var rcartcolor = "";
                                    rcartcolor = "green.png";
                                    this.cartsarry.push([
                                        response2[j].name,
                                        response2[j].latitude,
                                        response2[j].longitude,
                                        response2[j].id,
                                        response2[j].cartroletype,
                                        rcartcolor,
                                        response2[j].deviceStatus
                                    ]);
                                }
                            }
                        }
                        if (this.ddlcarts == '0') {
                            this.setMarkers(this.map);
                        }
                        this.spinnerService.hide();
                    }, error => {
                        this.spinnerService.hide();
                    });

                this.spinnerService.hide();
                if (this.inplay.length > 0 ||  this.ranger.length > 0 || this.beverage.length > 0 || this.bagDrop.length > 0) {
                    this.showbroadcastmsg = true;
                }
                else {
                    this.showbroadcastmsg = false;
                }


            }, error => {
                this.spinnerService.hide();
            });
    }

    maploading() {
        this.spinnerService.show();
        var stylecontrols = document.getElementById('styleControls');
        this.map = new google.maps.Map(document.getElementById('map'), {
            center: { lat: parseFloat(this.courselat), lng: parseFloat(this.courselong) },
            zoom: parseInt(this.coursezoomlevel),
            //disableDefaultUI: true,
            mapTypeId: 'satellite',
            tilt: 0,
            rotateControl: true,
            fullscreenControl: false,
            zoomControl: false,
            streetViewControl: false,
            mapTypeControl: false,
            //heading:parseInt(this.courserotate)
        });

        currentZoom = this.map.getZoom();
        minZoom = 0;
        maxZoom = 21;
        this.setoverlayimage();
        this.setMarkers(this.map);
        this.map.controls[google.maps.ControlPosition.TOP_RIGHT].push(stylecontrols);
        this.spinnerService.hide();
    }

    getcarttracking(readycartdata) {
        this.showpopover = true;
        this.getTabletVersion(readycartdata);
        this.pop = "none";
        this.inplayDetails = [];
        this.inplayBtn = true;
        this.message = "Loading..";
        let parameters = { searchvalue: " WHERE SC_CD_ID='" + readycartdata.value + "' AND SC_GAME_STATUS='L'" };

        this.api.postOH('getcartassignedusers', parameters).subscribe(
            (response) => {
                this.inplayDetails = [];
                if (response.length > 0) {
                    for (let i = 0; i < response.length; i++) {
                        this.inplayDetails.push({
                            "cartid": response[i].cartid,
                            "cartname": response[i].cartname,
                            "frontnine": response[i].frontnine,
                            "izonuseremail": response[i].izonuseremail,
                            "izonusername": response[i].izonusername,
                            "createddateinampm": response[i].createddate,
                            "starttime": response[i].starttime,
                            "endtime": response[i].endtime,
                            "izonusermobile": response[i].izonusermobile,
                            "izonuserpwd": response[i].izonuserpwd,
                        })
                        this.startinghole = response[0].frontnine === "Y" ? "1st" : "10th";
                        if (response[0].starttime != "") {
                            var st = new Date(response[0].starttime);
                            st.setMinutes(st.getMinutes() - 4);
                            this.startdate = moment(st).format('MM.DD.YYYY');
                            this.starttime = moment(st).format('@ hh:mm A');
                        }
                        else {
                            // var cd = new Date(response[0].createddateinampm);
                            // cd.setMinutes(cd.getMinutes() - 4);
                            // this.startdate = moment(cd).format('MM.DD.YYYY');
                            // this.starttime = moment(cd).format('@ hh:mm A');
                            this.starttime = "--";
                        }
                    }
                    this.inplayBtn = false;
                    this.pop = "block";
                }
                else {
                    this.inplayBtn = false; this.message = "No data found";
                }
            });
    }

    cartPlayTrack(readycartdata) {
        localStorage.setItem('playcartId', readycartdata.value);
        if (readycartdata.deviceStatus == 'C') {
            localStorage.setItem('playcartname', 'W');
        }
        else {
            localStorage.setItem('playcartname', readycartdata.name);
        }
        localStorage.setItem('userType', readycartdata.roleId);
        this.router.navigate(['/cartmanagement/cartplaytrack']);
    }

    navigateCartPlayTrack(cartId, cartName, roleId) {
        localStorage.setItem('playcartId', cartId);
        localStorage.setItem('playcartname', cartName);
        localStorage.setItem('userType', roleId);
        this.router.navigate(['/cartmanagement/cartplaytrack']);
    }

    getCartsList() {
        this.spinnerService.show();
        let parameters = {
            clubid: parseInt(this.golfclubid),
            courseid: localStorage.getItem('courseId'),
            cartid: 0
        };
        this.api.postOH('getinplaycartdetailsv2', parameters).subscribe(
            (response) => {
                this.ddCartsList = [];
                if (response.length > 0) {
                    for (var i = 0; i < response.length; i++) {
                        if (response[i].latitude != '') {
                            this.ddCartsList.push({
                                value: response[i].id,
                                name: response[i].name
                            });
                        }
                    }
                }
                let parameters1 = {
                    clubid: parseInt(this.golfclubid)
                };
                this.api.postOH('getrangersbeveragebagdropcartdetails', parameters1).subscribe(
                    (response1) => {
                        if (response1.length > 0) {
                            for (let j = 0; j < response1.length; j++) {
                                if (response1[j].latitude != '') {
                                    this.ddCartsList.push({
                                        value: response1[j].id,
                                        name: response1[j].name
                                    });
                                }
                            }
                        }
                        // this.localddlfun();
                    });

                //staging carts
                let params = {
                    clubid: parseInt(this.golfclubid)
                };
                this.api.postOH('getstagingcartdetails', params).subscribe(
                    (response2) => {
                        if (response2.length > 0) {
                            for (let j = 0; j < response2.length; j++) {
                                if (response2[j].latitude != '') {
                                    this.ddCartsList.push({
                                        value: response2[j].id,
                                        name: response2[j].name
                                    });
                                }
                            }
                        }
                        // this.localddlfun();
                    });
                this.localddlfun();
                this.spinnerService.hide();
            }, error => {
                this.spinnerService.hide();
            }
        );
    }

    localddlfun() {
        this.ddlcarts = "0";
        if (localStorage.getItem('cartId') == '' || localStorage.getItem('cartId') == undefined || localStorage.getItem('cartId') == null) {
            if (this.soursefrom == false) {
                this.maploading();
            } else {
                this.setMarkers(this.map);
            }
        } else {
            if (this.soursefrom == false) {
                this.ddlcarts = localStorage.getItem('cartId').toString();
                localStorage.removeItem('cartId');
                this.viewcartonmap();
            }
        }
    }

    //to set single cart map on dropdown change 
    getCartMap() {
        this.spinnerService.show();
        if (this.ddlcarts > '0') {
            let parameters = {
                clubid: parseInt(this.golfclubid),
                courseid: localStorage.getItem('courseId'),
                cartid: parseInt(this.ddlcarts)
            };
            this.cartsarry = [];
            this.api.postOH('getinplaycartdetailsv2', parameters).subscribe(
                (response) => {
                    if (response.length > 0) {
                        for (var i = 0; i < response.length; i++) {
                            if (response[i].latitude != '') {
                                var cartcolorname = "";
                                if (response[i].cartcolor === 'tournament') {
                                    cartcolorname = 'blue_circle.png';
                                }
                                else {
                                    cartcolorname = response[i].cartcolor;
                                }
                                this.cartsarry.push([
                                    response[i].name,
                                    response[i].latitude,
                                    response[i].longitude,
                                    response[i].id,
                                    response[i].cartroletype,
                                    cartcolorname,
                                    response[i].deviceStatus
                                ]);
                            }
                        }
                        this.cartsarry = this.cartsarry;
                        for (var i = 0; i < this.cartsarry.length; i++) {
                            var carts = this.cartsarry[i];
                        }
                        this.map.setCenter(new google.maps.LatLng(parseFloat(carts[1]), parseFloat(carts[2])));
                        this.map.setZoom(20);
                        this.setMarkers(this.map);
                        this.spinnerService.hide();
                    } else {
                        let parameters1 = {
                            searchvalue: " WHERE CD_ID='" + this.ddlcarts + "' and CD_STATUS='Y' ",
                            courseid: 0
                        }
                        this.api.postOH('getcartdetails', parameters1).subscribe(
                            (data) => {
                                if (data.length > 0) {
                                    for (var j = 0; j < data.length; j++) {
                                        if (data[j].latitude != '') {
                                            if (data[j].assignstatus == 'S') {
                                                data[j].cartcolor = "green.png";
                                            }
                                            this.cartsarry.push([
                                                data[j].name,
                                                data[j].latitude,
                                                data[j].longitude,
                                                data[j].id,
                                                data[j].cartroletype,
                                                data[j].cartcolor,
                                                data[j].deviceStatus
                                            ]);
                                        }
                                    }
                                    this.cartsarry = this.cartsarry;
                                    for (var i = 0; i < this.cartsarry.length; i++) {
                                        var carts = this.cartsarry[i];
                                    }
                                    this.map.setCenter(new google.maps.LatLng(parseFloat(carts[1]), parseFloat(carts[2])));
                                    this.map.setZoom(20);
                                    this.setMarkers(this.map);
                                    this.spinnerService.hide();
                                }
                            }, error => {
                                this.spinnerService.hide();
                            }
                        );
                    }
                }, error => {
                    this.spinnerService.hide();
                }
            );
        }
        else {
            this.maploading();
            this.getinplayCartDetails(this.golfclubid);
            this.spinnerService.hide();
        }
    }

    viewcartonmap() {
        this.spinnerService.show();
        let parameters = {
            clubid: parseInt(this.golfclubid),
            courseid: localStorage.getItem('courseId'),
            cartid: parseInt(this.ddlcarts)
        };
        localStorage.removeItem('cartId');
        this.cartsarry = [];
        this.api.postOH('getinplaycartdetailsv2', parameters).subscribe(
            (response) => {
                if (response.length > 0) {
                    for (var i = 0; i < response.length; i++) {
                        if (response[i].latitude != '') {
                            this.cartsarry.push([
                                response[i].name,
                                response[i].latitude,
                                response[i].longitude,
                                response[i].id,
                                response[i].cartroletype,
                                response[i].cartcolor,
                                response[i].deviceStatus
                            ]);
                            this.cartsarry = this.cartsarry;
                            this.maploadingforcart();
                        } else {
                            this.ddlcarts = "0";
                            this.getinplayCartDetails(this.golfclubid);
                            this.maploading();
                        }
                    }
                } else {
                    let parameters1 = {
                        searchvalue: " WHERE CD_ID='" + this.ddlcarts + "' and CD_STATUS='Y' and CD_ROLE_TYPE in(3,4,7) ",
                        courseid: 0
                    }
                    this.api.postOH('getcartdetails', parameters1).subscribe(
                        (data) => {
                            if (data.length > 0) {
                                for (var j = 0; j < data.length; j++) {
                                    if (data[j].latitude != '') {
                                        if (data[j].assignstatus == 'S') {
                                            data[j].cartcolor = "green.png";
                                        }
                                        this.cartsarry.push([
                                            data[j].name,
                                            data[j].latitude,
                                            data[j].longitude,
                                            data[j].id,
                                            data[j].cartroletype,
                                            data[j].cartcolor,
                                            data[j].deviceStatus
                                        ]);
                                    } else {
                                        this.ddlcarts = "0";
                                        this.getinplayCartDetails(this.golfclubid);
                                        this.maploading();
                                    }
                                }
                                this.cartsarry = this.cartsarry;
                                this.maploadingforcart();
                            } else {
                                this.ddlcarts = "0";
                                this.getinplayCartDetails(this.golfclubid);
                                this.maploading();
                            }
                        }, error => {
                            this.spinnerService.hide();
                        }
                    );
                }
                this.spinnerService.hide();
            }, error => {
                this.spinnerService.hide();
            }
        );
    }

    maploadingforcart() {
        for (var i = 0; i < this.cartsarry.length; i++) {
            var carts = this.cartsarry[i];
        }
        var stylecontrols = document.getElementById('styleControls');
        this.map = new google.maps.Map(document.getElementById('map'), {
            center: { lat: parseFloat(carts[1]), lng: parseFloat(carts[2]) },
            zoom: 20,
            //disableDefaultUI: true,
            mapTypeId: 'satellite',
            tilt: 0,
            rotateControl: true,
            fullscreenControl: false,
            zoomControl: false,
            streetViewControl: false,
            mapTypeControl: false,
            //heading:parseInt(this.courserotate)
        });
        currentZoom = this.map.getZoom();
        minZoom = 0;
        maxZoom = 21;
        this.setoverlayimage();
        this.setMarkers(this.map);
        this.map.controls[google.maps.ControlPosition.TOP_RIGHT].push(stylecontrols);
    }

    setoverlayimage() {
        let me = this;
        for (let i = 0; i < this.CoursesInfo.length; i++) {
            var imageMapType = new google.maps.ImageMapType({
                getTileUrl: function (coord, zoom) {
                    //console.log('http://iadmin.azaz.com/tiles/' + me.golfclubid+ '/' +me.CoursesInfo[i].id+ '/' + zoom + '/' + coord.x + '/' + coord.y + '.png');
                    // let clbid=''; let cursid='';
                    // if(me.golfclubid=='1002'){clbid='1445'}else{clbid=me.golfclubid};
                    // if(me.CoursesInfo[i].id==2){cursid='539'}else if(me.CoursesInfo[i].id==3){cursid='540'}else if(me.CoursesInfo[i].id==4){cursid='541'}else{cursid=me.CoursesInfo[i].id};
                    // return ['http://cp.izongolf.com/tiles/' + clbid + '/' + cursid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
                    return ['http://cp.izongolf.com/tiles/' + me.golfclubid + '/' + me.CoursesInfo[i].id + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
                },
                tileSize: new google.maps.Size(256, 256)
            });
            this.map.overlayMapTypes.push(imageMapType);
        }
    }

    setMarkers(map) {
        this.spinnerService.show();
        let me = this;
        me.clearMarkers();
        for (var i = 0; i < me.cartsarry.length; i++) {
            var carts = me.cartsarry[i];
            if (carts[4] == '3' || carts[4] == '7') {
                this.bluecircleimage = 'assets/imgs/star_view.png';
                this.iconnameonmap = '';
            } else if (carts[4] == '4') {
                this.bluecircleimage = 'assets/imgs/beverage_view.png';
                this.iconnameonmap = '';
            } else {
                if (carts[6] == 'C') {
                    this.bluecircleimage = 'assets/imgs/walkers/' + carts[5];
                    this.iconnameonmap = '';
                } else {
                    this.bluecircleimage = 'assets/imgs/' + carts[5];
                    this.iconnameonmap = {
                        text: carts[0],
                        color: 'white',
                        title: carts[0]
                    };
                }
            }
            var marker = new google.maps.Marker({
                position: { lat: parseFloat(carts[1]), lng: parseFloat(carts[2]) },
                icon: me.bluecircleimage,
                label: me.iconnameonmap,
                zIndex: parseInt(carts[3]),
                id: parseInt(carts[3])
            });
            marker.setMap(map);
            me.markers.push(marker);
            if (carts[6] == 'C') {
                marker.setTitle(carts[0]);
            }
            var infowindow = new google.maps.InfoWindow();
            google.maps.event.addListener(marker, 'click', (function (marker, infowindow) {
                return function () {
                    for (var i = 0; i < me.cartsarry.length; i++) {
                        if (marker.id == me.cartsarry[i][3]) {
                            this.cartlabelname = me.cartsarry[i][0];
                            this.fleetCartId = me.cartsarry[i][3];
                            this.fleetRoleId = me.cartsarry[i][4];
                            this.fleetCartColor = me.cartsarry[i][5];
                            this.fleetDeviceType = me.cartsarry[i][6];
                        }
                    }
                    var content = "";
                    me.closeLastOpenedInfoWindow();
                    if (this.fleetCartId > 0 && this.fleetRoleId == 0) {
                        let parameters = { searchvalue: " WHERE SC_CD_ID='" + this.fleetCartId + "' AND SC_GAME_STATUS='L'" };
                        me.inplayDetails = [];
                        me.api.postOH('getcartassignedusers', parameters).subscribe(
                            (response) => {
                                me.inplayDetails = [];
                                if (response.length > 0) {
                                    for (let i = 0; i < response.length; i++) {
                                        me.inplayDetails.push({
                                            "cartid": response[i].cartid,
                                            "cartname": response[i].cartname,
                                            "frontnine": response[i].frontnine,
                                            "izonuseremail": response[i].izonuseremail,
                                            "izonusername": response[i].izonusername,
                                            "createddateinampm": response[i].createddate,
                                            "starttime": response[i].starttime,
                                            "endtime": response[i].endtime,
                                            "izonusermobile": response[i].izonusermobile,
                                            "izonuserpwd": response[i].izonuserpwd,
                                        })
                                    }
                                    me.startinghole = response[0].frontnine === "Y" ? "1st" : "10th";
                                    if (response[0].starttime != "") {
                                        var st = new Date(response[0].starttime);
                                        st.setMinutes(st.getMinutes() - 4);
                                        me.starttime = moment(st).format('MM.DD.YYYY @ hh:mm A');
                                    }
                                    else {
                                        // var cd = new Date(response[0].createddateinampm);
                                        // cd.setMinutes(cd.getMinutes() - 4);
                                        // me.starttime = moment(cd).format('MM.DD.YYYY @ hh:mm A');
                                        me.starttime = "--";
                                    }

                                    // content to display in infowindow
                                    content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Cart Details:</div>'
                                    content += '<div style="color:green;font-weight:bold">Riders:</div>' +
                                        '<div class="horizontalline"></div>'
                                    for (let inplayuser of me.inplayDetails) {
                                        content += '<div class="username">' + inplayuser.izonusername + '</div>'
                                    }
                                    content += '<div style="margin-top:15px;margin-bottom:6px;">' +
                                        '<div style="color:green;font-weight:bold">Start Time:</div>' +
                                        '<div class="fontweight">' + me.starttime + '</div>' +
                                        '</div>' +
                                        '<div class="horizontalline"></div>'
                                    content += '<span style="cursor:pointer;float:left;"><a id="messageWindowButton" style="margin-right:5px;color:#ed9325de;"><i class="fa fa-envelope"></i>&nbsp;Message</a></span>'
                                    content += '<span style="color:green;cursor:pointer;float:right;" id="infoWindowButton"><a style="font-weight: bold;">More Info</a></span>';

                                    var cartId = ''; var cartName = ''; var cartcolor = ''; var cartDeviceType = '';
                                    cartId = me.inplayDetails[0].cartid;
                                    cartName = this.cartlabelname;
                                    cartcolor = this.fleetCartColor;
                                    cartDeviceType = this.fleetDeviceType;

                                    infowindow.setContent(content);
                                    infowindow.open(map, marker);

                                    infowindow.addListener('domready', () => {
                                        document.getElementById("infoWindowButton").addEventListener("click", () => {
                                            if (cartDeviceType == 'C') {
                                                cartName = 'W';
                                            }
                                            me.navigateCartPlayTrack(cartId, cartName, '0');
                                        });
                                    });
                                    infowindow.addListener('domready', () => {
                                        document.getElementById("messageWindowButton").addEventListener("click", () => {
                                            me.messageopenModal(cartId, cartName, cartcolor, '0', cartDeviceType);
                                        });
                                    });
                                    me.lastOpenedInfoWindow = infowindow;
                                }
                                else {
                                    if (this.fleetCartColor != 'green.png') {
                                        content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Cart Details:</div>'
                                        content += '<div><span>No data found</span></div>'

                                        infowindow.setContent(content);
                                        infowindow.open(map, marker);
                                        me.lastOpenedInfoWindow = infowindow;
                                    } else {
                                        content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Cart Details:</div>'
                                        content += '<div style="margin-bottom:6px;margin-bottom:6px;"><span>Not assigned</span></div>'
                                        '<div class="horizontalline"></div><br>'
                                        content += '<span style="cursor:pointer;float:left;"><a id="stagingMessageWindowButton" style="margin-right:5px;color:#ed9325de;"><i class="fa fa-envelope"></i>&nbsp;Message</a></span>'
                                        content += '<span style="color:green;cursor:pointer;float:right;" id="staginCartAssignButon"><a style="font-weight: bold;">Assign</a></span>';

                                        infowindow.setContent(content);
                                        infowindow.open(map, marker);

                                        infowindow.addListener('domready', () => {
                                            document.getElementById("stagingMessageWindowButton").addEventListener("click", () => {
                                                me.messageopenModal(this.fleetCartId, this.cartlabelname, this.fleetCartColor, '0', this.fleetDeviceType);
                                            });
                                        });

                                        infowindow.addListener('domready', () => {
                                            document.getElementById("staginCartAssignButon").addEventListener("click", () => {
                                                me.stagingAssignCart(this.fleetCartId);
                                            });
                                        });
                                        me.lastOpenedInfoWindow = infowindow;
                                    }
                                }
                            });
                    }
                    else {
                        for (var i = 0; i < me.cartsarry.length; i++) {
                            if (marker.id == me.cartsarry[i][3]) {
                                me.fleetRoleId = me.cartsarry[i][4];
                                me.fleetCartColor = me.cartsarry[i][5];
                                me.fleetDeviceType = me.cartsarry[i][6];
                            }
                        }
                        let parameters = {
                            searchvalue: " where CLL_GCB_ID=" + me.golfclubid + " AND CLL_CD_ID=" + marker.id + " AND CLL_ACTION='I' AND CLL_U_TYPE=" + me.fleetRoleId + " "
                        };
                        me.api.postOH('rangerandbeveragedetails', parameters).subscribe(
                            (response) => {
                                if (response.length > 0) {
                                    me.ranbavname = response[0].name;
                                    me.ranbavId = response[0].uid;
                                    me.cartlabelname = response[0].cartname;
                                    localStorage.setItem('rangerBeverageName', me.ranbavname);
                                    localStorage.setItem('rangerBeverageId', me.ranbavId);

                                    // content to display in infowindow
                                    if (me.fleetRoleId == 3) {
                                        content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Cart Details (' + me.cartlabelname + '):</div>'
                                        content += '<div style="color:green;font-weight:bold">Ranger:</div>'
                                    }
                                    else if (me.fleetRoleId == 4) {
                                        content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Cart Details (' + me.cartlabelname + '):</div>'
                                        content += '<div style="color:green;font-weight:bold">Beverage:</div>'
                                    }
                                    else if (me.fleetRoleId == 7) {
                                        content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Cart Details (' + me.cartlabelname + '):</div>'
                                        content += '<div style="color:green;font-weight:bold">Bag Drop:</div>'
                                    }
                                    content += '<div class="username" style="white-space: nowrap;overflow: hidden;text-overflow: ellipsis;margin-bottom:6px;">' + me.ranbavname + '</div>'
                                    content += '<span style="cursor:pointer;float:left;margin-top: 4px;"><a id="messageWindowButton" style="color:#ed9325de;margin-right:5px;"><i class="fa fa-envelope"></i>&nbsp;Message</a></span>'
                                    content += '<span style="cursor:pointer;float:right;margin-top: 4px;" id="infoWindowButton"><a id="link1" style="font-weight: bold;">More Info</a></span>';
                                    var cartId = ''; var cartName = ''; var roleId = ''; var cartcolor = ''; var cartDeviceType = '';
                                    cartId = marker.id;
                                    cartName = me.cartlabelname;
                                    roleId = me.fleetRoleId;
                                    cartcolor = me.fleetCartColor;
                                    cartDeviceType = me.fleetDeviceType;

                                    infowindow.setContent(content);
                                    infowindow.open(map, marker);

                                    infowindow.addListener('domready', () => {
                                        document.getElementById("infoWindowButton").addEventListener("click", () => {
                                            me.navigateCartPlayTrack(cartId, cartName, roleId);
                                        });
                                    });

                                    //calling angular2 function from a google map infowindow
                                    infowindow.addListener('domready', () => {
                                        document.getElementById("messageWindowButton").addEventListener("click", () => {
                                            me.messageopenModal(cartId, cartName, cartcolor, roleId, cartDeviceType);
                                        });
                                    });
                                    me.lastOpenedInfoWindow = infowindow;
                                }
                                else {
                                    me.ranbavname = "";
                                    if (me.fleetRoleId == 3) {
                                        content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Ranger Details (' + carts[0] + '):</div>'
                                    }
                                    else if (me.fleetRoleId == 4) {
                                        content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Beverage Details (' + carts[0] + '):</div>'
                                    }
                                    else if (me.fleetRoleId == 7) {
                                        content += '<div style="color: #5c5959;border-bottom: 1px solid #ddd;padding-bottom: 5px;font-weight:bold;margin-bottom: 5px;">Bag Drop Details (' + carts[0] + '):</div>'
                                    }
                                    content += '<div><span>No data found</span></div>'
                                    infowindow.setContent(content);
                                    infowindow.open(map, marker);
                                    me.lastOpenedInfoWindow = infowindow;
                                }
                            }, error => {

                            }
                        );
                    }
                };
            })(marker, infowindow));
        }
        this.spinnerService.hide();
    }

    // closes last opened infowindow
    closeLastOpenedInfoWindow() {
        if (this.lastOpenedInfoWindow) {
            this.lastOpenedInfoWindow.close();
        }
    }

    // Sets the map on all markers in the array.
    setMapOnAll(map) {
        for (var i = 0; i < this.markers.length; i++) {
            this.markers[i].setMap(map);
        }
    }

    // Removes the markers from the map, but keeps them in the array.
    clearMarkers() {
        this.setMapOnAll(null);
        this.markers = [];
    }

    goBackClub() {
        localStorage.removeItem('cartId');
        this.router.navigate(['/cartmanagement/cartdetails']);
    }

    assignCart(carts) {
        localStorage.setItem('readyCartId', carts.value);
        localStorage.setItem('readyCartName', carts.name);
        this.router.navigate(['/cartmanagement/cartuserassignment']);
    }

    stagingAssignCart(cart) {
        localStorage.setItem('readyCartId', cart);
        this.router.navigate(['/cartmanagement/cartuserassignment']);
    }

    getlastupdateddatetime() {
        let currentDate: any = ''; this.lastupdateddate = '';
        let d = new Date();
        let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
        currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
        this.lastupdateddate = moment(currentDate).format('MM.DD.YYYY HH:mm:ss');
    }

    refreshpage() {
        this.ddlcarts = '0';
        this.soursefrom = true;
        this.getreadyCartDetails(this.golfclubid);
        this.getRangerBeverageBagDropCartDetails(this.golfclubid);
        this.getinplayCartDetails(this.golfclubid);
        this.getStagingCartDetails(this.golfclubid);
        this.getCartsList();
        //this.getCartMap();
        this.getlastupdateddatetime();
        this.invalidcls = 1;
        this.activeall = "activecss";
        this.activeinplay = "";
        this.activeyellow = "";
        this.readycartslist = "";
        this.showready = false;
        this.showinplay = true;
    }

    openModal(template: TemplateRef<any>, cartValues) {
        if (this.messagepopup == false) {
            this.modalRef = this.modalService.show(template, { class: 'modal-lg modal-sm' });
            this.messagepopup = true;
            this.cartId = cartValues.value;
            this.messageForm.reset();
            this.submitAttempt = false;
            this.cartMessage = "";
            this.messageBtn = false;
        }
    }

    closemessgepopup() {
        this.modalRef.hide();
        this.messagepopup = false;
    }

    sendMessage() {
        this.currentGolfClubDateTime = "";
        if (!this.messageForm.valid) {
            this.invalidcls = 0;
        }
        this.submitAttempt = true;
        var lcmessage = this.cartMessage;
        lcmessage = lcmessage.trim();
        if (lcmessage != '') {
            if (this.messageForm.valid) {
                $("span").css("pointer-events", "none");
                let currentDate: any = '';
                let d = new Date();
                let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
                currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
                this.currentGolfClubDateTime = moment(currentDate).format('YYYY-MM-DD HH:mm:ss');
                var messageModal = { "action": "A", "id": 0, "clubid": this.golfclubid, "courseid": localStorage.getItem('courseId'), "fromcartid": 0, "tocartid": this.cartId, "message": this.cartMessage, "readstatus": "Y", "userid": this.userId, "datetime": this.currentGolfClubDateTime }
                this.api.postOH('savecartmessages', messageModal).subscribe(
                    response => {
                        this.spinnerService.hide();
                        if (response == "Success") {
                            this.invalidcls = 1;
                            let msg = '<span style="color: green">Message sent successfully</span>';
                            this.getclubcartmessages();
                            this.authService.getCall();
                            this.cartMessage = '';
                            this.toastMessage(msg);
                        } else {
                            let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                            this.toastMessage(msg);
                        }
                        $("span").css("pointer-events", "auto");
                    },
                    err => {
                        this.spinnerService.hide();
                        $("span").css("pointer-events", "auto");
                    }
                );
            }
        } else {
            this.cartMessage = '';
            this.invalidcls = 0;
            this.submitAttempt = true;
        }
    }

    getRangerBeverageNames(values) {
        this.getTabletVersion(values);
        this.ranbavname = "";
        this.message = "Loading..";
        let parameters = {
            searchvalue: " where CLL_GCB_ID=" + this.golfclubid + " AND CLL_CD_ID=" + values.value + " AND CLL_ACTION='I' AND CLL_U_TYPE=" + values.roleId + " "
        };
        this.api.postOH('rangerandbeveragedetails', parameters).subscribe(
            (response) => {
                if (response.length > 0) {
                    this.ranbavname = response[0].name;
                    this.ranbavId = response[0].uid;
                    localStorage.setItem('rangerBeverageName', this.ranbavname);
                    localStorage.setItem('rangerBeverageId', this.ranbavId);
                }
                else {
                    this.message = "No data found";
                }
            }, error => {

            }
        );
    }

    getTabletVersion(version) {
        this.showpopover = true;
        var device = ""; this.android = "none"; this.apple = "none";
        device = version.deviceid.toLowerCase();
        if (device.indexOf('android') >= 0) {
            this.android = "block"; this.apple = "none";
        }
        else if (device.indexOf('ios') >= 0) {
            this.apple = "block"; this.android = "none";
        }
        else {
            this.android = "block"; this.apple = "none";
        }
    }
    getcartsinfo(val) {
        this.allcarts = "cart-icon-green1.png";
        //  this.inplaycarts = "timer.png";
        // this.yellowcarts = "warning.png";
        this.inplaycarts = "cart-icon-orange.png";
        this.yellowcarts = "cart-icon-red.png";
        this.redcarts = "maintenance.PNG";
        this.activeall = "";
        this.activeinplay = "";
        this.activeyellow = "";
        this.activered = "";
        this.readycartslist = "";
        this.showready = false;
        this.showinplay = true;
        this.showmsgs = false;
        this.sendmessage = false;
        if (val == 1) {
            this.inplay = this.inplaycartsarray;
            this.allcarts = "cart-icon.png";
            this.activeall = "activecss";
            this.inplaycount = this.inplay.length;
        }
        else if (val == 2) {
            this.inplay = [];

            for (let i = 0; i < this.inplaycartsarray.length; i++) {
                if (this.inplaycartsarray[i].cartcolor === "yellow_circle.png") {
                    this.inplay.push({
                        value: this.inplaycartsarray[i].value,
                        name: this.inplaycartsarray[i].name,
                        roleId: this.inplaycartsarray[i].roleId,
                        deviceid: this.inplaycartsarray[i].deviceid,
                        cartcolor: this.inplaycartsarray[i].cartcolor,
                        Selected: true,
                        deviceStatus: this.inplaycartsarray[i].deviceStatus
                    });
                }
            }
            this.inplaycount = this.inplay.length;
            this.inplaycarts = "cart-icon-orange.png";
            this.activeinplay = "activecss";
        }
        else if (val == 3) {
            this.inplay = [];
            for (let i = 0; i < this.inplaycartsarray.length; i++) {
                if (this.inplaycartsarray[i].cartcolor === "red_circle.png") {
                    this.inplay.push({
                        value: this.inplaycartsarray[i].value,
                        name: this.inplaycartsarray[i].name,
                        roleId: this.inplaycartsarray[i].roleId,
                        deviceid: this.inplaycartsarray[i].deviceid,
                        cartcolor: this.inplaycartsarray[i].cartcolor,
                        Selected: true,
                        deviceStatus: this.inplaycartsarray[i].deviceStatus
                    });
                }
            }

            this.inplaycount = this.inplay.length;
            this.yellowcarts = "cart-icon-red.png";
            this.activeyellow = "activecss";
        }
        else if (val == 4) {
            this.showready = true;
            this.showinplay = false;
            this.readycartslist = "activecss";
            // this.inplay = [];
            // this.inplaycount = 0;
            // this.redcarts = "maintenance1.png";
            // this.activered = "activecss";
        }
    }
    increaseZoom() {
        if (currentZoom <= maxZoom) {
            currentZoom = currentZoom + 1;
            this.map.setZoom(currentZoom);
        }
        else if (currentZoom > maxZoom) {
            currentZoom = currentZoom;
            this.map.setZoom(currentZoom);
        }
    }

    decreaseZoom() {
        if (currentZoom >= minZoom) {
            currentZoom = currentZoom - 1;
            this.map.setZoom(currentZoom);
        }
        else if (currentZoom < minZoom) {
            currentZoom = currentZoom;
            this.map.setZoom(currentZoom);
        }
    }

    messageopenModal(cartId, cartName, cartcolor, roleid, cartDeviceType) {
        this.lastOpenedInfoWindow.close();
        this.sendmessage = false;
        this.invalidcls = 1;
        this.showmsgs = true;
        this.showpopover = false;
        this.cartId = cartId;

        if (roleid == "3" || roleid == "7") {
            this.inplaycartname = '';
            this.inplaycartcolor = 'star_view.png';
        } else if (roleid == "4") {
            this.inplaycartname = '';
            this.inplaycartcolor = 'beverage_view.png';
        }
        else {
            if (cartDeviceType == 'C') {
                this.displayWalkerName = cartName;
                this.inplaycartname = 'W';
            } else {
                this.inplaycartname = cartName;
            }
            this.inplaycartcolor = cartcolor;
        }
        this.sendmessage = true;
        this.getclubcartmessages();
    }


    showmessages(cartValues) {
        //window.scrollTo(500, 700);
        this.displayWalkerName = '';
        this.cartMessage = "";
        this.sendmessage = false;
        this.invalidcls = 1;
        this.showmsgs = true;
        this.showpopover = false;
        this.cartId = cartValues.value;
        if (cartValues.roleId == "3" || cartValues.roleId == "4" || cartValues.roleId == "7") {
            this.inplaycartname = "";
        }
        else {
            if (cartValues.deviceStatus == 'C') {
                this.displayWalkerName = cartValues.name;
                this.inplaycartname = 'W';
            } else {
                this.inplaycartname = cartValues.name;
            }
        }

        this.inplaycartcolor = cartValues.cartcolor;
        this.sendmessage = true;
        this.getclubcartmessages();
    }
    getclubcartmessages() {
        this.currentGolfClubDateTime = "";
        this.clubcartmessages = [];
        this.allclubcartmessages = [];
        let currentDate: any = '';
        let d = new Date();
        let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
        currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
        this.currentGolfClubDateTime = moment(currentDate).format('YYYY-MM-DD HH:mm:ss');

        let parameters = {
            "clubid": this.golfclubid, "fromcartid": "0", "tocartid": this.cartId, "totalcount": "0", "currentdate": this.currentGolfClubDateTime
        }
        this.api.postOH('Getclubcartmessages', parameters).subscribe(
            response => {
                if (response.length !== 0) {
                    if (response.length <= 9) {
                        this.viewall = false;
                    }
                    else if (response.length > 9) {
                        this.viewall = true;
                    }
                    this.spinnerService.hide();
                    for (let i = 0; i < response.length && i <= 9; i++) {
                        this.clubcartmessages.push({
                            "message": response[i].message,
                            "fromcartid": response[i].fromcartid,
                            "tocartid": response[i].tocartid,
                            "createddate": response[i].createddate,
                        })
                    }
                    for (let i = 0; i < response.length; i++) {
                        this.allclubcartmessages.push({
                            "message": response[i].message,
                            "fromcartid": response[i].fromcartid,
                            "tocartid": response[i].tocartid,
                            "createddate": response[i].createddate,
                        })
                    }
                }
                var msgelmnt = document.getElementById('message');
                msgelmnt.focus();
            }, error => {
                this.spinnerService.hide();
            })
    }
    viewallmessages(template2: TemplateRef<any>) {
        this.templatemessages = this.modalService.show(template2, { class: 'modal-lg modal-sm' });
    }
    declineformessages(): void {
        this.templatemessages.hide();
    }


    onKeyUp(event: any) {
        this.desclength = 180 - event.target.value.length;
    };
    getinplaycarts() {
        this.inplayselected = "";
        this.cartsList = [];
        let parameters = {
            clubid: this.golfclubid,
            courseid: localStorage.getItem('courseId'),
            cartid: 0
        };
        this.api.postOH('getinplaycartdetailsv2', parameters).subscribe(
            (response) => {
                if (response.length != 0) {
                    for (let i = 0; i < response.length; i++) {
                        var cartcolor = "";
                        var cartcolorname = "";
                        if (response[i].cartcolor === 'tournament') {
                            cartcolorname = 'blue_circle.png';
                        }
                        else {
                            cartcolorname = response[i].cartcolor;
                        }
                        if (response[i].deviceStatus == 'T') {
                            this.cartsList.push({
                                value: response[i].id,
                                name: response[i].name,
                                roleId: response[i].cartroletype,
                                deviceid: response[i].deviceid,
                                Selected: true,
                                deviceStatus: response[i].deviceStatus
                            });


                            if (this.inplayselected == "") {
                                this.inplayselected = response[i].id + ', '
                            } else {
                                this.inplayselected = this.inplayselected + response[i].id + ', '
                            }
                        }
                    }
                }
            })
    }

    broadcastmsg(activecartsmessage: TemplateRef<any>) {
        // var msgelmnt = document.getElementById('bcdmessage');
        // msgelmnt.focus();
        this.showmsgs = false;
        this.sendmessage = false;
        this.showcustommsgs = false;
        this.courseerrmsg = false;
        this.errorMessage = "none";
        this.desclength = 180;
        this.broadcartMessage = '';
        this.sub.unsubscribe();
        this.getinplaycarts();
        this.getreadyCartDetails(this.golfclubid);
        this.getRangerBeverageBagDropCartDetails(this.golfclubid);
        let parameters1 = { searchvalue: " where CCM_STATUS='Y'  and CCM_GC_ID='" + localStorage.getItem('courseId') + "'  and CCM_GCB_ID='" + this.golfclubid + "' " };
        this.getCourseCustomMessages(parameters1);
        this.IsinplayAllChecked = true;
        this.IsreadyAllChecked = true;
        this.IsrangerAllChecked = true;
        this.IsbevarageAllChecked = true;
        this.IsbagdropAllChecked = true;
        this.broadmessageForm.reset();
        this.broadcastsubmitAttempt = false;
        this.messageBtn = false;
        this.templatemessages = this.modalService.show(activecartsmessage, { class: 'modal-lg modal-sm' });
    }
    getcustommsgs() {
        this.desclength = 180;
        this.coursemsgid = 0;
        this.showtextArea_[this.indexval] = false;
        this.courseerrmsg = false;
        this.broadcastsubmitAttempt = false;
        this.showcustommsgs = !this.showcustommsgs ? true : false;
        this.selectbar = (this.showcustommsgs) ? "selectbar" : "";
        this.broadcartMessage = (this.showcustommsgs) ? this.broadcartMessage : "";
        this.rowval = -1;
        this.chevroncls = (this.showcustommsgs) ? "chevrn pull-right fa fa-chevron-up" : "chevrn pull-right fa fa-chevron-down"
    }
    getCourseCustomMessages(parameters) {
        this.contactMessages = [];
        this.spinnerService.show();
        this.api.postOH('getcoursecustomcartmessages', parameters).subscribe(
            response => {
                this.spinnerService.hide();
                if (response.length > 0) {
                    for (let i = 0; i < response.length; i++) {
                        this.showtextArea_[i] = false;
                        var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                        var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                        this.contactMessages.push({
                            "id": response[i].id,
                            "description": response[i].description,
                            "createddate": response[i].createddate,
                            "status": status,
                            "statusclass": statusclass,
                        });
                    }

                } else {
                    this.contactMessages = [];
                }
            },
            err => {
                this.spinnerService.hide();
            }
        );
    }

    onSelectionChange(entry, i: any) {
        this.rowval = 0;
        this.rowval = i;
        this.indexval = i;
        this.coursemsgtext = true;
        this.courseerrmsg = false;
        this.coursemsgid = entry.id;
        this.broadmessageForm.reset();
        this.broadcartMessage = '';
        this.broadcartMessage = entry.description;
        this.editCMessage = "";
        this.editCMessage = entry.description;
        this.desclength = 180 - this.editCMessage.length;
        for (var n = 0; n < this.contactMessages.length; n++) {
            if (i == n) {
                this.showtextArea_[i] = true;
            }
            else {
                this.showtextArea_[n] = false;
            }
        }
    }
    sendMessagetoactivecarts() {
        this.selectedCartIds = this.inplayselected + this.rangerselected + this.bevarageselected + this.bagdropselected;
        this.currentGolfClubDateTime = "";
        if (!this.broadmessageForm.valid) {

        }
        this.courseerrmsg = (this.coursemsgid == 0 && this.showcustommsgs) ? true : false;
        this.broadcastsubmitAttempt = true;

        this.messageBtn = true;
        if (this.showcustommsgs) {
            this.broadcartMessage = this.editCMessage;
        }
        this.broadcartMessage = this.broadcartMessage.trim();
        if ((this.broadcartMessage != "") && this.selectedCartIds != '') {
            let currentDate: any = '';
            let d = new Date();
            let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
            currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
            this.currentGolfClubDateTime = moment(currentDate).format('YYYY-MM-DD HH:mm:ss');
            var messageModal = { "action": "A", "id": 0, "clubid": this.golfclubid, "courseid": localStorage.getItem('courseId'), "fromcartid": 0, "tocartids": this.selectedCartIds, "message": this.broadcartMessage, "readstatus": "Y", "userid": this.userId, "datetime": this.currentGolfClubDateTime }
            this.spinnerService.show();
            this.api.postOH('savemultiplecartmessages', messageModal).subscribe(
                response => {
                    this.spinnerService.hide();
                    if (response == "Success") {
                        this.templatemessages.hide();
                        let msg = '<span style="color: green">Message sent successfully</span>';
                        this.editCMessage = "";
                        this.toastMessage(msg);
                        this.authService.getCall();
                        this.closeactivemessgepopup();
                        this.cartId = 0;
                        this.messageBtn = true;

                    } else {
                        let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                        this.toastMessage(msg);
                        this.messageBtn = false;
                    }
                },
                err => {
                    this.spinnerService.hide();
                }
            );
        }
        else {
            this.showtextArea_[this.rowval] = true;
            this.errorMessage = "block";
            this.messageBtn = false;
        }
    }

    closeactivemessgepopup(): void {
        this.templatemessages.hide();
        this.sub = Observable.interval(1000 * 60).subscribe(x => {
            this.soursefrom = true;
            this.getreadyCartDetails(this.golfclubid);
            this.getRangerBeverageBagDropCartDetails(this.golfclubid);
            this.getinplayCartDetails(this.golfclubid);
            this.getCartsList();
            //this.getCartMap();
            this.getlastupdateddatetime();
        });
    }
    inplayCheckUncheckAll() {
        this.courseerrmsg = (this.coursemsgid == 0 && this.showcustommsgs) ? true : false;
        this.inplayselected = '';
        for (var i = 0; i < this.cartsList.length; i++) {
            this.cartsList[i].Selected = this.IsinplayAllChecked;
        }
        for (var i = 0; i < this.cartsList.length; i++) {
            if (this.cartsList[i].Selected == true) {
                if (this.inplayselected == "") {
                    this.inplayselected = this.cartsList[i].value + ', '
                } else {
                    this.inplayselected = this.inplayselected + this.cartsList[i].value + ', '
                }
            }
        }
    }
    inplayCheckUncheckHeader() {
        this.inplayselected = '';
        this.courseerrmsg = (this.coursemsgid == 0 && this.showcustommsgs) ? true : false;
        this.IsinplayAllChecked = false;
        for (var i = 0; i < this.cartsList.length; i++) {
            if (!this.cartsList[i].Selected) {
                this.IsinplayAllChecked = false;
                this.errorMessage = "none";
                break;
            }
            else {
                if (this.cartsList.length == 1) { this.errorMessage = "none"; }
                this.IsinplayAllChecked = true;
            }
        };
        for (var i = 0; i < this.cartsList.length; i++) {
            if (this.cartsList[i].Selected == true) {
                if (this.inplayselected == "") {
                    this.inplayselected = this.cartsList[i].value + ', '
                } else {
                    this.inplayselected = this.inplayselected + this.cartsList[i].value + ', '
                }
            }
        }
    }
    rangerCheckUncheckAll() {
        this.rangerselected = '';
        this.courseerrmsg = (this.coursemsgid == 0 && this.showcustommsgs) ? true : false;
        for (var i = 0; i < this.ranger.length; i++) {
            this.ranger[i].Selected = this.IsrangerAllChecked;
        }
        for (var i = 0; i < this.ranger.length; i++) {
            if (this.ranger[i].Selected == true) {
                if (this.rangerselected == "") {
                    this.rangerselected = this.ranger[i].value + ', '
                } else {
                    this.rangerselected = this.rangerselected + this.ranger[i].value + ', '
                }
            }
        }

        if (this.rangerselected === '' && this.inplayselected === '' && this.bagdropselected === '' && this.bevarageselected === '') {
            this.errorMessage = "block";
        }
        else {
            this.errorMessage = "none";
        }
    }
    rangerCheckUncheckHeader() {
        this.rangerselected = '';
        this.courseerrmsg = (this.coursemsgid == 0 && this.showcustommsgs) ? true : false;
        this.IsrangerAllChecked = false;
        for (var i = 0; i < this.ranger.length; i++) {
            if (!this.ranger[i].Selected) {
                this.IsrangerAllChecked = false;
                this.errorMessage = "none";
                break;
            }
            else {
                if (this.ranger.length == 1) { this.errorMessage = "none"; }
                this.IsrangerAllChecked = true;
            }
        };
        for (var i = 0; i < this.ranger.length; i++) {
            if (this.ranger[i].Selected == true) {
                if (this.rangerselected == "") {
                    this.rangerselected = this.ranger[i].value + ', '
                } else {
                    this.rangerselected = this.rangerselected + this.ranger[i].value + ', '
                }
            }
        }
    }

    bevarageCheckUncheckAll() {
        this.bevarageselected = '';
        this.courseerrmsg = (this.coursemsgid == 0 && this.showcustommsgs) ? true : false;
        for (var i = 0; i < this.beverage.length; i++) {
            this.beverage[i].Selected = this.IsbevarageAllChecked;
        }
        for (var i = 0; i < this.beverage.length; i++) {
            if (this.beverage[i].Selected == true) {
                if (this.bevarageselected == "") {
                    this.bevarageselected = this.beverage[i].value + ', '
                } else {
                    this.bevarageselected = this.bevarageselected + this.beverage[i].value + ', '
                }
            }
        }
        if (this.rangerselected === '' && this.inplayselected === '' && this.bagdropselected === '' && this.bevarageselected === '') {
            this.errorMessage = "block";
        }
        else {
            this.errorMessage = "none";
        }
    }
    bevarageCheckUncheckHeader() {
        this.bevarageselected = '';
        this.courseerrmsg = (this.coursemsgid == 0 && this.showcustommsgs) ? true : false;
        this.IsbevarageAllChecked = false;
        for (var i = 0; i < this.beverage.length; i++) {
            if (!this.beverage[i].Selected) {
                this.IsbevarageAllChecked = false;
                this.errorMessage = "none";
                break;
            }
            else {
                if (this.beverage.length == 1) { this.errorMessage = "none"; }
                this.IsbevarageAllChecked = true;
            }
        };
        for (var i = 0; i < this.beverage.length; i++) {
            if (this.beverage[i].Selected == true) {
                if (this.bevarageselected == "") {
                    this.bevarageselected = this.beverage[i].value + ', '
                } else {
                    this.bevarageselected = this.bevarageselected + this.beverage[i].value + ', '
                }
            }
        }
    }
    bagdropCheckUncheckAll() {
        this.bagdropselected = '';

        for (var i = 0; i < this.bagDrop.length; i++) {
            this.bagDrop[i].Selected = this.IsbagdropAllChecked;
        }
        for (var i = 0; i < this.bagDrop.length; i++) {
            if (this.bagDrop[i].Selected == true) {
                if (this.bagdropselected == "") {
                    this.bagdropselected = this.bagDrop[i].value + ', '
                } else {
                    this.bagdropselected = this.bagdropselected + this.bagDrop[i].value + ', '
                }
            }
        }
        if (this.rangerselected === '' && this.inplayselected === '' && this.bagdropselected === '' && this.bevarageselected === '') {
            this.errorMessage = "block";
        }
        else {
            this.errorMessage = "none";
        }
        this.courseerrmsg = (this.coursemsgid == 0 && this.showcustommsgs) ? true : false;
    }
    bagdropCheckUncheckHeader() {
        this.bagdropselected = '';
        this.courseerrmsg = (this.coursemsgid == 0 && this.showcustommsgs) ? true : false;
        this.IsbagdropAllChecked = false;
        for (var i = 0; i < this.bagDrop.length; i++) {
            if (!this.bagDrop[i].Selected) {
                this.IsbagdropAllChecked = false;
                this.errorMessage = "none";
                break;
            }
            else {
                this.IsbagdropAllChecked = true;
                if (this.bagDrop.length == 1) { this.errorMessage = "none"; }
            }
        };
        for (var i = 0; i < this.bagDrop.length; i++) {
            if (this.bagDrop[i].Selected == true) {
                if (this.bagdropselected == "") {
                    this.bagdropselected = this.bagDrop[i].value + ', '
                } else {
                    this.bagdropselected = this.bagdropselected + this.bagDrop[i].value + ', '
                }
            }
        }
    }
}
