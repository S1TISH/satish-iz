import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CartuserassignmentComponent } from './cartuserassignment.component';

describe('CartuserassignmentComponent', () => {
  let component: CartuserassignmentComponent;
  let fixture: ComponentFixture<CartuserassignmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CartuserassignmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CartuserassignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
