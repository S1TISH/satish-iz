import { Component, OnInit, ViewContainerRef, TemplateRef, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import * as moment from "moment";
import { Title } from '@angular/platform-browser';

@Component({
    selector: 'app-cartuserassignment',
    templateUrl: './cartuserassignment.component.html',
    styleUrls: ['./cartuserassignment.component.css']
})
export class CartuserassignmentComponent implements OnInit {
    modalRef: BsModalRef;
    public cartuserForm: FormGroup; continueAttempt: boolean = false;
    cartDate: Date; cartTime: Date; golfer: any; selectedDate: string = ""; selectedTime: string = "";
    divheader: string = "Cart Golfer Assignment"; cartDetails: any = []; courseDetails: any = []; clubId: any;
    usersView: string = "none"; addUsers: string = "none"; userCartId: any; readyCartId: any; courseName: any;
    Golfer1: string = "block"; Golfer2: string = "block"; GolferBtn1: string = "none"; CartAssignBtn: string = "block";
    //first name search
    autocomplete: string = "none"; userDetails: any = []; errorCount: any = 0;
    //second name search
    autocomplete1: string = "none"; userDetails1: any = []; errorCount1: any = 0;
    //first lastname search
    lastnamesearch: any;
    //second lastname search
    lastnamesearch1: any;
    //first email search
    emailautocomplete: string = "none"; existingEmail: any = []; errorEmailCount: any = 0; UserId: any;
    //second email search
    emailautocomplete1: string = "none"; existingEmail1: any = []; errorEmailCount1: any = 0; UserId1: any;
    //first phone search
    phoneautocomplete: string = "none"; existingPhones: any = []; errorPhoneCount: any = 0; PhoneUserId: any;
    //second phone search
    phoneautocomplete1: string = "none"; existingPhones1: any = []; errorPhoneCount1: any = 0; PhoneUserId1: any;

    //IZON USER MODEL VALUES
    action: any = 'A'; action1: any = 'A'; id: any; id1: any; carts: any = "0"; course: any = "0"; course2: any = "0";
    name: any = ""; lastname: any = ""; email: any = ""; phonenumber: any = ""; name1: any = ""; lastname1: any = ""; email1: any = ""; phonenumber1: any = "";
    status: any; status1: any; registrationstatus: any = "N"; registrationstatus1: any = "N";
    //IZON CLUB USER MODEL VALUES
    clubaction: string = 'A'; clubid: any; izonuserid: any; handicap: any; clubstatus: any;
    //SCORE CARD MODEL VALUES
    courseid: any; userid: any = 0; cartid: any; gcid: any; scorehandicap: number; //front9: any;
    courseid1: any; userid1: any = 0; cartid1: any; scorehandicap1: number;

    cartUserDetails: any = []; cartName: string; gameStatus: string; userCartName: string; errorMessage: string;
    SecondAttempt: boolean = false; ctnDisabledBtn: any; gameBtn: any;
    cartsviewheadername: string = '';
    pagename: string = '';
    courselat: any; courselong: any; currentGolfClubDateTime: any = ""; HolesInfo: any = [];
    HoleId: any; minStartDate: any; timeoffset: any;
    nineholecourse: boolean = false; frontnine: any = []; backnine: any = [];

    @ViewChild('template') template: TemplateRef<any>;
    @ViewChild('template1') template1: TemplateRef<any>;
    @ViewChild('template2') template2: TemplateRef<any>;
    @ViewChild('template3') template3: TemplateRef<any>;

    constructor(private title: Title, public toastr: ToastsManager, private _router: Router,
        public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService,
        public api: ApiService, private authService: AuthService, vcr: ViewContainerRef,
        private modalService: BsModalService) {

        window.scrollTo(0, 0);
        this.cartsviewheadername = localStorage.getItem('clubname');
        this.pagename = "Assign cart";
        this.title.setTitle("IZON - Assign cart");
        //localStorage.removeItem('courseId');
        this.toastr.setRootViewContainerRef(vcr);

        var clubId = JSON.parse(localStorage.getItem('clubId'));
        this.clubId = clubId;
        var cartId = JSON.parse(localStorage.getItem('cartId'));
        this.userCartId = cartId;
        var cartName = "Assigned Golfers For Cart " + localStorage.getItem('cartUserName');
        this.userCartName = cartName;

        let searchexp = "";
        searchexp = " WHERE GC_GCB_ID='" + this.clubId + "' and GC_STATUS='Y' and  GC_ID='" + localStorage.getItem('courseId') + "'"
        let params = { searchvalue: searchexp };
        this.getcourses(params);

        // this.front9 = "Y";
        this.golfer = "2"; //this.cartDate = new Date(); this.cartTime = new Date();
        this.scorehandicap = 0; this.scorehandicap1 = 0;
        this.HoleId = 1;

        this.spinnerService.hide();
    }

    ngOnInit() {
        this.cartuserForm = this.formBuilder.group({
            fdate: [''],
            ftime: [''],
            fcourse: [0, Validators.compose([Validators.required])],
            fcourse2: [0, Validators.compose([Validators.required])],
            // fchkf9: [''],
            fholeid: [1],
            golfer: [''],
            fcart: [0, Validators.compose([Validators.required])],
            fname: ['', Validators.compose([Validators.required])],
            flastname: [''],
            femail: [''],
            fnumber: [''],
            fname1: [''],
            femail1: [''],
            fnumber1: [''],
            flastname1: ['']
        });

        if (this.userCartId > 0) {
            this.usersView = "block";
            this.addUsers = "none";
            this.getCartUsers(this.userCartId);
        }
        else {
            this.usersView = "none";
            this.addUsers = "block";
            // this.getCartDetails(this.clubId);
            this.getCourseDetails(this.clubId);
        }
        this.readyCartId = JSON.parse(localStorage.getItem('readyCartId'));
        if (this.readyCartId > 0) {
            this.carts = this.readyCartId;
        }
        else {
            this.carts = 0;
        }
    }

    ngOnDestroy() {
        localStorage.removeItem('cartId');
        localStorage.removeItem('readyCartId');
        this.readyCartId = 0;
    }

    //Gets Golf-Course Coordinates
    getcourses(params) {
        this.api.postOH('getgolfcourse', params).subscribe(
            response => {
                if (response.length > 0) {
                    this.courselat = response[0].latitude;
                    this.courselong = response[0].longitude;
                    this.timeoffset = response[0].timeoffset;
                    this.nineholecourse = response[0].oddcourse == 'Y' ? true : false;
                    this.getCourseDatTime();
                    //this.getTimeUsingLatLng(this.courselat, this.courselong);
                }
            }, error => {

            });
    }

    getCourseDatTime() {
        let currentDate: any = ''; this.currentGolfClubDateTime = "";
        let d = new Date();
        let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
        currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
        this.currentGolfClubDateTime = currentDate;
        this.cartDate = this.currentGolfClubDateTime; this.cartTime = this.currentGolfClubDateTime;
        this.minStartDate = this.currentGolfClubDateTime;
    }
    toastMessage(msg) {
        let options = {
            positionClass: 'toast-top-center',
        };

        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 3000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }

    getCourseDetails(id: any) {
        this.courseDetails = [];
        this.frontnine=[];
        this.backnine=[];
        let parameters = { searchvalue: " WHERE GC_GCB_ID='" + id + "' AND GC_STATUS='Y'" };
        this.api.postOH('getgolfcourse', parameters).subscribe(
            (response) => {
                if (response.length > 0) {
                    for (let i = 0; i < response.length; i++) {
                        this.courseDetails.push({
                            value: response[i].id,
                            name: response[i].labelname
                        });
                    }
                    this.frontnine=this.courseDetails;
                    this.backnine=this.courseDetails;
                }
                if ((this.courseDetails.length == 1 || !this.nineholecourse)) {
                    this.course = this.courseDetails[0].value;
                    this.courseName = this.courseDetails[0].name;
                }
                else {
                    this.course = "0"; this.courseName = "";this.course2="0";
                }
                this.getCartDetails(this.clubId);
            });
    }

    getCartDetails(id: any) {
        this.cartDetails = [];
        let parameters = {
            searchvalue: " WHERE CD_GCB_ID='" + id + "' AND (CD_DEVICE_TOKEN!='' or CD_DEVICE_TOKEN !=null) AND CD_ASSIGN_STATUS<>'Y' AND CD_STATUS = 'Y' AND CD_DEVICE_TYPE='T'"
        };
        this.api.postOH('getcartdetails', parameters).subscribe(
            (response) => {
                this.cartDetails = [];
                if (response.length != 0) {
                    for (let i = 0; i < response.length; i++) {
                        this.cartDetails.push({
                            value: response[i].id,
                            name: response[i].name
                        });
                    }
                }
                let parameters = { searchvalue: " WHERE HD_GCB_ID=" + this.clubId + " AND HD_GC_ID = " + localStorage.getItem('courseId') + " and HD_STATUS='Y' " };
                this.getHoles(parameters);
            });
    }

    getHoles(parameters) {
        this.HolesInfo = [];
       // let parameters = { searchvalue: " WHERE HD_GCB_ID=" + this.clubId + " AND HD_GC_ID = " + localStorage.getItem('courseId') + " and HD_STATUS='Y' " };
        this.api.postOH('getholes', parameters).subscribe(
            response => {
                this.HolesInfo = [];
                if (response.length > 0) {
                    for (let i = 0; i < response.length; i++) {
                        this.HolesInfo.push({
                            "id": response[i].sequence,
                            "holename": response[i].holename
                        });
                    }
                }
                this.HoleId = 1;
            },
            err => {

            }
        );
    }

    handleChange(evt) {
        if (evt.target.value == "1") {
            this.Golfer1 = "block"; this.Golfer2 = "none"; this.GolferBtn1 = "block"; this.CartAssignBtn = "none";
            this.name1 = ""; this.lastname1 = ""; this.email1 = ""; this.phonenumber1 = ""; this.continueAttempt = false;
            this.autocomplete1 = "none";
        }
        else if (evt.target.value == "2") {
            this.Golfer1 = "block"; this.Golfer2 = "block"; this.GolferBtn1 = "none"; this.CartAssignBtn = "block";
        }
    }

    //first firstname search
    searchName(term: string): void {
        if (term != '' && term.length > 2) {
            this.userid = 0; this.errorCount = 0;
            this.userDetails = [];
            let parameters = { searchvalue: " where (IZ_U_REGISTRATION_STATUS='Y') AND IZ_U_STATUS='Y' AND ((IZ_U_FIRST_NAME like '%" + term + "%')  OR (IZ_U_LAST_NAME like '%" + term + "%')  OR (IZ_U_FIRST_NAME + ' ' + IZ_U_LAST_NAME like '%" + term + "%'))" };
            this.api.postOH('GetIzonUser', parameters).subscribe(
                (response) => {
                    if (response.length != 0) {
                        this.autocomplete = "block";
                        this.userDetails = [];
                        for (let i = 0; i < response.length; i++) {
                            this.userDetails.push({
                                id: response[i].id,
                                name: response[i].name,
                                lastname: response[i].lastname,
                                email: response[i].email,
                                mobile: response[i].mobile,
                                livestats: response[i].livestats
                            });
                        }
                    }
                    else {
                        this.userDetails = [];
                        this.errorCount = 1;
                        this.autocomplete = "none"; this.userid = 0; this.registrationstatus = "N";
                    }
                });
        }
        else if (term == "") {
            this.userDetails = []; this.errorCount = 0;
            this.autocomplete = "none"; this.userid = 0; this.registrationstatus = "N";
        }
    }

    onselectUser(user: any) {
        this.errorCount = 0;
        if (user.id != 0) {
            if (this.userid1 == user.id) {
                let msg = '<span style="color: red">Golfer 1 and Golfer 2 should be different</span>';
                this.toastMessage(msg);
                this.autocomplete = "none";
            }
            else {
                for (let i = 0; i < this.userDetails.length; i++) {
                    if (this.userDetails[i].livestats != 'L') {
                        if (this.userDetails[i].id == user.id) {
                            this.name = this.userDetails[i].name;
                            this.lastnamesearch = this.lastname = this.userDetails[i].lastname;
                            this.userid = this.id = this.userDetails[i].id;
                            this.email = this.userDetails[i].email;
                            this.phonenumber = this.userDetails[i].mobile.replace(/^(\d{3})(\d{3})(\d{4}).*/, '$1-$2-$3');
                            // this.phonenumber = this.userDetails[i].mobile;
                            this.registrationstatus = 'Y';
                            this.autocomplete = "none";
                        }
                    } else {
                        if (this.userDetails[i].id == user.id) {
                            this.autocomplete = "none";
                            let msg = '<span style="color: red">Golfer Already Assigned</span>';
                            this.toastMessage(msg);
                        }

                    }
                }
            }
        }
    }

    //second firstname search
    searchName1(term: string): void {
        if (term != '' && term.length > 2) {
            this.userid1 = 0; this.errorCount1 = 0;
            this.userDetails1 = [];
            let parameters = { searchvalue: " where (IZ_U_REGISTRATION_STATUS='Y')  AND IZ_U_STATUS='Y'  AND ((IZ_U_FIRST_NAME like '%" + term + "%')  OR (IZ_U_LAST_NAME like '%" + term + "%')  OR (IZ_U_FIRST_NAME + ' ' + IZ_U_LAST_NAME like '%" + term + "%'))" };
            this.api.postOH('GetIzonUser', parameters).subscribe(
                (response) => {
                    if (response.length != 0) {
                        this.autocomplete1 = "block";
                        this.userDetails1 = [];
                        for (let i = 0; i < response.length; i++) {
                            this.userDetails1.push({
                                id: response[i].id,
                                name: response[i].name,
                                lastname: response[i].lastname,
                                email: response[i].email,
                                mobile: response[i].mobile,
                                livestats: response[i].livestats
                            });
                        }
                    }
                    else {
                        this.userDetails1 = [];
                        this.errorCount1 = 1;
                        this.autocomplete1 = "none"; this.userid1 = 0; this.registrationstatus1 = "N";
                    }
                });
        }
        else if (term == "") {
            this.userDetails1 = []; this.errorCount1 = 0;
            this.autocomplete1 = "none"; this.userid1 = 0; this.registrationstatus1 = "N";
        }
    }

    onselectUser1(user: any) {
        this.errorCount1 = 0;
        if (user.id != 0) {
            if (this.userid == user.id) {
                let msg = '<span style="color: red">Golfer 1 and Golfer 2 should be different</span>';
                this.toastMessage(msg);
                this.autocomplete1 = "none";
            }
            else {
                for (let i = 0; i < this.userDetails1.length; i++) {
                    if (this.userDetails1[i].livestats != 'L') {
                        if (this.userDetails1[i].id == user.id) {
                            this.name1 = this.userDetails1[i].name;
                            this.lastnamesearch1 = this.lastname1 = this.userDetails1[i].lastname;
                            this.userid1 = this.id1 = this.userDetails1[i].id;
                            this.email1 = this.userDetails1[i].email;
                            this.phonenumber1 = this.userDetails1[i].mobile.replace(/^(\d{3})(\d{3})(\d{4}).*/, '$1-$2-$3');
                            // this.phonenumber1 = this.userDetails1[i].mobile;
                            this.registrationstatus1 = 'Y';
                            this.autocomplete1 = "none";
                        }
                    } else {
                        if (this.userDetails1[i].id == user.id) {
                            this.autocomplete1 = "none";
                            let msg = '<span style="color: red">Golfer Already Assigned</span>';
                            this.toastMessage(msg);
                        }
                    }
                }
            }
        }
        else {

        }
    }

    ////first lastname search
    //searchLastName(term: string) {
    //    if (this.userid > 0) {
    //        if (this.lastnamesearch == term) {
    //            this.registrationstatus = "Y";
    //        }
    //        else {
    //            this.userid = 0; this.registrationstatus = "N";
    //        }
    //    }
    //    else {
    //        this.registrationstatus = "N";
    //    }
    //}

    ////second lastname search
    //searchLastName1(term: string) {
    //    if (this.userid1 > 0) {
    //        if (this.lastnamesearch1 == term) {
    //            this.registrationstatus1 = "Y";
    //        }
    //        else {
    //            this.userid1 = 0; this.registrationstatus1 = "N";
    //        }
    //    }
    //    else {
    //        this.registrationstatus1 = "N";
    //    }
    //}

    //first email serach
    searchEmail(term: string): void {
        if (term != '') {
            this.existingEmail = []; this.userid = 0; this.errorEmailCount = 0;
            let parameters = { searchvalue: " where IZ_U_EMAIL like '%" + term + "%' AND IZ_U_STATUS='Y'" };
            this.api.postOH('GetIzonUser', parameters).subscribe(
                (response) => {
                    if (response.length != 0) {
                        this.emailautocomplete = "block";
                        this.existingEmail = [];
                        for (let i = 0; i < response.length; i++) {
                            this.existingEmail.push({
                                id: response[i].id,
                                name: response[i].name,
                                lastname: response[i].lastname,
                                password: response[i].password,
                                email: response[i].email,
                                mobile: response[i].mobile,
                                livestats: response[i].livestats
                            });
                        }
                    }
                    else {
                        this.existingEmail = [];
                        this.errorEmailCount = 1;
                        this.emailautocomplete = "none"; this.userid = 0; this.registrationstatus = "N";
                    }
                });
        }
        else if (term == "") {
            this.existingEmail = []; this.errorEmailCount = 0;
            this.emailautocomplete = "none"; this.userid = 0; this.registrationstatus = 'N';
        }
    }

    onSelectEmail(user: any) {
        this.errorEmailCount = 0;
        this.UserId = user.id;
        if (user.id != 0) {
            if (this.userid1 == user.id) {
                let msg = '<span style="color: red">Golfer 1 and Golfer 2 should be different</span>';
                this.toastMessage(msg);
                this.emailautocomplete = "none";
            }
            else if (this.name != "" || this.lastname != "" || this.phonenumber != "") {
                this.modalRef = this.modalService.show(this.template, { class: 'modal-sm' });
            }
            else {
                this.confirm();
            }
        }
    }

    confirm(): void {
        for (let i = 0; i < this.existingEmail.length; i++) {
            if (this.existingEmail[i].livestats != 'L') {
                if (this.existingEmail[i].id == this.UserId) {
                    this.name = this.existingEmail[i].name;
                    this.lastname = this.existingEmail[i].lastname;
                    this.userid = this.id = this.existingEmail[i].id;
                    this.email = this.existingEmail[i].email;
                    this.phonenumber = this.existingEmail[i].mobile.replace(/^(\d{3})(\d{3})(\d{4}).*/, '$1-$2-$3');
                    // this.phonenumber = this.existingEmail[i].mobile;
                    this.registrationstatus = "Y";
                    this.emailautocomplete = "none";
                    this.UserId = 0;
                    this.modalRef.hide(); return;
                }
            } else {
                if (this.existingEmail[i].id == this.UserId) {
                    this.emailautocomplete = "none";
                    this.modalRef.hide();
                    let msg = '<span style="color: red">Golfer Already Assigned</span>';
                    this.toastMessage(msg);
                }
            }
        }
    }

    //second email search
    searchEmail1(term: string): void {
        if (term != '') {
            this.existingEmail1 = []; this.errorEmailCount1 = 0;
            let parameters = { searchvalue: " where IZ_U_EMAIL like '%" + term + "%' AND IZ_U_STATUS='Y'" };
            this.api.postOH('GetIzonUser', parameters).subscribe(
                (response) => {
                    if (response.length != 0) {
                        this.emailautocomplete1 = "block";
                        this.existingEmail1 = [];
                        for (let i = 0; i < response.length; i++) {
                            this.existingEmail1.push({
                                id: response[i].id,
                                name: response[i].name,
                                lastname: response[i].lastname,
                                password: response[i].password,
                                email: response[i].email,
                                mobile: response[i].mobile,
                                livestats: response[i].livestats
                            });
                        }
                    }
                    else {
                        this.existingEmail1 = [];
                        this.errorEmailCount1 = 1;
                        this.emailautocomplete1 = "none"; this.userid1 = 0; this.registrationstatus1 = 'N';
                    }
                });
        }
        else if (term == "") {
            this.existingEmail1 = []; this.errorEmailCount1 = 0;
            this.emailautocomplete1 = "none"; this.userid1 = 0; this.registrationstatus1 = 'N';
        }
    }

    onSelectEmail1(user: any) {
        this.errorEmailCount1 = 0;
        this.UserId1 = user.id;
        if (user.id != 0) {
            if (this.userid == user.id) {
                let msg = '<span style="color: red">Golfer 1 and Golfer 2 should be different</span>';
                this.toastMessage(msg);
                this.emailautocomplete1 = "none";
            }
            else if (this.name1 != "" || this.lastname1 != "" || this.phonenumber1 != "") {
                this.modalRef = this.modalService.show(this.template1, { class: 'modal-sm' });
            }
            else {
                this.confirm1();
            }
        }
    }

    confirm1(): void {
        for (let i = 0; i < this.existingEmail1.length; i++) {
            if (this.existingEmail1[i].livestats != 'L') {
                if (this.existingEmail1[i].id == this.UserId1) {
                    this.name1 = this.existingEmail1[i].name;
                    this.lastname1 = this.existingEmail1[i].lastname;
                    this.userid1 = this.id = this.existingEmail1[i].id;
                    this.email1 = this.existingEmail1[i].email;
                    this.phonenumber1 = this.existingEmail1[i].mobile.replace(/^(\d{3})(\d{3})(\d{4}).*/, '$1-$2-$3');
                    //this.phonenumber1 = this.existingEmail1[i].mobile;
                    this.registrationstatus1 = "Y";
                    this.emailautocomplete1 = "none";
                    this.UserId1 = 0;
                    this.modalRef.hide(); return;
                }
            } else {
                if (this.existingEmail1[i].id == this.UserId1) {
                    this.emailautocomplete1 = "none";
                    this.modalRef.hide();
                    let msg = '<span style="color: red">Golfer Already Assigned</span>';
                    this.toastMessage(msg);
                }
            }
        }
    }

    //first phone search
    searchPhone(term: string): void {
        if (term != '') {
            this.existingPhones = []; this.userid = 0; this.errorPhoneCount = 0;
            let parameters = { searchvalue: " where IZ_U_MOBILE like '%" + term + "%' AND IZ_U_STATUS='Y'" };
            this.api.postOH('GetIzonUser', parameters).subscribe(
                (response) => {
                    if (response.length != 0) {
                        this.phoneautocomplete = "block";
                        this.existingPhones = [];
                        for (let i = 0; i < response.length; i++) {
                            this.existingPhones.push({
                                id: response[i].id,
                                name: response[i].name,
                                lastname: response[i].lastname,
                                password: response[i].password,
                                email: response[i].email,
                                mobile: response[i].mobile,
                                livestats: response[i].livestats
                            });
                        }
                    }
                    else {
                        this.existingPhones = [];
                        this.errorPhoneCount = 1;
                        this.phoneautocomplete = "none"; this.userid = 0; this.registrationstatus = "N";
                    }
                });
        }
        else if (term == "") {
            this.existingPhones = []; this.errorPhoneCount = 0;
            this.phoneautocomplete = "none"; this.userid = 0; this.registrationstatus = 'N';
        }
    }

    onSelectPhone(user: any) {
        this.errorPhoneCount = 0;
        this.PhoneUserId = user.id;
        if (user.id != 0) {
            if (this.userid1 == user.id) {
                let msg = '<span style="color: red">Golfer 1 and Golfer 2 should be different</span>';
                this.toastMessage(msg);
                this.phoneautocomplete = "none";
            }
            else if (this.name != "" || this.lastname != "" || this.email != "") {
                this.modalRef = this.modalService.show(this.template2, { class: 'modal-sm' });
            }
            else {
                this.confirm2();
            }
        }
    }

    confirm2(): void {
        for (let i = 0; i < this.existingPhones.length; i++) {
            if (this.existingPhones[i].livestats != 'L') {
                if (this.existingPhones[i].id == this.PhoneUserId) {
                    this.name = this.existingPhones[i].name;
                    this.lastname = this.existingPhones[i].lastname;
                    this.userid = this.id = this.existingPhones[i].id;
                    this.email = this.existingPhones[i].email;
                    this.phonenumber = this.existingPhones[i].mobile.replace(/^(\d{3})(\d{3})(\d{4}).*/, '$1-$2-$3');
                    //this.phonenumber = this.existingPhones[i].mobile;
                    this.registrationstatus = "Y";
                    this.phoneautocomplete = "none";
                    this.PhoneUserId = 0;
                    this.modalRef.hide(); return;
                }
            } else {
                if (this.existingPhones[i].id == this.PhoneUserId) {
                    this.phoneautocomplete = "none";
                    this.modalRef.hide();
                    let msg = '<span style="color: red">Golfer Already Assigned</span>';
                    this.toastMessage(msg);
                }
            }
        }
    }

    //second phone search
    searchPhone1(term: string): void {
        if (term != '') {
            this.existingPhones1 = []; this.errorPhoneCount1 = 0;
            let parameters = { searchvalue: " where IZ_U_MOBILE like '%" + term + "%' AND IZ_U_STATUS='Y'" };
            this.api.postOH('GetIzonUser', parameters).subscribe(
                (response) => {
                    if (response.length != 0) {
                        this.phoneautocomplete1 = "block";
                        this.existingPhones1 = [];
                        for (let i = 0; i < response.length; i++) {
                            this.existingPhones1.push({
                                id: response[i].id,
                                name: response[i].name,
                                lastname: response[i].lastname,
                                password: response[i].password,
                                email: response[i].email,
                                mobile: response[i].mobile,
                                livestats: response[i].livestats
                            });
                        }
                    }
                    else {
                        this.existingPhones1 = [];
                        this.errorPhoneCount1 = 1;
                        this.phoneautocomplete1 = "none"; this.userid1 = 0; this.registrationstatus1 = 'N';
                    }
                });
        }
        else if (term == "") {
            this.existingPhones1 = []; this.errorPhoneCount1 = 0;
            this.phoneautocomplete1 = "none"; this.userid1 = 0; this.registrationstatus1 = 'N';
        }
    }

    onSelectPhone1(user: any) {
        this.errorPhoneCount1 = 0;
        this.PhoneUserId1 = user.id;
        if (user.id != 0) {
            if (this.userid == user.id) {
                let msg = '<span style="color: red">Golfer 1 and Golfer 2 should be different</span>';
                this.toastMessage(msg);
                this.phoneautocomplete1 = "none";
            }
            else if (this.name1 != "" || this.lastname1 != "" || this.email1 != "") {
                this.modalRef = this.modalService.show(this.template3, { class: 'modal-sm' });
            }
            else {
                this.confirm3();
            }
        }
    }

    confirm3(): void {
        for (let i = 0; i < this.existingPhones1.length; i++) {
            if (this.existingPhones1[i].livestats != 'L') {
                if (this.existingPhones1[i].id == this.PhoneUserId1) {
                    this.name1 = this.existingPhones1[i].name;
                    this.lastname1 = this.existingPhones1[i].lastname;
                    this.userid1 = this.id = this.existingPhones1[i].id;
                    this.email1 = this.existingPhones1[i].email;
                    this.phonenumber1 = this.existingPhones1[i].mobile.replace(/^(\d{3})(\d{3})(\d{4}).*/, '$1-$2-$3');
                    // this.phonenumber1 = this.existingPhones1[i].mobile;
                    this.registrationstatus1 = "Y";
                    this.phoneautocomplete1 = "none";
                    this.PhoneUserId1 = 0;
                    this.modalRef.hide(); return;
                }
            } else {
                if (this.existingPhones1[i].id == this.PhoneUserId1) {
                    this.phoneautocomplete1 = "none";
                    this.modalRef.hide();
                    let msg = '<span style="color: red">Golfer Already Assigned</span>';
                    this.toastMessage(msg);
                }
            }
        }
    }

    //modal close
    decline(): void {
        this.modalRef.hide();
    }

    //assigning carts to user
    continueCartUser() {
        this.ctnDisabledBtn = true;
        var nineholes=this.nineholecourse?this.course2 > 0:true;
        if (this.course > 0 && this.carts > 0 && nineholes) {
            this.continueAttempt = true;
            if (this.cartuserForm.valid) {
                this.spinnerService.show();
                if (this.userid == 0 && this.userid1 == 0) {
                    var cartusersmodal = {
                        "action": 'A', "id": 0, "name": this.name, "lastname": this.lastname, "email": this.email,
                        "password": "", "mobile": this.phonenumber, "image": "", "binaryimage": "", "gender": 'M', "status": 'Y',
                        "registrationstatus": this.registrationstatus
                    }
                    this.api.postOH('izonnonregsiterusers', cartusersmodal).subscribe(
                        response => {
                            if (response.length > 0) {
                                if (response[0] > 0) {
                                    this.userid = response[0];
                                    if (this.userid1 == 0 && (this.name1 != "" || this.email1 != "")) {
                                        var cartusersmodal1 = {
                                            "action": 'A', "id": 0, "name": this.name1, "lastname": this.lastname1, "email": this.email1,
                                            "password": "", "mobile": this.phonenumber1, "image": "", "binaryimage": "", "gender": 'M', "status": 'Y',
                                            "registrationstatus": this.registrationstatus1
                                        }
                                        this.api.postOH('izonnonregsiterusers', cartusersmodal1).subscribe(
                                            response => {
                                                if (response.length > 0) {
                                                    if (response[0] > 0) {
                                                        this.userid1 = response[0];
                                                        if (this.userid > 0 && this.userid1 > 0) {
                                                            this.assignCarts();
                                                        }
                                                    }
                                                } else {
                                                    let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                                                    this.toastMessage(msg);
                                                }
                                            }
                                        );
                                    }
                                    else if (this.userid > 0 && this.userid1 == 0) {
                                        this.assignCarts();
                                    }
                                }
                            } else {
                                let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                                this.toastMessage(msg);
                            }
                        }
                    );
                }
                else if (this.userid > 0 && this.userid1 == 0) {
                    if (this.userid1 == 0 && (this.name1 != "" || this.lastname1 != "")) {
                        var cartusersmodal1 = {
                            "action": 'A', "id": 0, "name": this.name1, "lastname": this.lastname1, "email": this.email1,
                            "password": "", "mobile": this.phonenumber1, "image": "", "binaryimage": "", "gender": 'M', "status": 'Y',
                            "registrationstatus": this.registrationstatus1
                        }
                        this.api.postOH('izonnonregsiterusers', cartusersmodal1).subscribe(
                            response => {
                                if (response.length > 0) {
                                    if (response[0] > 0) {
                                        this.userid1 = response[0];
                                        if (this.userid > 0 && this.userid1 > 0) {
                                            this.assignCarts();
                                        }
                                    }
                                } else {
                                    let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                                    this.toastMessage(msg);
                                }
                            }
                        );
                    }
                    else if (this.userid > 0 && this.userid1 == 0) {
                        this.assignCarts();
                    }
                }
                else if (this.userid1 > 0 && this.userid == 0) {
                    var cartusersmodal = {
                        "action": 'A', "id": 0, "name": this.name, "lastname": this.lastname, "email": this.email,
                        "password": "", "mobile": this.phonenumber, "image": "", "binaryimage": "", "gender": 'M', "status": 'Y',
                        "registrationstatus": this.registrationstatus
                    }
                    this.api.postOH('izonnonregsiterusers', cartusersmodal).subscribe(
                        response => {
                            if (response.length > 0) {
                                if (response[0] > 0) {
                                    this.userid = response[0];
                                    if (this.userid > 0 && this.userid1 > 0) {
                                        this.assignCarts();
                                    }
                                }
                            } else {
                                let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                                this.toastMessage(msg);
                            }
                        }
                    );
                }
                else if (this.userid > 0 && this.userid1 > 0) {
                    this.assignCarts();
                }
                this.spinnerService.hide();
            }
            else {
                this.spinnerService.hide();
                this.ctnDisabledBtn = false;
                this.continueAttempt = true;
            }
        }
        else {
            this.ctnDisabledBtn = false;
            this.continueAttempt = true;
        }
    }

    assignCarts() {
        var str = [];var courseinfo = [];
        this.selectedDate = moment(this.cartDate).format('MM/DD/YYYY');
        this.selectedTime = moment(this.cartTime).format('hh:mm A');
        //console.log(this.selectedDate); console.log(this.selectedTime);
        if (this.userid > 0) {
            var clubusermodal = {
                "action": 'A', "id": 0, "izonuserid": this.userid, "clubid": this.clubId,
                "handicap": 0, "status": 'Y'
            }
            this.api.postOH('saveizonclubuser', clubusermodal).subscribe(
                response => {
                    if (response.length > 0) {
                        courseinfo.push({
                            "SC_GC_ID": JSON.parse(this.course),
                            "SC_IZ_U_ID": localStorage.getItem('userId'),
                            "SC_CD_ID": this.carts,
                            "SC_HANDICAP": '0',
                            "SC_GOLFER_POSSITION": "1",
                            //"SC_FRONT_NINE": (this.front9 == true) ? 'Y' : 'N',
                            "SC_FRONT_NINE": 'Y',
                            "SC_START_HOLE": this.HoleId,
                            "SC_SCHEDULE_DATE": this.selectedDate,
                            "SC_SCHEDULE_TIME": this.selectedTime
                        })
                        if(this.nineholecourse){
                            courseinfo.push({
                                "SC_GC_ID": JSON.parse(this.course2),
                                "SC_IZ_U_ID": localStorage.getItem('userId'),
                                "SC_CD_ID": this.carts,
                                "SC_HANDICAP": '0',
                                "SC_GOLFER_POSSITION": "1",
                                //"SC_FRONT_NINE": (this.front9 == true) ? 'Y' : 'N',
                                "SC_FRONT_NINE": 'N',
                                "SC_START_HOLE": this.HoleId,
                                "SC_SCHEDULE_DATE": this.selectedDate,
                                "SC_SCHEDULE_TIME": this.selectedTime
                            })
                        }


                        str.push({
                            "SC_GC_ID": JSON.parse(this.course),
                            "SC_IZ_U_ID": this.userid,
                            "SC_CD_ID": this.carts,
                            "SC_HANDICAP": '0',
                            "SC_GOLFER_POSSITION": "1",
                            //"SC_FRONT_NINE": (this.front9 == true) ? 'Y' : 'N',
                            "SC_FRONT_NINE": this.HoleId == "1" ? 'Y' : 'N',
                            "SC_START_HOLE": this.HoleId,
                            "SC_SCHEDULE_DATE": this.selectedDate,
                            "SC_SCHEDULE_TIME": this.selectedTime
                        });
                        if (this.userid1 > 0) {
                            var clubusermodal = {
                                "action": 'A', "id": 0, "izonuserid": this.userid1, "clubid": this.clubId,
                                "handicap": 0, "status": 'Y'
                            }
                            this.api.postOH('saveizonclubuser', clubusermodal).subscribe(
                                response => {
                                    if (response.length > 0) {
                                        str.push({
                                            "SC_GC_ID": JSON.parse(this.course),
                                            "SC_IZ_U_ID": this.userid1,
                                            "SC_CD_ID": this.carts,
                                            "SC_HANDICAP": '0',
                                            "SC_GOLFER_POSSITION": "2",
                                            // "SC_FRONT_NINE": (this.front9 == true) ? 'Y' : 'N',
                                            "SC_FRONT_NINE": this.HoleId == "1" ? 'Y' : 'N',
                                            "SC_START_HOLE": this.HoleId,
                                            "SC_SCHEDULE_DATE": this.selectedDate,
                                            "SC_SCHEDULE_TIME": this.selectedTime
                                        });
                                        if (str.length == 2) {
                                            var model = { "ClubCartUserdata": str, "courseinfo":courseinfo, "gcid": this.clubId, "Golfer1": this.name, "Golfer2": this.name1 };
                                            this.assignCartToUser(model);
                                        }
                                    } else {

                                    }
                                },
                                err => {
                                    this.ctnDisabledBtn = false;
                                    let msg = '<span style="color: red">Something went wrong, please try again</span>';
                                    this.toastMessage(msg);
                                }
                            );
                        }

                        else {
                            var model = { "ClubCartUserdata": str, "courseinfo":courseinfo, "gcid": this.clubId, "Golfer1": this.name, "Golfer2": this.name1 };
                            this.assignCartToUser(model);
                        }
                    } else {
                        this.ctnDisabledBtn = false;
                    }
                },
                err => {
                    this.ctnDisabledBtn = false;
                    let msg = '<span style="color: red">Something went wrong, please try again</span>';
                    this.toastMessage(msg);
                }
            );
        }
    }

    assignCartToUser(model) {
        this.api.postOH('ClubCartAssignmenttoUserv2', model).subscribe(
            response => {
                if (response.saveClubCartUserAssignmentv2Result == "Success") {
                    this.getCartUsers(this.carts);
                    let msg = '<span style="color: green">Cart Golfer Assigned Successfully</span>';
                    this.toastMessage(msg);
                    this.addUsers = "none"; this.usersView = "block"; this.cartuserForm.reset();
                }
                else if(response.saveClubCartUserAssignmentv2Result == "Already Assigned"){
                    let msg = '<span style="color: red">Cart already assigned, please select another cart</span>';
                    this.toastMessage(msg);
                }
                else {
                    let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                    this.toastMessage(msg);
                }
                this.ctnDisabledBtn = false;
            },
            err => {
                this.ctnDisabledBtn = false;
                let msg = '<span style="color: red">Something went wrong, please try again</span>';
                this.toastMessage(msg);
            }
        );
    }

    getCartUsers(id: any) {
        this.cartUserDetails = [];
        this.cartName = "";
        this.gameStatus = "";
        this.errorMessage = "";
        // let parameters = { searchvalue: " WHERE SC_CD_ID='" + id + "' AND convert(datetime,SC_START_TIME,121) ='"+this.selectedDate+' '+this.selectedTime+"'" };
        let parameters = { searchvalue: " WHERE SC_CD_ID='" + id + "' AND SC_GAME_STATUS='N'" };
        this.api.postOH('getcartassignedusers', parameters).subscribe(
            (response) => {
                if (response.length != 0) {
                    this.cartUserDetails = response;
                    this.cartName = "Assigned Golfers For Cart " + this.cartUserDetails[0].cartname;
                    this.gameStatus = this.cartUserDetails[0].gamestatus;
                }
                else {
                    this.cartName = "Assigned Golfers For Cart " + this.userCartName;
                    this.errorMessage = "No Data Found";
                }
            });
    }

    completeTheGame() {
        let currentDate: any = '';
        let d = new Date();
        let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
        currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
        var enddate = moment(currentDate).format('MM/DD/YYYY hh:mm A');
        this.gameBtn = true;
        if (this.cartUserDetails.length > 1) {
            var gamemodel = { "cartid": this.cartUserDetails[0].cartid, "player1": this.cartUserDetails[0].izonuserid, "player2": this.cartUserDetails[1].izonuserid, "enddate": enddate }
        }
        else {
            gamemodel = { "cartid": this.cartUserDetails[0].cartid, "player1": this.cartUserDetails[0].izonuserid, "player2": '0', "enddate": enddate }
        }
        this.spinnerService.show();
        this.api.postOH('updategamestatus', gamemodel).subscribe(
            response => {
                if (response == "Game Status Updated Successfully") {
                    let msg = '<span style="color: green">Game Completed Successfully</span>';
                    this.toastMessage(msg);
                    this.gameStatus = "C";
                }
                else if (response == "Error While Updating Game Status") {
                    let msg = '<span style="color: green">Failed to Update the data, please try again</span>';
                    this.toastMessage(msg);
                }
                this.spinnerService.hide();
                this.gameBtn = false;
            },
            err => {
                this.spinnerService.hide();
                let msg = '<span style="color: red">Something went wrong, please try again</span>';
                this.toastMessage(msg); this.gameBtn = false;
            }
        );
    }

    backToCartDetails() {
        localStorage.removeItem('cartId');
        this._router.navigate(['/cartmanagement/cartdetails']);
    }

    userAssignment() {
        localStorage.removeItem('cartId');
        localStorage.removeItem('cartUserName');
        this.continueAttempt = false;
        this.getCartDetails(this.clubId); this.minStartDate = this.currentGolfClubDateTime;
        this.getCourseDetails(this.clubId); this.carts = 0;
        this.HoleId = 1;
        //this.front9 = "Y";
        this.name = ""; this.lastname = ""; this.email = ""; this.phonenumber = "";
        this.name1 = ""; this.lastname1 = ""; this.email1 = ""; this.phonenumber1 = "";
        this.userid = 0; this.userid1 = 0; this.golfer = "2";
        // this.cartDate = new Date(); this.cartTime = new Date();
        this.cartDate = this.currentGolfClubDateTime; this.cartTime = this.currentGolfClubDateTime;
        this.selectedDate = ""; this.selectedTime = "";
        this.usersView = "none";
        this.addUsers = "block"; this.CartAssignBtn = "block"; this.GolferBtn1 = "none";
        this.cartuserForm.patchValue({
            fcourse: this.course,
            fcourse2: this.course2,
        });
    }

    allowNumbers(event) {
        if (event.keyCode < 48 || event.keyCode > 57) {
            event.preventDefault();
        }
    }

    mobileFormat(e) {
        if (e.keyCode < 48 || e.keyCode > 57) {
            e.preventDefault();
        }
        if (e.target.value.length != "") {
            e.target.value = e.target.value.replace(/[^0-9]/g, '');

            if (!e.target.value) { return ''; }

            var number = String(e.target.value);
            e.target.value = number;

            var front = number.substring(0, 3);
            var center = number.substring(3, 6);
            var end = number.substring(6, 10);

            if (center) {
                e.target.value = (front + "-" + center);
            }
            if (end) {
                e.target.value += ("-" + end);
            }
            return e.target.value;
        }
    }

    ddlcoursechange(val) {
        if(val == 1){
            let parameters :any={};
            this.backnine=[];
            if(this.course=='0')
                {
                  parameters = { searchvalue: " WHERE HD_GCB_ID=" + this.clubId + " AND HD_GC_ID = " + localStorage.getItem('courseId') + " and HD_STATUS='Y' " };
                }
                else{
                  parameters = { searchvalue: " WHERE HD_GCB_ID=" + this.clubId + " AND HD_GC_ID = " + this.course + " and HD_STATUS='Y' " };
                }
            this.getHoles(parameters);
        }
        else{
        this.frontnine=[];
        }
       
        for (let i = 0; i < this.courseDetails.length; i++) {
          if (val == 1 && this.courseDetails[i].value!=this.course) {
            this.backnine.push({
                value: this.courseDetails[i].value,
                name: this.courseDetails[i].name
            });
          }
           else if (val == 2 && this.courseDetails[i].value!=this.course2) {
            this.frontnine.push({
                value: this.courseDetails[i].value,
                name: this.courseDetails[i].name
            });
            }
        }
    }

}
