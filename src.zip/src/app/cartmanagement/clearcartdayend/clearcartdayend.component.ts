import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Title } from '@angular/platform-browser';
import {Observable} from 'rxjs/Rx';
import * as moment from "moment";

@Component({
  selector: 'app-clearcartdayend',
  templateUrl: './clearcartdayend.component.html',
  styleUrls: ['./clearcartdayend.component.css']
})
export class ClearcartdayendComponent implements OnInit {
  modalRef: BsModalRef;
  clubdata: any;
  datetime: any;
  GridMessage: string = 'Loading, Please wait ... !';
  clubname: any; clubdatatoclearcart: any; timezoneoffset: any; sub: any; viewclubdata: any; displaydate: any;

  //sort values
  key: string = 'clubname';
  reverse: boolean = false;
  nameasc: any = "sortgreen";
  namedesc: any = "sortwhite";



  constructor(private title: Title,private modalService: BsModalService, public toastr: ToastsManager, vcr: ViewContainerRef, private _router: Router, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService,
    private authService: AuthService, private router: Router) {
      this.toastr.setRootViewContainerRef(vcr);
      this.clubdata = [];
      this.datetime = ""; 
      this.clubname = "";
      this.clubdatatoclearcart = []; this.viewclubdata = [];
      this.timezoneoffset = '';
      this.sub = ''; this.displaydate = "";
    }

  ngOnInit() {
    this.getgolfclubs();
    this.sub = Observable.interval(1000 * 60 * 1).subscribe(x =>
      {
        this.gettime();
      }
    )
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  } 

  getDateTime(offset)
  {
    let d = new Date();
    let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
    var currentDate = new Date(utc + (3600000 * offset));
    //this.datetime = Observable.interval(1000).map(() => currentDate);    
    this.datetime = currentDate;
    return this.datetime;
  }

  getgolfclubs()
  {
    let parameters = {
      searchvalue: " where GCB_STATUS='Y' order by GCB_NAME ASC"
    };
    this.clubdata = [];
    this.viewclubdata = [];
    this.spinnerService.show();
    this.api.postOH('getdayendallcartsforclub', parameters).subscribe(
      (response) => {
        //console.log(response);
        if(response.length > 0)
        {
          for(var i = 0; i < response.length; i++)
          {
            this.displaydate = this.getDateTime(response[i].timezoneoffset);
            this.clubdata.push({
              "id": response[i].clubid,
              "name": response[i].clubname,              
              "datetime": this.displaydate,
              "cartcount":response[i].cartscount
            });
          }
          this.viewclubdata = response;        
        }
        else {
          this.GridMessage = "No data found";
        }
        this.spinnerService.hide();     
      },error=>{
        this.spinnerService.hide();
      })
  }

  gettime()
  {
    this.clubdata = [];
    for(var k = 0; k < this.viewclubdata.length; k++)
    {
      this.displaydate = this.getDateTime(this.viewclubdata[k].timezoneoffset);
      this.clubdata.push({
        "id": this.viewclubdata[k].clubid,
        "name": this.viewclubdata[k].clubname,              
        "datetime": this.displaydate,
        "cartcount":this.viewclubdata[k].cartscount
      })
    }
  }

  sort(value: string) {
    this.key = value;
    this.nameasc = "sortwhite";
    this.namedesc = "sortwhite";
    

    if (this.key == value) {
      this.reverse = !this.reverse;
      if (this.key == "name" && this.reverse) {
        this.namedesc = "sortgreen";
      }
      else if (this.key == "name" && (!this.reverse)) {
        this.nameasc = "sortgreen";
      }
    }
  }

  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',
    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 5000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }

  clearcartdayend(clubdata)
  {
    var enddate = moment(new Date()).format('MM/DD/YYYY hh:mm A');
    //this.datetime.take(1).subscribe(val => { alert(val); });
    var parameters = {
      clubid: clubdata.id,
      enddate: enddate
    };
    this.spinnerService.show();
    this.api.postOH('dayendallcartsforclub', parameters).subscribe(
      (response) => {
        //console.log(response);
        if(response == "Success")
        {
          this.getgolfclubs();
          let msg = '<span style="color: green">Carts cleared Successfully. </span>';
          this.toastMessage(msg);
        }
        else
        {
          let msg = '<span style="color: red">Problem while clearing Carts. </span>';
          this.toastMessage(msg);
        }
        this.spinnerService.hide();
      },error=>{
        this.spinnerService.hide();
      })
  }

  //clear cart confirmation 
  openModal(template: TemplateRef<any>, cudata) {
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    this.clubname=cudata.name;
    this.clubdatatoclearcart = cudata;  
  }

  confirm(): void {
    this.modalRef.hide();
    this.clearcartdayend(this.clubdatatoclearcart);
  }

  decline(): void {
    this.modalRef.hide();
  }

}
