import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClearcartdayendComponent } from './clearcartdayend.component';

describe('ClearcartdayendComponent', () => {
  let component: ClearcartdayendComponent;
  let fixture: ComponentFixture<ClearcartdayendComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClearcartdayendComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClearcartdayendComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
