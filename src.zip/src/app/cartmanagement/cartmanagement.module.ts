import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FullCalendarModule } from 'ng-fullcalendar';
//import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { ModalModule } from 'ngx-bootstrap';
import { OrderModule } from 'ngx-order-pipe';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { PopoverModule } from 'ngx-bootstrap';

import { DashboardComponent } from './dashboard/dashboard.component';
import { CartdetailsComponent } from './cartdetails/cartdetails.component';
import { CartsviewComponent } from './cartsview/cartsview.component';
import { CartplaytrackComponent } from './cartplaytrack/cartplaytrack.component';
import { CarttrackdetailsComponent } from './carttrackdetails/carttrackdetails.component';
import { CartuserassignmentComponent } from './cartuserassignment/cartuserassignment.component';
import { ClearcartdayendComponent } from './clearcartdayend/clearcartdayend.component';
import { DownloadfilesComponent } from './downloadfiles/downloadfiles.component';
import { PaceofplayhistoryComponent } from './paceofplayhistory/paceofplayhistory.component';
import { FleetdashboardComponent } from './fleetdashboard/fleetdashboard.component';

const routes: Routes = [  
  {
    path:'dashboard',
    component:DashboardComponent
  },
  {
    path:'cartdetails',
    component:CartdetailsComponent
  },
  {
    path:'cartsview',
    component:CartsviewComponent
  },
  {
    path:'carttrackdetails',
    component:CarttrackdetailsComponent
  },
  {
    path:'cartplaytrack',
    component:CartplaytrackComponent
  },
  {
    path:'cartuserassignment',
    component:CartuserassignmentComponent
  },
  {
    path:'clearcartsdayend',
    component:ClearcartdayendComponent
  },
  {
    path:'filesdownload',
    component:DownloadfilesComponent
  },
  {
    path:'paceofplayhistory',
    component:PaceofplayhistoryComponent
  },
  {
    path:'fleetdashboard',
    component:FleetdashboardComponent
  }

];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule, ReactiveFormsModule,
    FullCalendarModule,OrderModule,
    ToastModule.forRoot(),
    ModalModule.forRoot(),
    OwlDateTimeModule,PopoverModule.forRoot(),
    OwlNativeDateTimeModule, BsDatepickerModule.forRoot()
  ],  
  declarations: [DashboardComponent, CartdetailsComponent, CartsviewComponent, CartplaytrackComponent, CarttrackdetailsComponent, CartuserassignmentComponent, ClearcartdayendComponent, DownloadfilesComponent, PaceofplayhistoryComponent, FleetdashboardComponent],
  exports: [RouterModule]  
})
export class CartmanagementModule { }
