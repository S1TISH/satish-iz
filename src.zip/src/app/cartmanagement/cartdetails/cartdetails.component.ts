import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
//import { ModalService } from 'ng-bootstrap-modal';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Observable } from 'rxjs/Rx';
import { getLocaleDateFormat } from '@angular/common';
import * as moment from "moment";
import { Title } from '@angular/platform-browser';

declare const google: any;

@Component({
    selector: 'app-cartdetails',
    templateUrl: './cartdetails.component.html',
    styleUrls: ['./cartdetails.component.css']
})


export class CartdetailsComponent implements OnInit {
    modalRef: BsModalRef; modalRef1: BsModalRef; messageModalRef: BsModalRef;
    templatecmprund: BsModalRef;templatecartsignout:BsModalRef;

    public cartsForm: FormGroup; submitAttempt: boolean = false; divheader: string = "Add Cart Details";
    public messageForm: FormGroup; messageSubmit: boolean = false;
    //cart message
    cartMessage: any; messagepopup: boolean = false; messageBtn: any; cartId: any = 0;

    searchtxt: boolean = true; searchddl: boolean = false;
    cartdetailsdata: any;
    contentShow: string = "none"; gridShow: string = "none"; searchcartdetails: string = "block";
    viewcontentShow: string = "none";
    txtShow: string = "none"; lblShow: string = "none";
    action: string = 'A'; golfClubId: string; userid: any; golfcourseid: string;
    searchvalues: any = []; searchstatus: any = [];
    cartid: string; deviceid: string;
    cartname: string; phoneno:string; cartstatus: any; cartchkstatus: boolean = true;
    stat: any; vcartid: string; vclubcode: string;

    carttxtstatus: string = 'Active'; txtsrch: string = '';
    GridMessage: string = 'Loading, Please wait ... !';
    srchError: string = '0';

    cartroleid: any;

    key: string = 'name';
    reverse: boolean = false;
    // reverse1: boolean = true;
    // reverseid:boolean = true;
    // reclubcode: boolean = true;
    // redevice:boolean = true;
    idasc: any = "sortwhite";
    iddesc: any = "sortwhite";
    nameasc: any = "sortgreen";
    namedesc: any = "sortwhite";
    clubasc: any = "sortwhite";
    clubdesc: any = "sortwhite";
    deviceinfoasc: any = "sortwhite";
    deviceinfodesc: any = "sortwhite";
    deviceasc: any = "sortwhite";
    devicedesc: any = "sortwhite";
    appversionasc: any = "sortwhite";
    appversiondesc: any = "sortwhite";

    cartheadername: string; viewheadername: string;
    ddldevice: any; ddlsearch: any; deviceddl: boolean = false; txtsearch: boolean = true;
    selectedoption: any = "Active"; randomcolor: any = "#5cb85c";

    detailsDiv_: any = []; rowval: any; assignedCartId: any; cartUserDetails: any; showMap: boolean = false; inplayDetails: any;
    courselat: any;
    courselong: any;
    coursezoomlevel: any; bluecircleimage: any;
    polylinecoordinates: any = []; map: any; datearry: any; CoursesInfo: any = []; day: string; month: any; fromdate: any; todate: any; todaydate: any; sub: any;
    count: any = 0; showDetails: boolean; gameStatus: string; showScore: boolean = false; polylines: any = []; circlemarkers: any = [];markers:any=[];

    playerUserIds: any = []; golfersScorecardIds: string; holePardetails: any = []; scoreInfo: any = []; golfersScoreInfo: any = [];
    backNinePar: any = 0; frontNinePar: any = 0; totalPar: any = 0; selectedPlayer: any = -1; golfersScoreInfoDummy: any = [];
    holesNumber: any = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18];

    DeviceInfo: string;

    //ranger
    ranbavname: any; ranbavId: any; loggedincart: any; userType: any; msg: any; iconnameonmap: any;

    //cartforcelogout
    cartdetailsforLogout: any;timeoffset:any;

    constructor(private title: Title, private modalService: BsModalService, public toastr: ToastsManager, vcr: ViewContainerRef, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService,
        private authService: AuthService, private router: Router) {
        this.title.setTitle("IZON - Cart Management");
        this.ddlsearch = "CD_NAME";
        this.ddldevice = "0";
        this.cartheadername = localStorage.getItem('clubname') + " >> Cart Details";
        
        this.toastr.setRootViewContainerRef(vcr);
        this.contentShow = "none"; this.gridShow = "none";
        this.cartdetailsdata = [];

        this.golfClubId = localStorage.getItem('clubId');
        this.golfcourseid = localStorage.getItem('courseId');
        this.userid = localStorage.getItem('userId');

        this.ranbavname = ""; this.userType = ""; this.ranbavId = ""; this.cartdetailsforLogout = "";

    }

    ngOnInit() {
        this.cartsForm = this.formBuilder.group({
            fcartname: ['', Validators.compose([Validators.required])],
            phoneno: [''],
            cartchkstatus: ['']
        });
        //cart messaging
        this.messageForm = this.formBuilder.group({
            fmessage: ['', Validators.compose([Validators.required])],
        });
        let parameters = {
            searchvalue: " WHERE CD_GCB_ID='" + this.golfClubId + "' AND CD_STATUS = 'Y'"
        };
        this.GetCartDetailsData(parameters);
        //this.bluecircleimage = 'assets/imgs/blue_circle.png';

        this.gridShow = "block";
        this.contentShow = "none";
    }

    sort(value: string) {
        this.detailsDiv_[this.rowval] = false;
        this.key = value;
        this.idasc = "sortwhite";
        this.iddesc = "sortwhite";
        this.nameasc = "sortwhite";
        this.namedesc = "sortwhite";
        this.clubasc = "sortwhite";
        this.clubdesc = "sortwhite";
        this.deviceasc = "sortwhite";
        this.devicedesc = "sortwhite";
        this.deviceinfoasc = "sortwhite";
        this.deviceinfodesc = "sortwhite";
        this.appversionasc = "sortwhite";
        this.appversiondesc = "sortwhite";

        if (this.key == value) {
            this.reverse = !this.reverse;
            if (this.key == "name" && this.reverse) {
                this.namedesc = "sortgreen";
            }
            else if (this.key == "name" && (!this.reverse)) {
                this.nameasc = "sortgreen";
            }
            else if (this.key == "id" && this.reverse) {
                this.iddesc = "sortgreen";
            }
            else if (this.key == "id" && (!this.reverse)) {
                this.idasc = "sortgreen";
            }
            else if (this.key == "golfclubcode" && this.reverse) {
                this.clubdesc = "sortgreen";
            }
            else if (this.key == "golfclubcode" && (!this.reverse)) {
                this.clubasc = "sortgreen";
            }

            else if (this.key == "devicetoken" && this.reverse) {
                this.deviceasc = "sortgreen";
            }
            else if (this.key == "devicetoken" && (!this.reverse)) {
                this.devicedesc = "sortgreen";
            }
            else if (this.key == "deviceidinfo" && this.reverse) {
                this.deviceinfoasc = "sortgreen";
            }
            else if (this.key == "deviceidinfo" && (!this.reverse)) {
                this.deviceinfodesc = "sortgreen";
            }
            else if (this.key == "appversion" && this.reverse) {
                this.appversiondesc = "sortgreen";
            }
            else if (this.key == "appversion" && (!this.reverse)) {
                this.appversionasc = "sortgreen";
            }
        }

    }

    refreshpage() {
        this.detailsDiv_[this.rowval] = false;
        let parameters = {
            searchvalue: " WHERE CD_GCB_ID='" + this.golfClubId + "' AND CD_STATUS = 'Y'"
        };
        this.GetCartDetailsData(parameters);
        this.txtsrch = "";
        this.ddlsearch = "CD_NAME";
        this.ddldevice = "0";
        this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
        this.srchError = '0';
    }

    addCartDetails() {
        this.action = 'A';
        this.cartsForm.reset();
        this.divheader = "Add Cart Details";
        this.gridShow = "none";
        this.contentShow = "block";
        this.txtShow = "block"; this.lblShow = "none";
        this.cartname = '';
        this.phoneno = '';
        this.cartid = "0";
        this.cartstatus = "A";
        this.submitAttempt = false;
    }

    goBackClub() {
        this.router.navigate(['/clubmanagement/golfclub']);
    }
    dropdownsearch(val) {
        if (val.value === "CD_DEVICE_TOKEN") {
            this.txtsearch = false;
            this.deviceddl = true;
        }
        else {
            this.txtsearch = true;
            this.deviceddl = false;
        }
    }
    search() {
        this.detailsDiv_[this.rowval] = false;
        if (this.txtsrch == '' && this.ddlsearch != "CD_DEVICE_TOKEN") {
            this.srchError = '1';
        }
        else if (this.txtsrch != '') {
            let parameters = {
                searchvalue: " WHERE CD_GCB_ID='" + this.golfClubId + "' and  " + this.ddlsearch + " LIKE '%" + this.txtsrch + "%' AND CD_STATUS<>'D'"
            };
            this.GetCartDetailsData(parameters);
            this.txtsrch = "";
            this.srchError = '0';
        }
        else if (this.ddlsearch === "CD_DEVICE_TOKEN") {
            this.srchError = '0';
            let searchexp = "";
            if (this.ddldevice === "assigned") {
                searchexp = " WHERE CD_GCB_ID='" + this.golfClubId + "' and  CD_DEVICE_TOKEN<>'' and CD_DEVICE_TOKEN IS NOT NULL AND CD_STATUS<>'D' "
            }
            else if (this.ddldevice === "notassigned") {
                searchexp = " WHERE CD_GCB_ID='" + this.golfClubId + "' and  ((CD_DEVICE_TOKEN='' or CD_DEVICE_TOKEN IS NULL) and (CD_APP_VERSION='' or CD_APP_VERSION IS NULL)) AND CD_STATUS<>'D' "
            } else if (this.ddldevice === "pending") {
                searchexp = " WHERE CD_GCB_ID='" + this.golfClubId + "' and  ((CD_DEVICE_TOKEN='' or CD_DEVICE_TOKEN IS NULL) and CD_APP_VERSION<>'' and CD_APP_VERSION IS NOT NULL) AND CD_STATUS<>'D' "
            } else {
                searchexp = " WHERE CD_GCB_ID='" + this.golfClubId + "' AND CD_STATUS<>'D' "
            }
            let parameters = {
                searchvalue: searchexp
            };
            this.GetCartDetailsData(parameters);
            this.txtsrch = "";
        }
    }

    srchKeyUp(event: any) {
        var keyupcode = event.keyCode;
        if (keyupcode == 13) {
            this.search();
        }
        else if (this.txtsrch != '') {
            this.srchError = '0';
        }
    }

    GetCartDetailsData(parameters) {
        this.DeviceInfo = "";
        this.spinnerService.show();
        this.api.postOH('getcartdetails', parameters).subscribe(
            (response) => {
                this.cartdetailsdata = [];
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                    var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var confirmshow = "row-icon-inactive";

                    var device = "";
                    device = response[i].deviceid.toLowerCase();
                    if (device.indexOf('android') >= 0 || device.indexOf('ios') >= 0) {
                        this.DeviceInfo = response[i].deviceid;
                    }
                    else {
                        this.DeviceInfo = "--";
                    }
                    if(response[i].deviceStatus=='T'){
                    this.cartdetailsdata.push({
                        "id": response[i].id,
                        "name": response[i].name,
                        "golfclubid": response[i].golfclubid,
                        "golfclubname": response[i].golfclubname,
                        "golfclubcode": response[i].golfclubcode,
                        "latitude": response[i].latitude,
                        "longitude": response[i].longitude,
                        "devicetoken": response[i].devicetoken,
                        "deviceid": response[i].deviceid,
                        "devicename": response[i].devicename,
                        "deviceidinfo": response[i].deviceid,
                        "appversion": response[i].appversion,
                        "latlongupdateddate": response[i].latlongupdateddate,
                        "createdby": response[i].updatedby,
                        "createddate": this.getDateTime(response[i].createddate,localStorage.getItem('timezone')),
                        "updateddate": response[i].updateddate,
                        "assignstatus": response[i].assignstatus,
                        "roletype": response[i].cartroletype,
                        "status": status,
                        "statusclass": statusclass,
                        "editshow": editshow,
                        "enableshow": enableshow,
                        "removeshow": removeshow,
                        "confirmshow": confirmshow,
                        "DevInfo": this.DeviceInfo,
                        "phoneno": response[i].phoneno
                    });
                }
                }
                {
                    this.GridMessage = "No Data Found";
                }

                this.spinnerService.hide();

            }, error => {
                this.spinnerService.hide();
            }
        );
    }

    goBack() {
        this.gridShow = "block";
        this.contentShow = "none";
        this.viewcontentShow = "none";
    }

    gotogrid() {
        if (this.action == 'A') {
            this.gridShow = "block";
            this.contentShow = "none";
            this.viewcontentShow = "none";
        }
        else {
            this.gridShow = "none";
            this.contentShow = "none";
            this.viewcontentShow = "block";
            this.action = 'V';
        }
    }

    viewcart(cartdetaildata) {
        window.scrollTo(0, 0);
        this.viewheadername = "Cart Info";
        localStorage.setItem('cartname', cartdetaildata.name);
        this.action = 'V';
        this.gridShow = "none";
        this.viewcontentShow = "block";
        this.contentShow = "none";
        this.cartid = cartdetaildata.id;
        this.cartroleid = cartdetaildata.roletype;
        this.cartname = (!cartdetaildata.name) ? "" : cartdetaildata.name;
        this.phoneno = (!cartdetaildata.phoneno) ? "" : cartdetaildata.phoneno;
        this.deviceid = (!cartdetaildata.deviceid) ? "" : cartdetaildata.deviceid;
        this.vcartid = (!cartdetaildata.id) ? "" : cartdetaildata.id;
        this.vclubcode = (!cartdetaildata.golfclubcode) ? "" : cartdetaildata.golfclubcode;
        if (cartdetaildata.status == 'Active') {
            this.cartstatus = 'Y';
        }
        else if (cartdetaildata.status == 'In-Active') {
            this.cartstatus = 'N';
        }
        this.cartchkstatus = (this.cartstatus == 'Y') ? true : false;
        this.carttxtstatus = (this.cartstatus == 'Y') ? 'Active' : 'In-Active';
        if (cartdetaildata.status == 'Deleted') {
            this.cartstatus = 'D';
            this.carttxtstatus = 'Deleted';
        }
    }

    editCartDetails() {
        this.divheader = "Edit Cart Details";
        this.action = 'U';
        this.gridShow = "none";
        this.contentShow = "block"; this.viewcontentShow = "none";
        this.txtShow = "block"; this.lblShow = "none";
        let parameters = {
            searchvalue: ' WHERE CD_ID=' + this.cartid + ''
        };
        //this.spinnerService.show();
        let cartdetaildata = [];
        this.api.postOH('getcartdetails', parameters).subscribe(
            (response) => {
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                    var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var confirmshow = "row-icon-inactive";

                    cartdetaildata.push({
                        "id": response[i].id,
                        "name": response[i].name,
                        "golfclubid": response[i].golfclubid,
                        "golfclubname": response[i].golfclubname,
                        "golfclubcode": response[i].golfclubcode,
                        "latitude": response[i].latitude,
                        "longitude": response[i].longitude,
                        "devicetoken": response[i].devicetoken,
                        "deviceid": response[i].deviceid,
                        "devicename": response[i].devicename,
                        "latlongupdateddate": response[i].latlongupdateddate,
                        "createdby": response[i].updatedby,
                        "createddate": this.getDateTime(response[i].createddate,localStorage.getItem('timezone')),
                        "updateddate": response[i].updateddate,
                        "assignstatus": response[i].assignstatus,
                        "status": status,
                        "statusclass": statusclass,
                        "editshow": editshow,
                        "enableshow": enableshow,
                        "removeshow": removeshow,
                        "confirmshow": confirmshow,
                        "phoneno": response[i].phoneno
                    });
                }
                this.cartid = cartdetaildata[0].id;
                this.cartname = (!cartdetaildata[0].name) ? "" : cartdetaildata[0].name;
                this.phoneno = (!cartdetaildata[0].phoneno) ? "" : cartdetaildata[0].phoneno;                
                this.deviceid = (!cartdetaildata[0].deviceid) ? "" : cartdetaildata[0].deviceid;
                //this.spinnerService.hide();
            }, error => {
                //this.spinnerService.hide();
            }
        );
    }

    checkBoxChange(status) {
        this.stat = status;
        if (this.stat == true) {
            this.cartstatus = 'Y';
            this.carttxtstatus = 'Active';
        }
        else {
            this.cartstatus = 'N';
            this.carttxtstatus = 'In-Active';
        }
    }

    LogOutcart(cartdetails) {
        if (cartdetails.assignstatus != 'Y') {
            var CartDiviceUpdateinfo = {
                "action": 'O',
                "id": cartdetails.id,
                "name": cartdetails.name,
                "golfclubcode": cartdetails.golfclubcode,
                "deviceid": cartdetails.deviceid,
                "appversion": cartdetails.appversion
            }
            this.api.postOH('cartdevicetokenupdate', CartDiviceUpdateinfo).subscribe(
                (data) => {
                    if (data[0] == '1') {
                        let parameters = {
                            searchvalue: " WHERE CD_GCB_ID= '" + this.golfClubId + "' AND CD_STATUS = 'Y'"
                        };
                        this.GetCartDetailsData(parameters);
                        this.gridShow = "block";
                        this.contentShow = "none";
                        this.viewcontentShow = "none";
                        let msg = '<span style="color: green">Logged out Successfully .</span>';
                        this.toastMessage(msg);
                    }
                    else if (data[0] == '0') {
                        let msg = '<span style="color: red">Unable to process your request!!! .</span>';
                        this.toastMessage(msg);
                    }
                });
        } else {
            let msg = '<span style="color: green">Please complete the round before logout cart.</span>';
            this.toastMessage(msg);
        }
    }

    toastMessage(msg) {
        let options = {
            positionClass: 'toast-top-center',

        };
        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 5000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }
    bindselectedoption(selectedoption) {
        this.detailsDiv_[this.rowval] = false;
        this.srchError = '0';
        if (this.selectedoption == 'Active') {
            this.randomcolor = "#5cb85c";
            this.srchSts('Y');
        }
        else if (this.selectedoption == 'In-Active') {
            this.randomcolor = "#337ab7";
            this.srchSts('N');
        }
        else if (this.selectedoption == 'Deleted') {
            this.randomcolor = "#d9534f";
            this.srchSts('D');
        }
    }
    srchSts(type) {
        let parameters = {
            searchvalue: " WHERE CD_GCB_ID='" + this.golfClubId + "' and CD_STATUS= '" + type + "' "
        };
        this.GetCartDetailsData(parameters);
    }
    viewcarthistory() {
        localStorage.setItem('cartId', this.cartid);
        localStorage.setItem('cartroleId', this.cartroleid);
        this.router.navigate(['/cartmanagement/carttrackdetails']);
    }
    viewcartonmap() {
        localStorage.setItem('cartId', this.cartid);
        this.router.navigate(['/cartmanagement/cartsview']);
    }
    cartsonmap() {
        localStorage.removeItem('cartId');
        this.router.navigate(['/cartmanagement/cartsview']);
    }

    saveData() {
        if (!this.cartsForm.valid) {

        }
        this.submitAttempt = true;
        if (this.cartsForm.valid) {
            this.spinnerService.show();
            if (this.action == 'A' || this.action == 'U') {
                var cartdetailsinfo = {
                    'action': this.action,
                    'id': this.cartid,
                    'name': this.cartname,
                    'phoneno': this.phoneno,
                    'golfclubid': this.golfClubId,
                    'latitude': '',
                    'longitude': '',
                    'updtaedid': this.userid,
                    'status': this.cartstatus
                }
                this.api.postOH('savecartdetails', cartdetailsinfo).subscribe(
                    (data) => {
                        if (this.action == 'A' || this.action == 'U') {
                            if (data[1] != 'Cart Details Already Exist or Unable to process your request ') {
                                let parameters = {
                                    searchvalue: " WHERE CD_GCB_ID='" + this.golfClubId + "' AND CD_STATUS = 'Y'"
                                };
                                this.GetCartDetailsData(parameters);
                                this.gridShow = "block";
                                this.contentShow = "none";
                                this.viewcontentShow = "none";
                                let msg = (this.action == "A") ? '<span style="color: green">Cart added Successfully .</span>' : '<span style="color: green">Cart updated Successfully .</span>';
                                this.toastMessage(msg);
                            }
                            else {
                                let msg = '<span style="color: green">' + data[1] + '</span>';
                                this.toastMessage(msg);
                            }
                        }
                        window.scrollTo(0, 0);
                        this.spinnerService.hide();
                    }, error => {
                        this.spinnerService.hide();
                    })
            }
        }

    }

    viewcarttrackonmap(cartdetails) {
        this.showMap = true;
        // this.fromdate = new Date();
        // this.todate = new Date();
        this.cartroleid = cartdetails.roletype;
        this.getcourses();
    }

    getcourses() {
        this.CoursesInfo = [];
        let parameters = { searchvalue: " WHERE GC_GCB_ID='" + this.golfClubId + "' and GC_ID='" + this.golfcourseid + "'" };
        this.api.postOH('getgolfcourse', parameters).subscribe(
            response => {
                //this.spinnerService.hide();
                if (response.length !== 0) {
                    for (let i = 0; i < response.length; i++) {
                        this.CoursesInfo.push({
                            "id": response[i].id
                        })
                    }
                    this.courselat = response[0].latitude;
                    this.courselong = response[0].longitude;
                    this.timeoffset = response[0].timeoffset;
                    this.coursezoomlevel = (response[0].zoomlevel != '') ? response[0].zoomlevel : 0;

                    let currentDate: any = ''; this.fromdate = ''; this.todate = '';
                    let d = new Date();
                    let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
                    currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
                     this.fromdate = moment(currentDate).format('MMMM DD, YYYY');
                    this.todate = moment(currentDate).format('MMMM DD, YYYY');
                    this.maploading();
                }
            })
    }

    maploading() {
        this.map = new google.maps.Map(document.getElementById('map'), {
            center: { lat: parseFloat(this.courselat), lng: parseFloat(this.courselong) },
            zoom: parseInt(this.coursezoomlevel),
            //disableDefaultUI: true,
            mapTypeId: 'satellite',
            tilt: 0,
            rotateControl: true,
            fullscreenControl: false,
            streetViewControl: false
        });

        var styleControls = document.getElementById('styleControl');
        this.map.controls[google.maps.ControlPosition.TOP_RIGHT].push(styleControls);

        var closeControl = document.getElementById('closeBtn');
        this.setoverlayimage();
        this.getpolylinedetails();
    }

    setoverlayimage() {
        let me = this;
        for (let i = 0; i < this.CoursesInfo.length; i++) {
            var imageMapType = new google.maps.ImageMapType({
                getTileUrl: function (coord, zoom) {
                    //console.log('http://iadmin.azaz.com/tiles/' + me.golfclubid+ '/' +me.CoursesInfo[i].id+ '/' + zoom + '/' + coord.x + '/' + coord.y + '.png');
                    // let clbid = ''; let cursid = '';
                    // if (me.golfClubId == '1002') { clbid = '1445' } else { clbid = me.golfClubId };
                    // if (me.CoursesInfo[i].id == 2) { cursid = '539' } else if (me.CoursesInfo[i].id == 3) { cursid = '540' } else if (me.CoursesInfo[i].id == 4) { cursid = '541' } else { cursid = me.CoursesInfo[i].id };
                    // return ['http://cp.izongolf.com/tiles/' + clbid + '/' + cursid + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
                    return ['http://cp.izongolf.com/tiles/' + me.golfClubId + '/' + me.CoursesInfo[i].id + '/' + zoom + '/' + coord.x + '/' + coord.y + '.png'].join('');
                },
                tileSize: new google.maps.Size(256, 256)
            });
            this.map.overlayMapTypes.push(imageMapType);
        }
    }

    dateformats(val) {
        this.datearry = val.split("-");
        var strdate = this.datearry[1] + "/" + this.datearry[0] + "/" + this.datearry[2];
        return strdate;
    }

    trackCart() {
        //var fromdate = new Date(this.fromdate);
        var fromdate = new Date(this.todate);
        var todate = new Date(this.todate);
        if (fromdate > todate) {
            this.toastMessage('<span style="color: red">From date should be less than or equal to To date.</span>');
        }
        else {
            this.fromdate = fromdate;
            this.todate = todate;
            this.getpolylinedetails();
        }
    }

    getpolylinedetails() {
        this.setMapOnAll(null);
        let fdate = moment(this.fromdate).format('MM/DD/YYYY');
        let todate = moment(this.todate).format('MM/DD/YYYY');
        var getcarttrackdetails = {
            "CartId": this.loggedincart, "FromDate": fdate, "Todate": todate, "Flag":'A'
        }
        this.polylinecoordinates = [];
        this.clearallpolylines();
        this.spinnerService.show();
        this.api.postOH('GetCartTrack', getcarttrackdetails).subscribe(
            (response) => {
                if (response[0].ResponseCode == "Success") {
                    if (response[0].CartTrackData.length > 0) {
                        for (var i = 0; i < response[0].CartTrackData.length; i++) {
                            this.polylinecoordinates.push({
                                lat: parseFloat(response[0].CartTrackData[i].Latitude),
                                lng: parseFloat(response[0].CartTrackData[i].Langitude),
                                timestamp: response[0].CartTrackData[i].Datetime,
                                cartname: response[0].CartTrackData[i].CartName
                            });
                            this.polylinecoordinates = this.polylinecoordinates;
                        }
                        this.drawpolyline();
                        this.spinnerService.hide();
                    } else {
                        this.spinnerService.hide();
                    }
                } else {
                    this.polylinecoordinates = this.polylinecoordinates;
                    this.spinnerService.hide();
                }
                this.carthazards();
            }, error => {
                this.spinnerService.hide();
            }
        );
    }
    carthazards() {
        
        let fdate = moment(this.fromdate).format('MM-DD-YYYY');
        var getcarthazarddetails = {
            "clubid": this.golfClubId, "dateString": fdate, "cartid": this.loggedincart,"Flag":"A"
        }
        this.api.postOH('GetCartHazardAlerts', getcarthazarddetails).subscribe(
            response => {
                if (response.GetCartHazardAlertsResult.length !== 0) {
                    for (let i = 0; i < response.GetCartHazardAlertsResult.length; i++) {
                        let latlng2 = { lat: parseFloat(response.GetCartHazardAlertsResult[i].latitude), lng: parseFloat(response.GetCartHazardAlertsResult[i].longitude) };
                        this.addMarker(latlng2, i, response.GetCartHazardAlertsResult[i].date, response.GetCartHazardAlertsResult[i].type);
                    }
                }
            })
    }
    addMarker(location, i, datetime, type) {
        let me = this;
        type = type == "HZ" ? "HZ" : "OB";
        var infowindow = new google.maps.InfoWindow();
        var marker = new google.maps.Marker({
            position: location,
            label: {
                text: type,
                color: 'white'
            },
            draggable: false,
            map: this.map
        });
        this.markers.push(marker);
        google.maps.event.addListener(marker, 'mouseover', (function (marker, i) {
            return function () {
                var content = "";
                // content += '<div style="color:green;font-weight:bold;padding-bottom:10px;">Cart Position At:</div>'
                // content += datetime + "\n";
                content += '<div style="color:green;font-weight:bold;padding-bottom:10px;">Cart Position At:'
                content += '<br/><br/><label style="color:black;font-weight:normal;margin-bottom:-5px;">' + datetime + '</label>';
                 content += '</div>';
                infowindow.setContent(content);
                infowindow.open(me.map, marker);
            }
        })(marker, i));

        google.maps.event.addListener(marker, 'mouseout', function () {
            infowindow.close();
        });
    }

    drawpolyline() {
        let lengthval = this.polylinecoordinates.length - 1;
        if (this.markers.length > 0) {
            this.clearMarkers();
        }
        if (this.cartroleid == '3') {
            this.bluecircleimage = 'assets/imgs/star_view.png';
            this.iconnameonmap = '';
        } else if (this.cartroleid == '4') {
            this.bluecircleimage = 'assets/imgs/beverage_view.png';
            this.iconnameonmap = '';
        } else {
            this.bluecircleimage = 'assets/imgs/blue_circle.png';
            this.iconnameonmap = {
                text: this.polylinecoordinates[lengthval].cartname,
                color: 'white'
            };
        }
        var marker1 = new google.maps.Marker({
            position: { lat: parseFloat(this.polylinecoordinates[lengthval].lat), lng: parseFloat(this.polylinecoordinates[lengthval].lng) },
            icon: this.bluecircleimage,
            label: this.iconnameonmap
        });
        marker1.setMap(this.map);
        this.markers.push(marker1);
        this.map.setCenter(new google.maps.LatLng(parseFloat(this.polylinecoordinates[lengthval].lat), parseFloat(this.polylinecoordinates[lengthval].lng)));

        var flightPath = new google.maps.Polyline({
            path: this.polylinecoordinates,
            //editable:true,      
            geodesic: true,
            strokeColor: '#FF0000',
            strokeOpacity: 1.0,
            strokeWeight: 2
        });
        this.polylines.push(flightPath);
        flightPath.setMap(this.map);

        let me = this;
        var infowindow = new google.maps.InfoWindow();
        var marker, i;
        for (i = 0; i < me.polylinecoordinates.length; i++) {
            marker = new google.maps.Marker({
                position: new google.maps.LatLng(me.polylinecoordinates[i].lat, me.polylinecoordinates[i].lng),
                icon: {
                    path: google.maps.SymbolPath.CIRCLE,
                    scale: 4.5,
                    fillColor: "#F00",
                    fillOpacity: 0.4,
                    strokeWeight: 0.4
                },
                map: me.map
            });
            this.circlemarkers.push(marker);

            google.maps.event.addListener(marker, 'mouseover', (function (marker, i) {
                return function () {
                    var content = "";
                    content += '<div style="color:green;font-weight:bold;padding-bottom:10px;">Cart Position At:'
                    content += '<br/><br/><label style="color:black;font-weight:normal;margin-bottom:-5px;">' + me.polylinecoordinates[i].timestamp + '</label>';
                    content += '</div>';
                    infowindow.setContent(content);
                    infowindow.open(me.map, marker);
                }
            })(marker, i));

            google.maps.event.addListener(marker, 'mouseout', function () {
                infowindow.close();
            });
        }
    }

    // Removes the markers from the map, but keeps them in the array.
    clearMarkers() {
        this.setMapOnAll(null);
        this.markers=[];
    }
    // Sets the map on all markers in the array.
    setMapOnAll(map) {
        for (var i = 0; i < this.markers.length; i++) {
            this.markers[i].setMap(map);
        }
    }

    clearallpolylines() {
        for (var i = 0; i < this.polylines.length; i++) {
            this.polylines[i].setMap(null);
        }
        for (var i = 0; i < this.circlemarkers.length; i++) {
            this.circlemarkers[i].setMap(null);
        }
        this.polylinecoordinates = [];
        this.circlemarkers = [];
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    }

    confirm(): void {
        this.modalRef.hide();
        this.action = 'D';
        this.cartstatus = 'D';
        var cartdetailsinfo = {
            'action': this.action,
            'id': this.cartid,
            'name': this.cartname,
            'phoneno': '',
            'golfclubid': this.golfClubId,
            'latitude': '',
            'longitude': '',
            'updtaedid': this.userid,
            'status': this.cartstatus
        }
        let msg = '<span style="color: green">Cart deleted Successfully</span>';
        this.DEapicall(cartdetailsinfo, msg);
    }

    enableCartDetails(id): void {
        this.action = "E";
        this.cartstatus = "Y";
        var cartdetailsinfo = {
            'action': this.action,
            'id': id,
            'name': "",
            'phoneno': '',
            'golfclubid': this.golfClubId,
            'latitude': '',
            'longitude': '',
            'updtaedid': this.userid,
            'status': this.cartstatus
        }
        let msg = '<span style="color: green">Cart enabled Successfully</span>';
        this.DEapicall(cartdetailsinfo, msg);
    }

    DEapicall(cartdetailsinfo, msg) {
        this.api.postOH('savecartdetails', cartdetailsinfo).subscribe(
            (response) => {
                let parameters = {
                    searchvalue: " WHERE CD_GCB_ID='" + this.golfClubId + "' AND CD_STATUS = 'Y'"
                };
                this.GetCartDetailsData(parameters);
                this.gridShow = "block";
                this.contentShow = "none";
                this.viewcontentShow = "none";
                this.txtsrch = "";
                this.ddlsearch = "CD_NAME";
                this.ddldevice = "0";
                this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
                this.srchError = '0';
                this.toastMessage(msg);
            }, error => {
                console.log(error);
            });
    }

    decline(): void {
        this.modalRef.hide();
    }

    viewUsers(cartdata, i) {
        this.showMap = false;
        this.showScore = false;
        this.showDetails = false;
        this.rowval = i;
        if (this.detailsDiv_[this.rowval] == false || this.detailsDiv_[this.rowval] == undefined) {
            this.detailsDiv_[this.rowval] = true;
        }
        else {
            this.detailsDiv_[this.rowval] = false;
        }
        this.assignedCartId = "";
        this.assignedCartId = cartdata.id;
        if (cartdata.roletype == 0) {
            this.spinnerService.show();
            let parameters = { searchvalue: " WHERE SC_CD_ID='" + this.assignedCartId + "' AND SC_GAME_STATUS='L'" };
            this.api.postOH('getcartassignedusers', parameters).subscribe(
                (response) => {
                    if (response.length != 0) {
                        this.cartUserDetails = response;
                        this.loggedincart = this.cartUserDetails[0].cartid;
                        this.gameStatus = this.cartUserDetails[0].gamestatus;
                        let scoreCardIds: any = [];
                        for (var i = 0; i < this.cartUserDetails.length; i++) {
                            scoreCardIds.push(this.cartUserDetails[i].id);
                            this.playerUserIds.push(this.cartUserDetails[i].izonuserid);
                        }
                        this.golfersScorecardIds = scoreCardIds.join(",");
                        this.getScoreCardInfo();
                    }
                    this.spinnerService.hide();
                });
        }
        else if (cartdata.roletype > 0)
            this.spinnerService.show();
        {
            let parameters = {
                searchvalue: " where CLL_GCB_ID=" + this.golfClubId + " AND CLL_CD_ID=" + this.assignedCartId + " AND CLL_ACTION='I' AND CLL_U_TYPE=" + cartdata.roletype + ""
            };
            this.api.postOH('rangerandbeveragedetails', parameters).subscribe(
                (response) => {
                    if (response.length > 0) {
                        this.ranbavname = response[0].name;
                        this.ranbavId = response[0].uid;
                        this.loggedincart = response[0].cartid;
                        this.userType = response[0].roleid;
                        localStorage.setItem('rangerBeverageName', this.ranbavname);
                        localStorage.setItem('rangerBeverageId', this.ranbavId);
                    }
                    this.msg = "No data found";
                    this.spinnerService.hide();
                }, error => {
                    this.spinnerService.hide();
                }
            );
        }

    }

    completeTheGame() {
        // var enddate = moment(new Date()).format('MM/DD/YYYY hh:mm A');
        let currentDate: any = '';
        let d = new Date();
        let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
        currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
        var enddate = moment(currentDate).format('MM/DD/YYYY hh:mm A');
        if (this.cartUserDetails.length > 1) {
            var gamemodel = { "cartid": this.cartUserDetails[0].cartid, "player1": this.cartUserDetails[0].izonuserid, "player2": this.cartUserDetails[1].izonuserid, "enddate":enddate }
        }
        else {
            gamemodel = { "cartid": this.cartUserDetails[0].cartid, "player1": this.cartUserDetails[0].izonuserid, "player2": '0', "enddate":enddate }
        }
        this.spinnerService.show();
        this.api.postOH('updategamestatus', gamemodel).subscribe(
            response => {
                if (response == "Game Status Updated Successfully") {
                    let msg = '<span style="color: green">Game Completed Successfully</span>';
                    this.toastMessage(msg);
                    this.gameStatus = "C";
                    let parameters = {
                        searchvalue: " WHERE CD_GCB_ID='" + this.golfClubId + "' AND CD_STATUS = 'Y'"
                    };
                    this.GetCartDetailsData(parameters);
                    this.detailsDiv_[this.rowval] = false;
                }
                else if (response == "Error While Updating Game Status") {
                    let msg = '<span style="color: red">Failed to Update the data, please try again</span>';
                    this.toastMessage(msg);
                }
                this.spinnerService.hide();
            },
            err => {
                this.spinnerService.hide();
                let msg = '<span style="color: red">Something went wrong, please try again</span>';
                this.toastMessage(msg);
            }
        );
    }

    viewscore() {
        this.showMap = false;
        this.showDetails = false;
        this.showScore = true;
    }

    //scorecard functionality
    ngAfterViewInit() {
        this.GetScoreCardHandicapsPars();
    }

    GetScoreCardHandicapsPars() {
        let parameters = { "CourseID": localStorage.getItem('courseId') };
        this.api.postOH('GetScoreCardHandicapsPars', parameters).subscribe(
            (response) => {
                this.holePardetails = [];
                if (response.ScoreCardHandicapParvaluesResult[0].Response == "Success") {
                    let hpdetails = response.ScoreCardHandicapParvaluesResult[0];
                    if (hpdetails && hpdetails.HandicapsandParValues && hpdetails.HandicapsandParValues.length > 0) {
                        this.holePardetails = hpdetails.HandicapsandParValues;
                        //Total Par values
                        this.frontNinePar = hpdetails.HandicapTotals[0].FrontNineTotal;
                        this.backNinePar = hpdetails.HandicapTotals[0].BackNineTotal;
                        this.totalPar = hpdetails.HandicapTotals[0].Total;
                    }
                }
            });
    }

    getScoreCardInfo() {
        this.golfersScoreInfo = [];
        let parameters = {
            "ScoreCardIds": this.golfersScorecardIds
        };
        this.api.postOH('GetScores', parameters).subscribe(
            (response) => {
                if (response.length > 0) {
                    if (response[0].Response == "Success") {
                        let scoreData = response[0].ScoreData;
                        let userInfo = [];                        
                        for (let q = 0; q < this.cartUserDetails.length; q++) {
                            userInfo.push({
                                'izonuserid': this.cartUserDetails[q].izonuserid,
                                'izonusername': this.cartUserDetails[q].izonusername,
                                'Handcap': 10
                            })
                        }
                        if (userInfo.length > 0) {
                            this.golfersScoreInfo = [];
                            for (let m = 0; m < userInfo.length; m++) {
                                let totalPuts: number = 0; let totalFair: number = 0; let totalGreen: number = 0;
                                let totalPar: number = 0; let netScore: number = 0; let gsinfo = [];
                                let dataLength = scoreData.length;
                                let holeSeq = [];
                                let ps = m; ps++;
                                // FOR unfilled holes
                                for (let h = 0; h < 18; h++) {
                                    let nh = 0;
                                    nh = h; nh++;
                                    gsinfo.push({
                                        "dclass": "block",
                                        "class": 'parClass',
                                        "Fairway": '-',
                                        "GreeRegulation": '-',
                                        "HoleID": 0,
                                        "HoleSequence": nh,
                                        "PlayerPossition": ps,
                                        "Putts": '-',
                                        "score": '-',
                                        "shots": '-',
                                        "UserId": 0,
                                        "UserName": '',
                                        "totalPar": totalPar,
                                        "netScore": netScore,
                                        "totalPuts": totalPuts,
                                        "totalFair": totalFair,
                                        "totalGreen": totalGreen,
                                        "FairwayImg": '-',
                                        "GreeRegulationImg": '-'
                                    })
                                }


                                if (dataLength > 0) {
                                    for (var i = 0; i < dataLength; i++) {
                                        if (userInfo[m].izonuserid == scoreData[i].UserId) {
                                            holeSeq.push(scoreData[i].HoleSequence);
                                            let score = parseInt(scoreData[i].Score);
                                            let shots = parseInt(scoreData[i].Shots);
                                            let puts = parseInt(scoreData[i].Putts);
                                            let fair = (scoreData[i].Fairway == 'Y') ? 1 : 0
                                            let green = (scoreData[i].GreeRegulation == 'Y') ? 1 : 0
                                            let uid = userInfo[m].izonuserid;
                                            let uname = userInfo[m].izonusername
                                            totalPar += shots;
                                            netScore += score;
                                            totalPuts += puts;
                                            totalFair += fair;
                                            totalGreen += green;
                                            let classname = (score == 0) ? 'parClass' : (score == -1) ? 'birdieClass' : (score == -2) ? 'eagleClass' :
                                                (score <= -3) ? 'albatrossClass' : (score == 1) ? 'bogeyClass' : (score == 2) ? 'doubleBogeyClass' : 'ThreeBogeyClass';
                                            let gsnum = scoreData[i].HoleSequence;
                                            gsnum--;
                                            gsinfo[gsnum].class = classname;
                                            gsinfo[gsnum].Fairway = scoreData[i].Fairway;
                                            gsinfo[gsnum].GreeRegulation = scoreData[i].GreeRegulation;
                                            gsinfo[gsnum].HoleID = scoreData[i].HoleID;
                                            gsinfo[gsnum].HoleSequence = scoreData[i].HoleSequence;
                                            gsinfo[gsnum].PlayerPossition = scoreData[i].PlayerPossition;
                                            gsinfo[gsnum].Putts = puts;
                                            gsinfo[gsnum].score = score;
                                            gsinfo[gsnum].shots = shots;
                                            gsinfo[gsnum].UserId = scoreData[i].UserId;
                                            gsinfo[gsnum].UserName = '';
                                            gsinfo[gsnum].FairwayImg = (scoreData[i].Fairway == 'Y') ? 'assets/imgs/checkdark.png' : (scoreData[i].Fairway == 'N')? 'assets/imgs/crossred.png':'-';
                                            gsinfo[gsnum].GreeRegulationImg = (scoreData[i].GreeRegulation == 'Y') ? 'assets/imgs/checkdark.png' : (scoreData[i].GreeRegulation == 'N')? 'assets/imgs/crossred.png':'-';
                                            gsinfo[gsnum].dclass = "block";
                                        }

                                    }

                                    gsinfo.sort(function (a, b) {
                                        return a.HoleSequence - b.HoleSequence;
                                    });


                                    this.golfersScoreInfo.push({
                                        "UserName": userInfo[m].izonusername,
                                        "Handcap": userInfo[m].Handcap,
                                        "totalPar": totalPar,
                                        "netScore": netScore, //totalPar - parseInt(userInfo[p].Handcap),
                                        "scoreBoard": gsinfo,
                                        "totalPuts": totalPuts,
                                        "totalFair": totalFair,
                                        "totalGreen": totalGreen

                                    });
                                }
                            }
                        }
                    }
                }
            });
    }

    ShowPuts(id) {
        this.selectedPlayer = id;
    }

    refreshScore() {
        this.getScoreCardInfo();
    }

    closeScorecard() {
        this.showMap = false;
        this.showDetails = false;
        this.showScore = false;
        document.getElementById('viewFirstLayout').style.display = "block";
    }

    //signout
    cartusersignout(cartdetails) {
        var clearmodel = { "clubid": this.golfClubId, "cartid": cartdetails.id, "userid": this.ranbavId, "roleid": this.userType }
        this.spinnerService.show();
        this.api.postOH('clearrangerbevaragecart', clearmodel).subscribe(
            response => {
                if (response == "Ranger Cart Cleared Successfully") {
                    localStorage.setItem('gameStatus', 'S');
                    this.router.navigate(['/cartmanagement/cartsview']);
                }
                else if (response == "Error While Clearing Ranger Cart") {

                }
                this.spinnerService.hide();
            },
            err => {
                this.spinnerService.hide();
            }
        );
    }

    //cart force logout confirmation
    openModal1(template1: TemplateRef<any>, cartdetails) {
        this.modalRef1 = this.modalService.show(template1, { class: 'modal-sm' });
        this.cartdetailsforLogout = cartdetails;
    }

    confirmforcelogout(): void {
        this.modalRef1.hide();
        this.LogOutcart(this.cartdetailsforLogout);
    }

    declineforcelogout(): void {
        this.modalRef1.hide();
    }

    //cart messaging
    messsageModal(messagetemplate: TemplateRef<any>, cartDetails) {
        if (this.messagepopup == false) {
            this.messageModalRef = this.modalService.show(messagetemplate, { class: 'modal-sm' });
            this.messagepopup = true;
            this.cartId = cartDetails.id;
            this.messageForm.reset();
            this.messageSubmit = false;
            this.cartMessage = "";
            this.messageBtn = false;
        }
    }

    closemessgepopup() {
        this.messageModalRef.hide();
        this.messagepopup = false;
    }

    sendMessage() {
        if (!this.messageForm.valid) {

        }
        this.messageSubmit = true;
        this.messageBtn = true;
        if (this.messageForm.valid) {
            var messageModal = { "action": "A", "id": 0, "clubid": this.golfClubId, "fromcartid": 0, "tocartid": this.cartId, "message": this.cartMessage, "readstatus": "N", "userid": this.userid }
            this.spinnerService.show();
            this.api.postOH('savecartmessages', messageModal).subscribe(
                response => {
                    this.spinnerService.hide();
                    if (response == "Success") {
                        let msg = '<span style="color: green">Message sent successfully</span>';
                        this.toastMessage(msg);
                        this.closemessgepopup();
                        this.cartId = 0;
                        this.messageBtn = false;
                    } else {
                        let msg = '<span style="color: red">Failed to save the data, please try again</span>';
                        this.toastMessage(msg);
                        this.messageBtn = false;
                    }
                },
                err => {
                    this.spinnerService.hide();
                }
            );
        }
        else {
            this.messageBtn = false;
        }
    }

    //cart complete round confirmation
    openModalforCmpRound(template1: TemplateRef<any>) {
        this.templatecmprund = this.modalService.show(template1, { class: 'modal-sm' });        
    }

    confirmforcompleteround(): void {
        this.templatecmprund.hide();
        this.completeTheGame();
    }

    declineforcompleteround(): void {
        this.templatecmprund.hide();
    }

    //cart sign out confirmation
    openModalforCartsignout(template1: TemplateRef<any>,cartdetails) {
        this.templatecartsignout = this.modalService.show(template1, { class: 'modal-sm' });
        this.cartdetailsforLogout = cartdetails;
    }

    confirmforsignout(): void {
        this.templatecartsignout.hide();
        this.cartusersignout(this.cartdetailsforLogout);
    }

    declineforsignout(): void {
        this.templatecartsignout.hide();
    }

    getDateTime(cdate,offset) {
        let d = new Date(cdate);
        let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
        var currentDate = new Date(utc + (3600000 * offset));
        //this.datetime = Observable.interval(1000).map(() => currentDate);    
        var datetime = currentDate;
        return moment(datetime).format('MM/DD/YYYY hh:mm A');;
    }
    mobileFormat(e) {
        if (e.keyCode < 48 || e.keyCode > 57) {
            e.preventDefault();
        }
        if (e.target.value.length != "") {
            e.target.value = e.target.value.replace(/[^0-9]/g, '');

            if (!e.target.value) { return ''; }

            var number = String(e.target.value);
            e.target.value = number;

            var front = number.substring(0, 3);
            var center = number.substring(3, 6);
            var end = number.substring(6, 10);

            if (center) {
                e.target.value = (front + "-" + center);
            }
            if (end) {
                e.target.value += ("-" + end);
            }
            return e.target.value;
        }
    }
}
