import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CarttrackdetailsComponent } from './carttrackdetails.component';

describe('CarttrackdetailsComponent', () => {
  let component: CarttrackdetailsComponent;
  let fixture: ComponentFixture<CarttrackdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarttrackdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CarttrackdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
