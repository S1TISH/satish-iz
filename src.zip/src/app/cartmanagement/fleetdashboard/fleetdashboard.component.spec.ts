import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FleetdashboardComponent } from './fleetdashboard.component';

describe('FleetdashboardComponent', () => {
  let component: FleetdashboardComponent;
  let fixture: ComponentFixture<FleetdashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FleetdashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FleetdashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
