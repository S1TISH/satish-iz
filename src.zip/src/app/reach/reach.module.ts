import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { SeeinventoryComponent } from './seeinventory/seeinventory.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxEditorModule } from 'ngx-editor';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { SendlinkComponent } from './sendlink/sendlink.component';
import { InvitationhistoryComponent } from './invitationhistory/invitationhistory.component';
import { RevenuereportComponent } from './revenuereport/revenuereport.component';
import { AnalyticsComponent } from './analytics/analytics.component';
import { HttpClientModule } from '@angular/common/http';
import { BsDatepickerModule } from 'ngx-bootstrap';

const routes: Routes = [  
  {
    path:'seeinventory',
    component:SeeinventoryComponent
  },
  {
    path:'sendlink',
    component:SendlinkComponent
  },
  {
    path:'invitationhistory',
    component:InvitationhistoryComponent
  },
  {
    path:'revenuereport',
    component:RevenuereportComponent
  },
  {
    path:'analytics',
    component:AnalyticsComponent
  }
];
@NgModule({
  imports: [
    CommonModule,
    NgxEditorModule,
    FormsModule, ReactiveFormsModule,
    ToastModule.forRoot(), BsDatepickerModule.forRoot(),
    RouterModule.forChild(routes), HttpClientModule
  ],
  declarations: [AnalyticsComponent, InvitationhistoryComponent, RevenuereportComponent, SeeinventoryComponent, SendlinkComponent]
})
export class ReachModule { }
