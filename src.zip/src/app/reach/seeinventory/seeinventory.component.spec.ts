import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SeeinventoryComponent } from './seeinventory.component';

describe('SeeinventoryComponent', () => {
  let component: SeeinventoryComponent;
  let fixture: ComponentFixture<SeeinventoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SeeinventoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SeeinventoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
