import { Component, OnInit,Output, EventEmitter, ViewChild, TemplateRef, ViewContainerRef  } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Http, RequestOptions, Response, Headers } from '@angular/http';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
declare var document: any;
import * as moment from "moment";

@Component({
    selector: 'app-seeinventory',
    templateUrl: './seeinventory.component.html',
    styleUrls: ['./seeinventory.component.css']
})
export class SeeinventoryComponent implements OnInit {
    ShowGrid: boolean = true;
    ShowAddScreen: boolean = false;
    showLoader: boolean = false;
    Id: any = 0;
    clubid: any;
    _clubID: any;
    errorClass: any;
    Grid: boolean = true;
    TotalNumberRecords: any = 0;
    GCmodal: any = { modal: { Id: 0 } };
    lblErrorMessage: any = '';
    lblGridMessage: any = '';
    SpotsList: any = [];
    clublist: any = [];
    SearchType: any;
    SImodal: any = { modal: {}, count: "0", sort: {} };
    clubname: any = "";
    clubId: any;
    showgolfcourse: boolean = true;
    LocalSpotsList: any = [];
    RegionalSpotsList: any = [];
    monthslist: any = [];
    position: any;
    showclubname: boolean = true;
    showPagination: boolean = false;
    tempFileUrl: any;
    fileToUpload: File = null;
    FileName: any;
    months: any = 12;
    start: any;
    end: any;
    size: any;
    actualImgWidth: any;
    actualImgHeight: any;
    tmpvdoduration: any;
    videoduration: any;
    videoheight: any;
    videowidth: any;
    filetype: any;
    fileextension: any;
    formData: FormData = new FormData();
    SpotCost: any;
    spotId: any;
    userId: any;
    code: any;

    constructor(private api: ApiService, private toastr: ToastsManager,private vcr: ViewContainerRef,) {
        this.toastr.setRootViewContainerRef(vcr);
        this.ShowGrid = true;
       
        this.clubId = localStorage.getItem('clubId');
        this.userId = localStorage.getItem('ReachuserId');
        this.clubname = localStorage.getItem('clubname').replace(/ *\([^)]*\) */g, "");
        this.getgolfclubsport(this.clubId);
        
    }
    ngOnInit() {
    }

    
    getgolfclubsport(ClubID: any) {
        this.LocalSpotsList = [];
        this.RegionalSpotsList = [];
        this.lblGridMessage = "";
        this.clubid = ClubID;
        this.SImodal.modal.clubId = ClubID;
        this.SImodal.sort.SortOrder = 'Desc';
        this.SImodal.sort.SortExpression = 'spot_ts';
        this.SImodal.count = 0;
        this.showLoader = true;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        this.api.postWithDataHeadersreach('getClubIntegratedSpots', options, this.SImodal).subscribe(
            response => {
                var data = response.d;
                if (data && data.length > 0 && data[0].ResponseCode == 'Success') {
                    {
                        this.SpotsList = data;
                        let j = 0;
                        let k = 0;
                        for (let i = 0; i < this.SpotsList.length; i++) {
                            if (this.SpotsList[i].Type == 'L') {

                                this.LocalSpotsList[j] = this.SpotsList[i];
                                j++;
                            }
                        }
                        k = 0; j = 0;
                    }
                }
            },
            error => {
                this.SpotsList = [];
            });
    }
    changeFile(event) {
        let fileList: FileList = event.target.files;
        if (fileList.length > 0) {
            let file: File = fileList[0];
            this.fileToUpload = file;
            if (this.fileToUpload) {
                var fileExtension;
                fileExtension = this.fileToUpload.name.replace(/^.*\./, '');
                this.fileextension = fileExtension;
                var allowedExtensions = /(jpg|jpeg|png|gif)$/i;
                var allowedVideoExtensions = /(mp4|mov)$/i;
                if (allowedExtensions.exec(fileExtension)) {
                    this.filetype = "image";
                }
                else if (allowedVideoExtensions.exec(fileExtension)) {
                    this.filetype = "video";
                }
            }
            if (this.filetype == "image") {
                this.formData.append('file', this.fileToUpload, this.fileToUpload.name);
                if (event.target.files && event.target.files[0]) {
                    var reader = new FileReader();
                    this.size = event.target.files[0].size;
                    reader.onload = (event: any) => {
                        this.tempFileUrl = event.target.result;
                        var img = new Image();
                        img.src = event.target.result;
                        var el = this;
                        img.onload = function () {
                            el.actualImgWidth = img.width;
                            el.actualImgHeight = img.height;
                        }
                    }
                    reader.readAsDataURL(event.target.files[0]);
                }
            }
            else {
                this.formData.append('file', this.fileToUpload, this.fileToUpload.name);
                if (event.target.files && event.target.files[0]) {
                    var reader = new FileReader();
                    this.size = event.target.files[0].size;
                    reader.onload = (event: any) => {
                        this.tempFileUrl = event.target.result;
                        var pl = this;
                        var video = document.createElement('video');
                        video.preload = 'metadata';
                        video.src = event.target.result;
                        video.onloadedmetadata = function () {
                            window.URL.revokeObjectURL(video.src);
                            pl.videoduration = video.duration;
                            pl.actualImgHeight = video.videoHeight;
                            pl.actualImgWidth = video.videoWidth;
                            if (pl.videoduration <= 15.1) {
                            }
                            else {
                                pl.toastr.warning("video duration should be less than or equal to 15seconds", "", {
                                    timeOut: 3000,
                                    positionClass: 'toast-top-center',
                                });
                            }
                            video.remove();
                        }
                    }
                }
                reader.readAsDataURL(event.target.files[0]);
            }
        }
    }

    dismiss() {
        this.tempFileUrl = "";
        this.months = 12;
        this.start = "";
        this.end = "";
        document.getElementById('myModal').classList.remove('show');
        document.getElementById('myModal').classList.add('fade');
        document.getElementById('modalbackdrop').classList.remove('show');
        document.getElementById('modalbackdrop').classList.add('hide');
    }
    openmodal(position: any, id: any, spotcost: any) {
        this.SpotCost = spotcost;
        this.spotId = id;
        this.position = position;
        var d = new Date();
        this.start = d;
        var d1 = new Date();
        this.end = d1.setMonth(d1.getMonth() + this.months); 
        document.getElementById('myModal').classList.remove('fade');
        document.getElementById('myModal').classList.add('show');
        document.getElementById('modalbackdrop').classList.remove('hide');
        document.getElementById('modalbackdrop').classList.add('show');
    }
   
    Save() {
        this.SImodal.modal.Filename = this.fileToUpload.name;
        this.SImodal.modal.Filetype = this.filetype;
        this.SImodal.modal.Base64image = this.tempFileUrl.replace(/^data:image\/[a-z]+;base64,/, "");
        this.SImodal.modal.name = this.fileToUpload.name;
        this.SImodal.modal.extension = this.fileextension;
        this.SImodal.modal.height = this.actualImgHeight;
        this.SImodal.modal.width = this.actualImgWidth;
        this.SImodal.modal.size = this.size;
        this.SImodal.modal.duration = this.videoduration;
        this.SImodal.modal.StartDate = (this.start) ? moment(this.start).format('MM/DD/YYYY') : "";
        this.SImodal.modal.EndDate = (this.end) ? moment(this.end).format('MM/DD/YYYY') : "";
        this.SImodal.modal.spotcost = this.SpotCost;
        this.SImodal.modal.spotId = this.spotId;
        this.SImodal.modal.UserId = this.userId;
        this.SImodal.modal.clubId = this.clubid;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        this.api.postWithDataHeadersreach('saveIntegratedSpots', options, this.SImodal).subscribe(
            response => {
                var data = response.d;
                if (data && data.ResponseCode == 'Success') {
                    document.getElementById('myModal').classList.remove('show');
                    document.getElementById('myModal').classList.add('fade');
                    document.getElementById('modalbackdrop').classList.remove('show');
                    document.getElementById('modalbackdrop').classList.add('hide');
                    this.tempFileUrl = "";
                      this.getgolfclubsport(this.clubid);
            }
            },
            error => {
      
            });
    }

}
