import { Component, OnInit,Output, EventEmitter, ViewChild, TemplateRef, ViewContainerRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Http, RequestOptions, Response, Headers } from '@angular/http';
import { ApiService } from '../../services/api.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-sendlink',
  templateUrl: './sendlink.component.html',
  styleUrls: ['./sendlink.component.css']
})
export class SendlinkComponent implements OnInit {
    emailPattern = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$";
    Email: any;
    GCmodal: any = { modal: {}, count: "options", sort: {} };
    ShowGrid: boolean = false;
    emailpreview: boolean = false;
    _EmailPreviewshow: boolean = false;
    resendEmail: boolean = false;
    SaveClicked = false;
    CourseName: any;
    value: any = 0;
    clubid: any;
    apiClubId: any = 0;
    encryId: any = 0;
    showLoader: boolean = false;
    _sendEmaillist = [];
    _findEmaillist: any = [];
    clublist: any = [];
    Adscheckbox: boolean = false
    textarea: any = "";
    displayerrorMsg: any = "";
    SendEmails: any;
    key: string = '';
    reverse: boolean = false;
    emailcount: any;
    invitationcount: any = "0"
    descriptionasc: any = "sortgreen";
    descriptiondesc: any = "sortwhite";
    showgolfcourse: boolean = true;
    CurrentYear: any;
    loginUid: any;
    loginname: any;
    SDescription: any = "";
    loginType: any;
    Statelevel: any = "";
    Nationallevel: any = "Y";
    Courselevel: any = "";
    National: any = "Y";
    fieldArray: any = [];
    newAttribute: any = {};
    Local: any = "";
    statelist: any = [];
    State: any;
    TextArea: any = "";
    Description: any = "";
    CourseId: any;
    adminview: boolean = false;
    salesview: boolean = false
    Checklevel: any = "";
    StateChecklevel: any = "";
    CourecheCklevel: any;
    @ViewChild("sendlink") form: any;
    Listlevel: any = [];
    adslength: any = "";
    NatrionalChecklevel: any = "";
    courseleveldisable: boolean = false;
    nationaldisable: boolean = false;
    localdisable: boolean = false;
    statedropdown: boolean = false;
    coursedropdown: boolean = false;
    editorConfig: any = [];
    constructor(private router:Router, private toast: ToastsManager, private vcr: ViewContainerRef,private api:ApiService) {
        this.toast.setRootViewContainerRef(vcr);
        this.Description = "";
        this.editorConfig = {
            editable: true,
            spellcheck: false,
            height: '10rem',

        };
        this.apiClubId = localStorage.getItem('clubId');
        this.loginUid = localStorage.getItem('ReachuserId');
        this.CourseName = localStorage.getItem('clubname').replace(/ *\([^)]*\) */g, "");
        this.emailpreview = true;
        this._EmailPreviewshow = false;
        this.resendEmail = false;
        
    }

    addEmail(valid) {
        if (valid) {
            if (this.value != 0) {
                const index = this._findEmaillist.findIndex(obj => obj.email === this.Email)
                if (index > 0 || index == 0) {
                    this.displayerrorMsg = "Email Address already exists";
                    this.toast.warning(this.displayerrorMsg, "", {
                        timeOut: 3000,
                        positionClass: 'toast-top-center',
                    });
                }
                else {
                    this.displayerrorMsg = "";
                    var _oldarray = { "email": this.Email, "name": "" };
                    var _findarray = { "email": this.Email, "name": "" };
                    this._sendEmaillist.push(_oldarray);
                    this._findEmaillist.push(_findarray);

                    if ((this._findEmaillist.length && this._sendEmaillist.length) != 0) {
                        this.invitationcount = this._findEmaillist.length;
                        this.emailcount = this._findEmaillist.length;
                    }
                    else {
                        this.invitationcount = "0"
                    }
                    this.ShowGrid = false;
                    this.Email = "";
                    //this.resetFormModal();
                    this.SaveClicked = false;
                }

            }
            else {
                var _newarray = { "email": this.Email, "name": "" };
                var _findarray = { "email": this.Email, "name": "" };
                this._sendEmaillist.push(_newarray);
                this._findEmaillist.push(_findarray);
                if ((this._findEmaillist.length && this._sendEmaillist.length) != 0) {
                    this.invitationcount = this._findEmaillist.length;
                    this.emailcount = this._findEmaillist.length;
                }
                else {
                    this.invitationcount = "0"
                }
                this.Email = "";
                //this.resetFormModal();
                this.ShowGrid = false;
                this.SaveClicked = false;

            }
            this.value++;

        }
        else {
            this.displayerrorMsg = "Enter Email Address";
            this.toast.warning(this.displayerrorMsg, "", {
                timeOut: 3000,
                positionClass: 'toast-top-center',
            });
        }
    }
    emailPreview() {
        this.adslength = document.querySelectorAll('.ref-ads input[type="checkbox"]:checked').length;
        if (this._sendEmaillist.length != 0) {
            this.emailpreview = false;
            this._EmailPreviewshow = true;
            this.resendEmail = false;
            this.Description = "Hello,<br/><br/>" + this.CourseName + " has recently enchanced its golf course management process and golf experience by installing the new IZON Golf GPS tablet system in every cart. The system has many features to engage the golfer, the most interesting of which is the proprietary advertising platform called IZON REACH. Each tablet includes a video player where each ad is displayed once per hole for 15 seconds on every cart during every round at the course.<br /><br />" +
                "  We think this provide a unique opportunity for your business to put your video or still ad message in front of thousands of golfers. By clicking the link below, you will see" +
                " the details necessary to make yoour own decision. At the REACH site at this link, you can also reserve a position for ad, upload it and pay all in one place.It is extremely cost efficient and effective.<br/><br/>" +
                "if you have any questions of require any assistnce after viewing the opportunity, follow the support link included within this email and help will be on its way.";
            this.SDescription = this.Description;
        }
        else {
            this.displayerrorMsg = "Enter Email Address";
            this.toast.warning(this.displayerrorMsg, "", {
                timeOut: 3000,
                positionClass: 'toast-top-center',
            });
        }
    }
    Sendanotheremail() {
        this.adminview = false;
        this.emailpreview = true;
        this.Adscheckbox = false
        this.resendEmail = false;
    }
    viewall() {
        this.router.navigate[('invitationhistory')];
    }
    _SendEmailAddress() {
        var _modal = {
            modal: {
                "Id": 0, "clubId": (this.apiClubId) ? this.apiClubId : "0",
                "emailList": this._sendEmaillist,
                "CourseName": (this.CourseName) ? this.CourseName : "",
                "Year": "",
                "loginname": "",
                "loginId": (this.loginUid) ? this.loginUid : 0,
                "logintype": "GC",
                "emailCount": (this.emailcount) ? this.emailcount : "",
                "level": "C",
                "local": "N",
                "regional": "N",
                "textarea": this.Description,
                "state": ""
            }
        };
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        this.api.postWithDataHeadersreach('sendintegratedLink', options, _modal).subscribe(
            response => {
                var data = response.d;
                if (data && data.length > 0 && data[0].ResponseCode == 'Success') {
                    {
                        this.Resendemail();
                        this._sendEmaillist = [];
                    }
                }
            },
            error => {
                this.ShowGrid = true;
                this._sendEmaillist = [];
            });
    }
    Resendemail() {
        this.emailpreview = false;
        this._EmailPreviewshow = false;
        this.resendEmail = true;

        this.emailcount = "0";
        this.invitationcount = "0";
        this.Email = "";

    }
    emailback() {
        this.emailpreview = true;
        this._EmailPreviewshow = false;
        this.resendEmail = false;
    }
    saveDiscription() {
        this.SDescription = this.Description;
        this.dismiss();
    }
    EditCopy() {
        document.getElementById('myModal').classList.remove('fade');
        document.getElementById('myModal').classList.add('show');
        document.getElementById('modalbackdrop').classList.remove('hide');
        document.getElementById('modalbackdrop').classList.add('show');
    }
    dismiss() {
        document.getElementById('myModal').classList.remove('show');
        document.getElementById('myModal').classList.add('fade');
        document.getElementById('modalbackdrop').classList.remove('show');
        document.getElementById('modalbackdrop').classList.add('hide');
    }

  ngOnInit() {
  }

}
