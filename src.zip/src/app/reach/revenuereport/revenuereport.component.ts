import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Http, RequestOptions, Response, Headers } from '@angular/http';
import * as moment from "moment";

@Component({
  selector: 'app-revenuereport',
  templateUrl: './revenuereport.component.html',
  styleUrls: ['./revenuereport.component.css']
})
export class RevenuereportComponent implements OnInit {
yearslist: any = [];
    year: any;
    clublist: any = [];
    clubid: any;
    type: any;
    revenueList: any = [];
    hideclub: boolean;
    lblGridMessage: any = '';
    hidename: boolean;
    clubname: any;
    grandtotal: any = 0;
    monthstartdate: any;
    yearstartdate: any;
    currentdate: any;
    monthlyrevenue: any;
    yearlyrevenue: any;
    monthlypositions: any;
    yearlypositions: any;
    monthlyrevenuelist: any = [];
    revenuedetailsList: any = [];
    hidelist: boolean;
    viewlist: any;
    RevenueModal: any = { modal: {} };
    GCmodal: any = { modal: {}, count: "0", sort: {} };
    constructor(private api: ApiService) {
        this.hideclub = false;
        this.hidename = true;
        this.clubname = localStorage.getItem('clubname').replace(/ *\([^)]*\) */g, "");
        this.clubid = localStorage.getItem('clubId');
       
        this.year = 2018;
        for (let i = 0; i < 20; i++) {
            this.yearslist.push({ 'Id': 2018 + i })
        }
        this.monthlyrevenuelist = [{ month: 'January', positions: 0, Amount: 399, Total: 0 }, { month: 'February', positions: 0, Amount: 399, Total: 0 }, { month: 'March', positions: 0, Amount: 399, Total: 0 }, { month: 'April', positions: 0, Amount: 399, Total: 0 },
            { month: 'May', positions: 0, Amount: 399, Total: 0 }, { month: 'June', positions: 0, Amount: 399, Total: 0 }, { month: 'July', positions: 0, Amount: 399, Total: 0 }, { month: 'August', positions: 0, Amount: 399, Total: 0 },
            { month: 'September', positions: 0, Amount: 399, Total: 0 }, { month: 'October', positions: 0, Amount: 399, Total: 0 }, { month: 'November', positions: 0, Amount: 399, Total: 0 }, { month: 'December', positions: 0, Amount: 399, Total: 0 }]

        var date = new Date();
        var firstday = new Date(date.getFullYear(), date.getMonth(), 1);
        this.monthstartdate = firstday;
        this.monthstartdate = moment(this.monthstartdate).format('MM/DD/YYYY');
        var d = new Date(new Date().getFullYear(), 0, 1);
        this.yearstartdate = d;
        this.yearstartdate = moment(this.yearstartdate).format('MM/DD/YYYY');
        var d1 = new Date();
        this.currentdate = d1;
        this.currentdate = moment(this.currentdate).format('MM/DD/YYYY');
        this.getrevenue();
    }

    yearchange(value: any) {
        this.revenueList = [];
        this.grandtotal = 0;
        this.year = value;
        this.getrevenuelist();
    }
    getrevenue() {
        this.hidelist = false;
        this.RevenueModal.modal.CpclubId = this.clubid;
        this.RevenueModal.modal.monthstartdate = this.monthstartdate;
        this.RevenueModal.modal.yearstartdate = this.yearstartdate;
        this.RevenueModal.modal.currentdate = this.currentdate;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        this.api.postWithDataHeadersreach('getrevenuedata', options, this.RevenueModal).subscribe(
            response => {
                var data = response.d;
                if (data && data.Result && data.Result.ResponseCode == 'Success') {
                    this.revenueList = data.Revenuelist;
                    this.monthlypositions = this.revenueList[0].monthsAdspositions;
                    this.yearlypositions = this.revenueList[0].Adpositions;
                    this.monthlyrevenue = this.revenueList[0].totalcost;
                    this.yearlyrevenue = this.revenueList[0].yeartotal;
                    this.lblGridMessage = "";
                }
                else if (data && data.Result && data.Result.ResponseCode == 'Empty') {
                    this.revenueList = "";
                    this.lblGridMessage = data.Result.ResponseMessage;
                }
            },
            error => {
                this.revenueList = "";
                this.lblGridMessage = "";
            });
        
    }
    getrevenuelist() {
        this.grandtotal = 0;
        this.revenueList = [];
        this.viewlist = "list";
        this.hidelist = true;
        this.RevenueModal.modal.CpclubId = this.clubid;
        this.RevenueModal.modal.year = this.year;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        this.api.postWithDataHeadersreach('getrevenue', options, this.RevenueModal).subscribe(
            response => {
                var data = response.d;
            if (data && data.Result && data.Result.ResponseCode == 'Success') {
                this.revenuedetailsList = data.RevenemodalList;
                for (let i = 0; i < this.revenuedetailsList.length; i++) {
                    for (let j = 0; j < this.monthlyrevenuelist.length; j++) {
                        if (this.revenuedetailsList[i].monthname == this.monthlyrevenuelist[j].month) {
                            this.monthlyrevenuelist[j].positions = this.revenuedetailsList[i].revenuecount;
                            this.monthlyrevenuelist[j].Total = this.revenuedetailsList[i].revenue;
                            this.grandtotal += this.revenuedetailsList[i].revenue;
                        }
                        else {
                            this.monthlyrevenuelist[j].positions = 0;
                            this.monthlyrevenuelist[j].Total = 0;
                        }
                    }
                }
                this.lblGridMessage = "";
            }
            else if (data && data.Result && data.Result.ResponseCode == 'Empty') {
                this.revenueList = "";
                for (let i = 0; i < this.monthlyrevenuelist.length; i++) {
                    this.monthlyrevenuelist[i].positions = 0;
                    this.monthlyrevenuelist[i].Total = 0;
                }
                this.lblGridMessage = data.Result.ResponseMessage;
            }
            }, error => {
                this.revenueList = "";
                this.lblGridMessage = "";
            });
    }
    back() {
        this.hidelist = false;
        this.viewlist = "";
        this.getrevenue();
    }

  ngOnInit() {
  }

}
