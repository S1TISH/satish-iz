import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvitationhistoryComponent } from './invitationhistory.component';

describe('InvitationhistoryComponent', () => {
  let component: InvitationhistoryComponent;
  let fixture: ComponentFixture<InvitationhistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvitationhistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvitationhistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
