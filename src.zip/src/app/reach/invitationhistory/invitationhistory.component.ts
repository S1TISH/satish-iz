import { Component, OnInit, Output, EventEmitter, ViewChild, TemplateRef, ViewContainerRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { Http, RequestOptions, Response, Headers } from '@angular/http';
import { ApiService } from '../../services/api.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-invitationhistory',
  templateUrl: './invitationhistory.component.html',
  styleUrls: ['./invitationhistory.component.css']
})
export class InvitationhistoryComponent implements OnInit {
    clublist: any = [];
    encryId: any;
    Id: any = 0;
    Name: any = "";
    Description: any;
    SendEmailCount: any = [];
    email: any = "";
    date: any = "";
    CourseName: any = "";
    Sales: any = "";
    Invationview: boolean = true;
    golfcoursedrop: boolean = false;
    showcpcluberror: boolean = false;
    emailPreview: boolean = false;
    salesview: boolean = false;
    InvitationList: any = [];
    editedeamilInvitation: any;
    Nationallevel: any;
    statelist: any = [];
    apiClubId: any = 0;;
    emailcount: any = "";
    clubid: any;
    Courselevel: any;
    National: any;
    Checklevel: any;
    Listlevel: any = [];
    Statelevel: any;
    Local: any;
    lblGridMessage: any;
    State: any;
    _sendEmaillist: any = [{ "email": "" }];
    loginUid: any;
    loginname: any;
    loginType: any;
    Sortvalue: any = "";
    countStart: any = 0;
    countEnd: any = 0;
    pageStart: any = 1;
    countIncrease: any = 10;
    showPagination: boolean = false;
    TotalNumberRecords: any = 0;
    GCmodal: any = { modal: {}, count: "options", sort: {} };
    emailModal: any = { modal: {}, count: "0", sort: {} };
    constructor(private router:Router,private toast: ToastsManager, private vcr: ViewContainerRef, private api: ApiService) {
    this.Description = "";
    this.toast.setRootViewContainerRef(vcr);
 
    this.apiClubId = localStorage.getItem('clubId');
    this.loginUid = localStorage.getItem('ReachuserId');
    this.CourseName = localStorage.getItem('clubname').replace(/ *\([^)]*\) */g, "");
    this.emailModal = { modal: {}, count: "0", sort: {} };
    var d = new Date();
        this.emailInvitation();
            }



    close() {
        document.getElementById('myModal').classList.remove('show');
        document.getElementById('myModal').classList.add('fade');
        document.getElementById('modalbackdrop').classList.remove('show');
        document.getElementById('modalbackdrop').classList.add('hide');
    }
    Emaildetailes(cId: any) {
        this.encryId = cId;
        this.emailInvitation();

    }
    Changechecklevel(TypeCheck: any) {
        this.Checklevel = "";
        this.Checklevel = TypeCheck;
        this.emailInvitation();
    }


    emailInvitation() {
        this.lblGridMessage = "";
        this.emailModal.modal.loginId = this.loginUid;
        this.emailModal.modal.clubId = this.apiClubId;
        this.emailModal.modal.logintype = this.loginType;
        this.emailModal.count = this.countStart;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        this.api.postWithDataHeadersreach('getsendintegratedLink', options, this.emailModal).subscribe(
            response => {
                var data = response.d;
                if (data && data[0] && data[0].ResponseCode == 'Success') {
                    this.showcpcluberror = false;
                    if (data[0].TotalRecords > this.countIncrease) {
                        this.showPagination = true;
                        if ((this.countEnd < data[0].TotalRecords) && ((this.countStart + this.countIncrease) < data[0].TotalRecords)) {
                            this.countEnd = this.countStart + this.countIncrease;
                        }
                        else {
                            this.countEnd = data[0].TotalRecords;
                        }
                    }
                    else {
                        this.countEnd = data[0].TotalRecords;
                        this.showPagination = false;
                    }
                    this.InvitationList = data;
                    this.TotalNumberRecords = data[0].TotalRecords;
                }
                if (data && data[0] && data[0].ResponseCode == 'Empty') {
                    this.InvitationList = [];
                    this.showcpcluberror = true;
                    this.TotalNumberRecords = "0";
                    this.lblGridMessage = data[0].ResponseMessage;
                    this.InvitationList.length = 0;
                }
            },
            error => {

            });
    }

    previous() {
        this.pageStart = this.pageStart - 1;
        this.countStart = this.countStart - this.countIncrease;
        if (this.countEnd == this.TotalNumberRecords) {
            this.countEnd = this.countEnd - this.countIncrease;
        }
        this.emailModal.sort.SortOrder = 'Desc';
        this.emailModal.sort.SortExpression = 'sl_ts';
        this.emailInvitation();
    }
    next() {
        this.pageStart = this.pageStart + 1;
        this.countStart = this.countEnd;
        this.emailModal.sort.SortOrder = 'Desc';
        this.emailModal.sort.SortExpression = 'sl_ts';
        this.emailInvitation();
    }


    Newmessage() {
        this.router.navigate(['/sendlink']);
    }
   
    _SendEmailAddress() {
        this._sendEmaillist.email = this.email;
        var _modal = {
            modal: {
                "Id": 0, "clubId": (this.encryId) ? this.encryId : "0",
                "emailList": this._sendEmaillist,
                "CourseName": (this.CourseName) ? this.CourseName : "",
                "loginname": (this.loginname) ? this.loginname : "",
                "loginId": (this.loginUid) ? this.loginUid : 0,
                "logintype": (this.loginType) ? this.loginType : "",
                "emailCount": (this.emailcount) ? this.emailcount : "1",
                "level": (this.Checklevel) ? (this.Checklevel) : "",
                "local": (this.Local == true) ? "Y" : (this.Local == false) ? "N" : "N",
                "regional": (this.National == true) ? "Y" : (this.National == false) ? "N" : "N",
                "textarea": this.Description,
                "state": (this.State) ? (this.State) : ""


            }
        };
         let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        this.api.postWithDataHeadersreach('sendLink', options, this.emailModal).subscribe(
            response => {
                var data = response.d;
                if (data && data.ResponseCode == "Success") {
                    this.toast.success("Your email has been sent.", "", {
                        timeOut: 3000,
                        positionClass: 'toast-top-center',
                    });
                    this.close();
                    this.emailInvitation();
                }
                else if (data && data.ResponseCode == "Failed") {
                    //this.ShowGrid = true;
                    this._sendEmaillist = [];
                    this.toast.success(data[0].ResponseMessage, "", {
                        timeOut: 3000,
                        positionClass: 'toast-top-center',
                    });
                }
            },
            error => {

            });
        


    }
    viewchange(InId: any) {
        this.InvitationList.forEach((item, index) => {
            if (item.id == InId) {
                this.editedeamilInvitation = item;
            }
        });
        this.Id = this.editedeamilInvitation.Id;
        this.Name = this.editedeamilInvitation.Name;
        this.email = this.editedeamilInvitation.email;
        this.date = this.editedeamilInvitation.ts;
        this.Description = this.editedeamilInvitation.textarea;
 
        this._sendEmaillist.push({ "email": this.email, "name": "" });
    }
    ngOnInit() {
    }
  
}
