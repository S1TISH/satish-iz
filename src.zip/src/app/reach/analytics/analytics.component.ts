import { Component, OnInit } from '@angular/core';
import * as moment from "moment";

@Component({
  selector: 'app-analytics',
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.css']
})
export class AnalyticsComponent implements OnInit {
    todate: any;
    clubname: any = "";
    constructor() {
         this.todate = '';
        let d = new Date();
        this.todate = d; this.clubname = localStorage.getItem('clubname').replace(/ *\([^)]*\) */g, "");}

  ngOnInit() {
  }

}
