import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClubcourseinfoComponent } from './clubcourseinfo.component';

describe('ClubcourseinfoComponent', () => {
  let component: ClubcourseinfoComponent;
  let fixture: ComponentFixture<ClubcourseinfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClubcourseinfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClubcourseinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
