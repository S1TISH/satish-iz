import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Title } from '@angular/platform-browser';


@Component({
  selector: 'app-clubcourseinfo',
  templateUrl: './clubcourseinfo.component.html',
  styleUrls: ['./clubcourseinfo.component.css']
})
export class ClubcourseinfoComponent implements OnInit {

    showDiv: boolean = true;
    //Club variable declaration
    golfclubdata: any = [];
    clubname: string; clubcode: string; clubstate: string = "0"; clubsts: string; clubtxtsts: string;
    email: string = ''; website: string = ''; clubrotate: string; address: string; city: string; cntry: string = "0"; state: string; country: any;
    zipcode: string; contact: string; clubzoomlevel: string; lat: string; long: string; tzone: string = "0"; desc: string; logoimagepath: string;

    //Holes variable declaration
    HolesInfo: any = []; clubId: any; courseId: any; userId: any;

    //Course variable declaration
    coursename: any;rotate: any; zoomlevel: any; latitude: any; longitude: any; measurement: any; checkStatus: any; AdserverKey: any; coursePerimeter: string = 'No';

    //individual hole variable declaration
    holename: any; parval: any; menhandicap: any; womenhandicap: any; clatitude: any; clongitude: any; greenzoomlevel: any; paceofplay: any; holestatus: any;
    holezoomlevel: any; holerotate: any; sequence: any; txtgreenfrontlat: any; txtgreenfrontlong: any; txtgreenmiddlelat: any; txtgreenmiddlelong: any; txtgreenbacklat: any; txtgreenbacklong: any;

    constructor(private title: Title, private api: ApiService) {
        window.scrollTo(0, 0);

        var clubId = JSON.parse(localStorage.getItem('clubId'));
        this.clubId = clubId;
        var courseId = JSON.parse(localStorage.getItem('courseId'));
        this.courseId = courseId;
        var userId = JSON.parse(localStorage.getItem('userId'));
        this.userId = userId;
        this.viewclub();
        this.viewCourse(this.courseId);
       
    }

    bindHoles() {
        for (let i = 1; i < 19; i++){
            this.HolesInfo.push({
                "id": 0,
                "holename": i,
                "title": 'In-Active',
                "stsIcon": 'fa fa-times',
                "iconColor": 'red',
                "clat": '-',
                "clong": '-',
                "clatlongsts": 'N',
                "gflat": '-',
                "gflong": '-',
                "gflatlongsts": 'N',
                "gmlat": '-',
                "gmlong": '-',
                "gmlatlongsts": 'N',
                "gblat": '-',
                "gblong": '-',
                "gblatlongsts": 'N',
                "gzoom": '-',
                "gzoomsts": 'N',
                "holezoom": '-',
                "holezoomsts": 'N',
                "holerotate": '-',
                "holerotatests": 'N',
                "pof": '-',
                "pofsts": 'N',
                "holeperimetersts": 'No',
                "pincount": '0',
                "pinnumbers": ''
              });
        }
    }

    //to get Club Data
    viewclub() {
        
        let parameters = {
            searchvalue: ' WHERE GCB_ID=' + this.clubId + ''
        };
       
       let golfclubdata = [];
        this.api.postOH('getgolfclubaddress', parameters).subscribe(
            (response) => {
                if (response.length > 0) {
                    golfclubdata = response;
                    this.clubname = (!golfclubdata[0].name) ? "" : golfclubdata[0].name;
                    this.clubcode = (!golfclubdata[0].clubcode) ? "" : golfclubdata[0].clubcode;
                    this.email = (!golfclubdata[0].email) ? "" : golfclubdata[0].email;
                    this.website = (!golfclubdata[0].website) ? "" : golfclubdata[0].website;
                    this.rotate = (!golfclubdata[0].rotate) ? "" : golfclubdata[0].rotate;
                    this.address = (!golfclubdata[0].address) ? "" : golfclubdata[0].address;
                    this.city = (!golfclubdata[0].city) ? "" : golfclubdata[0].city;
                    var status = (golfclubdata[0].status == 'Y') ? "Active" : (golfclubdata[0].status == 'N') ? "In-Active" : "Deleted";
                    this.clubsts = status;
                    this.clubtxtsts = status;
                    this.zipcode = (!golfclubdata[0].zipcode) ? "" : golfclubdata[0].zipcode;
                    this.contact = (!golfclubdata[0].contact) ? "" : golfclubdata[0].contact;
                    this.lat = (!golfclubdata[0].latitude) ? "" : golfclubdata[0].latitude;
                    this.long = (!golfclubdata[0].longitude) ? "" : golfclubdata[0].longitude;
                    this.zoomlevel = (!golfclubdata[0].zoomlevel) ? "" : golfclubdata[0].zoomlevel;
                    this.desc = (!golfclubdata[0].description) ? "" : golfclubdata[0].description;
                    this.logoimagepath = (!golfclubdata[0].logoimagepath) ? "" : golfclubdata[0].logoimagepath;
                    this.state = (!golfclubdata[0].state) ? "" : golfclubdata[0].state;
                    this.country = (!golfclubdata[0].country) ? "" : golfclubdata[0].country;
                }

            }, error => {
                // this.spinnerService.hide();
            }
        );
    }

    //to get Holes Data
    getHoles() {

        let parameters = { searchvalue: " WHERE HD_GCB_ID='" + this.clubId + "' AND HD_GC_ID = '" + this.courseId + "' AND HD_STATUS='Y'"};
       // this.HolesInfo = [];
        this.api.postOH('getholes', parameters).subscribe(
            response => {
                if (response.length > 0) {
                    for (let i = 0; i < response.length; i++) {
                        let hsnum = response[i].sequence;
                        hsnum--;
                        this.HolesInfo[hsnum].id = response[i].id;
                        this.HolesInfo[hsnum].title = 'Active';
                        this.HolesInfo[hsnum].stsIcon = 'fa fa-check';
                        this.HolesInfo[hsnum].iconColor = '#5cb85c';

                        this.HolesInfo[hsnum].clat = response[i].clatitude;
                        this.HolesInfo[hsnum].clong = response[i].clongitude;
                        this.HolesInfo[hsnum].clatlongsts = (response[i].clatitude != '' && response[i].clongitude != '') ? 'Y' : 'N';

                        this.HolesInfo[hsnum].gflat = response[i].gflatitude;
                        this.HolesInfo[hsnum].gflong = response[i].gflongitude;
                        this.HolesInfo[hsnum].gflatlongsts = (response[i].gflatitude != '' && response[i].gflongitude != '') ? 'Y' : 'N';


                        this.HolesInfo[hsnum].gmlat = response[i].gmlatitude;
                        this.HolesInfo[hsnum].gmlong = response[i].gmlongitude;
                        this.HolesInfo[hsnum].gmlatlongsts = (response[i].gmlatitude != '' && response[i].gmlongitude != '') ? 'Y' : 'N';


                        this.HolesInfo[hsnum].gblat = response[i].gblatitude;
                        this.HolesInfo[hsnum].gblong = response[i].gblongitude;
                        this.HolesInfo[hsnum].gblatlongsts = (response[i].gblatitude != '' && response[i].gblongitude!='') ? 'Y' : 'N';

                        this.HolesInfo[hsnum].gzoom = (response[i].gzoomlevel != '') ? response[i].gzoomlevel : 0;
                        this.HolesInfo[hsnum].gzoomsts = (response[i].gzoomlevel != '') ? 'Y' : 'N';

                        this.HolesInfo[hsnum].holezoom = (response[i].zoomlevel != '') ? response[i].zoomlevel : 0;
                        this.HolesInfo[hsnum].holezoomsts = (response[i].zoomlevel != '') ? 'Y' : 'N';

                        this.HolesInfo[hsnum].holerotate = (response[i].rotate != '') ? response[i].rotate : 0;
                        this.HolesInfo[hsnum].holerotatests = (response[i].rotate != '') ? 'Y' : 'N';

                        this.HolesInfo[hsnum].pof = response[i].paceofplay;
                        this.HolesInfo[hsnum].pofsts = (response[i].paceofplay != '') ? 'Y' : 'N';
                        
                    }
                    this.getholeperimetersdata();
                } else {
                    
                }
               
            },
            err => {
               
            }
        );
    }

    //to get Course data
    viewCourse(id: any) {
        let parameters = { searchvalue: ' WHERE GC_GCB_ID=' + this.clubId + ' AND GC_ID=' + id + '' };
        this.api.postOH('getgolfcourse', parameters).subscribe(
            response => {
                if (response.length > 0) {
                    this.coursename = response[0].labelname;
                    this.rotate = response[0].rotate;
                    this.latitude = response[0].latitude;
                    this.longitude = response[0].longitude;
                    this.zoomlevel = response[0].zoomlevel;
                    this.measurement = response[0].measurement;
                    this.AdserverKey = response[0].adsid;
                    let status = (response[0].status == 'Y') ? true : false;
                    this.checkStatus = (response[0].status == 'Y') ? 'Active' : (response[0].status == 'N') ? 'In-Active' : 'Deleted';
                    this.getHoles();
                    let parameters1 = {
                        search: " WHERE  GCP_GCB_ID='" + this.clubId + "' AND GCP_GC_ID='" + id + "'  AND GCP_STATUS='Y'"
                    }
                    this.getcourseperimetersdata(parameters1);
                } else {
                   
                }
                
            },
            err => {
                
            }
        );
    }

    //to get course perimeter
     getcourseperimetersdata(parameters1) {
         this.api.postOH('GetGolfCoursePerimeters', parameters1).subscribe(
             (response) => {
                 if (response.length > 0) {
                     this.coursePerimeter = 'Yes';
                 } else {
                     this.coursePerimeter = 'No'
                 }
             }, error => {
             }
         );
    } 

    //to get hole perimeter
     getholeperimetersdata() {
          for (let j = 0; j < this.HolesInfo.length;j++){
              if (this.HolesInfo[j].id != 0) {
                  let parameters = {
                      expression: " WHERE  HP_GC_ID='" + this.courseId + "' and HP_HD_ID='" + this.HolesInfo[j].id + "' "
                  }
                  this.api.postOH('GetHolePerimeters', parameters).subscribe(
                      (response) => {
                          if (response.length > 0) {
                              this.HolesInfo[j].holeperimetersts = 'Yes';
                          } else {
                              this.HolesInfo[j].holeperimetersts = 'No';
                          }
                      }, error => {

                      }
                  );
              }
              if (this.HolesInfo[j].id != 0) {
                  let parameters = {
                      searchvalue: " WHERE  FP_GCB_ID='" + this.clubId + "' AND FP_GC_ID='" + this.courseId + "' AND FP_HD_ID='" + this.HolesInfo[j].id + "' AND FP_STATUS='Y'"
                  };
                  this.api.postOH('getholeflagdetails', parameters).subscribe(
                      (res) => {
                          if (res.length > 0) {
                              let seq = [];
                              for (var i = 0; i < res.length; i++) {
                                  seq.push(res[i].sequence);
                              }
                              seq.sort(function (a, b) {
                                  return a - b;
                              });
                              this.HolesInfo[j].pincount = res.length;
                              this.HolesInfo[j].pinnumber = seq.join(',');
                          }
                          else {

                          }
                      }, error => {

                      });
              }
          }
     }  

     
    ngOnInit() {
        this.bindHoles();
     }

}
