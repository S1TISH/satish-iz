import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ClubcourseinfoComponent } from './clubcourseinfo/clubcourseinfo.component';

const routes: Routes = [
    {
        path: '',
        component: ClubcourseinfoComponent
    }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        FormsModule
    ],
    declarations: [ClubcourseinfoComponent],
    exports: [RouterModule]  
})
export class ClubcourseinfoModule { }
