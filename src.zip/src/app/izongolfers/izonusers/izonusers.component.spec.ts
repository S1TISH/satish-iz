import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IzonusersComponent } from './izonusers.component';

describe('IzonusersComponent', () => {
  let component: IzonusersComponent;
  let fixture: ComponentFixture<IzonusersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IzonusersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IzonusersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
