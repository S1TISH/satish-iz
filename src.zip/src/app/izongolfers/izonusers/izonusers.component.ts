import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Title } from '@angular/platform-browser';

@Component({
    selector: 'app-izonusers',
    templateUrl: './izonusers.component.html',
    styleUrls: ['./izonusers.component.css']
})
export class IzonusersComponent implements OnInit {
    modalRef: BsModalRef;
    public base64textString: String = "";
    public izonuserForm: FormGroup; submitAttempt: boolean = false; divheader: string = "Add IZON Golfer";
    searchtxt: boolean = true; searchddl: boolean = false;
    izonusersdata: any = []; contentShow: string = "none"; gridShow: string = "none";
    viewcontentShow: string = "none"; options: any;
    txtShow: string = "none"; lblShow: string = "none";
    action: string = 'A'; userid: string = "0"; gender: any = "Male";
    searchvalues: any = []; searchstatus: any = []; viewstatusclass: any;
    name: string; lname: string; email: string; izonpswd: string; clubchksts: boolean = true;
    mobile: string; izonuserstatus: any; txtstatus: string = 'Active'; izonuserchkstatus: boolean = true; chkstatus: any; txtsrch: string = '';
    izonuserdataInfo: any;
    golfclubdata: any = [];

    GridMessage: string = 'Loading, Please wait ... !';
    logoimagepath: string; logoimagename: string; logobinaryimage: any = "";
    path = '';
    public file_srcs: string[] = [];
    public debug_size_before: string[] = [];
    public debug_size_after: string[] = [];
    srchError: string = '0'; ddlclub: any;

    ddlsearch: any; key: string = 'name';
    reverse: boolean = false;
    nameasc: any = "sortgreen"; namedesc: any = "sortwhite"; emailasc: any = "sortwhite"; emaildesc: any = "sortwhite";
    selectedoption: any = "Active"; randomcolor: any = "#5cb85c";

    constructor(private title: Title,private modalService: BsModalService, public toastr: ToastsManager, vcr: ViewContainerRef, private _router: Router, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService, private authService: AuthService) {
        this.title.setTitle("IZON - Izon Golfers");
        this.toastr.setRootViewContainerRef(vcr);
        this.ddlsearch = "IZ_U_FIRST_NAME";
        this.contentShow = "none"; this.gridShow = "none";
        this.ddlclub = "0";
    }

    ngOnInit() {
        this.izonuserForm = this.formBuilder.group({
            fname: ['', Validators.compose([Validators.required])],
            flname: ['', Validators.compose([Validators.required])],
            fizonemail: ['', Validators.compose([Validators.required])],
            fizonpwd: ['', Validators.compose([Validators.required])],
            mobile: ['', Validators.compose([Validators.required])],
            izonuserchkstatus:[''],
            gender:['']
        });
        
        let parameters = { searchvalue: " WHERE GCB_STATUS = 'Y' " };
        this.getGolfClub(parameters);
        parameters = {
            searchvalue: " WHERE IZ_U_STATUS='Y' AND IZ_U_REGISTRATION_STATUS='Y'"
        };
        this.GetizonusersData(parameters);

        this.gridShow = "block";
        this.contentShow = "none";
    }

    sort(value: string) {
        this.nameasc = "sortwhite"; this.namedesc = "sortwhite"; this.emailasc = "sortwhite"; this.emaildesc = "sortwhite";
        this.key = value;
        if (this.key == value) {
            this.reverse = !this.reverse;
            if (this.key == "name" && this.reverse) {
                this.namedesc = "sortgreen";
            }
            else if (this.key == "name" && (!this.reverse)) {
                this.nameasc = "sortgreen";
            }
            else if (this.key == "email" && this.reverse) {
                this.emaildesc = "sortgreen";
            }
            else if (this.key == "email" && (!this.reverse)) {
                this.emailasc = "sortgreen";
            }
        }
    }
    
    getGolfClub(parameters) {
        this.api.postOH('getgolfclubaddressddl', parameters).subscribe(
            (response) => {
                this.golfclubdata = [];
                for (let i = 0; i < response.length; i++) {
                    this.golfclubdata.push({
                        "id": response[i].id,
                        "name": response[i].name,
                        "clubcode": response[i].clubcode
                    });
                }

            }, error => {

            }
        );
    }

    getclubusers(val) {
        this.txtsrch = "";
        var searchexp = (val.value === "0") ? " WHERE IZ_U_STATUS='Y'  AND IZ_U_REGISTRATION_STATUS='Y'" : " where IZ_U_STATUS='Y'  AND IZ_U_REGISTRATION_STATUS='Y' AND IZ_U_ID in(select IZCU_IZ_U_ID from [dbo].[IZON_CLUB_USERS] where IZCU_GCB_ID=" + val.value + " and IZCU_STATUS='Y')";
        let parameters = {
            searchvalue: searchexp
        };
        this.GetizonusersData(parameters);
    }

    refreshpage() {
        // let parameters = {
        //     searchvalue: " WHERE IZ_U_STATUS='Y'"
        // };
        this.ddlclub = "0";
        this.txtsrch = "";this.srchError = '0';
        this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
        var searchexp = (this.ddlclub === "0") ? " WHERE IZ_U_STATUS='Y'  AND IZ_U_REGISTRATION_STATUS='Y'" : " where IZ_U_STATUS='Y'  AND IZ_U_REGISTRATION_STATUS='Y' AND IZ_U_ID in(select IZCU_IZ_U_ID from [dbo].[IZON_CLUB_USERS] where IZCU_GCB_ID=" + this.ddlclub + " and IZCU_STATUS='Y')";
        let parameters = {
            searchvalue: searchexp
        };
        this.GetizonusersData(parameters);
        this.ddlsearch = "IZ_U_FIRST_NAME";
    }

    search() {
        if (this.txtsrch == '') {
            this.srchError = '1';
        }
        else if (this.txtsrch != '') {
            var searchexp = "";
            this.srchError = '0';
            if (this.ddlsearch === "IZ_U_EMAIL") {
                searchexp = (this.ddlclub === "0") ? " WHERE IZ_U_EMAIL LIKE '%" + this.txtsrch + "%'  AND IZ_U_REGISTRATION_STATUS='Y' AND IZ_U_STATUS<>'D'" : "  WHERE (IZ_U_EMAIL LIKE '%" + this.txtsrch + "%')  AND IZ_U_REGISTRATION_STATUS='Y' AND IZ_U_ID in(select IZCU_IZ_U_ID from [dbo].[IZON_CLUB_USERS] where IZCU_GCB_ID=" + this.ddlclub + " and IZCU_STATUS<>'D') AND IZ_U_STATUS<>'D'";
            }
            else if (this.ddlsearch === "IZ_U_FIRST_NAME") {
                searchexp = (this.ddlclub === "0") ? " WHERE (IZ_U_FIRST_NAME LIKE '%" + this.txtsrch + "%' OR IZ_U_LAST_NAME LIKE '%" + this.txtsrch + "%')  AND IZ_U_REGISTRATION_STATUS='Y' AND IZ_U_STATUS<>'D'" : "  WHERE (IZ_U_FIRST_NAME LIKE '%" + this.txtsrch + "%' OR IZ_U_LAST_NAME LIKE '%" + this.txtsrch + "%')  AND IZ_U_REGISTRATION_STATUS='Y' AND IZ_U_ID in(select IZCU_IZ_U_ID from [dbo].[IZON_CLUB_USERS] where IZCU_GCB_ID=" + this.ddlclub + " and IZCU_STATUS<>'D') AND IZ_U_STATUS<>'D'";
            }

            // searchexp = (this.ddlclub === "0") ? " WHERE IZ_U_FIRST_NAME LIKE '%" + this.txtsrch + "%' OR IZ_U_LAST_NAME LIKE '%" + this.txtsrch + "%'  AND IZ_U_REGISTRATION_STATUS='Y'" : "  WHERE (IZ_U_FIRST_NAME LIKE '%" + this.txtsrch + "%' OR IZ_U_LAST_NAME LIKE '%" + this.txtsrch + "%')  AND IZ_U_REGISTRATION_STATUS='Y' AND IZ_U_ID in(select IZCU_IZ_U_ID from [dbo].[IZON_CLUB_USERS] where IZCU_GCB_ID=" + this.ddlclub + " and IZCU_STATUS='Y')";
            let parameters = {
                searchvalue: searchexp
            };
            this.GetizonusersData(parameters);
        }
    }

    addizonuser() {
        this.action = 'A';
        this.divheader = "Add IZON Golfer";
        this.userid = "0"; this.logoimagename = ""; this.logobinaryimage = ""; this.logoimagepath = "";
        this.gridShow = "none"; this.viewcontentShow = "none";
        this.contentShow = "block";
        this.txtShow = "block"; this.lblShow = "none";
        this.submitAttempt = false;
        this.name = "";
        this.lname = "";
        this.email = "";
        this.izonpswd = "";
        this.mobile = "";
        this.gender = "Male";
        this.izonuserstatus = "Y";

    }

    srchKeyUp(event: any) {
        var keyupcode = event.keyCode;
        if (keyupcode == 13) {
            this.search();
        }
        else if (this.txtsrch != '') {
            this.srchError = '0';
        }
    }
    bindselectedoption(selectedoption) {
        this.srchError = '0';
        if (this.selectedoption == 'Active') {
            this.randomcolor = "#5cb85c";
            this.srchSts('Y');
        }
        else if (this.selectedoption == 'In-Active') {
            this.randomcolor = "#337ab7";
            this.srchSts('N');
        }
        else if (this.selectedoption == 'Deleted') {
            this.randomcolor = "#d9534f";
            this.srchSts('D');
        }
    }
    srchSts(type) {
        // let parameters = {
        //     searchvalue: " WHERE  IZ_U_STATUS= '" + type + "' "
        // };
        var searchexp = (this.ddlclub === "0") ? " WHERE  IZ_U_STATUS= '" + type + "' AND IZ_U_REGISTRATION_STATUS='Y'" : " WHERE  IZ_U_STATUS= '" + type + "' AND IZ_U_REGISTRATION_STATUS='Y' AND IZ_U_ID in(select IZCU_IZ_U_ID from [dbo].[IZON_CLUB_USERS] where IZCU_GCB_ID=" + this.ddlclub + " and IZCU_STATUS='Y')";
        let parameters = {
            searchvalue: searchexp
        };
        //console.log(parameters);
        this.GetizonusersData(parameters);
    }

    viewizonuser(izonuser) {
        window.scrollTo(0,0);
        this.izonuserdataInfo = izonuser;
        this.action = 'V';
        this.userid = izonuser.id;
        this.name = (!izonuser.name) ? "" : izonuser.name;
        this.lname = (!izonuser.lname) ? "" : izonuser.lname;
        this.email = (!izonuser.email) ? "" : izonuser.email;
        this.izonpswd = (!izonuser.password) ? "" : izonuser.password;
        this.mobile = (!izonuser.mobile) ? "" : izonuser.mobile;
        this.gender = izonuser.gender;
        if (this.gender == 'M') {
            this.gender = "Male";
        }
        else if (this.gender == 'F') {
            this.gender = "Female";
        }

        this.logoimagename = (!izonuser.image) ? "" : izonuser.image;
        this.logoimagepath = (!izonuser.imagepath) ? "" : izonuser.imagepath;
        if (izonuser.status == 'Active') {
            this.izonuserstatus = 'Y';
        }
        else if (izonuser.status == 'In-Active') {
            this.izonuserstatus = 'N';
        }
        this.izonuserchkstatus = (this.izonuserstatus == 'Y') ? true : false;
        // this.izonuserstatus = (this.izonuserstatus == 'Y') ? 'Active' : 'In-Active';
        if (izonuser.status == 'Deleted') {
            this.izonuserstatus = 'D';
            this.txtstatus = 'Deleted';
        }
        this.gridShow = "none";
        this.viewcontentShow = "block"; this.contentShow = "none";

    }

    saveData() {
        if (!this.izonuserForm.valid) {

        }
        this.submitAttempt = true;
        if (this.izonuserForm.valid) {
            let imagecropped1 = (this.logoimagepath != "") ? this.logoimagepath.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
            var lgender=(this.gender=="Male")?'M':'F';
            if (this.action == 'A' || this.action == 'U') {
                var izonuserinfo = {
                    "action": this.action, "id": this.userid, "name": this.name, "lastname": this.lname, "email": this.email, "password": this.izonpswd, "mobile": this.mobile,
                    "image": this.logoimagename, "binaryimage": imagecropped1, "gender": lgender, "registrationstatus": "Y", "status": this.izonuserstatus
                }
                this.saveizonuser(izonuserinfo);
            }
        }
    }

    saveizonuser(izonusermodel) {
        //console.log(izonusermodel);
        this.spinnerService.show();
        this.api.postOH('SaveIzonUser', izonusermodel).subscribe(
            (response) => {
                if(response[0]>0){
                    var searchexp = (this.ddlclub === "0") ? " WHERE IZ_U_STATUS='Y' AND IZ_U_REGISTRATION_STATUS='Y'" : " where IZ_U_STATUS='Y' AND IZ_U_REGISTRATION_STATUS='Y' AND IZ_U_ID in(select IZCU_IZ_U_ID from [dbo].[IZON_CLUB_USERS] where IZCU_GCB_ID=" + this.ddlclub + " and IZCU_STATUS='Y')";
                    let parameters = {
                        searchvalue: searchexp
                    };
                    this.GetizonusersData(parameters);
                    this.gridShow = "block";
                    this.contentShow = "none";
                    this.viewcontentShow = "none";
                    this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
                    //let msg = (this.action == "A") ? '<span style="color: green">IZON Golfer added Successfully .</span>' : (this.action == "U") ?'<span style="color: green">IZON Golfer updated Successfully</span>':(this.action == "D") ?'<span style="color: green">IZON Golfer deleted Successfully</span>':(this.action == "E") ?'<span style="color: green">IZON Golfer enabled Successfully</span>':"";
                    let msg = "<span style='color: green'>" + response[1] + "</span>";
                    this.toastMessage(msg);
                }else{
                    let msg = "<span style='color: red'>" + response[1] + "</span>";
                    this.toastMessage(msg);
                }
                this.spinnerService.hide();
                window.scrollTo(0,0);
            }, error => {
                //console.log(error);
                this.spinnerService.hide();
            });
    }

    openModal(template: TemplateRef<any>) {
        this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
    }

    decline(): void {
        this.modalRef.hide();
    }

    confirm(): void {
        this.modalRef.hide();
        this.action = 'D';
        this.izonuserstatus = 'D';
        let imagecropped1 = (this.logoimagepath != "") ? this.logoimagepath.replace(/^data:image\/(png|jpg|gif|jpeg);base64,/, "") : "";
        var izonuserinfo = {
            "action": this.action, "id": this.userid, "name": this.name, "lastname": this.lname, "email": this.email, "password": this.izonpswd, "mobile": this.mobile, "gender": 'M', "registrationstatus": "Y",
            "image": "", "binaryimage": "", "status": this.izonuserstatus
        }
        this.saveizonuser(izonuserinfo);
    }

    enableizonuser(id) {
        this.action = 'E';
        this.izonuserstatus = 'Y';
        var izonuserinfo = {
            "action": this.action, "id": id, "name": "", "lastname": "", "email": "", "password": "", "mobile": "", "gender": "M", "registrationstatus": "Y",
            "image": "", "binaryimage": "", "status": this.izonuserstatus
        }
        this.saveizonuser(izonuserinfo);
    }

    goBack() {
        this.gridShow = "block";
        this.contentShow = "none";
        this.viewcontentShow = "none";
    }

    checkstatus(e) {
        this.izonuserstatus = (e.target.checked == true) ? 'Y' : 'N';
        this.txtstatus = (e.target.checked == true) ? 'Active' : 'In-Active';
    }

    changegender(val) {
        //this.gender = val;
        if (val == 'M') {
            this.gender = "Male";
        }
        else if (val == 'F') {
            this.gender = "Female";
        }
    }

    cancelizonuser() {
        if (this.action == 'A') {
            this.izonuserForm.reset();
            this.gridShow = "block";
            this.contentShow = "none";
            this.viewcontentShow = "none";
        }
        else {
            this.gridShow = "none";
            this.contentShow = "none";
            this.viewcontentShow = "block";
            this.viewizonuser(this.izonuserdataInfo);
            this.divheader = "";
        }
    }

    toastMessage(msg) {
        let options = {
            positionClass: 'toast-top-center',

        };

        this.toastr.custom(msg, null, {
            enableHTML: true, toastLife: 3000,
            showCloseButton: true, 'positionClass': 'toast-bottom-right'
        });
    }

    fileChange(input, fimg) {
        this.readFiles(input.files, fimg);
    }
    readFile(file, fimg, reader, callback) {
        reader.onload = () => {
            callback(reader.result);
            if (fimg == 'logo') {
                this.logoimagepath = reader.result;
                this.logoimagename = file.name;
                // alert(this.logoimagepath); alert(this.logoimagename);
            }
        }
        reader.readAsDataURL(file);
    }
    readFiles(files, fimg, index = 0) {
        // Create the file reader  
        let reader = new FileReader();
        // If there is a file  
        if (index in files) {
            // Start reading this file  
            this.readFile(files[index], fimg, reader, (result) => {
                // Create an img element and add the image file data to it  
                var img = document.createElement("img");
                img.src = result;
                // Send this img to the resize function (and wait for callback)  
                //this.resize(img, 250, 250, (resized_jpeg, before, after) => {
                //    // For debugging (size in bytes before and after)  
                //    this.debug_size_before.push(before);
                //    this.debug_size_after.push(after);
                //    // Add the resized jpeg img source to a list for preview  
                //    // This is also the file you want to upload. (either as a  
                //    // base64 string or img.src = resized_jpeg if you prefer a file).  
                //    this.file_srcs.push(resized_jpeg);
                //    // Read the next file;  
                //    this.readFiles(files, index + 1);
                //});
            });
        } else {
            // When all files are done This forces a change detection  
            // this.changeDetectorRef.detectChanges();
        }
    }
    resize(img, MAX_WIDTH: number, MAX_HEIGHT: number, callback) {
        // This will wait until the img is loaded before calling this function  
        return img.onload = () => {
            // Get the images current width and height  
            var width = img.width;
            var height = img.height;
            // Set the WxH to fit the Max values (but maintain proportions)  
            if (width > height) {
                if (width > MAX_WIDTH) {
                    height *= MAX_WIDTH / width;
                    width = MAX_WIDTH;
                }
            } else {
                if (height > MAX_HEIGHT) {
                    width *= MAX_HEIGHT / height;
                    height = MAX_HEIGHT;
                }
            }
            // create a canvas object  
            var canvas = document.createElement("canvas");
            // Set the canvas to the new calculated dimensions  
            canvas.width = width;
            canvas.height = height;
            var ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0, width, height);
            // Get this encoded as a jpeg  
            // IMPORTANT: 'jpeg' NOT 'jpg'  
            var dataUrl = canvas.toDataURL('image/jpeg');
            // callback with the results  
            callback(dataUrl, img.src.length, dataUrl.length);
        };
    }

    GetizonusersData(parameters) {
        this.spinnerService.show();
        this.api.postOH('getizonuser', parameters).subscribe(
            (response) => {
                //console.log(response);
                this.izonusersdata = [];
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusicon = (response[i].status == 'Y') ? "fa fa-check-circle-o" : (response[i].status == 'N') ? "fa fa-ban" : "fa fa-times-circle-o";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                    var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var confirmshow = "row-icon-inactive";

                    this.izonusersdata.push({
                        "id": response[i].id,
                        "name": response[i].name,
                        "lname": response[i].lastname,
                        "email": response[i].email,
                        "password": response[i].password,
                        "mobile": response[i].mobile,
                        "image": response[i].image,
                        "imagepath": response[i].imagepath,
                        "binaryimage": response[i].binaryimage,
                        "gender": response[i].gender,
                        "date": response[i].date,
                        "status": status,
                        "statusicon": statusicon,
                        "statusclass": statusclass,
                        "editshow": editshow,
                        "enableshow": enableshow,
                        "removeshow": removeshow,
                        "confirmshow": confirmshow
                    });
                }
                {
                    this.GridMessage = "No Data Found";
                    this.spinnerService.hide();
                }
                this.spinnerService.hide();

            }, error => {
                this.spinnerService.hide();
            }
        );
    }



    //edit record
    editizonuser() {
        this.divheader = "Edit IZON Golfer";
        this.action = 'U';
        this.gridShow = "none";
        this.contentShow = "block"; this.viewcontentShow = "none";
        this.txtShow = "block"; this.lblShow = "none";
        let parameters = {
            searchvalue: ' WHERE IZ_U_ID=' + this.userid + ''
        };
        let izonuser = [];
        this.api.postOH('getizonuser', parameters).subscribe(
            (response) => {
                for (let i = 0; i < response.length; i++) {
                    var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
                    var statusicon = (response[i].status == 'Y') ? "fa fa-check-circle-o" : (response[i].status == 'N') ? "fa fa-ban" : "fa fa-times-circle-o";
                    var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
                    var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
                    var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
                    var confirmshow = "row-icon-inactive";

                    izonuser.push({
                        "id": response[i].id,
                        "name": response[i].name,
                        "lname": response[i].lastname,
                        "email": response[i].email,
                        "password": response[i].password,
                        "mobile": response[i].mobile,
                        "image": response[i].image,
                        "imagepath": response[i].imagepath,
                        "binaryimage": response[i].binaryimage,
                        "gender": response[i].gender,
                        "date": response[i].date,
                        "status": status,
                        "statusicon": statusicon,
                        "statusclass": statusclass,
                        "editshow": editshow,
                        "enableshow": enableshow,
                        "removeshow": removeshow,
                        "confirmshow": confirmshow
                    });
                }

                this.name = (!izonuser[0].name) ? "" : izonuser[0].name;
                this.lname = (!izonuser[0].lname) ? "" : izonuser[0].lname;
                this.email = (!izonuser[0].email) ? "" : izonuser[0].email;
                this.izonpswd = (!izonuser[0].password) ? "" : izonuser[0].password;
                this.mobile = (!izonuser[0].mobile) ? "" : izonuser[0].mobile.replace(/^(\d{3})(\d{3})(\d{4}).*/, '$1-$2-$3');
                this.logoimagename = (!izonuser[0].image) ? "" : izonuser[0].image;
                this.logoimagepath = (!izonuser[0].imagepath) ? "" : izonuser[0].imagepath;
            },
            error => {
                this.spinnerService.hide();
            })
    }


    mobileFormat(e) {
        if (e.keyCode < 48 || e.keyCode > 57) {
            e.preventDefault();
        }
        if (e.target.value.length != "") {
            e.target.value = e.target.value.replace(/[^0-9]/g, '');

            if (!e.target.value) { return ''; }

            var number = String(e.target.value);
            e.target.value = number;

            var front = number.substring(0, 3);
            var center = number.substring(3, 6);
            var end = number.substring(6, 10);

            if (center) {
                e.target.value = (front + "-" + center);
            }
            if (end) {
                e.target.value += ("-" + end);
            }
            return e.target.value;
        }
    }
}











