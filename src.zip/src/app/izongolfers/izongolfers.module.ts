import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { ModalModule } from 'ngx-bootstrap';
import { OrderModule } from 'ngx-order-pipe';
//import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';

import { IzonusersComponent } from './izonusers/izonusers.component';
import { IzonclubusersComponent } from './izonclubusers/izonclubusers.component';

const routes: Routes = [
  {
    path:'izonusers',
    component:IzonusersComponent
  },
  {
    path:'izonclubusers',
    component:IzonclubusersComponent
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule, ReactiveFormsModule,
    ToastModule.forRoot(),
    ModalModule.forRoot(),OrderModule
  ],
  declarations: [IzonusersComponent, IzonclubusersComponent],
  exports: [RouterModule]  
})
export class IzongolfersModule { }
