import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IzonclubusersComponent } from './izonclubusers.component';

describe('IzonclubusersComponent', () => {
  let component: IzonclubusersComponent;
  let fixture: ComponentFixture<IzonclubusersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IzonclubusersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IzonclubusersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
