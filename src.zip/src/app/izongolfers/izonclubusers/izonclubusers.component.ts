import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-izonclubusers',
  templateUrl: './izonclubusers.component.html',
  styleUrls: ['./izonclubusers.component.css']
})
export class IzonclubusersComponent implements OnInit {

  modalRef: BsModalRef;
  public izonclubuserForm: FormGroup; submitAttempt: boolean = false; divheader: string = "Add Club Golfer";
  searchtxt: boolean = true; searchddl: boolean = false;
  usersdata: any=[]; izonclubuserassignmentdata: any=[];
  contentShow: string = "none"; gridShow: string = "none"; searchgolfclub: string = "block";
  txtShow: string = "none"; lblShow: string = "none";
  action: string = 'A'; izonclubuserid: string = "0";handicap:any;
  clubname: string; username: string; chkstatus: any; assignmentstatus: any; viewcontentShow: string = "none";
  txtsrch: string = ''; ddlizonuser: any;  txtstatus: string = 'fa fa-check-circle-o'; clubuserchkstatus: boolean = true;
  GridMessage: string = 'Loading, Please wait ... !'; viewstatustitle: any; viewstatusclass: any;
  key: string = 'izonusername';
  reverse: boolean = false;
  nameasc:any="sortgreen"; namedesc:any="sortwhite"; statusasc:any="sortwhite"; statusdesc:any="sortwhite";
  selectedoption:any="Active";randomcolor:any="#5cb85c";srchError:any='0';
  
  constructor(private title: Title,private router: Router, private modalService: BsModalService, public toastr: ToastsManager, vcr: ViewContainerRef, private _router: Router, public formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, public api: ApiService, private authService: AuthService) {
    //localStorage.removeItem('courseId');
    this.title.setTitle("IZON - Club Golfer Assignment");
    this.toastr.setRootViewContainerRef(vcr);
    this.contentShow = "none"; this.gridShow = "none";
    this.ddlizonuser = "0";
  }

  ngOnInit() {
    this.izonclubuserForm = this.formBuilder.group({
      userinfo: ['0', Validators.compose([Validators.required])],
      fchandicap: ['', Validators.compose([Validators.required])],
      clubuserchkstatus: ['']
    });
  
    let parameters = { searchvalue: " WHERE IZ_U_STATUS = 'Y' AND IZ_U_REGISTRATION_STATUS='Y' " };
    this.getIZONUsers(parameters);

    let parameters1 = {
      searchvalue: " WHERE IZCU_STATUS='Y' AND IZ_U_REGISTRATION_STATUS='Y' and IZCU_GCB_ID='"+localStorage.getItem('clubId')+"' "
    };
    this.getIZONclubuserassignmenttable(parameters1);

    this.gridShow = "block";
    this.contentShow = "none";
  }

  sort(value : string)
  {
    this.key = value;
    this.nameasc="sortwhite"; this.namedesc="sortwhite"; this.statusasc="sortwhite"; this.statusdesc="sortwhite";
      if(this.key == value)
      {
        this.reverse = !this.reverse;
        if(this.key=="izonusername" && this.reverse){
          this.namedesc="sortgreen";
        }
        else  if(this.key=="izonusername" && (!this.reverse)){
          this.nameasc="sortgreen";
        }
        else  if(this.key=="assignedstatus" && this.reverse){
          this.statusdesc="sortgreen";
        }
        else  if(this.key=="assignedstatus" && (!this.reverse)){
          this.statusasc="sortgreen";
        }
      }
  }
  
  getIZONclubuserassignmenttable(parameters) {
    this.spinnerService.show();
    this.api.postOH('GetIzonClubUsers', parameters).subscribe(
      (response) => {
        //console.log(response);
        this.izonclubuserassignmentdata = [];
        for (let i = 0; i < response.length; i++) {
          var status = (response[i].status == 'Y') ? "fa fa-check-circle-o" : (response[i].status == 'N') ? "fa fa-ban" : "fa fa-times-circle-o";
          var statustitle = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
          var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
          var editshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var enableshow = (response[i].status == 'D') ? "row-icon-active" : "row-icon-inactive";
          var removeshow = (response[i].status != 'D') ? "row-icon-active" : "row-icon-inactive";
          var confirmshow = "row-icon-inactive";

          this.izonclubuserassignmentdata.push({
            "id": response[i].id,
            "izonuserid": response[i].izonuserid,
            "izonusername": response[i].izonusername,
            "clubid": response[i].clubid,
            "assignedstatus": response[i].assignedstatus,
            "cartname": response[i].cartname,
            "clubname": response[i].clubname,
            "handicap": response[i].handicap,
            "status": status,
            "statustitle": statustitle,
            "statusclass": statusclass,
            "editshow": editshow,
            "enableshow": enableshow,
            "removeshow": removeshow,
            "confirmshow": confirmshow
          });
        }
        if (this.action === "U") {
          this.ddlizonuser = (!this.izonclubuserassignmentdata[0].izonuserid) ? "" : this.izonclubuserassignmentdata[0].izonuserid;
          this.handicap=(!this.izonclubuserassignmentdata[0].handicap) ? "" : this.izonclubuserassignmentdata[0].handicap;
          this.assignmentstatus = (this.izonclubuserassignmentdata[0].statustitle == "Active") ? true : false;
        }
        {
          this.GridMessage = "No Data Found";
          this.spinnerService.hide();
        }
        this.spinnerService.hide();

      }, error => {
        this.spinnerService.hide();
      }
    );

  }
  goBackClub() {
    //localStorage.removeItem('clubId');
    //localStorage.removeItem('clubname');
    this.authService.getCall();
    this.router.navigate(['/clubmanagement/golfclub']);
  }
  
  goBack() {
    this.izonclubuserForm.reset();
    this.gridShow = "block";
    this.contentShow = "none";
    this.viewcontentShow = "none";
    this.action = 'A';
  }
  refreshpage() {
    this.txtsrch = "";
    this.srchError = '0';
    this.selectedoption="Active";this.randomcolor="#5cb85c";
    let parameters = {
      searchvalue: " WHERE  IZCU_STATUS= 'Y' AND IZ_U_REGISTRATION_STATUS='Y' and IZCU_GCB_ID= '"+localStorage.getItem('clubId')+"' "
    };
    this.getIZONclubuserassignmenttable(parameters);
  }

  search() {
    if (this.txtsrch == '') {
      this.srchError = '1';
    }
    else if (this.txtsrch != '') {
      this.srchError = '0';
      let parameters = {
        searchvalue: " WHERE (IZ_U_FIRST_NAME LIKE '%" + this.txtsrch + "%' OR IZ_U_LAST_NAME LIKE '%" + this.txtsrch + "%') AND IZ_U_REGISTRATION_STATUS='Y' and IZCU_GCB_ID= '" + localStorage.getItem('clubId') + "' and IZCU_STATUS<>'D' "
      };
      this.getIZONclubuserassignmenttable(parameters);
    }
  }

  getIZONUsers(parameters) {
    this.api.postOH('getizonuser', parameters).subscribe(
      (response) => {
       this.usersdata = [];
        for (let i = 0; i < response.length; i++) {
          this.usersdata.push({
            "id": response[i].id,
            "name": response[i].name+' '+response[i].lastname,
          });
        }

      }, error => {

      }
    );
  }

  checkBoxChange(status) {
    this.chkstatus = status;
    if (this.chkstatus == true) {
      //this.assignmentstatus = 'Y';
      this.assignmentstatus = true;
      this.txtstatus = 'fa fa-check-circle-o';
    }
    else {
      //this.assignmentstatus = 'N';
      this.assignmentstatus = false;
      this.txtstatus = 'fa fa-ban';
    }
  }
  viewclubuser(izonclubassignments) {
    window.scrollTo(0,0);
    this.action = 'V';
    this.gridShow = "none";
    this.viewcontentShow = "block";
    this.contentShow = "none";
    this.izonclubuserid = izonclubassignments.id;
    this.clubname = (!izonclubassignments.clubname) ? "" : izonclubassignments.clubname;
    this.username = (!izonclubassignments.izonusername) ? "" : izonclubassignments.izonusername;
    if (izonclubassignments.status == 'fa fa-check-circle-o') {
      this.assignmentstatus = 'Y';
      this.viewstatustitle = "Active";
      this.viewstatusclass = "active-status";
    }
    else if (izonclubassignments.status == 'fa fa-ban') {
      this.assignmentstatus = 'N';
      this.viewstatustitle = "In-Active";
      this.viewstatusclass = "inactive-status";
    }
    else {
      this.viewstatustitle = "Deleted";
      this.viewstatusclass = "deleted-status";
    }
    this.clubuserchkstatus = (this.assignmentstatus == 'Y') ? true : false;
    this.txtstatus = (this.assignmentstatus == 'Y') ? 'fa fa-check-circle-o' : (this.assignmentstatus == 'N') ? 'fa fa-ban' : 'fa fa-times-circle-o';
    if (izonclubassignments.status == 'fa fa-times-circle-o') {
      this.assignmentstatus = 'D';
      this.txtstatus = 'fa fa-times-circle-o';
    }
  }

  addclubuser() {
    this.action = 'A';
    this.izonclubuserid = "0";
    this.gridShow = "none";
    this.contentShow = "block";
    this.txtShow = "block"; this.lblShow = "none";
    this.submitAttempt = false;
    this.clearform();
    this.divheader = "Add IZON Club Golfer";
  }
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }
  decline(): void {
    this.modalRef.hide();
  }
  confirm(): void {
    this.modalRef.hide();
    this.action = "D";
    var izonuserclubassignmentmodel = {
      "action": "D",
      "id": this.izonclubuserid,
      "izonuserid": this.ddlizonuser,
      "clubid": localStorage.getItem('clubId'),
      "clubname":localStorage.getItem('clubname'),
      "handicap": '0',
      "status": 'D'
    }
    this.saveclubassignment(izonuserclubassignmentmodel);
  }
  bindselectedoption(selectedoption) {
    this.txtsrch='';this.srchError='0';
    if (this.selectedoption == 'Active') {
        this.randomcolor = "#5cb85c";
        this.srchSts('Y');
    }
    else if (this.selectedoption == 'In-Active') {
        this.randomcolor = "#337ab7";
        this.srchSts('N');
    }
    else if (this.selectedoption == 'Deleted') {
        this.randomcolor = "#d9534f";
        this.srchSts('D');
    }
  }
  srchSts(type) {
    let parameters = {
      searchvalue: " WHERE  IZCU_STATUS= '" + type + "' AND IZ_U_REGISTRATION_STATUS='Y' and IZCU_GCB_ID= '"+localStorage.getItem('clubId')+"' "
    };
    this.getIZONclubuserassignmenttable(parameters);
  }
  enableclubuser(clubassignments) {
    this.action = "E";
    var izonuserclubassignmentmodel = {
      "action": this.action,
      "id": clubassignments.id,
      "izonuserid": this.ddlizonuser,
      "clubid": localStorage.getItem('clubId'),
      "clubname":localStorage.getItem('clubname'),
      "handicap": '0',
      "status": 'Y'
    }
    this.saveclubassignment(izonuserclubassignmentmodel);
  }
  editclubuser() {
    this.divheader = "Edit IZON Club Golfer";
    this.action = 'U';
    this.gridShow = "none";
    this.contentShow = "block";
    this.viewcontentShow = "none";
    this.txtShow = "block"; this.lblShow = "none";
    let parameters = {
      searchvalue: " WHERE IZCU_ID=" + this.izonclubuserid + " and IZCU_GCB_ID= '"+localStorage.getItem('clubId')+"' "
    };
    this.spinnerService.show();
    this.getIZONclubuserassignmenttable(parameters);
    this.spinnerService.hide();
  }
  gotogrid() {
    this.izonclubuserForm.reset();
    let parameters = {
      searchvalue: " WHERE  IZCU_STATUS= 'Y' AND IZ_U_REGISTRATION_STATUS='Y' and IZCU_GCB_ID= '"+localStorage.getItem('clubId')+"' "
    };
    this.getIZONclubuserassignmenttable(parameters);
    this.gridShow = "block";
    this.contentShow = "none";
    this.viewcontentShow = "none";
    this.action = 'A';
  }
  
  clearform() {
    this.ddlizonuser = "0";
    this.action = "A";
    this.izonclubuserid = "0";
    this.handicap="";
    this.assignmentstatus = "Y"
  }
  saveData() {
    if (!this.izonclubuserForm.valid) {
      //alert('f');
    }
    this.submitAttempt = true;
    if (this.ddlizonuser != '0') {
      if (this.izonclubuserForm.valid) {        
        this.assignmentstatus = this.assignmentstatus === true ? 'Y' : 'N';
        var izonuserclubassignmentmodel = {
          "action": this.action,
          "id": this.izonclubuserid,
          "izonuserid": this.ddlizonuser,
          "clubid": localStorage.getItem('clubId'),
          "clubname":localStorage.getItem('clubname'),
          "handicap": this.handicap,
          "status": this.assignmentstatus
        }
      //console.log(izonuserclubassignmentmodel);
       this.saveclubassignment(izonuserclubassignmentmodel);
      }
    }
  }
  saveclubassignment(golfclubuserassignmentmodel) {
    this.spinnerService.show();
    this.api.postOH('saveizonclubuser', golfclubuserassignmentmodel).subscribe(
      (response) => {
        if(response[0]>0){
          let parameters = {
            searchvalue: " WHERE  IZCU_STATUS= 'Y' AND IZ_U_REGISTRATION_STATUS='Y' and IZCU_GCB_ID= '"+localStorage.getItem('clubId')+"' "
          };
          this.getIZONclubuserassignmenttable(parameters);
          this.gridShow = "block";
          this.contentShow = "none";
          this.viewcontentShow = "none";
          this.selectedoption="Active";this.randomcolor="#5cb85c";
          let msg = (this.action == "A") ? '<span style="color: green">IZON Club Golfer added Successfully .</span>' : (this.action == "U") ? '<span style="color: green">IZON Club Golfer updated Successfully</span>' : (this.action == "D") ? '<span style="color: green">IZON Club Golfer deleted Successfully</span>' : (this.action == "E") ? '<span style="color: green">IZON Club Golfer enabled Successfully</span>' : "";
          this.toastMessage(msg);
        }else{
          let msg = '<span style="color: red">'+response[1]+'</span>';
          this.toastMessage(msg);
        }       
        this.spinnerService.hide();
        window.scrollTo(0, 0);
      },error=>{
        this.spinnerService.hide();
      });
  }
  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',

    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 3000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }

  allowNumbers(event) {
    if (event.keyCode < 48 || event.keyCode > 57) {
        event.preventDefault();
    }
  }

}

