import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { OrderModule } from 'ngx-order-pipe';

import { TournamentComponent } from './tournament/tournament.component';
import { LeaderboardComponent } from './leaderboard/leaderboard.component';

const routes: Routes = [
  {
    path: 'tournament',
    component: TournamentComponent
  },
  {
    path: 'leaderboard',
    component: LeaderboardComponent
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule, ReactiveFormsModule,
    OwlDateTimeModule,OrderModule,
    OwlNativeDateTimeModule, BsDatepickerModule.forRoot()
  ],
  declarations: [TournamentComponent, LeaderboardComponent],
  exports: [RouterModule]
})
export class TournamentModule { }
