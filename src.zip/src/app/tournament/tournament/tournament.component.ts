import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form'
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { AuthService } from '../../services/auth.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Title } from '@angular/platform-browser';
import { Options } from 'ng5-slider';
import * as moment from "moment";
import { Observable } from 'rxjs/Rx';

@Component({
  selector: 'app-tournament',
  templateUrl: './tournament.component.html',
  styleUrls: ['./tournament.component.css']
})
export class TournamentComponent implements OnInit {
  modalRef: BsModalRef;
  public tournamentSetUpForm: FormGroup; public playerCartsForm: FormGroup;
  submitAttempt: boolean = false; cartSubmitAttempt: boolean = false;
  courseDetails: any = []; cartDetails: any = []; HolesInfo: any = []; playerCartsList: any = [];
  currentDate: any;
  tournamentFormat: string = "none"; playerHandicaps: string = "none"; totalDuration: any = ""; totalTournamentDuration: any = "";
  //tournamentFormat: string = "block"; playerHandicaps: string = "block";
  //tournament get
  divheader: string = "Create Tournament"; GridMessage: string = 'Loading... !'; addShow: string = "none";
  tournamentList: any = [];
  searchInfo: string = "block"; gridInfo: string = "block"; viewInfo: string = "none";
  selectedoption: any = "Active"; randomcolor: any = "#5cb85c";
  refreshBtn: any; disableDatePicker: boolean = false; disableTimePicker: boolean = false;
  //search
  search: any = ''; srchError: string = '0';
  //sorting
  key: string = 'tournamentStartDate';
  // reverse: boolean = true;
  reverse: boolean = false;
  tournamentNameasc: any = "sortwhite"; tournamentNamedesc: any = "sortwhite";
  tournamentStartDateasc: any = "sortgreen"; tournamentStartDatedesc: any = "sortwhite";
  tournamentEndDateasc: any = "sortwhite"; tournamentEndDatedesc: any = "sortwhite";
  //tournament
  action: any = "A"; action1: any = "A"; action2: any = ""; tournamentName: any; tournamentStartDate: any; tournamentStartTime: any;
  tournamentEndDate: any; tournamentEndTime: any; courseId: any; courseName: any;
  noOfRounds: any; roundsLength: any; tournamentStatus: any = "";
  userId: any; clubId: any; courseHolesId: any; tournamentId: any = 0;
  subBtn: any; playerSubBtn: any;
  minStartDate: any; minEndDate: any; errorDate: any = "";
  status: any; checkStatus: any;
  editButton: string = "none";
  //player cart
  cartId: any; holeId: any; rider1: any; rider2: any;
  userDetails: any = []; rideruserDetails: any = []; userid: any = '0'; errorCount: any = '0'; autocomplete: string = "none"; riderautocomplete: string = "none";
  userDetails1: any = []; rideruserDetails1: any = []; userid1: any = '0'; errorCount1: any = '0'; autocomplete1: string = "none"; riderautocomplete1: string = "none";
  tournamentInfo: string; playerCartsInfo: string; totalRecords: number = 0;
  //slider components
  value: number = 50;
  options: Options = {
    floor: 0,
    ceil: 100,
    translate: (value: number): string => {
      if (value > 0 && value < 100) {
        return value + '%';
      }
      else {
        return value + '';
      }
    },
  };
  addPlayerCarts: any = []; nameIndex: any = 0; rider1Count: number = 0; rider2Count: number = 0; riderCount: number = 0;
  cartIdCount: number = 0; validateCount: number = 0; tempPlayerCarts: any = [];
  gridPlayerInfo: string; addPlayerInfo: string;
  showSubmitBtn: string; showFinishBtn: string; addPlayerCartBtn: string; gridPlayerCartBtn: string;
  editPlayer: string = "block"; updatePlayer: string = "none"; groupId: any = 0;
  updatedPlayerCartsList: any = []; editButtonCount: number;
  lastOpenedWindow: any = ""; deletedArray: any = []; assignedPlayerCarts: any = [];
  endTournamentModal: any = [];
  golfclubid: any = localStorage.getItem('clubId'); courselat: any; courselong: any; sub: any;
  currentGolfClubDateTime: any = ""; timeoffset: any = '';
  constructor(private title: Title, public toastr: ToastsManager, vcr: ViewContainerRef,
    private router: Router, public formBuilder: FormBuilder,
    private spinnerService: Ng4LoadingSpinnerService,
    private api: ApiService, private authService: AuthService,
    private modalService: BsModalService) {
    this.title.setTitle("IZON - Tournament Set Up");
    this.toastr.setRootViewContainerRef(vcr);
    this.clubId = localStorage.getItem('clubId');
    this.courseHolesId = localStorage.getItem('courseId');
    this.userId = localStorage.getItem('userId');
    //this.currentDate = moment(new Date()).format('MM/DD/YYYY');
  }

  ngOnInit() {
    this.tournamentSetUpForm = this.formBuilder.group({
      ftname: ['', Validators.compose([Validators.required])],
      ftstartdate: [''],
      ftstarttime: [''],
      ftenddate: [''],
      ftendtime: [''],
      ftcourse: [0, Validators.compose([Validators.required])],
      roundsLength: ['']
    });

    this.playerCartsForm = this.formBuilder.group({
    });

    let searchexp = "";
    searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' and  GC_ID='" + localStorage.getItem('courseId') + "'"
    let params = { searchvalue: searchexp };
    this.getcourses(params);

    // let parameters = { searchvalue: " where T_GCB_ID='" + this.clubId + "' and T_GC_ID='" + this.courseHolesId + "' and T_STATUS='Y'" };
    // this.getTournaments(parameters);
    this.getCourseDetails();
    this.getAddPlayerCartsList();
    this.sub = Observable.interval(1000 * 60).subscribe(x => {
      let searchexp = "";
      searchexp = " WHERE GC_GCB_ID='" + this.golfclubid + "' and GC_STATUS='Y' and  GC_ID='" + localStorage.getItem('courseId') + "'"
      let params = { searchvalue: searchexp };
      this.getcourses(params);
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  //Gets Golf-Course Coordinates
  getcourses(params) {
    this.api.postOH('getgolfcourse', params).subscribe(
      response => {
        if (response.length > 0) {
          this.courselat = response[0].latitude;
          this.courselong = response[0].longitude;
          this.timeoffset = response[0].timeoffset;
          //this.getTimeUsingLatLng(this.courselat, this.courselong);
          this.getCourseDateTime();
        }
      }, error => {

      });
  }

  getCourseDateTime() {
    let currentDate: any = ''; this.currentGolfClubDateTime = '';
    let d = new Date();
    let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
    currentDate = new Date(utc + (3600000 * parseInt(this.timeoffset)));
    this.currentGolfClubDateTime = currentDate;
    let parameters = { searchvalue: " where T_GCB_ID='" + this.clubId + "' and T_GC_ID='" + this.courseHolesId + "' and T_STATUS='Y'" };
    this.getTournaments(parameters);
  }



  getAddPlayerCartsList() {
    this.addPlayerCarts = [];//this.tempPlayerCarts=[];
    for (let i = 0; i < 10; i++) {
      this.addPlayerCarts.push({
        "playerId": i,
        "rider1": "",
        "rider2": "",
        "cartId": 0,
        "holeId": 0,
        "userId1": 0,
        "userId2": 0,
        "registeredUser1": "N",
        "registeredUser2": "N"
      });
      this.playerCartsForm.addControl('frider1' + i, this.formBuilder.control(['']));
      this.playerCartsForm.addControl('frider2' + i, this.formBuilder.control(['']));
      this.playerCartsForm.addControl('fcartId' + i, this.formBuilder.control([0]));
      this.playerCartsForm.addControl('fholeId' + i, this.formBuilder.control([0]));
    }
  }

  getGridAddPlayerCarts() {
    if (this.addPlayerCarts.length === 0) {
      this.getAddPlayerCartsList();
    }
    else if (this.addPlayerCarts.length > 0) {
      this.addMorePlayerCarts();
    }
    this.addPlayerInfo = "block"; this.showSubmitBtn = "block"; this.showFinishBtn = "none";
  }

  addMorePlayerCarts() {
    var count = (this.addPlayerCarts.length - 1) + 1;
    var countlength = this.addPlayerCarts.length + 10;
    for (let i = count; i < countlength; i++) {
      this.addPlayerCarts.push({
        "playerId": i,
        "rider1": "",
        "rider2": "",
        "cartId": 0,
        "holeId": 0,
        "userId1": 0,
        "userId2": 0,
        "registeredUser1": "N",
        "registeredUser2": "N"
      });
      this.playerCartsForm.addControl('frider1' + i, this.formBuilder.control(['']));
      this.playerCartsForm.addControl('frider2' + i, this.formBuilder.control(['']));
      this.playerCartsForm.addControl('fcartId' + i, this.formBuilder.control([0]));
      this.playerCartsForm.addControl('fholeId' + i, this.formBuilder.control([0]));
    }
  }

  sort(value: string) {
    this.key = value;
    this.tournamentNameasc = "sortwhite"; this.tournamentNamedesc = "sortwhite";
    this.tournamentStartDateasc = "sortwhite"; this.tournamentStartDatedesc = "sortwhite";
    this.tournamentEndDateasc = "sortwhite"; this.tournamentEndDatedesc = "sortwhite";
    if (this.key == value) {
      this.reverse = !this.reverse;
      if (this.key == "tournamentName" && this.reverse) {
        this.tournamentNamedesc = "sortgreen";
        this.nameSorting(this.tournamentList);
      }
      else if (this.key == "tournamentName" && (!this.reverse)) {
        this.tournamentNameasc = "sortgreen";
        this.nameReverseSorting(this.tournamentList);
      }
      if (this.key == "tournamentStartDate" && this.reverse) {
        this.tournamentStartDatedesc = "sortgreen";
        this.startDateReverseSorting(this.tournamentList);
      }
      else if (this.key == "tournamentStartDate" && (!this.reverse)) {
        this.tournamentStartDateasc = "sortgreen";
        this.startDateReverseSorting(this.tournamentList);
      }
      if (this.key == "tournamentEndDate" && this.reverse) {
        this.tournamentEndDatedesc = "sortgreen";
        this.endDateReverseSorting(this.tournamentList);
      }
      else if (this.key == "tournamentEndDate" && (!this.reverse)) {
        this.tournamentEndDateasc = "sortgreen";
        this.endDateReverseSorting(this.tournamentList);
      }
    }
  }

  nameSorting(tournament) {
    // sort by tournamentName
    tournament.sort(function (a, b) {
      var typeA = a.tournamentName.toUpperCase();
      var typeB = b.tournamentName.toUpperCase();
      if (typeA < typeB) {
        return -1;
      }
      if (typeA > typeB) {
        return 1;
      }
      return 0;
    });
  }

  nameReverseSorting(tournament) {
    // reverse sort by tournamentName
    tournament.reverse(function (a, b) {
      var typeA = a.tournamentName.toUpperCase();
      var typeB = b.tournamentName.toUpperCase();
      if (typeA < typeB) {
        return -1;
      }
      if (typeA > typeB) {
        return 1;
      }
      return 0;
    });
  }


  startDateSorting(tournament) {
    return tournament.sort((a, b) => {
      <any>new Date(a.tournamentStartDate) - <any>new Date(b.tournamentStartDate);
      return <any>new Date(a.tournamentStartTime) - <any>new Date(b.tournamentStartTime);
    });
  }

  startDateReverseSorting(tournament) {
    return tournament.reverse((b, a) => {
      <any>new Date(b.tournamentStartDate) - <any>new Date(a.tournamentStartDate);
      return <any>new Date(b.tournamentStartTime) - <any>new Date(a.tournamentStartTime);
    });
  }

  endDateSorting(tournament) {
    return tournament.sort((a, b) => {
      return <any>new Date(a.tournamentEndDate, a.tournamentEndTime) - <any>new Date(b.tournamentEndDate, b.tournamentEndTime);
    });
  }

  endDateReverseSorting(tournament) {
    return tournament.reverse((b, a) => {
      return <any>new Date(b.tournamentEndDate, a.tournamentEndTime) - <any>new Date(a.tournamentEndDate, b.tournamentEndTime);
    });
  }

  //search 
  searchTournament() {
    var status = '';
    status = this.selectedoption == 'Active' ? 'Y' : 'N';
    if (this.search == '') {
      this.srchError = '1';
    }
    else if (this.search != '') {
      this.srchError = '0';
      let parameters = { searchvalue: " where T_GCB_ID='" + this.clubId + "' and T_GC_ID='" + this.courseHolesId + "' and T_NAME LIKE '%" + this.search + "%' and T_STATUS='" + status + "'" };
      this.getTournaments(parameters);
      this.search = "";
    }
  }

  bindselectedoption(selectedoption) {
    this.srchError = '0';
    if (this.selectedoption == 'Active') {
      this.randomcolor = "#5cb85c";
      this.searchStatus('Y');
    }
    else if (this.selectedoption == 'In-Active') {
      this.randomcolor = "#337ab7";
      this.searchStatus('N');
    }
    else if (this.selectedoption == 'Deleted') {
      this.randomcolor = "#d9534f";
      this.searchStatus('D');
    }
  }

  searchStatus(type) {
    let parameters = { searchvalue: " where T_GCB_ID='" + this.clubId + "' and T_GC_ID='" + this.courseHolesId + "' and T_STATUS='" + type + "'" };
    this.getTournaments(parameters);
  }

  srchKeyUp(event: any) {
    if (this.search != '') {
      this.srchError = '0';
    }
  }

  //refresh
  refreshpage() {
    this.search = '';
    this.srchError = '0';
    this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
    this.tournamentNameasc = "sortwhite"; this.tournamentNamedesc = "sortwhite";
    this.tournamentStartDateasc = "sortgreen"; this.tournamentStartDatedesc = "sortwhite";
    this.tournamentEndDateasc = "sortwhite"; this.tournamentEndDatedesc = "sortwhite";
    let parameters = { searchvalue: " where T_GCB_ID='" + this.clubId + "' and T_GC_ID='" + this.courseHolesId + "' and T_STATUS='Y'" };
    this.getTournaments(parameters);
  }

  //gets days difference between start and end dates
  getDateDifference(presentenddate) {
    let presentdate: any = ""; let enddate: any = ""; this.totalDuration = "";
    //presentdate = new Date();
    presentdate = this.currentGolfClubDateTime;
    let diffInMs: number = Date.parse(presentenddate) - Date.parse(presentdate);

    var day, hour, minute, seconds;
    seconds = Math.floor(diffInMs / 1000);
    minute = Math.floor(seconds / 60);
    seconds = seconds % 60;
    hour = Math.floor(minute / 60);
    minute = minute % 60;
    this.totalDuration = hour + 'hours' + " " + minute + 'mins';
  }

  //Getting
  getTournaments(parameters) {
    this.tournamentList = [];
    this.refreshBtn = true;
    this.spinnerService.show();
    this.api.postOH('gettournaments', parameters).subscribe(
      response => {
        this.tournamentList = [];
        if (response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            this.getDateDifference(new Date(response[i].tournamentenddate + ' ' + response[i].tournamentendtime));
            var device = this.totalDuration.toLowerCase();
            if (device.indexOf('-') >= 0) {
              var dateDiff = 1;
              if ((response[i].tournamentStatus == 'Y' || response[i].tournamentStatus == 'C' || response[i].tournamentStatus == 'N') && dateDiff == 1) {
                this.editButton = "none";
              }
              else {
                this.editButton = "block";
              }
              // this.editButton = "none";
              // if (response[i].tournamentstatus == 'Y') {
              //   this.editButton = "block";
              // }
            }
            else {
              var dateDiff = 0;
              if (response[i].tournamentstatus == 'Y' || this.tournamentStatus == 'N') {
                this.editButton = "block";
              }
              if (response[i].tournamentstatus == 'C') {
                this.editButton = "none";
              }
            }

            var status = (response[i].status == 'Y') ? "Active" : (response[i].status == 'N') ? "In-Active" : "Deleted";
            var statusclass = (response[i].status == 'Y') ? "active-status" : (response[i].status == 'N') ? "inactive-status" : "deleted-status";
            this.tournamentList.push({
              "id": response[i].id,
              "clubid": response[i].clubid,
              "courseId": response[i].courseid,
              "tournamentName": response[i].tournamentname,
              "tournamentStartDate": response[i].tournamentdate,
              "tournamentEndDate": response[i].tournamentenddate,
              "tournamentStartTime": response[i].tournamentstarttime,
              "tournamentEndTime": response[i].tournamentendtime,
              // "noOfRounds": response[i].noofrounds,
              "roundsLength": response[i].roundslength,
              "tournamentstatus": response[i].tournamentstatus,
              "editButtonCount": response[i].pendingcartscount,
              "status": status,
              "statusclass": statusclass,
              "dateDiff": dateDiff
            });
          }
          window.scrollTo(0, 0);
          this.refreshBtn = false;
          this.spinnerService.hide();
        } else {
          this.tournamentList = []; this.refreshBtn = false;
          this.spinnerService.hide();
          this.GridMessage = "No Records Found";
        }
      },
      err => {
        this.spinnerService.hide(); this.tournamentList = [];
        this.GridMessage = "No Records Found";
      }
    );
  }

  //add Tournament
  addTournament() {
    this.divheader = "Create Tournament"; this.addShow = "block"; this.searchInfo = "none";
    this.gridInfo = "none"; this.viewInfo = "none"; this.action = "A"; this.errorDate = "";
    if (this.courseDetails.length > 1) {
      this.courseId = this.courseHolesId;
    }
    this.tournamentName = "";
    // this.tournamentStartDate = new Date(); this.tournamentStartTime = new Date();
    // this.tournamentEndDate = new Date(); this.tournamentEndTime = new Date();
    // this.minStartDate = new Date(); this.minEndDate = new Date();
    this.tournamentStartDate = this.currentGolfClubDateTime; this.tournamentStartTime = this.currentGolfClubDateTime;
    this.tournamentEndDate = moment(this.currentGolfClubDateTime).add(1, 'd').toDate(); this.tournamentEndTime = this.currentGolfClubDateTime;
    this.minStartDate = this.currentGolfClubDateTime; this.minEndDate = this.currentGolfClubDateTime;
    //this.noOfRounds = "1"; 
    this.roundsLength = "18";
    this.tournamentInfo = "block"; this.playerCartsInfo = "none"; this.status = "Y";
    this.submitAttempt = false;
    this.cartSubmitAttempt = false;
    this.rider1 = ""; this.rider2 = "";
    this.showSubmitBtn = "block"; this.showFinishBtn = "none";
    this.addPlayerCartBtn = "block"; this.gridPlayerCartBtn = "none";
    this.disableDatePicker = false; this.disableTimePicker = false;
    this.tournamentSetUpForm.controls['ftstartdate'].enable();
    this.tournamentSetUpForm.controls['ftstarttime'].enable();
  }

  //view
  viewTournament(id) {
    let presentTimeDiff; this.totalDuration = "";
    // let todayDate = moment(new Date()).format('MM/DD/YYYY');
    let todayDate = moment(this.currentGolfClubDateTime).format('MM/DD/YYYY');
    this.searchInfo = "none"; this.gridInfo = "none"; this.viewInfo = "block";
    this.spinnerService.show();
    let parameters = { searchvalue: " where T_GCB_ID='" + this.clubId + "' and T_GC_ID='" + this.courseHolesId + "' and T_ID='" + id + "'" };
    this.api.postOH('gettournaments', parameters).subscribe(
      response => {
        window.scrollTo(0, 0);
        this.spinnerService.hide();
        if (response.length > 0) {
          this.tournamentId = response[0].id;
          this.courseId = response[0].courseid;
          this.tournamentName = response[0].tournamentname;
          this.tournamentStartDate = response[0].tournamentdate;
          this.tournamentStartTime = response[0].tournamentstarttime;
          this.tournamentEndDate = response[0].tournamentenddate;
          this.tournamentEndTime = response[0].tournamentendtime;
          // this.noOfRounds = response[0].noofrounds;
          this.roundsLength = response[0].roundslength;
          this.status = (response[0].status == 'Y') ? true : false;
          this.checkStatus = (response[0].status == 'Y') ? 'Active' : (response[0].status == 'N') ? 'In-Active' : 'Deleted';
          this.tournamentStatus = response[0].tournamentstatus;
          this.getDateDifference(new Date(response[0].tournamentenddate + ' ' + response[0].tournamentendtime));
          var device = this.totalDuration.toLowerCase();
          if (device.indexOf('-') >= 0) {
            var dateDiff = 1;
            // this.editButton = "none";
            // if (this.tournamentStatus == 'Y') {
            //   this.editButton = "block";
            // }
            if ((this.tournamentStatus == 'Y' || this.tournamentStatus == 'C' || this.tournamentStatus == 'N') && dateDiff == 1) {
              this.editButton = "none";
            }
            else {
              this.editButton = "block";
            }
          }
          else {
            var dateDiff = 0;
            if (this.tournamentStatus == 'Y' || this.tournamentStatus == 'N') {
              this.editButton = "block";
            }
            if (this.tournamentStatus == 'C') {
              this.editButton = "none";
            }
          }
        } else {
          this.GridMessage = "No Records Found";
        }
        this.spinnerService.hide();
        this.getAssignedCarts();
      },
      err => {
        this.spinnerService.hide(); this.GridMessage = "No Records Found";
      }
    );
  }

  getAssignedCarts() {
    this.assignedPlayerCarts = [];
    let parameters = { "tournamentid": this.tournamentId, "clubid": this.clubId, "courseid": this.courseHolesId, "scorecardgroupid": 0 };
    this.api.postOH('gettournamentscheduledetails', parameters).subscribe(
      (response) => {
        this.assignedPlayerCarts = [];
        this.spinnerService.show();
        if (response.length > 0) {
          response.map(ob => {
            const index = this.assignedPlayerCarts.findIndex(a => a.scoregroupid === ob.scoregroupid && a.cartid === ob.cartid && a.cartname === ob.cartname);
            if (index === -1) {
              this.assignedPlayerCarts.push({
                scheduleid1: ob.id,
                rider1: ob.username,
                cartid: ob.cartid,
                cartname: ob.cartname,
                holeId: ob.holeid,
                holename: ob.holename,
                scoregroupid: ob.scoregroupid,
                userid1: ob.userid
              });
            }
            else {
              Object.assign(this.assignedPlayerCarts[index], { rider2: ob.username });
              Object.assign(this.assignedPlayerCarts[index], { userid2: ob.userid });
              Object.assign(this.assignedPlayerCarts[index], { scheduleid2: ob.id });
            }
          });
          this.spinnerService.hide();
        }
        else {
          this.spinnerService.hide(); this.assignedPlayerCarts = [];
        }
      },
      err => {
        this.spinnerService.hide(); this.assignedPlayerCarts = [];
      });
  }

  //back to view
  goBack() {
    this.searchInfo = "block"; this.gridInfo = "block"; this.viewInfo = "none";
    let parameters = { searchvalue: " where T_GCB_ID='" + this.clubId + "' and T_GC_ID='" + this.courseHolesId + "' and T_STATUS='Y' " };
    this.getTournaments(parameters); this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
  }

  getCourseDetails() {
    this.courseDetails = [];
    let parameters = { searchvalue: " WHERE GC_GCB_ID='" + this.clubId + "' AND GC_STATUS='Y'" };
    this.api.postOH('getgolfcourse', parameters).subscribe(
      (response) => {
        if (response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            this.courseDetails.push({
              value: response[i].id,
              name: response[i].labelname
            });
          }
        }
        if (this.courseDetails.length == 1) {
          this.courseId = this.courseDetails[0].value;
          this.courseName = this.courseDetails[0].name;
        }
        else {
          this.courseId = "0"; this.courseName = "";
        }
      });
  }

  getCartDetails() {
    this.cartDetails = [];
    let parameters = { "clubid": this.clubId, "tournamentid": this.tournamentId, "scorecardgroupid": 0 };
    this.api.postOH('gettournamentreadycarts', parameters).subscribe(
      (response) => {
        if (response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            this.cartDetails.push({
              value: response[i].id,
              name: response[i].name
            });
          }
        }
        this.cartId = 0;
      });
  }

  getHoles() {
    this.HolesInfo = [];
    let parameters = { searchvalue: " WHERE HD_GCB_ID=" + this.clubId + " AND HD_GC_ID = " + this.courseHolesId + " and HD_STATUS='Y' " };
    this.api.postOH('getholes', parameters).subscribe(
      response => {
        if (response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            this.HolesInfo.push({
              "id": response[i].sequence,
              "holename": response[i].holename
            });
          }
        }
        this.holeId = 0;
      },
      err => {

      }
    );
  }

  getTournamentDateDifference(startDate, endDate) {
    this.totalTournamentDuration = "";
    let diffInMs: number = Date.parse(endDate) - Date.parse(startDate);

    var day, hour, minute, seconds;
    seconds = Math.floor(diffInMs / 1000);
    minute = Math.floor(seconds / 60);
    seconds = seconds % 60;
    hour = Math.floor(minute / 60);
    minute = minute % 60;
    this.totalTournamentDuration = hour + 'hours' + " " + minute + 'mins';
  }

  //save tournament
  nextTournament() {
    // let msg: any = ""; var cDate = moment(new Date()).format('MM/DD/YYYY');
    let msg: any = ""; var cDate = moment(this.currentGolfClubDateTime).format('MM/DD/YYYY');
    let startdate = moment(this.tournamentStartDate).format('MM/DD/YYYY');
    let starttime = moment(this.tournamentStartTime).format('hh:mm A');
    let enddate = moment(this.tournamentEndDate).format('MM/DD/YYYY');
    let endtime = moment(this.tournamentEndTime).format('hh:mm A');

    let presentStartDate = new Date(startdate + ' ' + starttime);
    let presentEndDate = new Date(enddate + ' ' + endtime);
    this.getTournamentDateDifference(presentStartDate, presentEndDate);
    var device = this.totalTournamentDuration.toLowerCase();
    if (!this.tournamentSetUpForm.valid) {

    }
    this.submitAttempt = true;
    if (device.indexOf('-') >= 0) {
      var dateDiff = 0;
    }
    else {
      if (this.totalTournamentDuration == '0hours 0mins') {
        var dateDiff = 0;
      }
      else {
        var dateDiff = 1;
      }
    }
    if ((this.action == 'U' && this.tournamentStatus == 'Y') ? (moment(startdate).isSameOrAfter(cDate) || moment(startdate).isSameOrBefore(cDate)) : moment(startdate).isSameOrAfter(cDate)) {
      if (dateDiff > 0) {
        this.errorDate = "";
        if (this.tournamentSetUpForm.valid) {
          if (this.courseId > 0) {
            this.subBtn = true;
            var tournamentSetUpModal = {
              "action": this.action, "id": this.tournamentId, "clubid": this.clubId, "courseid": this.courseId,
              "tournamentname": this.tournamentName, "tournamentdate": startdate,
              "tournamentstarttime": starttime, "tournamentenddate": enddate,
              "tournamentendtime": endtime, "noofrounds": 0,
              "roundslength": parseInt(this.roundsLength), "userid": this.userId, "status": this.status
            }
            this.spinnerService.show();
            this.api.postOH('savetournamentinfo', tournamentSetUpModal).subscribe(
              response => {
                if (response.length > 0 && response[0] > 0) {
                  if (this.action == 'A') {
                    this.tournamentId = response[0];
                  }
                  this.getCartDetails();
                  this.getPlayerCartsList();
                  this.getHoles();
                  this.playerCartsInfo = "block"; this.tournamentInfo = "none";
                } else {
                  this.tournamentId = 0;
                  let message = '<span style="color: red">' + response[1] + '</span>';
                  this.toastMessage(message);
                }
                window.scrollTo(0, 0);
                this.spinnerService.hide();
                this.subBtn = false;
              },
              err => {
                this.spinnerService.hide();
                this.subBtn = false; this.tournamentId = 0;
                let msg = '<span style="color: red">Falied to save data, please try again</span>';
                this.toastMessage(msg);
              }
            );
          }
        }
      }
      else {
        this.errorDate = "End date and time should be greater than start date and time";
      }
    }
    else {
      this.errorDate = "Start date should be greater than or equal to today's date";
    }
  }

  //edit Tournament
  editTournament(id) {
    // var cDate = new Date();
    var cDate = this.currentGolfClubDateTime;
    this.addShow = "block"; this.searchInfo = "none"; this.gridInfo = "none"; this.viewInfo = "none";
    this.tournamentInfo = "block"; this.playerCartsInfo = "none"; this.errorDate = "";
    this.spinnerService.show(); this.divheader = "Edit Tournament";
    let parameters = { searchvalue: " where T_GCB_ID='" + this.clubId + "' and T_GC_ID='" + this.courseHolesId + "' and T_ID='" + id + "'" };
    this.api.postOH('gettournaments', parameters).subscribe(
      response => {
        if (response.length > 0) {
          this.action = "U";
          this.tournamentId = response[0].id;
          this.tournamentName = response[0].tournamentname;
          this.tournamentStartDate = new Date(response[0].tournamentdate);
          this.tournamentEndDate = new Date(response[0].tournamentenddate);
          this.tournamentStartTime = new Date(response[0].tournamentdate + ' ' + response[0].tournamentstarttime);
          this.tournamentEndTime = new Date(response[0].tournamentenddate + ' ' + response[0].tournamentendtime);
          this.courseId = response[0].courseid;
          //this.noOfRounds = (response[0].noofrounds).toString();
          this.roundsLength = (response[0].roundslength).toString();
          this.status = response[0].status;
          this.tournamentStatus = response[0].tournamentstatus;
        }
        if (cDate > this.tournamentStartDate) {
          this.minStartDate = this.tournamentStartDate; //this.minEndDate = this.tournamentEndDate;
          // this.minEndDate = new Date();
          this.minEndDate = this.currentGolfClubDateTime;
        }
        if (this.tournamentStatus == 'Y') {
          this.disableDatePicker = true; this.disableTimePicker = true;
          this.tournamentSetUpForm.controls['ftstartdate'].disable();
          this.tournamentSetUpForm.controls['ftstarttime'].disable();
        }
        else {
          this.disableDatePicker = false; this.disableTimePicker = false;
          this.tournamentSetUpForm.controls['ftstartdate'].enable();
          this.tournamentSetUpForm.controls['ftstarttime'].enable();
        }
        window.scrollTo(0, 0);
        this.spinnerService.hide();
      },
      err => {
        this.spinnerService.hide();
      }
    );
  }

  //rider1 search
  searchName(term: string, i: any): void {
    if (term != '' && term.length > 0) {
      this.errorCount = 0; this.nameIndex = 0; this.userDetails = [];
      if (term.length > 2) {
        let parameters = { searchvalue: " where (IZ_U_REGISTRATION_STATUS='Y') AND IZ_U_STATUS='Y' AND ((IZ_U_FIRST_NAME like '%" + term + "%')  OR (IZ_U_LAST_NAME like '%" + term + "%')  OR (IZ_U_FIRST_NAME + ' ' + IZ_U_LAST_NAME like '%" + term + "%'))" };
        this.api.postOH('GetIzonUser', parameters).subscribe(
          (response) => {
            if (response.length > 0) {
              this.autocomplete = "block";
              this.userDetails = [];
              for (let i = 0; i < response.length; i++) {
                this.userDetails.push({
                  id: response[i].id,
                  name: response[i].name,
                  lastname: response[i].lastname,
                  email: response[i].email,
                  mobile: response[i].mobile,
                  livestats: response[i].livestats
                });
              }
              this.nameIndex = i;
            }
            else {
              this.userDetails = []; this.errorCount = 1; this.autocomplete = "none";
              if (this.addPlayerCarts[i].rider1 == this.addPlayerCarts[i].rider2) {
                let msg = '<span style="color: red">Rider names should be different</span>';
                this.toastMessage(msg);
                this.autocomplete = "none"; //this.rider1 = "";
              }
            }
          });
      } else {
        this.userDetails = []; this.errorCount = 1; this.autocomplete = "none";
        if (this.addPlayerCarts[i].rider1 == this.addPlayerCarts[i].rider2) {
          let msg = '<span style="color: red">Rider names should be different</span>';
          this.toastMessage(msg);
          this.autocomplete = "none"; //this.rider1 = "";
        }
      }
    }
    else if (term == "") {
      this.userDetails = []; this.errorCount = 0; this.autocomplete = "none";
      this.nameIndex = 0; this.addPlayerCarts[i].userId1 = 0;
    }
  }

  onselectUser(user: any, nameId: any) {
    this.errorCount = 0;
    if (user.id > 0) {
      if (this.addPlayerCarts[nameId].userId2 == user.id) {
        let msg = '<span style="color: red">Rider names should be different</span>';
        this.toastMessage(msg);
        this.autocomplete = "none";
      }
      else {
        for (let i = 0; i < this.userDetails.length; i++) {
          if (this.userDetails[i].id == user.id) {
            this.addPlayerCarts[nameId].rider1 = this.userDetails[i].name;
            this.addPlayerCarts[nameId].userId1 = this.userDetails[i].id;
            this.addPlayerCarts[nameId].registeredUser1 = "Y";
            this.autocomplete = "none";
          }
        }
      }
    }
  }

  //rider2 search
  searchName1(term: string, i: any): void {
    if (term != '' && term.length > 0) {
      this.errorCount1 = 0; this.nameIndex = 0; this.userDetails1 = [];
      if (term.length > 2) {
        let parameters = { searchvalue: " where (IZ_U_REGISTRATION_STATUS='Y')  AND IZ_U_STATUS='Y'  AND ((IZ_U_FIRST_NAME like '%" + term + "%')  OR (IZ_U_LAST_NAME like '%" + term + "%')  OR (IZ_U_FIRST_NAME + ' ' + IZ_U_LAST_NAME like '%" + term + "%'))" };
        this.api.postOH('GetIzonUser', parameters).subscribe(
          (response) => {
            if (response.length > 0) {
              this.autocomplete1 = "block";
              this.userDetails1 = [];
              for (let i = 0; i < response.length; i++) {
                this.userDetails1.push({
                  id: response[i].id,
                  name: response[i].name,
                  lastname: response[i].lastname,
                  email: response[i].email,
                  mobile: response[i].mobile,
                  livestats: response[i].livestats
                });
              }
              this.nameIndex = i;
            }
            else {
              this.userDetails1 = []; this.errorCount1 = 1; this.autocomplete1 = "none";
              if (this.addPlayerCarts[i].rider1 == this.addPlayerCarts[i].rider2) {
                let msg = '<span style="color: red">Rider names should be different</span>';
                this.toastMessage(msg);
                this.autocomplete = "none"; //this.rider2 = "";
              }
            }
          });
      }
      else {
        this.userDetails1 = []; this.errorCount1 = 1; this.autocomplete1 = "none";
        if (this.addPlayerCarts[i].rider1 == this.addPlayerCarts[i].rider2) {
          let msg = '<span style="color: red">Rider names should be different</span>';
          this.toastMessage(msg);
          this.autocomplete = "none"; //this.rider2 = "";
        }
      }
    }
    else if (term == "") {
      this.userDetails1 = []; this.errorCount1 = 0; this.autocomplete1 = "none";
      this.addPlayerCarts[i].userId2 = 0;
    }
  }

  onselectUser1(user: any, nameId: any) {
    this.errorCount1 = 0;
    if (user.id > 0) {
      if (this.addPlayerCarts[nameId].userId1 == user.id) {
        let msg = '<span style="color: red">Rider names should be different</span>';
        this.toastMessage(msg);
        this.autocomplete1 = "none";
      }
      else {
        for (let i = 0; i < this.userDetails1.length; i++) {
          if (this.userDetails1[i].id == user.id) {
            this.addPlayerCarts[nameId].rider2 = this.userDetails1[i].name;
            this.addPlayerCarts[nameId].userId2 = this.userDetails1[i].id;
            this.addPlayerCarts[nameId].registeredUser2 = "Y";
            this.autocomplete1 = "none";
          }
        }
      }
    }
  }

  //update search names
  //rider1 search
  searchRiderName1(term: string, i: any): void {
    if (term != '' && term.length > 0) {
      this.errorCount = 0; this.nameIndex = 0; this.rideruserDetails = [];
      if (term.length > 2) {
        let parameters = { searchvalue: " where (IZ_U_REGISTRATION_STATUS='Y') AND IZ_U_STATUS='Y' AND ((IZ_U_FIRST_NAME like '%" + term + "%')  OR (IZ_U_LAST_NAME like '%" + term + "%')  OR (IZ_U_FIRST_NAME + ' ' + IZ_U_LAST_NAME like '%" + term + "%'))" };
        this.api.postOH('GetIzonUser', parameters).subscribe(
          (response) => {
            if (response.length > 0) {
              this.riderautocomplete = "block";
              this.rideruserDetails = [];
              for (let i = 0; i < response.length; i++) {
                this.rideruserDetails.push({
                  id: response[i].id,
                  name: response[i].name,
                  lastname: response[i].lastname,
                  email: response[i].email,
                  mobile: response[i].mobile,
                  livestats: response[i].livestats
                });
              }
              this.nameIndex = i;
              if (this.playerCartsList[i].userid1 > 0 && this.playerCartsList[i].registeredUser1 == "N") {
                this.action1 = "A";
              }
              if (this.playerCartsList[i].userid1 > 0 && this.playerCartsList[i].registeredUser1 == "Y") {
                this.action1 = "A";
              }
              if (this.playerCartsList[i].userid1 == 0 && this.playerCartsList[i].registeredUser1 == "N") {
                this.action1 = "A";
              }
            }
            else {
              this.rideruserDetails = []; this.errorCount = 1; this.riderautocomplete = "none";
              if (this.playerCartsList[i].userid1 == 0 && this.playerCartsList[i].registeredUser1 == "N") {
                this.action1 = "A";
              }
              if (this.playerCartsList[i].userid1 > 0 && this.playerCartsList[i].registeredUser1 == "N") {
                this.action1 = "U";
              }
              if (this.playerCartsList[i].userid1 > 0 && this.playerCartsList[i].registeredUser1 == "Y") {
                this.action1 = "A"; this.playerCartsList[i].userid1 = 0;
              }
              if (this.playerCartsList[i].rider1 == this.playerCartsList[i].rider2) {
                let msg = '<span style="color: red">Rider names should be different</span>';
                this.toastMessage(msg);
                this.riderautocomplete = "none";
              }
            }
          });
      }
      else {
        this.rideruserDetails = []; this.errorCount = 1; this.riderautocomplete = "none";
        if (this.playerCartsList[i].userid1 == 0 && this.playerCartsList[i].registeredUser1 == "N") {
          this.action1 = "A";
        }
        if (this.playerCartsList[i].userid1 > 0 && this.playerCartsList[i].registeredUser1 == "N") {
          this.action1 = "U";
        }
        if (this.playerCartsList[i].userid1 > 0 && this.playerCartsList[i].registeredUser1 == "Y") {
          this.action1 = "A"; this.playerCartsList[i].userid1 = 0;
        }
        if (this.playerCartsList[i].rider1 == this.playerCartsList[i].rider2) {
          let msg = '<span style="color: red">Rider names should be different</span>';
          this.toastMessage(msg);
          this.riderautocomplete = "none";
        }
      }
    }
    else if (term == "") {
      this.rideruserDetails = []; this.errorCount = 0; this.riderautocomplete = "none";
      this.nameIndex = 0;
      if (this.playerCartsList[i].userid1 > 0 && (this.playerCartsList[i].registeredUser1 == "N" || this.playerCartsList[i].registeredUser1 == "Y")) {
        this.action1 = "D";
      }
    }
  }

  onselectRider1(user: any, nameId: any) {
    this.errorCount = 0;
    if (user.id > 0) {
      if (this.playerCartsList[nameId].userid2 == user.id) {
        let msg = '<span style="color: red">Rider names should be different</span>';
        this.toastMessage(msg);
        this.riderautocomplete = "none";
      }
      else {
        for (let i = 0; i < this.rideruserDetails.length; i++) {
          if (this.rideruserDetails[i].id == user.id) {
            this.playerCartsList[nameId].rider1 = this.rideruserDetails[i].name;
            this.playerCartsList[nameId].userid1 = this.rideruserDetails[i].id;
            this.playerCartsList[nameId].registeredUser1 = "Y";
            this.riderautocomplete = "none";
          }
        }
      }
    }
  }

  //rider2 search
  searchRiderName2(term: string, i: any): void {
    if (term != '' && term.length > 0) {
      this.errorCount1 = 0; this.nameIndex = 0; this.rideruserDetails1 = [];
      if (term.length > 2) {
        let parameters = { searchvalue: " where (IZ_U_REGISTRATION_STATUS='Y')  AND IZ_U_STATUS='Y'  AND ((IZ_U_FIRST_NAME like '%" + term + "%')  OR (IZ_U_LAST_NAME like '%" + term + "%')  OR (IZ_U_FIRST_NAME + ' ' + IZ_U_LAST_NAME like '%" + term + "%'))" };
        this.api.postOH('GetIzonUser', parameters).subscribe(
          (response) => {
            if (response.length > 0) {
              this.riderautocomplete1 = "block";
              this.rideruserDetails1 = [];
              for (let i = 0; i < response.length; i++) {
                this.rideruserDetails1.push({
                  id: response[i].id,
                  name: response[i].name,
                  lastname: response[i].lastname,
                  email: response[i].email,
                  mobile: response[i].mobile,
                  livestats: response[i].livestats
                });
              }
              this.nameIndex = i;
              if (this.playerCartsList[i].userid2 > 0 && this.playerCartsList[i].registeredUser2 == "N") {
                this.action2 = "A";
              }
              if (this.playerCartsList[i].userid2 > 0 && this.playerCartsList[i].registeredUser2 == "Y") {
                this.action2 = "A";
              }
              if (this.playerCartsList[i].userid2 == 0 && this.playerCartsList[i].registeredUser2 == "N") {
                this.action2 = "A";
              }
            }
            else {
              this.rideruserDetails1 = []; this.errorCount1 = 1; this.riderautocomplete1 = "none";
              if (this.playerCartsList[i].userid2 == 0 && this.playerCartsList[i].registeredUser2 == "N") {
                this.action2 = "A";
              }
              if (this.playerCartsList[i].userid2 > 0 && this.playerCartsList[i].registeredUser2 == "N") {
                this.action2 = "U";
              }
              if (this.playerCartsList[i].userid2 > 0 && this.playerCartsList[i].registeredUser2 == "Y") {
                this.action2 = "A"; this.playerCartsList[i].userid2 = 0;
              }
              if (this.playerCartsList[i].rider1 == this.playerCartsList[i].rider2) {
                let msg = '<span style="color: red">Rider names should be different</span>';
                this.toastMessage(msg);
                this.riderautocomplete = "none";
              }
            }
          });
      }
      else {
        this.rideruserDetails1 = []; this.errorCount1 = 1; this.riderautocomplete1 = "none";
        if (this.playerCartsList[i].userid2 == 0 && this.playerCartsList[i].registeredUser2 == "N") {
          this.action2 = "A";
        }
        if (this.playerCartsList[i].userid2 > 0 && this.playerCartsList[i].registeredUser2 == "N") {
          this.action2 = "U";
        }
        if (this.playerCartsList[i].userid2 > 0 && this.playerCartsList[i].registeredUser2 == "Y") {
          this.action2 = "A"; this.playerCartsList[i].userid2 = 0;
        }
        if (this.playerCartsList[i].rider1 == this.playerCartsList[i].rider2) {
          let msg = '<span style="color: red">Rider names should be different</span>';
          this.toastMessage(msg);
          this.riderautocomplete = "none";
        }
      }
    }
    else if (term == "") {
      this.rideruserDetails1 = []; this.errorCount1 = 0; this.riderautocomplete1 = "none";
      if (this.playerCartsList[i].userid2 > 0 && (this.playerCartsList[i].registeredUser2 == "N" || this.playerCartsList[i].registeredUser2 == "Y")) {
        this.action2 = "D";
      }
    }
  }

  onselectRider2(user: any, nameId: any) {
    this.errorCount1 = 0;
    if (user.id > 0) {
      if (this.playerCartsList[nameId].userid1 == user.id) {
        let msg = '<span style="color: red">Rider names should be different</span>';
        this.toastMessage(msg);
        this.riderautocomplete1 = "none";
      }
      else {
        for (let i = 0; i < this.rideruserDetails1.length; i++) {
          if (this.rideruserDetails1[i].id == user.id) {
            this.playerCartsList[nameId].rider2 = this.rideruserDetails1[i].name;
            this.playerCartsList[nameId].userid2 = this.rideruserDetails1[i].id;
            this.playerCartsList[nameId].registeredUser2 = "Y";
            this.riderautocomplete1 = "none";
          }
        }
      }
    }
  }

  validatePlayerCarts() {
    this.validateCount = 0; this.tempPlayerCarts = [];
    for (var i = 0; i < this.addPlayerCarts.length; i++) {
      if (this.addPlayerCarts[i].rider1 != "" && this.addPlayerCarts[i].rider2 != "" && this.addPlayerCarts[i].cartId > 0 && this.addPlayerCarts[i].holeId > 0) {
        this.validateCount += 1;
      }
      if (this.addPlayerCarts[i].rider1 != "" && this.addPlayerCarts[i].rider2 == "" && this.addPlayerCarts[i].cartId > 0 && this.addPlayerCarts[i].holeId > 0) {
        this.validateCount += 1;
      }
      if (this.addPlayerCarts[i].rider1 == "" && this.addPlayerCarts[i].rider2 != "" && this.addPlayerCarts[i].cartId > 0 && this.addPlayerCarts[i].holeId > 0) {
        this.validateCount += 1;
      }
      if (this.addPlayerCarts[i].rider1 != "" && this.addPlayerCarts[i].rider2 != "" && (this.addPlayerCarts[i].cartId === 0 || this.addPlayerCarts[i].holeId === 0)) {
        this.validateCount = 0;
        break;
      }
      if (this.addPlayerCarts[i].rider1 == "" && this.addPlayerCarts[i].rider2 != "" && (this.addPlayerCarts[i].cartId === 0 || this.addPlayerCarts[i].holeId === 0)) {
        this.validateCount = 0;
        break;
      }
      if (this.addPlayerCarts[i].rider1 != "" && this.addPlayerCarts[i].rider2 == "" && (this.addPlayerCarts[i].cartId === 0 || this.addPlayerCarts[i].holeId === 0)) {
        this.validateCount = 0;
        break;
      }
      if (this.addPlayerCarts[i].rider1 == "" && this.addPlayerCarts[i].rider2 == "" && this.addPlayerCarts[i].cartId > 0 && this.addPlayerCarts[i].holeId > 0) {
        this.validateCount = 0;
        break;
      }
      if (this.addPlayerCarts[i].rider1 == "" && this.addPlayerCarts[i].rider2 == "" && this.addPlayerCarts[i].cartId > 0 && this.addPlayerCarts[i].holeId === 0) {
        this.validateCount = 0;
        break;
      }
      if (this.addPlayerCarts[i].rider1 == "" && this.addPlayerCarts[i].rider2 == "" && this.addPlayerCarts[i].cartId == 0 && this.addPlayerCarts[i].holeId > 0) {
        this.validateCount = 0;
        break;
      }
      // if (this.addPlayerCarts[i].rider1 != "" || this.addPlayerCarts[i].rider2 != "") {
      if ((this.addPlayerCarts[i].rider1 != "" || this.addPlayerCarts[i].rider2 != "") && this.addPlayerCarts[i].cartId > 0 && this.addPlayerCarts[i].holeId > 0) {
        this.tempPlayerCarts.push({
          //"playerId": this.addPlayerCarts[i].playerId,
          "rider1": this.addPlayerCarts[i].rider1,
          "rider2": this.addPlayerCarts[i].rider2,
          "cartId": parseInt(this.addPlayerCarts[i].cartId),
          "holeId": parseInt(this.addPlayerCarts[i].holeId),
          "userId1": this.addPlayerCarts[i].userId1,
          "userId2": this.addPlayerCarts[i].userId2,
          "registeredUser1": this.addPlayerCarts[i].registeredUser1,
          "registeredUser2": this.addPlayerCarts[i].registeredUser2,
          "fromGrid": "N"
        });
      }
    }
    if (this.playerCartsList.length > 0) {
      for (let i = 0; i < this.playerCartsList.length; i++) {
        this.tempPlayerCarts.push({
          // "playerId": this.playerCartsList[i].playerId,
          "rider1": this.playerCartsList[i].rider1,
          "rider2": this.playerCartsList[i].rider2,
          "cartId": parseInt(this.playerCartsList[i].cartid),
          "holeId": parseInt(this.playerCartsList[i].holeId),
          "userId1": this.playerCartsList[i].userid1,
          "userId2": this.playerCartsList[i].userid2,
          "registeredUser1": this.playerCartsList[i].registeredUser1,
          "registeredUser2": this.playerCartsList[i].registeredUser2,
          "fromGrid": "Y"
        });
      }
    }
    if (this.validateCount > 0) {
      this.getDuplicateRider1Ids();
    }
  }

  getDuplicateRider1Ids() {
    this.rider1Count = 0; let tempRider1Ids: any = [];
    let Rider1Ids = [];
    for (let i = 0; i < this.tempPlayerCarts.length; i++) {
      if (this.tempPlayerCarts[i].userId1 > 0) {
        if (tempRider1Ids.indexOf(this.tempPlayerCarts[i].userId1) === -1) {
          tempRider1Ids.push(this.tempPlayerCarts[i].userId1);
        }
        else {
          Rider1Ids.push({ "UserId1": this.tempPlayerCarts[i].userId1 });
        }
      }
    }
    this.rider1Count = Rider1Ids.length;
    this.getDuplicateRider2Ids();
  }

  getDuplicateRider2Ids() {
    this.rider2Count = 0; let tempRider2Ids: any = []; let Rider2Ids = [];
    for (let i = 0; i < this.tempPlayerCarts.length; i++) {
      if (this.tempPlayerCarts[i].userId2 > 0) {
        if (tempRider2Ids.indexOf(this.tempPlayerCarts[i].userId2) === -1) {
          tempRider2Ids.push(this.tempPlayerCarts[i].userId2);
        }
        else {
          Rider2Ids.push({ "UserId2": this.tempPlayerCarts[i].userId2 });
        }
      }
    }
    this.rider2Count = Rider2Ids.length;
    this.getDuplicateRiderIds();
  }

  getDuplicateRiderIds() {
    this.riderCount = 0; let RiderFirstIds: any = []; let RiderSecondIds: any = []; let RiderIds = [];
    for (let j = 0; j < this.tempPlayerCarts.length; j++) {
      if (this.tempPlayerCarts[j].userId1 > 0) {
        RiderFirstIds.push(
          this.tempPlayerCarts[j].userId1
        );
      }
    }
    for (let j = 0; j < this.tempPlayerCarts.length; j++) {
      if (this.tempPlayerCarts[j].userId2 > 0) {
        RiderSecondIds.push(
          this.tempPlayerCarts[j].userId2
        );
      }
    }
    for (let i = 0; i < RiderFirstIds.length; i++) {
      const index = RiderSecondIds.indexOf(RiderFirstIds[i]);
      if (index != -1) {
        this.riderCount += 1;
      }
    }
    this.getDuplicateCartIds();
  }

  getDuplicateCartIds() {
    this.cartIdCount = 0; let tempCartIds: any = []; let cartIds = [];
    for (let i = 0; i < this.tempPlayerCarts.length; i++) {
      if (this.tempPlayerCarts[i].cartId > 0) {
        if (tempCartIds.indexOf(this.tempPlayerCarts[i].cartId) === -1) {
          tempCartIds.push(this.tempPlayerCarts[i].cartId);
        }
        else {
          cartIds.push({ "cartId": this.tempPlayerCarts[i].cartId });
        }
      }
    }
    this.cartIdCount = cartIds.length;
  }

  savePlayerCart() {
    this.validatePlayerCarts();
    if (this.validateCount > 0) {
      if (this.rider1Count === 0 && this.rider2Count === 0 && this.riderCount === 0) {
        if (this.cartIdCount === 0) {
          this.playerSubBtn = true;
          let playerCartArary: any = [];
          for (let i = 0; i < this.tempPlayerCarts.length; i++) {
            if (this.tempPlayerCarts[i].rider1 != "" && this.tempPlayerCarts[i].rider2 != "" && this.tempPlayerCarts[i].cartId > 0 && this.tempPlayerCarts[i].holeId > 0 && this.tempPlayerCarts[i].fromGrid == "N") {
              playerCartArary.push(
                {
                  "action": "A", "scheduleid": 0, "userid": this.tempPlayerCarts[i].userId1, "clubid": this.clubId,
                  "courseid": this.courseHolesId, "cartid": this.tempPlayerCarts[i].cartId,
                  "holeid": this.tempPlayerCarts[i].holeId, "tournamentid": this.tournamentId,
                  "frontnine": "Y", "username": this.tempPlayerCarts[i].rider1, "golferposition": 1,
                  "scoregroupid": 0, "type": "T", "status": "Y", "isregistereduser": this.tempPlayerCarts[i].registeredUser1
                },
                {
                  "action": "A", "scheduleid": 0, "userid": this.tempPlayerCarts[i].userId2, "clubid": this.clubId,
                  "courseid": this.courseHolesId, "cartid": this.tempPlayerCarts[i].cartId,
                  "holeid": this.tempPlayerCarts[i].holeId, "tournamentid": this.tournamentId,
                  "frontnine": "Y", "username": this.tempPlayerCarts[i].rider2, "golferposition": 2,
                  "scoregroupid": 0, "type": "T", "status": "Y", "isregistereduser": this.tempPlayerCarts[i].registeredUser2
                }
              );
            }
            if (this.tempPlayerCarts[i].rider1 != "" && this.tempPlayerCarts[i].rider2 == "" && this.tempPlayerCarts[i].cartId > 0 && this.tempPlayerCarts[i].holeId > 0 && this.tempPlayerCarts[i].fromGrid == "N") {
              playerCartArary.push(
                {
                  "action": "A", "scheduleid": 0, "userid": this.tempPlayerCarts[i].userId1, "clubid": this.clubId,
                  "courseid": this.courseHolesId, "cartid": this.tempPlayerCarts[i].cartId,
                  "holeid": this.tempPlayerCarts[i].holeId, "tournamentid": this.tournamentId,
                  "frontnine": "Y", "username": this.tempPlayerCarts[i].rider1, "golferposition": 1,
                  "scoregroupid": 0, "type": "T", "status": "Y", "isregistereduser": this.tempPlayerCarts[i].registeredUser1
                }
              );
            }
            if (this.tempPlayerCarts[i].rider1 == "" && this.tempPlayerCarts[i].rider2 != "" && this.tempPlayerCarts[i].cartId > 0 && this.tempPlayerCarts[i].holeId > 0 && this.tempPlayerCarts[i].fromGrid == "N") {
              playerCartArary.push(
                {
                  "action": "A", "scheduleid": 0, "userid": this.tempPlayerCarts[i].userId2, "clubid": this.clubId,
                  "courseid": this.courseHolesId, "cartid": this.tempPlayerCarts[i].cartId,
                  "holeid": this.tempPlayerCarts[i].holeId, "tournamentid": this.tournamentId,
                  "frontnine": "Y", "username": this.tempPlayerCarts[i].rider2, "golferposition": 2,
                  "scoregroupid": 0, "type": "T", "status": "Y", "isregistereduser": this.tempPlayerCarts[i].registeredUser2
                }
              );
            }
          }
          var model = { "tournamentdetails": playerCartArary };
          this.spinnerService.show();
          this.api.postOH('SaveTournamentdetailschedule', model).subscribe(
            response => {
              if (response.SaveTournamentdetailscheduleResult.length > 0 && response.SaveTournamentdetailscheduleResult[0] > 0) {
                // let msg = '<span style="color: green">Player carts assigned successfully</span>';
                let msg = '<span style="color: green">' + response.SaveTournamentdetailscheduleResult[1] + '</span>';
                this.toastMessage(msg);
                this.getCartDetails();
                this.getPlayerCartsList();
                this.cartSubmitAttempt = false;
                this.holeId = '0';
              } else {
                let msg = '<span style="color: red">' + response.SaveTournamentdetailscheduleResult[1] + '</span>';
                this.toastMessage(msg);
              }
              window.scrollTo(0, 0);
              this.spinnerService.hide();
              this.playerSubBtn = false;
            },
            err => {
              this.spinnerService.hide();
              this.playerSubBtn = false;
            }
          );
        }
        else {
          let msg = '<span style="color: red">Carts assigned to the riders should be different</span>';
          this.toastMessage(msg);
        }
      }
      else {
        let msg = '<span style="color: red">Registered Rider names should be different</span>';
        this.toastMessage(msg);
      }
    }
    else {
      let msg = '<span style="color: red">Please add riders, cart and hole to the tournament</span>';
      this.toastMessage(msg);
    }
  }

  getPlayerCartsList() {
    this.playerCartsList = [];
    let parameters = { "tournamentid": this.tournamentId, "clubid": this.clubId, "courseid": this.courseHolesId, "scorecardgroupid": 0 };
    this.api.postOH('gettournamentscheduledetails', parameters).subscribe(
      (response) => {
        this.playerCartsList = [];
        if (response.length > 0) {
          response.map(ob => {
            const index = this.playerCartsList.findIndex(a => a.scoregroupid === ob.scoregroupid && a.cartid === ob.cartid && a.cartname === ob.cartname);
            if (index === -1) {
              this.playerCartsList.push({
                scheduleid1: ob.id,
                rider1: ob.username,
                cartid: ob.cartid,
                cartname: ob.cartname,
                holeId: ob.holeid,
                holename: ob.holename,
                gameStatus: ob.gamestatus,
                scoregroupid: ob.scoregroupid,
                userid1: ob.userid,
                registeredUser1: ob.isregistereduser,
                golferposition1: ob.golferposition,
                displayClass: "block",
                displayTxtClass: "none",
                displayEditBtn: "block",
                displayDeleteBtn: "block",
                displayUpdateBtn: "none"
              });
            }
            else {
              Object.assign(this.playerCartsList[index], { rider2: ob.username });
              Object.assign(this.playerCartsList[index], { userid2: ob.userid });
              Object.assign(this.playerCartsList[index], { scheduleid2: ob.id });
              Object.assign(this.playerCartsList[index], { registeredUser2: ob.isregistereduser });
              Object.assign(this.playerCartsList[index], { golferposition2: ob.golferposition2 });
            }
          });
          window.scrollTo(0, 0);
          this.totalRecords = this.playerCartsList.length;
          this.gridPlayerInfo = "block"; this.addPlayerInfo = "none";
          this.showSubmitBtn = "none"; this.showFinishBtn = "block";
          this.addPlayerCartBtn = "none"; this.gridPlayerCartBtn = "Block";
          for (let i = 0; i < this.addPlayerCarts.length; i++) {
            this.playerCartsForm.removeControl('frider1' + i);
            this.playerCartsForm.removeControl('frider2' + i);
            this.playerCartsForm.removeControl('fcartId' + i);
            this.playerCartsForm.removeControl('fholeId' + i);
          }
          this.addPlayerCarts = []; this.riderautocomplete = "none"; this.riderautocomplete1 = "none";
          for (let i = 0; i < this.playerCartsList.length; i++) {
            if (this.playerCartsList[i].rider2 === undefined && this.playerCartsList[i].userid2 === undefined && this.playerCartsList[i].scheduleid2 === undefined) {
              Object.assign(this.playerCartsList[i], { rider2: "" });
              Object.assign(this.playerCartsList[i], { userid2: 0 });
              Object.assign(this.playerCartsList[i], { scheduleid2: 0 });
              Object.assign(this.playerCartsList[i], { registeredUser2: "N" });
            }
          }
        }
        else {
          this.playerCartsList = []; this.totalRecords = 0;
          this.gridPlayerInfo = "none"; this.addPlayerInfo = "block";
          this.showSubmitBtn = "block"; this.showFinishBtn = "none";
          this.addPlayerCartBtn = "block"; this.gridPlayerCartBtn = "none";
          for (let i = 0; i < this.addPlayerCarts.length; i++) {
            this.playerCartsForm.removeControl('frider1' + i);
            this.playerCartsForm.removeControl('frider2' + i);
            this.playerCartsForm.removeControl('fcartId' + i);
            this.playerCartsForm.removeControl('fholeId' + i);
          }
          this.addPlayerCarts = [];
          this.getAddPlayerCartsList();
        }
      },
      err => {
        this.playerCartsList = [];
      });
  }

  cancelPlayerCarts() {
    this.gridPlayerInfo = "none"; this.addPlayerInfo = "none";
    this.playerCartsInfo = "none"; this.tournamentInfo = "block";
    this.action = "U";
  }

  cancelCarts(i) {
    this.playerCartsList[i].displayClass = "block";
    this.playerCartsList[i].displayTxtClass = "none";
    this.playerCartsList[i].displayEditBtn = "block";
    this.playerCartsList[i].displayDeleteBtn = "block";
    this.playerCartsList[i].displayUpdateBtn = "none";
  }

  editPlayerCart(i, scoregroupid) {
    this.cartDetails = [];
    let parameters = { "clubid": this.clubId, "tournamentid": this.tournamentId, "scorecardgroupid": scoregroupid };
    this.api.postOH('gettournamentreadycarts', parameters).subscribe(
      (response) => {
        if (response.length > 0) {
          for (let i = 0; i < response.length; i++) {
            this.cartDetails.push({
              value: response[i].id,
              name: response[i].name
            });
          }
        }
        this.cartId = 0;
        this.playerCartsList[i].displayClass = "none";
        this.playerCartsList[i].displayTxtClass = "block";
        this.playerCartsList[i].displayEditBtn = "none";
        this.playerCartsList[i].displayDeleteBtn = "none";
        this.playerCartsList[i].displayUpdateBtn = "block";
        this.getHoles();
        this.closeLastOpenedInfoWindow(scoregroupid);
        this.action1 = "U"; this.action2 = "U";
      });
  }

  closeLastOpenedInfoWindow(scoregroupid) {
    for (let i = 0; i < this.playerCartsList.length; i++) {
      if (this.playerCartsList[i].scoregroupid != scoregroupid) {
        this.playerCartsList[i].displayClass = "block";
        this.playerCartsList[i].displayTxtClass = "none";
        this.playerCartsList[i].displayEditBtn = "block";
        this.playerCartsList[i].displayDeleteBtn = "block";
        this.playerCartsList[i].displayUpdateBtn = "none";
      }
    }
  }

  updatePlayerCarts(i) {
    this.tempPlayerCarts = [];
    for (let i = 0; i < this.playerCartsList.length; i++) {
      this.tempPlayerCarts.push({
        "rider1": this.playerCartsList[i].rider1,
        "rider2": this.playerCartsList[i].rider2,
        "cartId": parseInt(this.playerCartsList[i].cartid),
        "holeId": parseInt(this.playerCartsList[i].holeId),
        "userId1": this.playerCartsList[i].userid1,
        "userId2": this.playerCartsList[i].userid2,
        "registeredUser1": this.playerCartsList[i].registeredUser1,
        "registeredUser2": this.playerCartsList[i].registeredUser2,
        "fromGrid": "Y"
      });
    }
    this.getDuplicateRider1Ids();
    if (this.rider1Count === 0 && this.rider2Count === 0 && this.riderCount === 0) {
      if (this.cartIdCount === 0) {
        if ((this.playerCartsList[i].rider1 != "" && this.playerCartsList[i].rider2 == "") || (this.playerCartsList[i].rider1 == "" && this.playerCartsList[i].rider2 != "") || (this.playerCartsList[i].rider1 != "" && this.playerCartsList[i].rider2 != "")) {
          let updatedRecords = [];
          if (this.playerCartsList[i].rider1 != "" && this.playerCartsList[i].rider2 == "" && this.playerCartsList[i].scheduleid1 > 0 && this.playerCartsList[i].scheduleid2 == 0) {
            updatedRecords.push(
              {
                "action": this.action1, "scheduleid": this.playerCartsList[i].scheduleid1, "userid": this.playerCartsList[i].userid1, "clubid": this.clubId,
                "courseid": this.courseHolesId, "cartid": this.playerCartsList[i].cartid,
                "holeid": this.playerCartsList[i].holeId, "tournamentid": this.tournamentId,
                "frontnine": "Y", "username": this.playerCartsList[i].rider1, "type": "T", "status": "Y",
                "golferposition": 1, "scoregroupid": this.playerCartsList[i].scoregroupid,
                "isregistereduser": this.playerCartsList[i].registeredUser1
              }
            );
          }
          else if (this.playerCartsList[i].rider2 != "" && this.playerCartsList[i].rider1 == "" && this.playerCartsList[i].scheduleid2 > 0 && this.playerCartsList[i].scheduleid2 == 0) {
            updatedRecords.push(
              {
                "action": this.action2, "scheduleid": this.playerCartsList[i].scheduleid2, "userid": this.playerCartsList[i].userid2, "clubid": this.clubId,
                "courseid": this.courseHolesId, "cartid": this.playerCartsList[i].cartid,
                "holeid": this.playerCartsList[i].holeId, "tournamentid": this.tournamentId,
                "frontnine": "Y", "username": this.playerCartsList[i].rider2, "type": "T", "status": "Y",
                "golferposition": 2, "scoregroupid": this.playerCartsList[i].scoregroupid,
                "isregistereduser": this.playerCartsList[i].registeredUser2
              }
            );
          }
          else {
            updatedRecords.push(
              {
                "action": this.action1, "scheduleid": this.playerCartsList[i].scheduleid1, "userid": this.playerCartsList[i].userid1, "clubid": this.clubId,
                "courseid": this.courseHolesId, "cartid": this.playerCartsList[i].cartid,
                "holeid": this.playerCartsList[i].holeId, "tournamentid": this.tournamentId,
                "frontnine": "Y", "username": this.playerCartsList[i].rider1, "type": "T", "status": "Y",
                "golferposition": 1, "scoregroupid": this.playerCartsList[i].scoregroupid,
                "isregistereduser": this.playerCartsList[i].registeredUser1
              },
              {
                "action": this.action2, "scheduleid": this.playerCartsList[i].scheduleid2, "userid": this.playerCartsList[i].userid2, "clubid": this.clubId,
                "courseid": this.courseHolesId, "cartid": this.playerCartsList[i].cartid,
                "holeid": this.playerCartsList[i].holeId, "tournamentid": this.tournamentId,
                "frontnine": "Y", "username": this.playerCartsList[i].rider2, "type": "T", "status": "Y",
                "golferposition": 2, "scoregroupid": this.playerCartsList[i].scoregroupid,
                "isregistereduser": this.playerCartsList[i].registeredUser2
              }
            );
          }
          var model = { "tournamentdetails": updatedRecords };
          this.spinnerService.show();
          this.api.postOH('SaveTournamentdetailschedule', model).subscribe(
            response => {
              if (response.SaveTournamentdetailscheduleResult.length > 0 && (response.SaveTournamentdetailscheduleResult[0] == 0 || response.SaveTournamentdetailscheduleResult[0] > 0)) {
                this.playerCartsList[i].displayClass = "block";
                this.playerCartsList[i].displayTxtClass = "none";
                this.playerCartsList[i].displayEditBtn = "block";
                this.playerCartsList[i].displayDeleteBtn = "block";
                this.playerCartsList[i].displayUpdateBtn = "none";
                let msg = '<span style="color: green">Player cart details updated successfully</span>';
                this.toastMessage(msg);
                this.getPlayerCartsList();
                this.getCartDetails();
              } else {
              }
              window.scrollTo(0, 0);
              this.spinnerService.hide();
            },
            err => {
              this.spinnerService.hide();
            }
          );
        }
        else {
          let msg = '<span style="color: red">Please enter rider names</span>';
          this.toastMessage(msg);
        }
      }
      else {
        let msg = '<span style="color: red">Carts assigned to the riders should be different</span>';
        this.toastMessage(msg);
      }
    }
    else {
      let msg = '<span style="color: red">Registered Rider names should be different</span>';
      this.toastMessage(msg);
    }
  }


  //delete
  openModal1(template1: TemplateRef<any>, i) {
    this.deletedArray = [];
    this.modalRef = this.modalService.show(template1, { class: 'modal-sm' });
    this.deletedArray = this.playerCartsList[i];
  }

  confirm1(): void {
    this.modalRef.hide();
    var playerCartsModal = [
      {
        "action": "D", "scheduleid": this.deletedArray.scheduleid1, "userid": this.deletedArray.userid1, "clubid": this.clubId,
        "courseid": this.courseHolesId, "cartid": this.deletedArray.cartid,
        "holeid": this.deletedArray.holeId, "tournamentid": this.tournamentId,
        "frontnine": "Y", "username": this.deletedArray.rider1, "type": "T",
        "status": "Y", "golferposition": 1, "scoregroupid": this.deletedArray.scoregroupid,
        "isregistereduser": this.deletedArray.registeredUser1
      },
      {
        "action": "D", "scheduleid": this.deletedArray.scheduleid2, "userid": this.deletedArray.userid2, "clubid": this.clubId,
        "courseid": this.courseHolesId, "cartid": this.deletedArray.cartid,
        "holeid": this.deletedArray.holeId, "tournamentid": this.tournamentId,
        "frontnine": "Y", "username": this.deletedArray.rider2, "type": "T",
        "status": "Y", "golferposition": 2, "scoregroupid": this.deletedArray.scoregroupid,
        "isregistereduser": this.deletedArray.registeredUser2
      }
    ]
    let msg = '<span style="color: green">Player carts details deleted successfully</span>';
    this.DEapicall1(playerCartsModal, msg);
  }

  DEapicall1(playerCartsModal, msg) {
    var model = { "tournamentdetails": playerCartsModal };
    this.api.postOH('SaveTournamentdetailschedule', model).subscribe(
      (response) => {
        this.getPlayerCartsList();
        this.getCartDetails();
        this.toastMessage(msg);
      }, error => {
        let msg = '<span style="color: red">Failed to update the data, please try again</span>';
        this.toastMessage(msg);
      });
  }

  decline1(): void {
    this.modalRef.hide();
  }

  cancelTournament() {
    this.addShow = "block"; this.searchInfo = "block"; this.gridInfo = "block"; this.viewInfo = "none";
    this.tournamentInfo = "none"; this.playerCartsInfo = "none"; this.action = "A";
    this.submitAttempt = false;
    this.tournamentSetUpForm.controls['ftname'].reset();
    this.cartSubmitAttempt = false;
    for (let i = 0; i < this.addPlayerCarts.length; i++) {
      this.playerCartsForm.removeControl('frider1' + i);
      this.playerCartsForm.removeControl('frider2' + i);
      this.playerCartsForm.removeControl('fcartId' + i);
      this.playerCartsForm.removeControl('fholeId' + i);
    }
    this.addPlayerCarts = [];
    this.getAddPlayerCartsList();
    let parameters = { searchvalue: " where T_GCB_ID='" + this.clubId + "' and T_GC_ID='" + this.courseHolesId + "' and T_STATUS='Y'" };
    this.getTournaments(parameters); this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
  }


  FinishTournament() {
    this.addShow = "block"; this.searchInfo = "block"; this.gridInfo = "block"; this.viewInfo = "none";
    this.tournamentInfo = "none"; this.playerCartsInfo = "none"; this.action = "A";
    this.submitAttempt = false;
    this.tournamentSetUpForm.controls['ftname'].reset();
    this.cartSubmitAttempt = false;
    for (let i = 0; i < this.addPlayerCarts.length; i++) {
      this.playerCartsForm.removeControl('frider1' + i);
      this.playerCartsForm.removeControl('frider2' + i);
      this.playerCartsForm.removeControl('fcartId' + i);
      this.playerCartsForm.removeControl('fholeId' + i);
    }
    this.addPlayerCarts = [];
    this.getAddPlayerCartsList();
    let parameters = { searchvalue: " where T_GCB_ID='" + this.clubId + "' and T_GC_ID='" + this.courseHolesId + "' and T_STATUS='Y'" };
    this.getTournaments(parameters); this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
    let msg = '<span style="color: green">Tournament set up finished successfully</span>';
    this.toastMessage(msg);
  }

  toastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',
    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 3000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }

  tournamentToastMessage(msg) {
    let options = {
      positionClass: 'toast-top-center',
    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 4000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }

  //delete
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, { class: 'modal-sm' });
  }

  confirm(): void {
    this.modalRef.hide();
    var tournamentModal = {
      "action": "D", "id": this.tournamentId, "clubid": this.clubId, "courseid": this.courseId,
      "tournamentname": "", "tournamentdate": "", "tournamentstarttime": "", "tournamentenddate": "",
      "tournamentendtime": "", "noofrounds": 0, "roundslength": 0,
      "userid": this.userId, "status": "D"
    }
    let msg = '<span style="color: green">Tournament deleted successfully</span>';
    this.DEapicall(tournamentModal, msg);
  }

  //enable
  enableMessage(id: any, measurement: any): void {
    var tournamentModal = {
      "action": "E", "id": this.tournamentId, "clubid": this.clubId, "courseid": this.courseId,
      "tournamentname": "", "tournamentdate": "", "tournamentstarttime": "", "tournamentenddate": "",
      "tournamentendtime": "", "noofrounds": 0, "roundslength": 0,
      "userid": this.userId, "status": "Y"
    }
    let msg = '<span style="color: green">Tournament enabled successfully</span>';
    this.DEapicall(tournamentModal, msg);
  }

  DEapicall(tournamentModal, msg) {
    this.api.postOH('savetournamentinfo', tournamentModal).subscribe(
      (response) => {
        let parameters = { searchvalue: " where T_GCB_ID='" + this.clubId + "' and T_GC_ID='" + this.courseHolesId + "' and T_STATUS='Y'" };
        this.getTournaments(parameters);
        this.action = 'A';
        this.selectedoption = "Active"; this.randomcolor = "#5cb85c";
        this.searchInfo = "block"; this.gridInfo = "block"; this.addShow = "none"; this.viewInfo = "none";
        this.toastMessage(msg);
      }, error => {
        let msg = '<span style="color: red">Failed to update the data, please try again</span>';
        this.toastMessage(msg);
      });
  }

  decline(): void {
    this.modalRef.hide();
  }

  //leaderboard
  getLeaderboard(id, name) {
    localStorage.setItem('tournamentId', id);
    localStorage.setItem('tournamentName', name);
    this.router.navigate(['/tournaments/leaderboard']);
  }
  startTournament(tournament) {
    // this.currentDate = moment(new Date()).format('MM/DD/YYYY');
    let tStartDateTime: any = ""; let tEndDateTime: any = "";
    this.currentDate = moment(this.currentGolfClubDateTime).format('MM/DD/YYYY hh:mm A');
    tStartDateTime = moment(new Date(tournament.tournamentStartDate + ' ' + tournament.tournamentStartTime)).format('MM/DD/YYYY hh:mm A');
    tEndDateTime = moment(new Date(tournament.tournamentEndDate + ' ' + tournament.tournamentEndTime)).format('MM/DD/YYYY hh:mm A');
    if ((moment(this.currentDate).isSameOrAfter(tStartDateTime) && moment(this.currentDate).isSameOrBefore(tEndDateTime))) {
      let parameters = { "tournamentid": tournament.id, "clubid": this.clubId, "courseid": this.courseHolesId, "scorecardgroupid": 0 };
      this.api.postOH('gettournamentscheduledetails', parameters).subscribe(
        (response) => {
          if (response.length > 0) {
            this.spinnerService.show();
            let params = { "clubid": this.clubId, "courseid": this.courseHolesId, "tournamentid": tournament.id }
            this.api.postOH('createtournamentscorecardinfo', params).subscribe(
              response => {
                if (response.createtournamentscorecardinfoResult != "") {
                  let msg = '<span style="color: red">The following carts are already used by another golfer for golfing (' + response.createtournamentscorecardinfoResult + '). Please choose another cart to start the tournament </span>';
                  this.toastMessageForTournament(msg);
                  let parameters = { searchvalue: " where T_GCB_ID='" + this.clubId + "' and T_GC_ID='" + this.courseHolesId + "' and T_STATUS='Y'" };
                  this.getTournaments(parameters);
                  this.spinnerService.hide();
                }
                else {
                  let parameters = { searchvalue: " where T_GCB_ID='" + this.clubId + "' and T_GC_ID='" + this.courseHolesId + "' and T_STATUS='Y'" };
                  this.getTournaments(parameters);
                  let msg = '<span style="color: green">Tournament started successfully</span>';
                  this.toastMessage(msg);
                  this.spinnerService.hide();
                }
              },
              err => {
                let msg = '<span style="color: red">Unable to process your request, please try again</span>';
                this.toastMessage(msg);
                this.spinnerService.hide();
              }
            );
          }
          else {
            let msg = '<span style="color: red">Please add carts to start the tournament</span>';
            this.tournamentToastMessage(msg);
          }
        },
        err => {
          this.spinnerService.hide();
        });
    }
    else {
      let msg = '<span style="color: red">Current date time should be equal (or) in between the tournament start date time and end date time to start the tournament based on Golf Club Timezone</span>';
      this.tournamentToastMessagenew(msg);
    }
  }
  tournamentToastMessagenew(msg) {
    let options = {
      positionClass: 'toast-top-center',
    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 7000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }


  toastMessageForTournament(msg) {
    let options = {
      positionClass: 'toast-top-center',
    };

    this.toastr.custom(msg, null, {
      enableHTML: true, toastLife: 5000,
      showCloseButton: true, 'positionClass': 'toast-bottom-right'
    });
  }

  //End Tournament 
  openTournamentModal(template2: TemplateRef<any>, tournament) {
    this.endTournamentModal = [];
    this.modalRef = this.modalService.show(template2, { class: 'modal-sm' });
    this.endTournamentModal = tournament;
  }

  confirmToEndTournament(): void {
    this.modalRef.hide();
    this.endTournament(this.endTournamentModal);
  }

  endTournament(tournament) {
    // let parameters = { "tournamentid": tournament.id, "endtime": new Date() };
    let parameters = { "tournamentid": tournament.id, "endtime": this.currentGolfClubDateTime };
    this.api.postOH('endtournament', parameters).subscribe(
      (response) => {
        if (response == 'Success') {
          let parameters = { searchvalue: " where T_GCB_ID='" + this.clubId + "' and T_GC_ID='" + this.courseHolesId + "' and T_STATUS='Y'" };
          this.getTournaments(parameters);
          let msg = '<span style="color: green">Tournament ended successfully</span>';
          this.toastMessage(msg);
          this.endTournamentModal = [];
        }
        else {
          let msg = '<span style="color: red">Failed to end tournament, please try again</span>';
          this.tournamentToastMessage(msg);
        }
      },
      err => {
        this.endTournamentModal = [];
      });
  }

  decline2(): void {
    this.modalRef.hide();
  }
}
