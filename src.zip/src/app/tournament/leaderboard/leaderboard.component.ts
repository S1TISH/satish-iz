import { Component, OnInit, ViewContainerRef, TemplateRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms/src/directives/ng_form'
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { AuthService } from '../../services/auth.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Title } from '@angular/platform-browser';
import * as moment from "moment";
import { Observable } from 'rxjs/Rx';

@Component({
  selector: 'app-leaderboard',
  templateUrl: './leaderboard.component.html',
  styleUrls: ['./leaderboard.component.css']
})
export class LeaderboardComponent implements OnInit {
  modalRef: BsModalRef;
  clubId: any; courseid: any; userId: any; tournamentId: any; tournamentName: any;
  //holes
  holePardetails: any = [];
  backNinePar: any = 0; frontNinePar: any = 0; totalPar: any = 0;
  holesNumber: any = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18]; sub: any;
  //leaderboard
  leaderBoardInfo: any = [];
  constructor(private title: Title, public toastr: ToastsManager, vcr: ViewContainerRef,
    private router: Router, public formBuilder: FormBuilder,
    private spinnerService: Ng4LoadingSpinnerService,
    private api: ApiService, private authService: AuthService,
    private modalService: BsModalService) {
    this.title.setTitle("IZON - Leaderboard");
    this.clubId = localStorage.getItem('clubId');
    this.courseid = localStorage.getItem('courseId');
    this.userId = localStorage.getItem('userId');
    this.tournamentId = localStorage.getItem('tournamentId');
    this.tournamentName = localStorage.getItem('tournamentName');
    this.toastr.setRootViewContainerRef(vcr);
  }

  ngOnInit() {
    this.getLeaderBoardInfo();
    this.GetScoreCardHandicapsPars();
    this.sub = Observable.interval(1000 * 60).subscribe(x => {
      this.getLeaderBoardInfo();
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  goBack() {
    localStorage.removeItem('tournamentId');
    localStorage.removeItem('tournamentName');
    this.router.navigate(['/tournaments/tournament']);    
  }

  //total par values
  GetScoreCardHandicapsPars() {
    let parameters = { "CourseID": localStorage.getItem('courseId') };
    this.api.postOH('GetScoreCardHandicapsPars', parameters).subscribe(
      (response) => {
        this.holePardetails = [];
        if (response.ScoreCardHandicapParvaluesResult[0].Response == "Success") {
          let hpdetails = response.ScoreCardHandicapParvaluesResult[0];
          if (hpdetails && hpdetails.HandicapsandParValues && hpdetails.HandicapsandParValues.length > 0) {
            this.holePardetails = hpdetails.HandicapsandParValues;
            //Total Par values
            this.frontNinePar = hpdetails.HandicapTotals[0].FrontNineTotal;
            this.backNinePar = hpdetails.HandicapTotals[0].BackNineTotal;
            this.totalPar = hpdetails.HandicapTotals[0].Total;
          }
        }
      });
  }

  refreshScore() {
    this.getLeaderBoardInfo();
  }

  // leaderboardInfo
  getLeaderBoardInfo() {
    this.leaderBoardInfo = [];
    var parameters = { "tournamentid": this.tournamentId, "courseid": this.courseid };
    this.spinnerService.show();
    // TournamentLeaderBoardScoreDetails
    this.api.postOH('TournamentLeaderBoardScoreinfo', parameters).subscribe(
      response => {
        if (response.length > 0) {
          this.leaderBoardInfo = response;
          // static 18 holes data
          const holesInfo = [];
          for (let h = 1; h < 19; h++) {
            let nh = 1;
            nh = h; nh++;
            holesInfo.push({
              "CourseId": '-',
              "Fairway": "-",
              "GreenReg": "-",
              "HoleID": '-',
              "HoleSeq": h,
              "Par": '-',
              "PlayerId": '-',
              "PlayerPosition": '-',
              "Putts": '-',
              "Score": 0,
              "ScoreCardId": '-',
              "Shots": '-',
            });
          }
          // 18 holes data merging
          for (let j = 0; j < this.leaderBoardInfo.length; j++) {
            this.leaderBoardInfo[j].HSDetails = holesInfo.map(obj => this.leaderBoardInfo[j].HSDetails.find(o => o.HoleSeq === obj.HoleSeq) || obj);
          }
          window.scrollTo(0, 0);
          this.spinnerService.hide();
        }
        else {
          this.leaderBoardInfo = [];
          this.spinnerService.hide();
        }
      },
      err => {
        this.leaderBoardInfo = [];
        this.spinnerService.hide();
      }
    );
  }
}
