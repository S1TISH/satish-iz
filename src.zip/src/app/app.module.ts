import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { ModalModule } from 'ngx-bootstrap';
import { Cookie } from 'ng2-cookies/ng2-cookies';
import { FullCalendarModule } from 'ng-fullcalendar';
import { PopoverModule } from 'ngx-bootstrap';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { OrderModule } from 'ngx-order-pipe';
import { ColorPickerModule } from 'ngx-color-picker';

import { AuthGaurdService } from './services/auth-gaurd.service';
import { AuthService } from './services/auth.service';
import { JwtService } from './services/jwt.service';
import { ApiService } from './services/api.service';
import { CalendarService } from './services/calendar.service';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { HeaderComponent } from '../app/header/header/header.component';
import { FooterComponent } from '../app/header/footer/footer.component';
import { NotificationsComponent } from '../app/notifications/notifications/notifications.component';
import { CartalertsComponent } from '../app/header/cartalerts/cartalerts.component';

import { SidemenubindComponent } from '../app/header/sidemenubind/sidemenubind.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NotificationsComponent,
    CartalertsComponent,
    SidemenubindComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule, OrderModule,
    FormsModule, ReactiveFormsModule,FullCalendarModule,
    HttpModule, ToastModule.forRoot(),
    ModalModule.forRoot(),    
    PopoverModule.forRoot(),
    OwlDateTimeModule,
    OwlNativeDateTimeModule, BsDatepickerModule.forRoot(),
    Ng4LoadingSpinnerModule.forRoot(),
    ColorPickerModule
  ],
  providers: [AuthGaurdService, AuthService, JwtService, ApiService, Cookie, CalendarService],
  bootstrap: [AppComponent]
})
export class AppModule { }
