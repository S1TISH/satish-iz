// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  //admin and app api callings
  //local
  //api_url: 'http://localhost:57085/IZONAdmin.svc/',

  //dev(devcp.izongolf.com)(db-izon)
  // api_url: 'http://localhost:49344/IZONAdmin.svc/',
  // api_url1:'http://iapi.azaz.com/IZON.svc/',
    
  //prod(cp.izongolf.com)(db-prodizon)
   api_url: 'http://adminapi.izongolf.com/IZONAdmin.svc/',
 // api_url: 'http://localhost:49344/IZONAdmin.svc/',
  api_url1:'http://api.izongolf.com/IZON.svc/',
  api_url_reach: 'https://reachadmin.izongolf.com/ReachService.svc/',
  production: true
};
