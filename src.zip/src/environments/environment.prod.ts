export const environment = {
  api_url: 'http://adminapi.izongolf.com/IZONAdmin.svc/',
  api_url1:'http://api.izongolf.com/IZON.svc/',
  api_url_reach: 'https://reachadmin.izongolf.com/ReachService.svc/',
  production: true
};
